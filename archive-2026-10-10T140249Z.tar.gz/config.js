const env = process.env;

const DEFAULT_IMAGE = 'https://files.catbox.moe/pvlrl1.jpg';

module.exports = {
  BOT_NAME: env.BOT_NAME || 'Rem',
  BOT_JID: env.BOT_JID || '@lid',
  OWNER_NAME: env.OWNER_NAME || '𓆩ᥫ𝐑𝐢𝐤𝐮𓆪',
  CREATOR_NAME: env.CREATOR_NAME || 'Riku',
  PREFIX: env.PREFIX || '.',

  MENU_IMAGE: 'https://files.catbox.moe/c8qh9i.jpeg',
  MOONLIGHT_IMAGE: env.MOONLIGHT_IMAGE || DEFAULT_IMAGE,

  SESSION_FOLDER: env.SESSION_FOLDER || './sessions',

  WEB: env.WEB || 'https://haven-moon.zone.id',
  FASTIVAL_GROUP: env.FASTIVAL_GROUP || '',
  COMMUNITY_LINK: env.COMMUNITY_LINK || '',
  RPG_LINK: env.RPG_LINK || '',
  POKEMON_LINK: env.POKEMON_LINK || '',
  POKEMON_LINK2: env.POKEMON_LINK2 || '',
  COMBAT: env.COMBAT || 'https://chat.whatsapp.com/DNyrXCpXv26AJ3sggoGEMq',
  CASINO_LINK1: env.CASINO_LINK1 || 'https://chat.whatsapp.com/LQvvVsiRDkq2BnbVOQD05s',
  CASINO_LINK2: env.CASINO_LINK2 || 'https://chat.whatsapp.com/LQvvVsiRDkq2BnbVOQD05s',
  DISCORD_LINK: env.DISCORD_LINK || '',
  CHATBOT_API_URL: env.CHATBOT_API_URL || 'https://api.openai.com/v1/chat/completions',
  CHATBOT_MODEL: env.CHATBOT_MODEL || 'gpt-4o-mini',
  CHATBOT_API_KEY: env.CHATBOT_API_KEY || env.OPENAI_API_KEY || '',

  TENOR_API_KEY: env.TENOR_API_KEY || '',
  REALMS_ENABLED: env.REALMS_ENABLED !== 'false',

  PANEL_API_BASE: env.PANEL_API_BASE || 'https://control.bot-hosting.net/api/client/servers',
  PANEL_API_TOKEN: env.PANEL_API_TOKEN || env.ACCESS_TOKEN || '',
};
