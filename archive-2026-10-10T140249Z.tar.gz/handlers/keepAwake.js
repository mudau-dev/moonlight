const config = require('../config');

let timer = null;

async function pingWeb() {
  const base = String(config.WEB || '').replace(/\/$/, '');
  if (!base) return;
  try {
    const response = await fetch(`${base}/`, { method: 'HEAD', signal: AbortSignal.timeout(10_000) });
    console.log(`[KEEP-AWAKE] Web ping ${response.status}`);
  } catch (error) {
    console.warn(`[KEEP-AWAKE] Web ping failed: ${error.message}`);
  }
}

function startKeepAwake() {
  if (timer) return;
  pingWeb();
  timer = setInterval(pingWeb, 4 * 60 * 1000);
  timer.unref?.();
}

module.exports = { startKeepAwake, pingWeb };
