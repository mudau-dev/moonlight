// handlers/Bot.js
// ─────────────────────────────────────────────────────────────────────────────
// Bot Utilities & Protection Handlers
// ─────────────────────────────────────────────────────────────────────────────
const config = require('../config');

// Track groups the bot intentionally joined
const intentionalJoins = new Set();

/**
 * Call this BEFORE sock.groupAcceptInvite(code)
 */
function markIntentionalJoin(groupJid) {
  intentionalJoins.add(groupJid);
  setTimeout(() => intentionalJoins.delete(groupJid), 60_000);
}

/**
 * Force-Add Protection Handler
 *
 * When someone adds the bot to a group without permission:
 * 1. Bot sends a message explaining why it's leaving
 * 2. Bot leaves the group
 * 3. The user who added the bot gets a PERMANENT SUSPENSION
 */
async function handleForceAdd(sock, update) {
  try {
    const { id: groupJid, participants, action, author } = update;
    if (action !== 'add') return;

    // Determine bot's JID
    const rawBotJid = sock.user?.id || '';
    const botJid    = rawBotJid.includes(':')
      ? rawBotJid.split(':')[0] + '@s.whatsapp.net'
      : rawBotJid;

    const botWasAdded = participants.some(p => {
      const norm = p.includes(':') ? p.split(':')[0] + '@s.whatsapp.net' : p;
      return norm === botJid;
    });

    if (!botWasAdded) return;

    // If this was an intentional join (via .join command), allow it
    if (intentionalJoins.has(groupJid)) {
      intentionalJoins.delete(groupJid);
      return;
    }

    const botName = config.BOT_NAME || 'Moonlight';

    // ── 1. Send leave message in group ────────────────────────────────────────
    const leaveMsg =
      `⛔ *${botName} cannot be added to groups without permission.*\n\n` +
      `This bot can only join groups using an invite link from an *Owner* or *Mod*.\n` +
      `If you want ${botName} in your group, ask an Owner/Mod to use the *.join <invite link>* command.\n\n` +
      `> The user who added this bot has been *permanently suspended*.`;

    try { await sock.sendMessage(groupJid, { text: leaveMsg }); } catch (_) {}

    // ── 2. Leave the group ────────────────────────────────────────────────────
    try { await sock.groupLeave(groupJid); } catch (_) {}

    // ── 3. Suspend the adder ──────────────────────────────────────────────────
    if (author) {
      const adderJid = author.includes(':') ? author.split(':')[0] + '@s.whatsapp.net' : author;
      const adderNumber = adderJid.split('@')[0];

      // Notify the adder via DM
      try {
        await sock.sendMessage(adderJid, {
          text:
            `⛔ *You have been permanently suspended.*\n\n` +
            `*Reason:* Adding ${botName} to a group without permission from Owners/Mods.\n\n` +
            `> Contact an Owner or Mod to appeal this suspension.`
        });
      } catch (_) {}

      // Apply permanent suspension in database
      try {
        const User = require('../models/User');
        const { findOrCreateWhatsApp } = require('../database/users');

        const adderDoc = await findOrCreateWhatsApp(adderJid, 'Unknown');
        if (adderDoc) {
          await User.updateOne(
            { _id: adderDoc._id },
            {
              $set: {
                suspended: true,
                suspendReason: `Added ${botName} to a group without permission`,
                suspendedBy: 'SYSTEM',
                suspendUntil: null, // null = permanent
              },
            }
          );
          console.log(`[FORCE-ADD] Suspended user: ${adderNumber}`);
        }
      } catch (suspendErr) {
        console.error('[FORCE-ADD SUSPEND ERROR]', suspendErr.message);
      }
    }
  } catch (err) {
    console.error('[FORCE-ADD HANDLER ERROR]', err);
  }
}

/**
 * Legacy compatibility hook.
 * Panel uploads are now authoritative; never fetch or pull from GitHub at runtime.
 */
function startAutoUpdate() {
  console.log('[DEPLOYMENT] Panel-managed mode enabled; GitHub auto-update is disabled.');
}

module.exports = { handleForceAdd, markIntentionalJoin, startAutoUpdate };
