const { delay } = require('../utils/baileys');
const readline = require('readline');

async function handlePairing(sock) {
  if (sock.authState?.creds?.registered || sock.user) return;
  if (global.__moonlightPairingInProgress) return;
  global.__moonlightPairingInProgress = true;
  console.log('\n✨ MOONLIGHT PAIRING SYSTEM ✨\n');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const number = await new Promise((resolve) => rl.question('Please enter your phone number (with country code, e.g., 27675859928): ', resolve));
    if (!number || number.trim().length < 8) {
      console.log('\n❌ Invalid number.\n');
      return;
    }
    const phoneNumber = number.replace(/[^0-9]/g, '');
    console.log(`\n⏳ Requesting pairing code for ${phoneNumber}...`);
    await delay(3000);
    const code = await sock.requestPairingCode(phoneNumber, 'MOONBOTS');
    const formattedCode = code?.match(/.{1,4}/g)?.join('-') || code;
    console.log(`\n✅ YOUR PAIRING CODE: \x1b[32m${formattedCode}\x1b[0m`);
    console.log('Enter this code on your WhatsApp (Linked devices > Link with phone number)\n');
  } catch (error) {
    console.error('\n❌ PAIRING FAILED:', error.message);
  } finally {
    rl.close();
    global.__moonlightPairingInProgress = false;
  }
}

module.exports = { handlePairing };
