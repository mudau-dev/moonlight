const KickRequest = require('../models/athers/KickRequest');
const System = require('../models/System');
const config = require('../config');
const { getBotIdentity, isParticipantAdminByIdentity, sameIdentity, phoneNumberFromValue } = require('../utils/adminIdentity');
const { getRealUserIdentity } = require('../utils/whatsappIdentity');

const COMMUNITY_CONFIG_KEY = 'communityKick:communities';
const MAX_COMMUNITIES = 5;
const EVALUATION_DELAY_MS = 7000;
const SETTLEMENT_GRACE_MS = 30 * 1000;
const POLL_INTERVAL_MS = 1000;
let managerTimer = null;
let activeSocket = null;
let tickRunning = false;

function normalizeCommunityJid(value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  if (/^\d+(?:-\d+)?@g\.us$/i.test(raw)) return raw;
  const digits = raw.replace(/[^0-9-]/g, '');
  return /^\d+(?:-\d+)?$/.test(digits) ? `${digits}@g.us` : null;
}

async function getConfiguredCommunities() {
  const configDoc = await System.findOne({ key: COMMUNITY_CONFIG_KEY }).lean();
  return [...new Set((Array.isArray(configDoc?.value) ? configDoc.value : []).map(normalizeCommunityJid).filter(Boolean))];
}

async function setConfiguredCommunities(communities) {
  const value = [...new Set(communities.map(normalizeCommunityJid).filter(Boolean))].slice(0, MAX_COMMUNITIES);
  await System.findOneAndUpdate(
    { key: COMMUNITY_CONFIG_KEY },
    { $set: { value, updatedAt: new Date() } },
    { upsert: true, new: true }
  );
  return value;
}

function botName() {
  return String(config.BOT_NAME || 'Unknown');
}

function participantFor(metadata, jid) {
  return (metadata?.participants || []).find((participant) => sameIdentity(participant, jid));
}

async function isBotAdmin(sock, metadata) {
  const participants = metadata?.participants || [];
  const candidates = [sock?.user?.id, sock?.user?.jid, sock?.user?.lid, getBotIdentity(sock, config), config.BOT_JID].filter(Boolean);
  for (const candidate of candidates) {
    if (isParticipantAdminByIdentity(participants, candidate)) return true;
    if (String(candidate).endsWith('@lid')) {
      try {
        const resolved = await getRealUserIdentity(sock, candidate, sock?.user?.jid || sock?.user?.phoneJid);
        if (resolved?.phoneJid && isParticipantAdminByIdentity(participants, resolved.phoneJid)) return true;
      } catch {}
    }
  }
  return false;
}

async function removeIfPresent(sock, groupJid, targetJid, scope) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    if (!(await isBotAdmin(sock, metadata))) {
      return { communityJid: scope.communityJid, groupJid, scope: scope.type, status: 'permission_denied' };
    }
    if (!participantFor(metadata, targetJid)) {
      return { communityJid: scope.communityJid, groupJid, scope: scope.type, status: 'absent' };
    }
    await sock.groupParticipantsUpdate(groupJid, [targetJid], 'remove');
    return { communityJid: scope.communityJid, groupJid, groupName: metadata.subject || groupJid, scope: scope.type, status: 'removed' };
  } catch (error) {
    const message = String(error?.message || 'Unknown WhatsApp error');
    const permissionDenied = /admin|not-authorized|not authorized|permission|forbidden/i.test(message);
    return {
      communityJid: scope.communityJid,
      groupJid,
      scope: scope.type,
      groupName: groupJid,
      status: permissionDenied ? 'permission_denied' : 'failed',
      error: message.slice(0, 180),
    };
  }
}

function linkedCommunityJid(group) {
  return group?.linkedParent || group?.linkedParentJid || group?.parentGroupJid || group?.parentJid || group?.communityJid || null;
}

async function relatedGroups(sock, communityJid) {
  try {
    const groups = await sock.groupFetchAllParticipating();
    return Object.entries(groups || {})
      .filter(([groupJid, group]) => groupJid !== communityJid && sameIdentity(linkedCommunityJid(group), communityJid))
      .map(([groupJid]) => groupJid);
  } catch (error) {
    console.warn('[COMMUNITY KICK] Could not list linked groups:', error.message);
    return [];
  }
}

async function enforceRequest(sock, request) {
  const details = [];
  for (const communityJid of request.communities || []) {
    details.push(await removeIfPresent(sock, communityJid, request.targetJid, { type: 'community', communityJid }));
    const groups = await relatedGroups(sock, communityJid);
    for (const groupJid of groups) {
      details.push(await removeIfPresent(sock, groupJid, request.targetJid, { type: 'group', communityJid }));
    }
  }
  const hasPermissionFailure = details.some((detail) => detail.status === 'permission_denied');
  const hasFailure = details.some((detail) => detail.status === 'failed');
  const success = details.length > 0 && !hasPermissionFailure && !hasFailure;
  return { details, status: success ? 'success' : (hasPermissionFailure ? 'permission_denied' : 'failed') };
}

async function claimAndProcess(sock, request) {
  const name = botName();
  const claimed = await KickRequest.findOneAndUpdate(
    { _id: request._id, 'results.botName': { $ne: name } },
    { $push: { results: { botName: name, status: 'processing', details: [] } }, $set: { status: 'processing' } },
    { new: true }
  );
  if (!claimed) return;

  let outcome;
  try {
    outcome = await enforceRequest(sock, claimed);
  } catch (error) {
    outcome = { status: 'failed', details: [{ scope: 'community', status: 'failed', error: String(error?.message || error).slice(0, 180) }] };
  }

  await KickRequest.updateOne(
    { _id: request._id, 'results.botName': name, 'results.status': 'processing' },
    { $set: { 'results.$.status': outcome.status, 'results.$.details': outcome.details, 'results.$.completedAt': new Date() } }
  );
  await updateProgress(sock, request._id).catch(() => {});
}

async function updateProgress(sock, requestId) {
  const request = await KickRequest.findById(requestId).lean();
  if (!request?.progressKey || (request.progressBotName && String(request.progressBotName).toLowerCase() !== botName().toLowerCase())) return;
  const completed = (request.results || []).filter((result) => result.status !== 'processing');
  const unique = [...new Map(completed.map((result) => [String(result.botName).toLowerCase(), result])).values()];
  const latest = unique[unique.length - 1];
  const lines = [`> kicking user from all community's groups`, `${unique.length}. *${latest?.botName || botName()}*`];
  const detail = latest?.details?.find((item) => item.status === 'removed');
  if (detail) lines.push(`kicked in *${detail.groupName || detail.groupJid}*`);
  else if (completed.length) lines.push(completed[completed.length - 1].status === 'permission_denied' ? 'could not kick: bot is not an admin' : 'checked configured communities');
  await sock.sendMessage(request.responseJid, { text: lines.join('\n') }, { edit: request.progressKey });
}

async function evaluateRequest(sock, request) {
  const fresh = await KickRequest.findById(request._id).lean();
  if (!fresh || fresh.completedAt || new Date(fresh.evaluationAt).getTime() > Date.now()) return;
  if (fresh.progressBotName && String(fresh.progressBotName).toLowerCase() !== botName().toLowerCase()) return;
  const results = fresh.results || [];
  if (results.some((result) => result.status === 'processing')) return;
  if (!results.length && Date.now() < new Date(fresh.evaluationAt).getTime() + SETTLEMENT_GRACE_MS) return;
  const successful = results.find((result) => result.status === 'success');
  const permissionFailure = results.some((result) => result.status === 'permission_denied' || result.details?.some((detail) => detail.status === 'permission_denied'));

  let text;
  if (successful) {
    const kickedDetails = results.flatMap((result) => (result.details || [])
      .filter((detail) => detail.status === 'removed')
      .map((detail) => `${result.botName} → ${detail.groupName || detail.groupJid}`));
    text = [
      `user kicked out of all groups and out of the community by *${successful.botName}*`,
      '',
      `*Bot(s) that kicked the user:* ${[...new Set(results.filter((result) => result.details?.some((detail) => detail.status === 'removed')).map((result) => result.botName))].join(', ') || successful.botName}`,
      kickedDetails.length ? `*Community groups:*\n${kickedDetails.map((item) => `• ${item}`).join('\n')}` : '',
    ].filter(Boolean).join('\n');
  } else if (permissionFailure) {
    text = '> I tried kicking the user, but neither I nor the other bots is an admin in the community\'s admin list.';
  } else {
    text = '> I could not confirm that the user was removed from every configured community.';
  }

  const completed = await KickRequest.findOneAndUpdate(
    { _id: fresh._id, completedAt: { $exists: false } },
    { $set: { status: successful ? 'completed' : 'failed', completedAt: new Date(), activeKey: null } },
    { new: true }
  );
  if (completed) {
    if (completed.progressKey) {
      const heading = successful ? '> user has been kicked in all groups and communities' : '> community kick finished';
      await sock.sendMessage(completed.responseJid, { text: `${heading}\n\n${text}` }, { edit: completed.progressKey }).catch(() => {});
    }
    else await sock.sendMessage(completed.responseJid, { text }, {}).catch(() => {});
  }
}

async function processRequests(sock) {
  if (tickRunning) return;
  tickRunning = true;
  try {
    const now = new Date();
    const requests = await KickRequest.find({
      completedAt: { $exists: false },
      status: { $in: ['pending', 'processing'] },
    }).sort({ createdAt: 1 }).limit(20).lean();

    for (const request of requests) {
      if (new Date(request.evaluationAt).getTime() > now.getTime()) claimAndProcess(sock, request).catch((error) => console.error('[COMMUNITY KICK]', error));
      else await evaluateRequest(sock, request);
    }
  } catch (error) {
    console.error('[COMMUNITY MANAGER]', error.message);
  } finally {
    tickRunning = false;
  }
}

function startCommunityManager(sock) {
  activeSocket = sock;
  if (managerTimer) return;
  managerTimer = setInterval(() => { processRequests(activeSocket).catch(() => {}); processCommunityScanRequests(activeSocket).catch(() => {}); }, POLL_INTERVAL_MS);
  processRequests(activeSocket).catch(() => {});
  processCommunityScanRequests(activeSocket).catch(() => {});
}

async function createKickRequest({ targetJid, requesterJid, responseJid }) {
  const communities = await getConfiguredCommunities();
  if (!communities.length) return { request: null, reason: 'no_communities' };
  const activeKey = targetJid;
  try {
    const request = await KickRequest.create({
      activeKey,
      targetJid,
      requesterJid,
      responseJid,
      communities,
      evaluationAt: new Date(Date.now() + EVALUATION_DELAY_MS),
    });
    if (activeSocket) processRequests(activeSocket).catch(() => {});
    return { request, created: true };
  } catch (error) {
    if (error?.code === 11000) {
      const request = await KickRequest.findOne({ activeKey }).lean();
      return { request, created: false, reason: 'duplicate' };
    }
    throw error;
  }
}

const SCAN_PREFIX = 'communityKickScan:';
const EXPECTED_SCAN_BOTS = new Set(['rem', 'frieren', 'rimuru', 'saber', 'cid', 'kurumi']);
function scanKey(id) { return `${SCAN_PREFIX}${id}`; }
function scanMemberKey(value) { return phoneNumberFromValue(value) || String(value || '').split(':')[0].toLowerCase(); }
function groupCommunityId(group) { return group?.linkedParent || group?.linkedParentJid || group?.parentGroupJid || group?.parentJid || group?.communityJid || null; }
async function liveScanForBot(sock, communityJid) {
  const community = await sock.groupMetadata(communityJid);
  const all = await sock.groupFetchAllParticipating();
  const linked = Object.values(all || {}).filter((group) => group?.id && group.id !== communityJid && sameIdentity(groupCommunityId(group), communityJid));
  const members = new Set();
  for (const group of linked) for (const participant of group.participants || []) {
    const id = participant.id || participant.jid || participant.lid;
    if (id) members.add(scanMemberKey(id));
  }
  return {
    botName: botName(),
    communityMembers: (community.participants || []).map((participant) => participant.id || participant.jid || participant.lid).filter(Boolean),
    linkedGroups: linked.map((group) => ({ id: group.id, subject: group.subject || group.id, count: (group.participants || []).length })),
    groupMembers: [...members],
    checkedAt: new Date(),
  };
}
async function processCommunityScanRequests(sock) {
  try {
    const requests = await System.find({ key: new RegExp(`^${SCAN_PREFIX}`) }).limit(20).lean();
    for (const row of requests) {
      const data = row.value || {};
      if (data.status === 'ready' || data.status === 'completed' || data.expiresAt && new Date(data.expiresAt).getTime() < Date.now()) continue;
      const name = botName().toLowerCase();
      if ((data.results || []).some((result) => String(result.botName).toLowerCase() === name)) continue;
      let result;
      try { result = await liveScanForBot(sock, data.communityJid); }
      catch (error) { result = { botName: botName(), error: String(error?.message || error).slice(0, 180), communityMembers: [], linkedGroups: [], groupMembers: [], checkedAt: new Date() }; }
      await System.updateOne({ _id: row._id, 'value.results.botName': { $ne: botName() } }, { $push: { 'value.results': result } });
      const fresh = await System.findById(row._id).lean();
      const results = fresh?.value?.results || [];
      const age = Date.now() - new Date(fresh?.value?.createdAt || data.createdAt || Date.now()).getTime();
      const names = new Set(results.map((item) => String(item.botName || '').toLowerCase()));
      if (age < 6000 || results.length < 1) continue;
      if (age < 10000 && results.length < 3) continue;
      const communityMembers = results.find((item) => item.communityMembers?.length)?.communityMembers || [];
      const groupMembers = new Set(results.flatMap((item) => item.groupMembers || []));
      const candidates = communityMembers.filter((member) => !groupMembers.has(scanMemberKey(member)) && scanMemberKey(member) !== scanMemberKey(getBotIdentity(sock, config))).slice(0, Number(data.amount) || 1000);
      const updated = await System.findOneAndUpdate({ _id: row._id, 'value.status': { $nin: ['ready', 'completed'] } }, { $set: { 'value.status': 'ready', 'value.candidates': candidates, 'value.checkedBots': [...names], 'value.completedAt': new Date(), 'value.reportedAt': new Date() } }, { new: true }).lean();
      if (updated) {
        const checked = [...names].map((item) => item[0].toUpperCase() + item.slice(1)).join(', ');
        await sock.sendMessage(data.responseJid, { text: `🔎 *COMMUNITY LIVE SCAN COMPLETE*\n\nChecked bots: *${checked}*\nLinked-group members were collected from each responding bot.\n\nMembers found in the community but in none of the linked groups: *${candidates.length}*\n\nNo one was removed. Review the result, then send *.kickc confirm* to continue.` }).catch(() => {});
      }
    }
  } catch (error) { console.error('[COMMUNITY LIVE SCAN]', error.message); }
}

module.exports = {
  COMMUNITY_CONFIG_KEY,
  MAX_COMMUNITIES,
  normalizeCommunityJid,
  getConfiguredCommunities,
  setConfiguredCommunities,
  createKickRequest,
  startCommunityManager,
  processRequests,
  processCommunityScanRequests,
  scanKey,
};
