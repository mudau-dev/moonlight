module.exports = {
  // Command prefix used across the bot. Many commands assume '.' in examples.
  PREFIX: ".",

  // Basic metadata — set these to match your bot/environment
  BOT_NAME: "Moonlight",
  BOT_JID: "",

  OWNER_NAME: "kaizel",
  MENU_IMAGE: "https://files.catbox.moe/gim8wi.jpeg",
  MOONLIGHT_IMAGE: "https://files.catbox.moe/gim8wi.jpeg",
  SESSION_FOLDER: "./sessions",

  WEB: require('../config').WEB,

  FASTIVAL_GROUP: "https://chat.whatsapp.com/I2QG7U5CeofIqZnj35rs2u",
  COMMUNITY_LINK: "https://chat.whatsapp.com/I02K7SZKD9hAoY7AmAxMNE",
  RPG_LINK: "https://chat.whatsapp.com/JwQGQLcV95ZJjtoL52j85R",
  CASINO_LINK1: "https://chat.whatsapp.com/KTVKqpZAQeP3GsyCN8z69w",
  CASINO_LINK2: "https://chat.whatsapp.com/G6WNUFs3IAOKf2YVvdNPQr",
  DISCORD_LINK: "https://discord.gg/KUzsCHp9WG",
};