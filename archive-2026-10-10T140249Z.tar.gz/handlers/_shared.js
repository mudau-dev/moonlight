const config = require('../config');
const { findOrCreateWhatsApp } = require('../database/users');
const botModeCache = new Map();
const BOT_MODE_CACHE_TTL_MS = 30 * 1000;
const gamblingGroupCache = new Map();
const GAMBLING_CACHE_TTL_MS = 15 * 1000;

function mentionTag(jid) { return `@${jid.split('@')[0]}`; }
function jidToNumber(jid) { return jid.split('@')[0]; }

function formatTime(ms) {
  if (!ms || ms <= 0) return '0s';
  const totalSeconds = Math.floor(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const parts = [];
  if (h > 0) parts.push(`${h}h`);
  if (m > 0) parts.push(`${m}m`);
  if (s > 0 || parts.length === 0) parts.push(`${s}s`);
  return parts.join(' ');
}

function formatDate(date) {
  const d = date instanceof Date ? date : new Date(date);
  return d.toLocaleDateString('en-US', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
}

const OWNER_ROLES = ['Owner', 'True Owner', 'Mod', 'CDC'];
async function isOwner(senderJid) {
  try {
    const user = await findOrCreateWhatsApp(senderJid);
    return Boolean(user && (OWNER_ROLES.includes(user.role) || user.isTrueOwner === true || user.isCDC === true));
  } catch { return false; }
}
async function getUserRole(senderJid) {
  try {
    const user = await findOrCreateWhatsApp(senderJid);
    return user?.isTrueOwner === true ? 'True Owner' : (user?.role || 'User');
  } catch { return 'User'; }
}

async function isGroupAllowed(groupJid) {
  try {
    const Group = require('../models/athers/Group');
    return (await Group.findOne({ groupId: groupJid }))?.eventEnabled === true;
  } catch { return false; }
}
async function isGamblingGroup(groupJid) {
  const cached = gamblingGroupCache.get(groupJid);
  if (cached && cached.expiresAt > Date.now()) return cached.value;
  try {
    const Group = require('../models/athers/Group');
    const value = (await Group.findOne({ groupId: groupJid }).select('gamblingEnabled').lean())?.gamblingEnabled === true;
    gamblingGroupCache.set(groupJid, { value, expiresAt: Date.now() + GAMBLING_CACHE_TTL_MS });
    return value;
  } catch { return false; }
}
async function checkGamblingAllowed(groupJid) {
  if (await isGamblingGroup(groupJid)) return null;
  return [
    '> You cant *gamble* here join the *following groups* in order to use *gambling commands* 🎰',
    '',
    '> 𝐌𝐨𝐨𝐧𝐥𝐢𝐠𝐡𝐭 *gambling - l*',
    config.CASINO_LINK1 || 'Casino link 1 is not configured.',
    '> 𝐌𝐨𝐨𝐧𝐥𝐢𝐠𝐡𝐭 *gambling - ll*',
    config.CASINO_LINK2 || 'Casino link 2 is not configured.',
    '',
    '> Fore more fun and higher prizes and giveaways join our discord server',
    `> *Link:* ${config.DISCORD_LINK || 'Discord link is not configured.'}`,
  ].join('\n');
}

// Avoid a user lookup for every ordinary command. User data is only required when
// staff-only or group-disabled mode is actually enabled.
async function isBotActive(sock, jid, sender) {
  const config = require('../config');
  const Bot = require('../models/athers/Bot');
  const GroupSettings = require('../models/athers/GroupSettings');
  const botName = (config.BOT_NAME || 'Rem').toLowerCase();
  let botData = botModeCache.get(botName);
  if (!botData || botData.expiresAt <= Date.now()) {
    const promise = Bot.findOne({ name: botName }).lean().catch(() => null);
    botModeCache.set(botName, { promise, expiresAt: Date.now() + BOT_MODE_CACHE_TTL_MS });
    // Ordinary commands should not wait on the first mode lookup. The next
    // command uses the resolved value, while staff-only mode remains enforced
    // as soon as the cache has been populated.
    promise.then((value) => botModeCache.set(botName, { value, expiresAt: Date.now() + BOT_MODE_CACHE_TTL_MS })).catch(() => {});
    botData = null;
  } else if (botData.promise) {
    botData = await botData.promise;
  } else {
    botData = botData.value;
  }
  const group = jid.endsWith('@g.us') ? GroupSettings.getGroup(jid) : null;
  const needsStaffCheck = Boolean(botData?.staffOnlyMode || group?.botEnabled === false);
  if (!needsStaffCheck) return true;
  return isOwner(sender);
}

function getMessageText(m) {
  return m.message?.conversation || m.message?.extendedTextMessage?.text || m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || '';
}
async function sendMention(sock, jid, senderJid, text, extra = {}) {
  return sock.sendMessage(jid, { text, mentions: [senderJid], ...extra });
}
function formatNumber(n) { return Number(n || 0).toLocaleString('en-US'); }
function clamp(value, min, max) { return Math.min(Math.max(value, min), max); }

module.exports = {
  mentionTag, jidToNumber, formatTime, formatDate, isOwner, getUserRole, OWNER_ROLES,
  isGroupAllowed, isGamblingGroup, checkGamblingAllowed, isBotActive, getMessageText,
  sendMention, formatNumber, clamp,
};
