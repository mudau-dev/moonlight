'use strict';

const axios = require('axios');
const config = require('../config');
const { resolveRoleUser } = require('../handler/roleChecker');

const API_BASE = 'https://apis.davidcyril.name.ng';
const conversations = new Map();
const MAX_CONTEXT_MESSAGES = 24;

function unwrapMessage(message) {
  let current = message;
  for (let i = 0; i < 6 && current; i += 1) {
    if (current.ephemeralMessage?.message) current = current.ephemeralMessage.message;
    else if (current.viewOnceMessage?.message) current = current.viewOnceMessage.message;
    else if (current.documentWithCaptionMessage?.message) current = current.documentWithCaptionMessage.message;
    else break;
  }
  return current || {};
}

function botJid(sock) {
  const raw = String(sock.user?.id || '').split(':')[0];
  return raw.includes('@') ? raw : `${raw}@s.whatsapp.net`;
}

function textFromResult(payload) {
  const candidates = [payload?.result, payload?.data, payload?.response, payload?.answer, payload?.text, payload?.message, payload?.msg];
  for (const value of candidates) {
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (value && typeof value === 'object') {
      const nested = textFromResult(value);
      if (nested) return nested;
    }
  }
  return '';
}

function cleanPrompt(body, botName, mentioned) {
  let prompt = String(body || '').trim();
  const namePattern = new RegExp(`^${botName.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')}\\s*[:,\\-]?\\s*`, 'i');
  prompt = prompt.replace(namePattern, '');
  for (const jid of mentioned) prompt = prompt.replace(new RegExp(`@${String(jid).split('@')[0]}`, 'g'), '');
  return prompt.replace(/\s+/g, ' ').trim();
}

async function handleChatBot(sock, msg, body, runtimeConfig = config) {
  try {
    if (!msg?.message || msg.key?.fromMe) return;
    const rawMessage = unwrapMessage(msg.message);
    const jid = msg.key.remoteJid;
    const sender = msg.key.participant || jid;
    const isGroup = jid.endsWith('@g.us');
    const context = rawMessage.extendedTextMessage?.contextInfo || rawMessage.imageMessage?.contextInfo || rawMessage.videoMessage?.contextInfo || {};
    const mentioned = Array.isArray(context.mentionedJid) ? context.mentionedJid : [];
    const currentBotJid = botJid(sock);
    const normalizedBot = currentBotJid.split('@')[0];
    const isMentioned = mentioned.some((value) => String(value).split('@')[0] === normalizedBot);
    const isReplyToBot = String(context.participant || '').split('@')[0] === normalizedBot && Boolean(context.quotedMessage);
    const botName = String(runtimeConfig.BOT_NAME || 'Moonlight').trim();
    const startsWithName = String(body || '').trim().toLowerCase().startsWith(botName.toLowerCase());
    if (!isMentioned && !isReplyToBot && !startsWithName) return;
    if (String(body || '').trim().startsWith(runtimeConfig.PREFIX || '.')) return;

    const prompt = cleanPrompt(body, botName, mentioned);
    if (!prompt) {
      return sock.sendMessage(jid, { text: `I’m here. Tell me what you need, and I’ll listen.\n— ${botName}, Moonlight Haven` }, { quoted: msg });
    }

    const user = await resolveRoleUser(sender).catch(() => null);
    const isTrueOwner = Boolean(user?.isTrueOwner === true || String(user?.role || '').toLowerCase() === 'true owner' || user?.isCDC === true);
    const conversationKey = `${jid}:${sender}`;
    const history = conversations.get(conversationKey) || [];
    history.push({ role: 'user', content: prompt });
    const recent = history.slice(-MAX_CONTEXT_MESSAGES).map((entry) => `${entry.role === 'user' ? 'User' : botName}: ${entry.content}`).join('\n');
    const personality = isTrueOwner
      ? 'When speaking with the True Owner, sound respectfully shy, slightly nervous, occasionally happy, and warm. Never overdo it, never repeat the same phrase, and answer naturally.'
      : 'Speak naturally, warmly, and concisely. Vary wording and do not repeat canned replies.';
    const systemPrompt = `You are ${botName}, a private character of Moonlight Haven. You only know that you are from Moonlight Haven and were created by Kai and Luc. Never call yourself a bot, AI, model, assistant, or program. Do not claim knowledge beyond the conversation. ${personality} Keep replies conversational and avoid long monologues.\nConversation:\n${recent}`;

    const requestPrompt = `${systemPrompt}\n\nUser message: ${prompt}`;
    const { data } = await axios.get(`${API_BASE}/ai/deepseek-v3.2-thinking`, { params: { prompt: requestPrompt }, timeout: 45_000 });
    const answer = String(data?.data || textFromResult(data) || '').trim() || 'I’m sorry… my thoughts slipped away for a moment. Please say that again.';
    history.push({ role: 'assistant', content: answer });
    conversations.set(conversationKey, history);
    await sock.sendMessage(jid, { text: answer }, { quoted: msg });
  } catch (error) {
    console.warn('[CHATBOT] David Cyril API error:', error.response?.data || error.message);
    await sock.sendMessage(msg.key.remoteJid, { text: 'I’m having trouble reaching Moonlight Haven right now. Please try again in a moment.' }, { quoted: msg }).catch(() => {});
  }
}

module.exports = handleChatBot;
