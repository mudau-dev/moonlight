const GroupSettings = require('../models/athers/GroupSettings');
const { suspendUser } = require('../utils/modTools');
const { checkUserRole } = require('./roleChecker');

const DEFAULT_WELCOME = `■-------□-☆-☆-□--------■
hello @user welcome to *@gname*
have fun and make friends

*useful tips you can use:*
1. ".rules" to get our rules
2. ".reg" to register
3. ".support" for our link
4. ".menu" to see my cmds
■-------□-☆-☆-□--------■
> you are the @count member in our group
@p`;
const DEFAULT_LEAVE = `■-------□-☆-☆-□--------■
😢 @user has left *@gname*
> the group now has @count members
■-------□-☆-☆-□--------■`;

function enabled(value, fallback = true) {
  if (value === undefined || value === null) return fallback;
  return value === true || value === 'true' || value === 'on' || value === 1;
}

module.exports = async function handleGroupEvents(sock, update) {
  try {
    const { id, participants: rawParticipants = [], action } = update || {};
    const participants = rawParticipants.map((entry) => typeof entry === 'string' ? entry : (entry?.id || entry?.jid || entry?.participant)).filter(Boolean);
    if (!id || !id.endsWith('@g.us') || !participants.length) return;
    const group = GroupSettings.getGroup(id) || {};
    const metadata = await sock.groupMetadata(id).catch(() => ({ subject: id.split('@')[0], participants: [] }));

    if (action === 'add') {
      const botId = `${String(sock.user?.id || '').split(':')[0]}@s.whatsapp.net`;
      if (participants.includes(botId) && update.author) {
        const { allowed } = await checkUserRole(update.author, ['Mod', 'Owner', 'True Owner', 'CDC']);
        if (!allowed) {
          await suspendUser(update.author, 25 * 60 * 60 * 1000, 'Added bot to group without permission', 'system');
          await sock.sendMessage(id, { text: `⚠️ @${update.author.split('@')[0]} is not authorized to add this bot. Leaving now.`, mentions: [update.author] }).catch(() => {});
          return sock.groupLeave(id);
        }
      }
    }

    const nestedWelcome = group.welcome || {};
    const nestedLeave = group.leave || {};
    const welcomeEnabled = enabled(nestedWelcome.enabled, false) || enabled(group.welcomeEnabled, true);
    const leaveEnabled = enabled(nestedLeave.enabled, false) || enabled(group.leaveEnabled, true);
    const welcomeMessage = String(nestedWelcome.message || group.welcomeMessage || DEFAULT_WELCOME).trim();
    const leaveMessage = String(nestedLeave.message || group.leaveMessage || DEFAULT_LEAVE).trim();

    for (const userJid of participants) {
      const isJoin = action === 'add';
      const isLeave = action === 'remove';
      if ((isJoin && !welcomeEnabled) || (isLeave && !leaveEnabled) || (!isJoin && !isLeave)) continue;
      const botBase = String(sock.user?.id || '').split(':')[0];
      const userBase = String(userJid).split('@')[0].split(':')[0];
      if (isJoin && botBase && userBase === botBase) continue;
      const userNumber = String(userJid).split('@')[0];
      const mentionTag = `@${userNumber}`;
      const template = isJoin ? welcomeMessage : leaveMessage;
      const wantsProfilePic = template.includes('@p');
      const text = template.replace(/@user/g, mentionTag).replace(/@gname/g, metadata.subject || id.split('@')[0]).replace(/@count/g, String(metadata.participants?.length || 0)).replace(/@p/g, '').trim();
      const payload = { mentions: [userJid] };
      if (wantsProfilePic) {
        try {
          const pp = await sock.profilePictureUrl(userJid, 'image');
          await sock.sendMessage(id, { image: { url: pp }, caption: text, ...payload });
          continue;
        } catch {}
      }
      await sock.sendMessage(id, { text, ...payload });
    }
  } catch (error) {
    console.error('[GROUP EVENT ERROR]', error);
  }
};

module.exports.DEFAULT_WELCOME = DEFAULT_WELCOME;
module.exports.DEFAULT_LEAVE = DEFAULT_LEAVE;
