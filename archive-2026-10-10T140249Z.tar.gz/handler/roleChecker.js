const User = require('../models/User');
const roleCache = new Map();
const ROLE_CACHE_TTL_MS = 30000;

const ROLE_HIERARCHY = {
  User: 0,
  Tester: 1,
  Mod: 2,
  Guardian: 2,
  Owner: 3,
  'True Owner': 4,
  CDC: 4,
};

async function resolveRoleUser(sender) {
  const value = String(sender || '');
  if (!value || value.endsWith('@lid')) return null;
  const digits = value.replace(/[^0-9]/g, '');
  const candidates = [
    { whatsappNumber: value },
    ...(digits ? [{ phoneNumber: digits }, { userId: digits }, { moonId: digits }, { whatsappNumber: digits }] : []),
  ];
  const key = value.toLowerCase();
  const cached = roleCache.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.user;
  const user = await User.findOne({ $or: candidates }).lean();
  roleCache.set(key, { user, expiresAt: Date.now() + ROLE_CACHE_TTL_MS });
  return user;
}

async function checkUserRole(sender, requiredRoles) {
  if (!requiredRoles || requiredRoles.length === 0) return { allowed: true };

  try {
    const user = await resolveRoleUser(sender);
    if (!user) return { allowed: false, message: '❌ User identity could not be resolved by phone number.' };

    let userRole = user.isTrueOwner === true ? 'True Owner' : (user.role || 'User');
    if (userRole.toLowerCase() === 'mod') userRole = 'Mod';
    if (userRole.toLowerCase() === 'owner') userRole = 'Owner';
    if (userRole.toLowerCase() === 'true owner') userRole = 'True Owner';

    if (user.isTrueOwner === true || user.isCDC === true || userRole === 'True Owner' || userRole === 'CDC') {
      return { allowed: true, user };
    }

    const userLevel = ROLE_HIERARCHY[userRole] ?? 0;
    const requiredLevels = requiredRoles.map((role) => ROLE_HIERARCHY[role] ?? 4);
    const minimumRequired = Math.min(...requiredLevels);
    if (userLevel >= minimumRequired) return { allowed: true, user };

    return { allowed: false, message: "❌ You do not have permission to use this command." };
  } catch (err) {
    console.error('[ROLE CHECK ERROR]', err);
    return { allowed: false, message: '❌ Internal permission error.' };
  }
}

module.exports = { checkUserRole, resolveRoleUser };
