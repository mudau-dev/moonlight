const fs = require('node:fs');
const path = require('node:path');
const { findOrCreateWhatsApp } = require('../database/users');
const { getRealUserIdentity } = require('../utils/whatsappIdentity');
const config = require('../config');
const System = require('../models/System');

const STICKER_EXTENSIONS = new Set(['.webp', '.png', '.jpg', '.jpeg', '.gif']);

function stickerFiles() {
  const roots = [
    path.join(process.cwd(), 'stickers'),
    path.join(process.cwd(), 'sticker'),
    path.join(process.cwd(), 'media', 'stickers'),
    path.join(process.cwd(), 'assets', 'stickers'),
    '/home/container/stickers',
    '/home/container/sticker',
    '/home/container/media/stickers',
  ];
  const found = [];
  for (const root of roots) {
    if (!fs.existsSync(root)) continue;
    for (const name of fs.readdirSync(root)) {
      const file = path.join(root, name);
      try {
        if (fs.statSync(file).isFile() && STICKER_EXTENSIONS.has(path.extname(name).toLowerCase())) found.push(file);
      } catch {}
    }
  }
  return [...new Set(found)];
}

function randomItem(items) {
  return items[Math.floor(Math.random() * items.length)];
}

async function sendRandomSticker(sock, jid, m) {
  const files = stickerFiles();
  if (files.length) {
    await sock.sendMessage(jid, { sticker: fs.readFileSync(randomItem(files)) }, { quoted: m });
    return true;
  }
  return false;
}

function isBotTrigger(sock, body, mentioned) {
  const botNumber = String(sock.user?.id || '').split(':')[0];
  const botJid = `${botNumber}@s.whatsapp.net`;
  const mentionedBot = mentioned.some((value) => value === botJid || value.split('@')[0] === botNumber);
  const escapedName = String(config.BOT_NAME || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return mentionedBot || (escapedName && new RegExp(`\\b${escapedName}\\b`, 'i').test(body));
}

async function handleOwnerTag(sock, m, body = '') {
  try {
    const jid = m.key.remoteJid;
    const sender = m.key.participant || m.key.remoteJid;
    const msg = m.message?.extendedTextMessage || m.message?.imageMessage || m.message?.videoMessage || m.message?.conversation || m.message;
    if (!msg) return;
    const mentions = msg.contextInfo?.mentionedJid || [];

    // Bot mentions belong to the chatbot. Do not send a sticker here and
    // return, because this handler runs before handler/ChatBot.js and would
    // otherwise swallow the user's message before the text response exists.
    if (isBotTrigger(sock, body, mentions)) return false;

    if (!mentions.length) return;
    for (const target of mentions) {
      if (target === sender) continue;
      const resolved = await getRealUserIdentity(sock, target).catch(() => null);
      const lookupJid = resolved?.phoneJid || target;
      const userDoc = await findOrCreateWhatsApp(lookupJid, undefined, true);
      if (!userDoc) continue;
      const user = userDoc.toObject ? userDoc.toObject() : userDoc;
      const isOwner = user.isTrueOwner === true || ['True Owner', 'Owner'].includes(user.role);
      if (!isOwner) continue;

      const ownerDigits = String(lookupJid || user.whatsappNumber || user.phoneNumber || user.userId || target).replace(/\D/g, '');
      const setting = await System.findOne({ key: `dtag:${ownerDigits}` }).lean();
      const value = setting?.value || {};
      if (!value.enabled) continue;
      const mentionsOut = [sender];
      const tagText = value.responseText;
      if (value.type === 'sticker' && value.data) {
        await sock.sendMessage(jid, { sticker: Buffer.from(value.data, 'base64') }, { quoted: m });
      } else if (value.type === 'video' && value.url) {
        await sock.sendMessage(jid, { video: { url: value.url }, caption: tagText || '', mentions: mentionsOut }, { quoted: m });
      } else if (value.type === 'text' && tagText) {
        await sock.sendMessage(jid, { text: tagText, mentions: mentionsOut }, { quoted: m });
      }
      return;
    }
  } catch (err) {
    console.error('[OWNER TAG ERROR]', err);
  }
}

module.exports = handleOwnerTag;
module.exports.sendRandomSticker = sendRandomSticker;
