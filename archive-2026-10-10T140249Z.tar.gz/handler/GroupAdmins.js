const { isParticipantAdminByIdentity } = require('../utils/adminIdentity');
const { getRealUserIdentity } = require('../utils/whatsappIdentity');
const { getGroup, updateGroup } = require('../models/athers/GroupSettings');
const { isMuted } = require('../utils/muteStore');
const { checkSuspension } = require('../utils/modTools');
const User = require('../models/User');
const System = require('../models/System');
const axios = require('axios');

function updateWarn(group, userId) {
  if (!group.antilink) group.antilink = {};
  if (!group.antilink.warns) group.antilink.warns = {};
  const current = group.antilink.warns[userId] || 0;
  group.antilink.warns[userId] = current + 1;
  updateGroup(group.groupId || '', group);
  return group.antilink.warns[userId];
}

function resetWarn(group, userId) {
  if (!group.antilink?.warns) return;
  group.antilink.warns[userId] = 0;
  updateGroup(group.groupId || '', group);
}

function updateGproWarn(group, userId) {
  if (!group.antigpro) group.antigpro = {};
  if (!group.antigpro.warns) group.antigpro.warns = {};
  group.antigpro.warns[userId] = Number(group.antigpro.warns[userId] || 0) + 1;
  updateGroup(group.groupId || '', group);
  return group.antigpro.warns[userId];
}

function isGroupProfileStatus(message) {
  const serialized = JSON.stringify(message?.message || {});
  if (serialized.includes('status@broadcast')) return true;
  let current = message?.message;
  for (let depth = 0; depth < 4 && current; depth += 1) {
    const context = current.extendedTextMessage?.contextInfo
      || current.imageMessage?.contextInfo
      || current.videoMessage?.contextInfo
      || current.documentMessage?.contextInfo
      || current.stickerMessage?.contextInfo;
    if (context?.remoteJid === 'status@broadcast' || current.groupStatusMentionMessage || current.statusMentionMessage) return true;
    current = current.ephemeralMessage?.message || current.viewOnceMessage?.message || null;
  }
  return false;
}

function containsLink(text = '') {
  return /https?:\/\/|www\.|chat\.whatsapp\.com|t\.me\/|discord\.gg\//i.test(text);
}

function mentionText(jid) {
  return `@${jid.split('@')[0]}`;
}

const rapidLinkHits = new Map();

async function safeDelete(sock, m) {
  try {
    await sock.sendMessage(m.key.remoteJid, { delete: m.key });
  } catch (error) {
    console.error('[DELETE ERROR]', error.message);
  }
}

async function handleOwnerTag(sock, m, jid, mentionedJid) {
  const setting = await System.findOne({ key: 'dtag' }).lean();
  if (!setting?.value?.enabled || !mentionedJid.length) return false;

  const resolvedMentions = (await Promise.all(mentionedJid.map(async (value) => {
    const identity = await getRealUserIdentity(sock, value).catch(() => null);
    return identity?.phoneJid || value;
  }))).filter(Boolean);
  const numbers = resolvedMentions.map((value) => value.split('@')[0]);
  const owner = await User.findOne({
    $and: [
      { $or: [
        { whatsappNumber: { $in: resolvedMentions } },
        { phoneNumber: { $in: numbers } },
        { userId: { $in: numbers } },
      ] },
      { $or: [{ isTrueOwner: true }, { role: { $in: ['True Owner', 'Owner'] } }] },
    ],
  }).lean();

  if (!owner) return false;
  const responseText = setting.value.responseText || owner.ownerTagText || '> Please do not tag the owners here.';
  const mentions = [m.key.participant || m.key.remoteJid];
  const taggedReply = `${responseText}\n\n@${mentions[0].split('@')[0]}`;

  const type = setting.value.type || owner.ownerTagType;
  const stickerData = setting.value.data || owner.ownerTagData;
  const mediaUrl = setting.value.url || owner.ownerTagUrl;
  if (type === 'sticker' && stickerData) {
    await sock.sendMessage(jid, { sticker: Buffer.from(stickerData, 'base64'), mentions }, { quoted: m });
  } else if ((type === 'video' || type === 'media') && mediaUrl) {
    const media = await downloadRemoteMedia(mediaUrl);
    if (media) await sock.sendMessage(jid, { video: media, caption: taggedReply, mentions }, { quoted: m });
    else await sock.sendMessage(jid, { text: taggedReply, mentions }, { quoted: m });
  } else if (type === 'image' && mediaUrl) {
    const media = await downloadRemoteMedia(mediaUrl);
    if (media) await sock.sendMessage(jid, { image: media, caption: taggedReply, mentions }, { quoted: m });
    else await sock.sendMessage(jid, { text: taggedReply, mentions }, { quoted: m });
  } else {
    await sock.sendMessage(jid, { text: taggedReply, mentions }, { quoted: m });
  }
  return true;
}

async function downloadRemoteMedia(url) {
  try {
    const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000, maxContentLength: 15 * 1024 * 1024, maxBodyLength: 15 * 1024 * 1024 });
    const type = String(response.headers?.['content-type'] || '').toLowerCase();
    if (!type.startsWith('image/') && !type.startsWith('video/')) return null;
    return Buffer.from(response.data);
  } catch (error) {
    console.warn('[DTAG MEDIA]', error.message);
    return null;
  }
}

function getOfficialMentions(message) {
  let current = message?.message;
  for (let depth = 0; depth < 4 && current; depth += 1) {
    const context = current.extendedTextMessage?.contextInfo
      || current.imageMessage?.contextInfo
      || current.videoMessage?.contextInfo
      || current.documentMessage?.contextInfo
      || current.stickerMessage?.contextInfo;
    if (context?.mentionedJid?.length) return context.mentionedJid;
    current = current.ephemeralMessage?.message || current.viewOnceMessage?.message || null;
  }
  return [];
}

module.exports = async function handleGroupAdmins(sock, m, options = {}) {
  try {
    const jid = m.key.remoteJid;
    if (!jid || !jid.endsWith('@g.us') || m.key.fromMe) return false;

    // Owner-tag protection must be checked before identity, suspension, and
    // group-metadata lookups so an official mention gets an immediate reply.
    const earlyMentions = getOfficialMentions(m);
    if (earlyMentions.length && await handleOwnerTag(sock, m, jid, earlyMentions)) return true;

    const rawSender = m.key.participant || m.key.remoteJid;
    if (!rawSender) return false;
    let sender = options.sender;
    if (!sender) {
      const resolved = await getRealUserIdentity(sock, rawSender);
      if (String(rawSender).endsWith('@lid') && !resolved?.phoneJid) return false;
      sender = resolved?.phoneJid || rawSender;
    }

    if (!options.skipSuspension) {
      const suspension = await checkSuspension(sender);
      if (suspension.blocked) {
        await safeDelete(sock, m);
        try {
          await sock.groupParticipantsUpdate(jid, [sender], 'remove');
          await sock.sendMessage(jid, { text: `🚫 Banned user ${mentionText(sender)} was detected and removed from the group.`, mentions: [sender] });
        } catch (error) {
          console.error('[BAN AUTO-REMOVE ERROR]', error.message);
        }
        return true;
      }
    }

    if (await isMuted(jid, sender)) {
      await safeDelete(sock, m);
      return true;
    }

    const group = getGroup(jid);
    group.groupId = jid;
    const body = m.message?.conversation || m.message?.extendedTextMessage?.text || m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || '';
    const mentioned = earlyMentions;
    const needsParticipantMetadata = Boolean(
      mentioned.length || group.antilink?.enabled || group.antimention?.enabled || group.antibot?.enabled || group.spm?.locked
    );

    // With no active protection, avoid the expensive WhatsApp groupMetadata call.
    if (!needsParticipantMetadata) return false;

    let isAdmin = false;
    try {
      const metadata = await sock.groupMetadata(jid);
      isAdmin = isParticipantAdminByIdentity(metadata.participants || [], sender);
    } catch {}
    if (isAdmin) return false;

    if (group.spm?.locked && containsLink(body)) {
      const key = `${jid}:${sender}`;
      const now = Date.now();
      const windowMs = Number(group.spm.windowMs || 2000);
      const hits = (rapidLinkHits.get(key) || []).filter((timestamp) => now - timestamp < windowMs);
      hits.push(now);
      rapidLinkHits.set(key, hits);
      await safeDelete(sock, m);
      if (hits.length >= Number(group.spm.linkLimit || 2)) {
        rapidLinkHits.delete(key);
        try { await sock.groupParticipantsUpdate(jid, [sender], 'remove'); } catch {}
        await sock.sendMessage(jid, { text: `🚫 ${mentionText(sender)} was removed for sending repeated links too quickly.`, mentions: [sender] });
      }
      return true;
    }

    if (group.antilink?.enabled && containsLink(body)) {
      await safeDelete(sock, m);
      const warn = updateWarn(group, sender);
      const limit = group.antilink.warnLimit || 3;
      const tag = mentionText(sender);
      if (warn >= limit) {
        resetWarn(group, sender);
        try { await sock.groupParticipantsUpdate(jid, [sender], 'remove'); } catch {}
        await sock.sendMessage(jid, { text: `🚫 ${tag} has been removed for repeatedly sending links.`, mentions: [sender] });
      } else {
        await sock.sendMessage(jid, { text: `⚠️ ${tag} links are not allowed in this group!\n> You have been warned.\n*→* ${warn}/${limit} warnings`, mentions: [sender] });
      }
      return true;
    }

    const isStatusMention = isGroupProfileStatus(m);
    if (group.antigpro?.enabled && isStatusMention) {
      await safeDelete(sock, m);
      const action = String(group.antigpro.action || 'warn').toLowerCase();
      const warn = updateGproWarn(group, sender);
      const limit = Number(group.antigpro.warnLimit || 3);
      const tag = mentionText(sender);
      if (action === 'delete') return true;
      if (action === 'kick' || (action === 'warn' && warn >= limit)) {
        try { await sock.groupParticipantsUpdate(jid, [sender], 'remove'); } catch {}
        await sock.sendMessage(jid, { text: `🚫 ${tag} was removed for promoting a WhatsApp status/profile in this group.`, mentions: [sender] });
      } else {
        await sock.sendMessage(jid, { text: `⚠️ ${tag} you have been warned for promoting a WhatsApp status/profile in this group.\n> Warning ${warn}/${limit}`, mentions: [sender] });
      }
      return true;
    }

    if (group.antimention?.enabled && (mentioned.length >= 5 || isStatusMention)) {
      await safeDelete(sock, m);
      const tag = mentionText(sender);
      await sock.sendMessage(jid, { text: `🚫 ${tag} mass-mentions and status mentions are not allowed here!`, mentions: [sender] });
      return true;
    }

    const isBotLike = sender.endsWith('@broadcast') || sender.includes(':') || /bot|spam|auto/i.test(sender.split('@')[0]);
    if (group.antibot?.enabled && isBotLike) {
      await safeDelete(sock, m);
      const warn = updateWarn(group, sender);
      const limit = group.antilink?.warnLimit || 3;
      const tag = mentionText(sender);
      await sock.sendMessage(jid, { text: `🤖 ${tag} bot activity detected!\n> You have been warned.\n*→* ${warn}/${limit} warnings`, mentions: [sender] });
      return true;
    }

    return false;
  } catch (error) {
    console.error('[GROUP ADMINS ERROR]', error);
    return false;
  }
};
