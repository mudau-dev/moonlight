const axios = require('axios');
const fs = require('node:fs');
const path = require('node:path');
const User = require('../models/User');
const Group = require('../models/athers/Group');
const { getBotIdentity } = require('../utils/adminIdentity');
const { buildSystemPrompt, directReply } = require('./AIprompts');
const chatMemory = new Map();
const seenMessages = new Map();
const pendingMessages = new Set();
const recentSignatures = new Map();
const STICKER_DIRS = [path.join(process.cwd(), 'assets', 'stickers'), path.join(process.cwd(), 'stickers'), '/home/container/assets/stickers', '/home/container/stickers'];
function messageWasSeen(id, signature) {
  if (!id) return false;
  const now = Date.now();
  for (const [key, at] of seenMessages) if (now - at > 120000) seenMessages.delete(key);
  for (const [key, at] of recentSignatures) if (now - at > 30000) recentSignatures.delete(key);
  if (seenMessages.has(id) || pendingMessages.has(id)) return true;
  if (signature && recentSignatures.has(signature)) return true;
  seenMessages.set(id, now);
  if (signature) recentSignatures.set(signature, now);
  pendingMessages.add(id);
  return false;
}
function finishMessage(id) { if (id) pendingMessages.delete(id); }
function stickerFiles(botName) {
  const files = [];
  for (const root of STICKER_DIRS) {
    if (!fs.existsSync(root)) continue;
    for (const name of fs.readdirSync(root)) {
      const file = path.join(root, name);
      try { if (fs.statSync(file).isFile() && new RegExp(`^sticker_${String(botName || 'moonlight').toLowerCase().replace(/[^a-z0-9]+/g, '_')}_.*\\.webp$`, 'i').test(name)) files.push(file); } catch {}
    }
  }
  return [...new Set(files)];
}
async function sendFavoriteSticker(sock, jid, quoted, config) {
  let files = stickerFiles(config?.BOT_NAME);
  if (!files.length) {
    for (const root of STICKER_DIRS) {
      if (!fs.existsSync(root)) continue;
      for (const name of fs.readdirSync(root)) if (/\.webp$/i.test(name)) files.push(path.join(root, name));
    }
  }
  if (!files.length) return false;
  const file = files[Math.floor(Math.random() * files.length)];
  await sock.sendMessage(jid, { sticker: fs.readFileSync(file) }, { quoted });
  return true;
}
async function learnIncomingSticker(msg, config) {
  const sticker = msg.message?.stickerMessage;
  if (!sticker || !global.baileys?.downloadContentFromMessage) return false;
  const root = STICKER_DIRS[0];
  fs.mkdirSync(root, { recursive: true });
  const slug = String(config?.BOT_NAME || 'moonlight').toLowerCase().replace(/[^a-z0-9]+/g, '_');
  const target = path.join(root, `sticker_${slug}_${Math.random().toString(36).slice(2, 7)}.webp`);
  const stream = await global.baileys.downloadContentFromMessage(sticker, 'sticker');
  const chunks = [];
  for await (const chunk of stream) chunks.push(Buffer.from(chunk));
  const data = Buffer.concat(chunks);
  if (!data.length) return false;
  fs.writeFileSync(target, data);
  return true;
}

function bare(value) {
  return String(value || '').split(':')[0].replace(/@.*$/, '').replace(/[^0-9]/g, '');
}
function jidForms(value) {
  const raw = String(value || '').trim();
  const b = bare(raw);
  return new Set([raw, raw.split(':')[0], b, b ? `${b}@s.whatsapp.net` : '', b ? `${b}@lid` : ''].filter(Boolean));
}
function botJids(sock, config) {
  const values = [sock.user?.id, sock.user?.lid, sock.user?.jid, config?.BOT_JID, getBotIdentity(sock, config)];
  return new Set(values.flatMap(jidForms));
}
function isBotJid(value, ids) {
  const forms = jidForms(value);
  for (const form of forms) if (ids.has(form)) return true;
  const b = bare(value);
  return b && [...ids].some((id) => bare(id) === b);
}
function trigger(sock, msg, body, config) {
  const message = msg.message?.extendedTextMessage || msg.message?.imageMessage || msg.message?.videoMessage || msg.message?.conversation || {};
  const context = message?.contextInfo || {};
  const ids = botJids(sock, config);
  const mentioned = (context.mentionedJid || []).some((id) => isBotJid(id, ids));
  const quotedAuthor = context.participant || context.participantAlt || context.participantPn || context.remoteJid || context.quotedMessage?.extendedTextMessage?.contextInfo?.participant;
  const directChat = !String(msg.key.remoteJid || '').endsWith('@g.us');
  // Baileys omits quoted-message keys in many incoming replies. In a DM every quoted message is a bot message; in groups use the author, nested author, or bot name in the quoted text.
  const quotedFromBot = quotedAuthor && isBotJid(quotedAuthor, ids);
  const quotedText = String(context.quotedMessage?.conversation || context.quotedMessage?.extendedTextMessage?.text || context.quotedMessage?.imageMessage?.caption || context.quotedMessage?.videoMessage?.caption || '');
  const quotedFromMe = context.quotedMessage?.key?.fromMe === true || msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.key?.fromMe === true;
  const replied = Boolean(context.quotedMessage && (quotedFromBot || quotedFromMe || directChat || !quotedAuthor || quotedText.toLowerCase().includes(String(config.BOT_NAME || '').toLowerCase())));
  const name = String(config.BOT_NAME || '').trim();
  const startsWithName = Boolean(name && new RegExp(`^${name.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}(?:\\b|[,!:])`, 'i').test(String(body).trim()));
  return { context, mentioned, replied, startsWithName };
}
function extractPrompt(body, config, t) {
  let prompt = String(body || '').trim();
  if (t.startsWithName) prompt = prompt.replace(new RegExp(`^${String(config.BOT_NAME).replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}(?:\\b|[,!:])`, 'i'), '').trim();
  if (t.mentioned) prompt = prompt.replace(/@\d+/g, '').trim();
  return prompt;
}
async function profileFor(sender) {
  const b = bare(sender);
  if (!b) return null;
  return User.findOne({ $or: [{ whatsappNumber: sender }, { userId: sender }, { phoneNumber: sender }, { phoneNumber: b }, { moonId: b }, { whatsappNumber: `${b}@s.whatsapp.net` }] }).lean().catch(() => null);
}
function shortAnswer(value) {
  let answer = String(value || '').replace(/\s+/g, ' ').trim();
  if (!answer) return '';
  answer = answer.replace(/^['"`]|['"`]$/g, '');
  if (answer.length > 220) answer = `${answer.slice(0, 217).replace(/\s+\S*$/, '')}...`;
  return answer;
}
function fallback(botName, prompt, profile, config, userName) {
  const direct = directReply(botName, prompt, profile, config, userName);
  if (direct) return direct;
  const name = String(botName || 'Moonlight');
  const key = name.toLowerCase();
  const text = String(prompt || '').trim();
  const who = /^(who are you|what are you|introduce yourself|what is your name)\b/i.test(text);
  const hello = /^(hi|hey|hello|hy|yo|oi|good morning|good evening)\b/i.test(text);
  if (who) {
    if (key === 'rimuru') return 'I am Rimuru Tempest, a demon lord. What about you, kid?';
    if (key === 'rem') return `I am Rem, your Moonlight Haven guardian, ${userName || 'friend'}.`;
    if (key === 'frieren') return 'I am Frieren, an elven mage. I have lived a very long time.';
    if (key === 'saber') return 'I am Saber, a knight and guardian. Speak plainly.';
    if (key === 'cid') return 'I am Cid Kagenou. The shadows are always watching.';
    if (key === 'kurumi' || key === 'lain') return 'I am Kurumi. Time and love are both interesting, are they not?';
  }
  if (hello) return `Hello ${userName || 'there'}—${key === 'rimuru' ? 'Rimuru is here.' : 'I am here.'}`;
  const variants = {
    rimuru: ['I hear you. Tell me the important part.', 'Hmm. Say a little more, kid.', 'I am listening—what do you mean?'],
    rem: ['I am listening. Tell me more.', 'Of course. What is on your mind?', 'I am here with you.'],
    frieren: ['Hmm. Tell me more.', 'That is interesting. Continue.', 'I am listening.'],
    saber: ['Understood. Explain further.', 'I am listening. Speak plainly.', 'Very well. Continue.'],
    cid: ['Interesting. The shadows heard you.', 'Say more.', 'I am listening from the shadows.'],
    kurumi: ['How curious. Tell me more.', 'Oh? Continue—I am listening.', 'Time is short, so be clear.'],
  };
  const choices = variants[key] || ['Oi. Do I look like Google to you baka', 'I am listening—say that another way.', 'Tell me more.'];
  const last = [...chatMemory.values()].flat().reverse().find((entry) => entry.role === 'assistant')?.content;
  const available = choices.filter((choice) => choice !== last);
  const n = Math.abs([...text].reduce((sum, char) => sum + char.charCodeAt(0), 0) + Date.now());
  return (available.length ? available : choices)[n % (available.length || choices.length)];
}
async function publicAnswer(apiUrl, system, history) {
  const transcript = history.slice(-6).map((m) => `${m.role}: ${m.content}`).join('\n');
  const prompt = `${system}\nConversation:\n${transcript}\nReply now with only one tiny in-character answer.`;
  let last;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await axios.get(`${apiUrl.replace(/\/$/, '')}/${encodeURIComponent(prompt)}`, { timeout: 18_000, responseType: 'text', headers: { 'User-Agent': 'MoonlightHavenBot/1.0' } });
      const answer = shortAnswer(response.data);
      if (answer && !/^\{.*(error|status).*\}$/i.test(answer)) return answer;
    } catch (error) { last = error; await new Promise((resolve) => setTimeout(resolve, 500 * (attempt + 1))); }
  }
  throw last || new Error('empty public response');
}
async function chatbotEnabled(jid) {
  if (!String(jid || '').endsWith('@g.us')) return true;
  const group = await Group.findOne({ groupId: jid }).select('chatbotEnabled').lean().catch(() => null);
  return group?.chatbotEnabled !== false;
}
async function handleChatBot(sock, msg, body, config) {
  if (!(await chatbotEnabled(msg.key?.remoteJid))) return;
  const eventId = msg.key?.id;
  const contextInfo = msg.message?.extendedTextMessage?.contextInfo || msg.message?.imageMessage?.contextInfo || msg.message?.videoMessage?.contextInfo || {};
  const signature = [msg.key?.remoteJid || '', msg.key?.participant || msg.key?.participantAlt || '', contextInfo.stanzaId || '', String(body || '').trim().toLowerCase()].join('|');
  if (messageWasSeen(eventId, signature)) return;
  try {
  const t = trigger(sock, msg, body, config);
  if (!t.mentioned && !t.replied && !t.startsWithName) { finishMessage(eventId); return; }
  if (String(body).startsWith(config.PREFIX) && config.PREFIX !== '') { finishMessage(eventId); return; }
  await learnIncomingSticker(msg, config).catch(() => false);
  const prompt = extractPrompt(body, config, t);
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;
  const profile = await profileFor(sender);
  const userName = msg.pushName || msg.notifyName || profile?.aiIdentityName || 'friend';
  if (!prompt) {
    await sock.sendMessage(jid, { text: `Hello ${userName}, how can I help?` }, { quoted: msg });
    await sendFavoriteSticker(sock, jid, msg, config).catch(() => {});
    finishMessage(eventId);
    return;
  }
  const memoryKey = `${String(config.BOT_NAME || 'Moonlight').toLowerCase()}:${jid}:${bare(sender) || sender}`;
  const history = chatMemory.get(memoryKey) || [];
  const direct = directReply(config.BOT_NAME, prompt, profile, config, userName);
  let answer = direct;
  history.push({ role: 'user', content: prompt });
  while (history.length > 8) history.shift();
  if (!answer) {
    const system = buildSystemPrompt(config.BOT_NAME, config, profile, userName);
    const apiKey = process.env.CHATBOT_API_KEY || process.env.OPENAI_API_KEY || '';
    const apiUrl = process.env.CHATBOT_API_URL || 'https://text.pollinations.ai';
    try {
      if (/^https?:\/\/text\.pollinations\.ai\/?$/i.test(apiUrl)) answer = await publicAnswer(apiUrl, system, history);
      else if (apiKey) {
        const response = await axios.post(apiUrl, { model: process.env.CHATBOT_MODEL || 'gpt-4o-mini', temperature: 0.55, max_tokens: 90, messages: [{ role: 'system', content: system }, ...history] }, { timeout: 20_000, headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' } });
        answer = shortAnswer(response.data?.choices?.[0]?.message?.content);
      } else throw new Error('no configured provider');
    } catch (error) {
      console.error('[CHATBOT FALLBACK]', error.response?.status || error.code || error.message);
      answer = fallback(config.BOT_NAME, prompt, profile, config, userName);
    }
  }
  answer = shortAnswer(answer) || fallback(config.BOT_NAME, prompt, profile, config, userName);
  history.push({ role: 'assistant', content: answer });
  while (history.length > 8) history.shift();
  chatMemory.set(memoryKey, history);
  await sock.sendMessage(jid, { text: answer }, { quoted: msg });
  await sendFavoriteSticker(sock, jid, msg, config).catch(() => {});
  finishMessage(eventId);
  } catch (error) {
    finishMessage(eventId);
    console.error('[CHATBOT HANDLER]', error?.stack || error?.message || error);
    await sock.sendMessage(msg.key.remoteJid, { text: fallback(config.BOT_NAME, body, null, config, msg.pushName || 'friend') }, { quoted: msg }).catch(() => {});
  }
}
module.exports = { handleChatBot };
