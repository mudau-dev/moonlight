const path = require('path');
const fs = require('fs');
const config = require('../config');
const { downloadMediaMessage } = require('../utils/baileys');
const { checkGamblingAllowed } = require('../handlers/_shared');
const { findOrCreateWhatsApp } = require('../database/users');
const { getRealUserIdentity } = require('../utils/whatsappIdentity');
const { checkUserRole } = require('./roleChecker');
const Group = require('../models/athers/Group');
const { groupAllowed, getProgress, levelData } = require('../utils/gym');
const { isGuildMember } = require('../utils/guildAccess');
const { setPending } = require('../utils/gymPending');
const CategoryLock = require('../models/athers/CategoryLock');
const GroupCategoryLock = require('../models/athers/GroupCategoryLock');
const { commands } = require('./moon');

const LOCK_BYPASS_ROLES = new Set(['True Owner', 'Owner', 'Mod', 'CDC']);
const RESTRICTED_CATEGORIES = new Set(['economy', 'gambling', 'pokémon', 'pokemons', 'lagacy', 'legacy', 'cards', 'card']);
const STAFF_OVERRIDE_COMMANDS = new Set(['kick', 'welcome', 'tleave', 'antilink', 'antimention', 'tag', 'tagall', 'active', 'unactive', 'inactive', 'ctv', 'antigpro']);
const STAFF_ROLES = ['Owner', 'True Owner', 'Mod', 'Guardian'];
const lockCache = new Map();
const LOCK_CACHE_TTL_MS = 10000;
const LOCK_QUERY_TIMEOUT_MS = 150;
// All command folders are loaded. Broken individual files are isolated by the
// per-file try/catch below instead of disabling an entire command category.
const DISABLED_COMMAND_DIRECTORIES = new Set();
const PERMANENT_LOCK_EXCEPTION_COMMANDS = new Set(['ctg', 'gctg']);

function getMessageText(m) {
  return m.message?.conversation || m.message?.extendedTextMessage?.text || m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || m.message?.buttonsResponseMessage?.selectedButtonId || m.message?.listResponseMessage?.singleSelectReply?.selectedRowId || '';
}
function createReply(sock, jid, m) { return async (text, extra = {}) => sock.sendMessage(jid, { text, ...extra }, { quoted: m }); }
function createReplyWithImage(sock, jid, m) { return (imageUrl, caption, extra = {}) => sock.sendMessage(jid, { image: { url: imageUrl }, caption, ...extra }, { quoted: m }); }
function isGamblingCommand(cmd) { return String(cmd.category || '').toLowerCase() === 'gambling'; }
const GYM_COMMANDS = new Set(['gym', 'pokegym', 'gb', 'gymbattle']);
function isGymCommand(cmd) { return GYM_COMMANDS.has(String(cmd?.name || '').toLowerCase()); }
function gymGroupError() {
  return [
    '> To play Pokémon, catch Pokémon, and battle wild Pokémon, join these 2 allowed groups:',
    '',
    '> 𝐌𝐨𝐨𝐧𝐥𝐢𝐠𝐡𝐭 *Pokémon - l*',
    config.POKEMON_LINK || 'Pokémon group 1 is not configured.',
    '> 𝐌𝐨𝐨𝐧𝐥𝐢𝐠𝐡𝐭 *Pokémon - ll*',
    config.POKEMON_LINK2 || 'Pokémon group 2 is not configured.',
  ].join('\n');
}

async function cachedLock(key, query) {
  const cached = lockCache.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.value;
  if (!cached?.promise) {
    const promise = Promise.resolve().then(query).then((value) => {
      lockCache.set(key, { value, expiresAt: Date.now() + LOCK_CACHE_TTL_MS });
      return value;
    }).catch(() => false);
    lockCache.set(key, { promise, expiresAt: Date.now() + LOCK_CACHE_TTL_MS });
  }
  const pending = lockCache.get(key).promise;
  return Promise.race([
    pending,
    new Promise((resolve) => setTimeout(() => resolve(false), LOCK_QUERY_TIMEOUT_MS)),
  ]);
}

async function loadCommands() {
  const commandsDir = path.join(process.cwd(), 'commands');
  const readCommands = (dir) => {
    if (!fs.existsSync(dir)) return;
    for (const file of fs.readdirSync(dir).sort()) {
      const fullPath = path.join(dir, file);
      if (fs.statSync(fullPath).isDirectory()) {
        if (DISABLED_COMMAND_DIRECTORIES.has(file.toLowerCase())) continue;
        readCommands(fullPath);
      }
      else if (file.endsWith('.js')) {
        try {
          delete require.cache[require.resolve(fullPath)];
          require(fullPath);
        } catch (error) {
          console.error(`[LOADER] Failed to load ${fullPath}:`, error.stack || error.message);
        }
      }
    }
  };
  global.moon = require('./moon').moon;
  readCommands(commandsDir);
  console.log(`[LOADER] Loaded ${commands.size} commands/aliases from ${commandsDir}.`);
  console.log(`[LOADER] Sample commands: ${[...commands.keys()].slice(0, 20).join(', ')}`);
  if (!commands.size) console.error('[LOADER FATAL] No commands were registered. Check the command directory and loader errors above.');
}

async function runCommand(sock, jid, sender, m, options = {}) {
  try {
    const identity = options.identity || await getRealUserIdentity(sock, sender).catch(() => null);
    // Do not drop commands merely because LID-to-phone mapping is temporarily
    // unavailable; index.js supplies the original/alternate sender fallback.
    sender = identity?.phoneJid || options.fallbackSender || sender;
    if (!sender) { console.error('[CMD TRACE] No sender identity', { jid, originalSender: sender }); return; }

    const text = getMessageText(m).trim();
    if (!text || !text.startsWith(config.PREFIX)) return;
    const args = text.slice(config.PREFIX.length).trim().split(/ +/).filter(Boolean);
    const cmdName = args.shift()?.toLowerCase();
    if (!cmdName) return;
    const cmd = commands.get(cmdName);
    if (!cmd) { console.error('[CMD TRACE] Unknown command', { jid, sender, cmdName, text, loaded: commands.size, sample: [...commands.keys()].slice(0, 20) }); return; }

    // Normal commands must not be silently gated by stale global bot-state cache data.
    const pushName = m.pushName || m.notifyName || sender.split('@')[0];
    let userPromise = null;
    const ensureUser = async () => {
      if (!userPromise) userPromise = findOrCreateWhatsApp(sender, pushName).catch(() => null);
      return userPromise;
    };
    const context = {
      reply: createReply(sock, jid, m),
      replyWithImage: createReplyWithImage(sock, jid, m),
      commands,
      config,
      findOrCreateWhatsApp,
      user: null,
      ensureUser,
      pushName,
      prefix: config.PREFIX,
      body: text,
      downloadMediaMessage,
    };
    if (STAFF_OVERRIDE_COMMANDS.has(String(cmd.name || '').toLowerCase())) {
      context.isStaff = (await checkUserRole(sender, STAFF_ROLES)).allowed;
    }
    return await executeWrapped(cmd, sock, jid, sender, args, m, context);
  } catch (error) {
    console.error('[DISPATCH ERROR]', error.stack || error.message || error);
  }
}

function bypassesLocks(user) {
  const role = user?.isTrueOwner === true ? 'True Owner' : (user?.role || 'User');
  return LOCK_BYPASS_ROLES.has(role) || user?.isTrueOwner === true || user?.isCDC === true;
}

async function executeWrapped(cmd, sock, jid, sender, args, m, context) {
  try {
    if (isGymCommand(cmd)) {
      if (!jid.endsWith('@g.us') || !groupAllowed(jid)) return context.reply(gymGroupError());
      const group = await Group.findOne({ groupId: jid }).lean();
      if (group?.pokemonSpawnEnabled !== true) return context.reply(gymGroupError());
      if (!(await isGuildMember(sender))) return context.reply('❌ You must belong to a guild before using Pokémon Gym battles.');
      const commandName = String(cmd.name || '').toLowerCase();
      const firstArg = String(args[0] || '').toLowerCase();
      if (commandName === 'gym' && /^\d+$/.test(firstArg)) {
        const stageIndex = Number(firstArg);
        const { user, progress } = await getProgress(sender);
        if (!user) return context.reply('❌ Create your Pokémon profile first with `.start`.');
        if (stageIndex !== Number(progress.current || 1)) return context.reply(`❌ You cannot skip or revisit stages. Your current stage is *${progress.current || 1}*.`);
        if (stageIndex < 1 || stageIndex > 250) return context.reply('❌ Gym stages are numbered from *1 to 250*.');
        const stage = levelData(stageIndex);
        setPending(sender, stageIndex);
        user.gymPendingStage = stageIndex;
        user.gymPendingAt = new Date();
        user.gymPending = stageIndex;
        await user.save();
        return context.reply(`🏟️ Are you sure you want to battle this round?\n\n*${stage.name}*\nOpponent: *${stage.opponent}* · level ${stage.opponentLevel}\n\n*.gym yes* — continue\n*.gym no* — cancel\n\n> Use one of these cmds in order to continue or stop.`);
      }
    }

    if (Array.isArray(cmd.roles) && cmd.roles.length) {
      const roleResult = await checkUserRole(sender, cmd.roles);
      if (!roleResult.allowed) return context.reply(roleResult.message || '❌ No permission');
      context.user = roleResult.user || context.user;
    }

    if (cmd.category) {
      const commandKey = String(cmd.name || '').toLowerCase();
      const category = String(cmd.category).toLowerCase();
      let groupLock = false;
      let globalLock = null;
      if (category !== 'owner' && !PERMANENT_LOCK_EXCEPTION_COMMANDS.has(commandKey)) {
        [groupLock, globalLock] = await Promise.all([
          jid.endsWith('@g.us') ? cachedLock(`group:${jid}:${category}`, async () => Boolean(await GroupCategoryLock.findOne({ groupId: jid, category, locked: true }).lean())) : false,
          cachedLock(`global:${category}`, async () => CategoryLock.findOne({ category, locked: true }).lean()),
        ]);
      }

      if (['pokemon', 'pokemons'].includes(category) && !PERMANENT_LOCK_EXCEPTION_COMMANDS.has(commandKey)) {
        const pokemonGroup = jid.endsWith('@g.us') ? await Group.findOne({ groupId: jid }).select('pokemonSpawnEnabled').lean().catch(() => null) : null;
        if (jid.endsWith('@g.us') && pokemonGroup?.pokemonSpawnEnabled !== true && !bypassesLocks(context.user)) {
          return context.reply(gymGroupError());
        }
      }

      const needsUser = RESTRICTED_CATEGORIES.has(category) || groupLock || globalLock;
      if (needsUser && !context.user) context.user = await context.ensureUser();
      const bypass = bypassesLocks(context.user);
      if (!bypass && groupLock) return;
      if (!bypass && RESTRICTED_CATEGORIES.has(category)) {
        const senderDigits = sender.split('@')[0].replace(/[^0-9]/g, '');
        if (!context.user?.moonId || context.user.moonId !== senderDigits) {
          return context.reply('You have to be register to use this command\n> use `.reg` in order to register on our community');
        }
      }
      if (!bypass && globalLock?.locked) {
        return context.reply(`🔒 *Category Locked*\nThe *${cmd.category}* category is currently unavailable.\n\n📝 *Reason:* ${globalLock.reason || 'No reason provided.'}`);
      }
    }

    if (isGamblingCommand(cmd)) {
      const blockMsg = await checkGamblingAllowed(jid);
      if (blockMsg) return context.reply(blockMsg);
      try {
        const shared = require('../commands/gambling/_shared');
        const commandKey = String(cmd.name).toLowerCase();
        if (!['db', 'deathbattle'].includes(commandKey)) {
          const multiplierBlock = await shared.checkMultiplierCooldown(sender, cmd.name);
          if (multiplierBlock) return context.reply(multiplierBlock);
        }
        if (String(cmd.name).toLowerCase() === 'race') {
          const raceQuota = await shared.consumeRaceUse(sender);
          if (!raceQuota.allowed) return context.reply(shared.raceLimitMessage(raceQuota));
        }
        const quota = await shared.consumeCasinoUse(sender, cmd.name);
        if (!quota.allowed) return context.reply(shared.casinoLimitMessage(quota));
      } catch (error) {
        console.error('[CASINO LIMIT ERROR]', error);
        return context.reply('❌ Unable to verify your casino command limit. Please try again.');
      }
    }

    return await cmd.execute(sock, jid, sender, args, m, context);
  } catch (error) {
    console.error(`[CMD ERROR] ${cmd.name}:`, error.stack || error.message || error);
    return context.reply(`❌ An error occurred: ${error.message}`);
  }
}

module.exports = { commands, runCommand, loadCommands };
