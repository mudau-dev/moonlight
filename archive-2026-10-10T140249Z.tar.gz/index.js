let makeWASocket;
let useMultiFileAuthState;
let fetchLatestBaileysVersion;
let DisconnectReason;
let Browsers;
let loadCommands;
let runCommand;
let handlePairing;
let heartbeatTimer;
let groupSnapshotTimer;
let pino;
try {
  pino = require("pino");
} catch (error) {
  // Keep the bot operational on constrained hosts if a package installer blocks pino's dependency tree.
  console.warn('[STARTUP] pino is unavailable; using the built-in silent logger fallback.');
  pino = () => ({
    child() { return this; },
    trace() {}, debug() {}, info() {}, warn() {}, error() {}, fatal() {},
  });
}
const { Boom } = require("@hapi/boom");
const fs = require("fs");
const path = require("path");
require("dotenv").config();
// ── Core modules ──────────────────────────────────────────────────────────────
const { connectDB } = require("./database/index");

const afkEvent = require("./handler/afk");
const handleOwnerTag = require("./handler/OwnersMeme");
const { startNewsScheduler } = require("./handlers/News");
const handleGroupEvents = require("./handler/GroupSettings");
const handleGroupAdmins = require("./handler/GroupAdmins");

const { handleSuspension } = require("./handler/Stetus");
const { spawnCard } = require("./handler/CardsSystem");
const { spawnPokemon, startPokemonSpawnScheduler } = require("./handler/PokemonSpawn");
const { updateEventStats } = require("./commands/gambling/_shared");
const { startCommunityManager } = require("./handlers/Community");
const { handleForceAdd } = require("./handlers/Bot");
const { startKeepAwake } = require('./handlers/keepAwake');
const { handleGstatus } = require("./handlers/Admin");
const Bot = require("./models/athers/Bot");
const BotGroup = require('./models/athers/BotGroup');
const BotAction = require('./models/athers/BotAction');
const Group = require("./models/athers/Group");
const GroupActivity = require("./models/GroupActivity");
const User = require("./models/User");
const { handleGuess } = require('./utils/ngsGame');
const config = require("./config");
const { getRealUserIdentity } = require("./utils/whatsappIdentity");
const { findParticipantByIdentity, isParticipantAdmin, getBotIdentity } = require('./utils/adminIdentity');
const { handleChatBot } = require("./handler/ChatBot");
let trackSupportReply;

function getMessageText(m) {
  return (
    m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption ||
    m.message?.videoMessage?.caption ||
    m.message?.buttonsResponseMessage?.selectedButtonId ||
    m.message?.listResponseMessage?.singleSelectReply?.selectedRowId ||
    ""
  );
}

// ── Heartbeat (non-blocking) ──────────────────────────────────────────────────
async function updateHeartbeat() {
  try {
    const botName = (config.BOT_NAME || "Rem").toLowerCase();
    Bot.findOne({ name: new RegExp(`^${String(botName).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }).then((record) => {
      if (record?.disabled) return;
      return Bot.findOneAndUpdate({ _id: record?._id || new Bot({ name: botName })._id }, { $set: { name: record?.name || botName, lastSeen: new Date() } }, { upsert: true });
    }).catch(() => {});
  } catch {}
}

function startHeartbeat() {
  if (!heartbeatTimer) heartbeatTimer = setInterval(updateHeartbeat, 30000);
  updateHeartbeat();
}

// ── Per-user message XP tracking ─────────────────────────────────────────────
function trackUserMessage(senderJid) {
  User.findOneAndUpdate(
    { whatsappNumber: senderJid },
    { $inc: { messageCount: 1 } },
    { upsert: false }
  ).catch(() => {});
}

function trackGroupActivity(groupId, senderJid) {
  const bucketStart = GroupActivity.getSouthAfricaBucketStart();
  GroupActivity.findOneAndUpdate(
    { groupId, bucketStart, userId: senderJid },
    { $inc: { count: 1 } },
    { upsert: true, setDefaultsOnInsert: true }
  ).catch(() => {});
}

function printStartupBanner(dbConnected) {
  console.log('');
  console.log('========================================');
  console.log('Moonlight Haven bot now owner');
  console.log(`Name: ${config.BOT_NAME}`);
  console.log(`Creater: ${config.CREATOR_NAME || config.OWNER_NAME}`);
  console.log(`Owner: ${config.OWNER_NAME}`);
  console.log(`Prefix: ${config.PREFIX}`);
  console.log(`db connection: ${dbConnected ? 'connected' : 'not connected'}`);
  console.log('Moonlight haven bot ready fore use and all');
  console.log('========================================');
  console.log('');
}

async function syncBotGroupSnapshot(sock) {
  try {
    const botName = String(config.BOT_NAME || 'Rem');
    const pendingActions = await BotAction.find({ botName, status: 'pending' }).sort({ createdAt: 1 }).limit(5).lean();
    for (const action of pendingActions) {
      try {
        if (action.action === 'leave') await sock.groupLeave(action.groupId);
        await BotAction.updateOne({ _id: action._id }, { $set: { status: 'done', completedAt: new Date() } });
      } catch (error) {
        await BotAction.updateOne({ _id: action._id }, { $set: { status: 'failed', completedAt: new Date() } });
        console.error('[BOT ACTION]', error.message);
      }
    }
    const all = await sock.groupFetchAllParticipating();
    const groups = Object.values(all || {}).filter((group) => group?.id && !group.isCommunity && !group.isCommunityAnnounce && !/community|announcement/i.test(String(group.subject || '')));
    const simplified = groups.map((group) => {
      const bot = findParticipantByIdentity(group.participants || [], getBotIdentity(sock, config));
      const admins = (group.participants || []).filter((participant) => participant.admin).map((participant) => participant.id);
      return { id: group.id, subject: group.subject || 'Unknown', participantCount: group.participants?.length || 0, isAdmin: isParticipantAdmin(bot), isCommunity: Boolean(group.isCommunity), isCommunityAnnounce: Boolean(group.isCommunityAnnounce), communityId: group.linkedParent || group.linkedParentJid || group.parentGroupJid || group.parentJid || group.communityJid || null, members: (group.participants || []).map((participant) => participant.id || participant.jid || participant.lid).filter(Boolean), admins };
    });
    const existingBot = await Bot.findOne({ name: new RegExp(`^${String(botName).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i'), disabled: { $ne: true } }) || await Bot.findOne({ name: new RegExp(`^${String(botName).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') });
    if (existingBot?.disabled) return;
    await Bot.findOneAndUpdate({ _id: existingBot?._id || new Bot({ name: botName })._id }, { $set: { name: existingBot?.name || botName, lastSeen: new Date(), groups: simplified.map(({ id, subject, participantCount, isAdmin }) => ({ id, subject, participantCount, isAdmin })) } }, { upsert: true });
    await BotGroup.deleteMany({ botName });
    if (simplified.length) await BotGroup.insertMany(simplified.map((group) => ({ botName, groupId: group.id, subject: group.subject, participantCount: group.participantCount, isAdmin: group.isAdmin, isCommunity: group.isCommunity, isCommunityAnnounce: group.isCommunityAnnounce, communityId: group.communityId, members: group.members, admins: group.admins })), { ordered: false });
  } catch (error) { console.error('[BOT GROUP SNAPSHOT]', error.message); }
}

async function dedupeBotRegistry() {
  try {
    const rows = await Bot.find({}).sort({ lastSeen: -1, _id: -1 }).lean();
    const groups = new Map();
    for (const row of rows) (groups.get(String(row.name || '').trim().toLowerCase()) || groups.set(String(row.name || '').trim().toLowerCase(), []).get(String(row.name || '').trim().toLowerCase())).push(row);
    for (const [key, list] of groups) {
      if (!key || list.length < 2) continue;
      const disabled = list.some((row) => row.disabled === true);
      const keep = list.find((row) => disabled ? row.disabled === true : row.disabled !== true) || list[0];
      await Bot.deleteMany({ _id: { $in: list.filter((row) => String(row._id) !== String(keep._id)).map((row) => row._id) } });
      if (disabled && !keep.disabled) await Bot.updateOne({ _id: keep._id }, { $set: { disabled: true } });
    }
  } catch (error) { console.error('[BOT DEDUPE]', error.message); }
}

async function startBot() {
  // Baileys 7 is ESM and provides the persistent LID-to-phone mapping store.
  // It must be available before command modules are evaluated.
  global.baileys = await import('@whiskeysockets/baileys');
  ({ makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, DisconnectReason, Browsers } = global.baileys);
  ({ loadCommands, runCommand } = require('./handler/cmds'));
  ({ handlePairing } = require('./handlers/pair'));
  const [dbConnected] = await Promise.all([
    connectDB(),
    loadCommands(),
  ]);
  ({ trackSupportReply } = require("./commands/general/mods"));
  await dedupeBotRegistry();
  printStartupBanner(dbConnected);

  const sessionPath = path.join(process.cwd(), "sessions");
  if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    auth: state,
    browser: Browsers.ubuntu("Chrome"),
    printQRInTerminal: false,
    markOnlineOnConnect: true,
    retryRequestDelayMs: 250,
    maxMsgRetryCount: 3,
    connectTimeoutMs: 20000,
    keepAliveIntervalMs: 15000,
    emitOwnEvents: false,
    syncFullHistory: false,
    fireInitQueries: false,
    generateHighQualityLinkPreview: true,
  });

  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      const shouldReconnect = (lastDisconnect?.error instanceof Boom)
        ? lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut
        : true;
      if (shouldReconnect) {
        console.log("🔄 Reconnecting...");
        setTimeout(() => startBot().catch((error) => console.error('[RECONNECT]', error.message)), 1000);
      } else {
        console.log("❌ Logged out. Shutting down bot automatically...");
        process.exit(0);
      }
    } else if (connection === "open") {
      console.log("✅ Connected!");
      saveCreds().catch((error) => console.error('[CREDS SAVE]', error.message));
      startNewsScheduler(sock);
      startPokemonSpawnScheduler(sock);
      startCommunityManager(sock);
      startKeepAwake();
      require("./handlers/Bot").startAutoUpdate(sock);
      syncBotGroupSnapshot(sock).catch(() => {});
      if (!groupSnapshotTimer) groupSnapshotTimer = setInterval(() => syncBotGroupSnapshot(sock).catch(() => {}), 60000);
    }
  });

  if (!state.creds.registered) await handlePairing(sock);
  startHeartbeat();

  // ── Group participant events ──────────────────────────────────────────────
  sock.ev.on("group-participants.update", async (update) => {
    handleForceAdd(sock, update).catch(() => {});
    handleGroupEvents(sock, update).catch(() => {});
    if (update.action === 'add') {
      const { handleAutoKick } = require('./commands/owner/akick');
      for (const participant of (update.participants || [])) {
        handleAutoKick(sock, update.id, participant).catch(() => {});
      }
    }
  });

  // ── Main message handler ──────────────────────────────────────────────────
  sock.ev.on("messages.upsert", async (m) => {
    if (m.type !== "notify") return;
    const msg = m.messages?.[0];
    // Commands sent from the bot account itself are valid owner/operator commands.
    // Non-command bot replies do not re-enter dispatch because they lack the prefix.
    if (!msg?.message) return;

    const jid = msg.key.remoteJid;
    if (!jid) return;
    const isGroup = jid.endsWith("@g.us");
    // Self-authored group messages may omit key.participant. Fall back to the
    // bot's verified JID so commands sent from the bot account still dispatch.
    const botIdentity = getBotIdentity(sock, config);
    const originalSender = isGroup
      ? (msg.key.participant || msg.key.participantAlt || botIdentity)
      : jid;
    const alternatePhoneJid = isGroup
      ? (msg.key.participantAlt || botIdentity)
      : msg.key.remoteJidAlt;
    const body = getMessageText(msg);
    const isCmd = body.startsWith(config.PREFIX);
    const cmdName = isCmd
      ? body.slice(config.PREFIX.length).trim().split(/ +/)[0]?.toLowerCase() || ""
      : "";

    // Identity is the only required per-message lookup. Phone JIDs resolve locally;
    // LIDs use the verified Baileys mapping when needed.
    const identity = await getRealUserIdentity(sock, originalSender, alternatePhoneJid).catch(() => null);
    // A missing LID mapping must not discard ordinary commands. Keep the
    // verified alternate JID when present, otherwise retain the original sender
    // for command execution while the mapping cache catches up.
    const sender = identity?.phoneJid || alternatePhoneJid || originalSender;
    if (!sender) return;

    // Count unique Mod replies to an active `.mods` support request.
    trackSupportReply(sock, msg, sender).catch(() => {});

    // Private-chat messages are allowed for the chatbot; group-only protection and commands remain gated below.

    // Activity tracking is fire-and-forget so command dispatch stays fast.
    if (isGroup) trackGroupActivity(jid, sender);

    // NGS guesses are handled before normal dispatch: one exact numeric message
    // is recorded in memory and acknowledged without touching command databases.
    if (!isCmd && await handleGuess(sock, jid, sender, body, msg)) return;

    // These writes and spawn checks deliberately do not block command dispatch.
    if (isGroup) Group.findOneAndUpdate(
      { groupId: jid },
      { $inc: { totalMessages: isCmd ? 0 : 1, botMessages: isCmd ? 1 : 0 } },
      { upsert: true }
    ).catch(() => {});
    updateEventStats(sender, "message", 1).catch(() => {});
    if (!isCmd) trackUserMessage(sender);

    // Suspended command users still receive the existing explanation. Non-command
    // enforcement remains inside GroupAdmins, which can remove banned participants.
    if (isCmd && isGroup) {
      const suspended = await handleSuspension(sock, jid, sender, msg, cmdName, true);
      if (suspended?.blocked) return;
    }

    // Group protection preserves all moderation behavior. It avoids metadata calls
    // unless a protection setting requires one and does not re-query suspension for
    // command traffic already checked above.
    if (isCmd && isGroup) {
      // Command replies must not wait for mute/antilink metadata checks. Those
      // checks continue in the background so link-spam protection stays active.
      handleGroupAdmins(sock, msg, { sender, skipSuspension: true }).catch(() => {});
    } else if (isGroup) {
      const adminHandled = await handleGroupAdmins(sock, msg, { sender, skipSuspension: false });
      if (adminHandled) return;
    }
    handleGstatus(sock, msg).catch(() => {});

    handleOwnerTag(sock, msg, body).catch(() => {});
    spawnCard(sock, jid).catch(() => {});
    spawnPokemon(sock, jid).catch(() => {});

    // AFK processing retains its original behavior without creating or fetching a
    // user record before lightweight commands.
    if (isGroup && (isCmd || body.includes("@"))) afkEvent(sock, msg, sender, jid).catch(() => {});

    if (isCmd && isGroup) {
      runCommand(sock, jid, sender, msg, { identity, fallbackSender: sender }).catch((error) => {
        console.error("CMD DISPATCH ERROR:", error);
      });
      return;
    }

    // Automatic link preview replies intentionally removed. Links continue through
    // moderation, confirmation replies, and normal chatbot/message processing.
    const { handlePdelReply } = require('./commands/Pokemon/pdel');
    const pdelHandled = await handlePdelReply(sock, jid, sender, body, msg).catch(() => false);
    if (!pdelHandled) await handleChatBot(sock, msg, body, config);
  });
}

startBot().catch((error) => {
  console.error('[STARTUP]', error);
  process.exit(1);
});
