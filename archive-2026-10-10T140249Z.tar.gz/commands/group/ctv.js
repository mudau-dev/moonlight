const Group = require('../../models/athers/Group');
const { generateWAMessageFromContent, proto } = require('../../utils/baileys');
const { findParticipantByIdentity } = require('../../utils/adminIdentity');

function isAdmin(participant) { return participant?.admin === 'admin' || participant?.admin === 'superadmin'; }

moon({
  name: 'ctv',
  aliases: ['activity'],
  category: 'group',
  description: 'Show group card-spawn activity totals.',
  async execute(sock, jid, sender, args, m, { reply, isStaff }) {
    try {
      if (!jid.endsWith('@g.us')) return reply('❌ This command only works in groups.');
      const metadata = await sock.groupMetadata(jid);
      if (!isStaff && !isAdmin(findParticipantByIdentity(metadata.participants || [], sender))) return reply('❌ You must be a group admin or approved staff member.');
      const group = await Group.findOne({ groupId: jid }).lean() || {};
      const req = 250;
      const msg = generateWAMessageFromContent(jid, proto.Message.fromObject({
        pollResultSnapshotMessage: proto.Message.PollResultSnapshotMessage.fromObject({
          name: '📊 *GROUP ACTIVITY - MOONLIGHT HAVEN*',
          pollVotes: [
            { optionName: `*Spawns: ${group.cardsSpawnedThisCycle || 0}/10*`, optionVoteCount: group.cardsSpawnedThisCycle || 0 },
            { optionName: '*Required messages*', optionVoteCount: req },
            { optionName: '*Normal messages*', optionVoteCount: group.totalMessages || 0 },
            { optionName: '*Bot commands used*', optionVoteCount: group.botMessages || 0 },
            { optionName: '*Spawn Progress*', optionVoteCount: Math.min(100, Math.floor(((group.totalMessages || 0) / req) * 100)) },
          ],
        }),
      }), { quoted: m });
      return sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
    } catch (error) {
      console.error('[CTV CMD ERROR]', error);
      return reply('❌ Error fetching activity.');
    }
  },
});
