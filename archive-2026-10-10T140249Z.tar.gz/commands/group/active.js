const GroupActivity = require('../../models/GroupActivity');
const { findParticipantByIdentity, getBotIdentity } = require('../../utils/adminIdentity');
const config = require('../../config');
const User = require('../../models/User');

const inactiveLists = global.inactiveActivityLists || (global.inactiveActivityLists = new Map());
const STAFF_ROLES = ['Owner', 'True Owner', 'Mod', 'Guardian'];

function isAdmin(participant) { return participant?.admin === 'admin' || participant?.admin === 'superadmin'; }
function contextInfo(message) {
  return message?.message?.extendedTextMessage?.contextInfo
    || message?.message?.imageMessage?.contextInfo
    || message?.message?.videoMessage?.contextInfo
    || message?.message?.stickerMessage?.contextInfo
    || {};
}
function mention(jid) { return `@${String(jid).split('@')[0]}`; }

async function removeInactiveList(sock, jid, list, m, reply) {
  const metadata = await sock.groupMetadata(jid);
  const bot = findParticipantByIdentity(metadata.participants || [], getBotIdentity(sock, config));
  if (!isAdmin(bot)) return reply('❌ I need to be a group admin to remove the inactive members.');
  const current = new Map((metadata.participants || []).map((participant) => [participant.id, participant]));
  const candidates = [...new Set(list)].filter((id) => current.has(id) && !isAdmin(current.get(id)));
  if (!candidates.length) return reply('ℹ️ There are no removable inactive members in that list.');

  const numbers = candidates.map((id) => id.split('@')[0]);
  const protectedUsers = await User.find({
    $and: [
      { $or: [{ whatsappNumber: { $in: candidates } }, { phoneNumber: { $in: numbers } }, { userId: { $in: numbers } }] },
      { $or: [{ isTrueOwner: true }, { role: { $in: STAFF_ROLES } }] },
    ],
  }).select('whatsappNumber phoneNumber userId').lean().catch(() => []);
  const protectedIds = new Set(protectedUsers.flatMap((user) => [user.whatsappNumber, user.phoneNumber, user.userId].filter(Boolean)));
  const removable = candidates.filter((id) => !protectedIds.has(id) && !protectedIds.has(id.split('@')[0]));
  if (!removable.length) return reply('🔒 The inactive list contains only protected staff or no longer-present members.');
  await sock.groupParticipantsUpdate(jid, removable, 'remove');
  return reply(`🚫 Removed ${removable.length} inactive member(s):\n${removable.map(mention).join(' ')}`, { mentions: removable });
}

moon({
  name: 'active',
  aliases: ['unactive', 'inactive'],
  category: 'group',
  description: 'Tag active or inactive group members from the current South Africa 12-hour activity window.',
  usage: '.active | .unactive | .inactive',
  async execute(sock, jid, sender, args, m, { reply, isStaff }) {
    if (!jid.endsWith('@g.us')) return reply('❌ This command only works in groups.');
    const metadata = await sock.groupMetadata(jid);
    if (!isStaff && !isAdmin(findParticipantByIdentity(metadata.participants || [], sender))) return reply('❌ You must be a group admin or approved staff member.');
    const command = String(m?.message?.conversation || m?.message?.extendedTextMessage?.text || '').trim().slice(1).split(/\s+/)[0].toLowerCase();
    const mode = command === 'active' ? 'active' : 'inactive';
    const quotedId = contextInfo(m).stanzaId;
    const saved = quotedId ? inactiveLists.get(`${jid}:${quotedId}`) : null;
    if (mode === 'inactive' && saved) return removeInactiveList(sock, jid, saved.members, m, reply);

    const bot = findParticipantByIdentity(metadata.participants || [], getBotIdentity(sock, config));
    const participants = (metadata.participants || []).filter((participant) => participant.id !== bot?.id);
    const bucketStart = GroupActivity.getSouthAfricaBucketStart();
    const rows = await GroupActivity.find({ groupId: jid, bucketStart }).lean();
    const counts = new Map(rows.map((row) => [row.userId, Number(row.count || 0)]));
    const threshold = mode === 'active' ? 15 : 5;
    const members = participants.filter((participant) => mode === 'active'
      ? counts.get(participant.id) >= threshold
      : counts.get(participant.id) <= threshold).map((participant) => participant.id);
    const label = mode === 'active' ? 'ACTIVE MEMBERS' : 'INACTIVE MEMBERS';
    const rule = mode === 'active' ? '15 or more messages' : '5 or fewer messages';
    if (!members.length) return reply(`📊 *${label}*\n\nNo members matched the ${rule} rule in this South Africa 12-hour window.`);
    const lines = [`📊 *${label}*`, `🕛 Window reset: 12:00 AM / 12:00 PM South Africa time`, `📌 Rule: ${rule}`, '', members.map((id) => `${mention(id)} · ${counts.get(id) || 0} messages`).join('\n')];
    const sent = await sock.sendMessage(jid, { text: lines.join('\n'), mentions: members }, { quoted: m });
    if (mode === 'inactive' && sent?.key?.id) {
      inactiveLists.set(`${jid}:${sent.key.id}`, { members, expiresAt: Date.now() + 30 * 60 * 1000 });
      setTimeout(() => inactiveLists.delete(`${jid}:${sent.key.id}`), 30 * 60 * 1000).unref?.();
    }
  },
});
