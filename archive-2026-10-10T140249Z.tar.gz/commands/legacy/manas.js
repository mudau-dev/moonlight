/**
 * commands/legacy/manas.js
 *
 * .mana — View your current Mana balance (User.manas — the currency bought from shop)
 *
 * NOTE: This is SEPARATE from LegacyPlayer.mana (battle mana used in .us combat).
 *   - User.manas  = mana currency bought from shop (this command shows this)
 *   - LegacyPlayer.mana = battle mana used in .us skill commands
 */
const User         = require('../../models/User');
const LegacyPlayer = require('../../models/LegacyPlayer');
const { findOrCreateWhatsApp } = require('../../database/users');

function userNumber(jid) {
  return (jid || '').split('@')[0];
}

// .mana — Show user's mana currency balance (User.manas)
moon({
  name: 'mana',
  aliases: ['mp', 'manas'],
  category: 'legacy',
  description: 'View your current Mana balance',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const userDoc = await findOrCreateWhatsApp(sender, pushName);
      const user    = userDoc.toObject ? userDoc.toObject() : userDoc;

      const manaBalance = user.manas || 0;

      // Also show battle mana for context
      const playerNum = userNumber(sender);
      let battleMana = null;
      try {
        const player = await LegacyPlayer.findOne({
          $or: [
            { whatsappId: sender },
            { whatsappId: playerNum },
          ],
        }).lean();
        if (player) {
          battleMana = { current: player.mana || 0, max: player.maxMana || 0 };
        }
      } catch {}

      let text = `🌙 *Your Mana Balance*\n\n`;
      text += `💰 *Manas (currency):* ${manaBalance.toLocaleString()}\n`;
      if (battleMana !== null) {
        text += `⚔️ *Battle Mana:* ${battleMana.current.toLocaleString()} / ${battleMana.max.toLocaleString()}`;
      }

      return reply(text);
    } catch (err) {
      console.error('[MANA ERROR]', err);
      return reply('❌ Failed to load your mana.');
    }
  }
});

// .addmana — Admin command to add mana currency to a user (User.manas)
moon({
  name: 'addmana',
  category: 'legacy',
  description: 'Add mana currency to a user (Owners/Mods only)',
  roles: ['Mod', 'Owner', 'True Owner', 'CDC'],
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      const target    = mentioned || sender;
      const amountArg = mentioned ? args[1] : args[0];
      const amount    = parseInt(amountArg) || 0;

      if (amount <= 0) {
        return reply('❌ Usage: `.addmana @user <amount>` or `.addmana <amount>`');
      }

      const targetNumber = target.split('@')[0];

      // Find user by multiple ID fields
      const targetUser = await User.findOne({
        $or: [
          { moonId: targetNumber },
          { whatsappNumber: target },
          { whatsappNumber: `${targetNumber}@s.whatsapp.net` },
          { phoneNumber: targetNumber },
        ],
      });

      if (!targetUser) return reply(`❌ @${targetNumber} does not have an account.`);

      // Add to User.manas (currency), NOT LegacyPlayer.mana (battle)
      await User.updateOne(
        { _id: targetUser._id },
        { $inc: { manas: amount } }
      );

      const newBalance = (targetUser.manas || 0) + amount;

      return await sock.sendMessage(jid, {
        text:
          `✅ *Mana Added*\n` +
          `👤 @${targetNumber}\n` +
          `🌙 +${amount.toLocaleString()} manas\n` +
          `💎 New total: ${newBalance.toLocaleString()} manas`,
        mentions: [target]
      }, { quoted: m });
    } catch (err) {
      console.error('[ADDMANA ERROR]', err);
      return reply('❌ Failed to add mana.');
    }
  }
});
