const { findLegacyPlayer } = require('../../utils/legacyUtils');

const PRACTICE_COOLDOWN_MS = 10 * 60 * 1000;
const QUEST_COOLDOWN_MS = 6 * 60 * 60 * 1000;

function duration(ms) {
  const minutes = Math.max(1, Math.ceil(ms / 60000));
  return minutes >= 60 ? `${Math.ceil(minutes / 60)}h` : `${minutes}m`;
}

function awardXp(player, amount) {
  player.xp += amount;
  const levels = [];
  while (player.xp >= player.xpToNext) {
    player.xp -= player.xpToNext;
    player.level += 1;
    player.xpToNext = Math.floor(player.xpToNext * 1.2);
    player.maxHp += 10;
    player.maxMana += 10;
    player.attack += 2;
    player.defense += 1;
    player.hp = Math.min(player.maxHp, player.hp + 10);
    player.mana = Math.min(player.maxMana, player.mana + 10);
    levels.push(player.level);
  }
  return levels;
}

moon({
  name: 'practice',
  aliases: ['train'],
  category: 'legacy',
  description: 'Practice to recover battle mana and gain Legacy XP.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const player = await findLegacyPlayer(sender);
    if (!player) return reply('❌ No Legacy account. Use *.genesis*.');
    const wait = player.lastPracticeAt ? PRACTICE_COOLDOWN_MS - (Date.now() - new Date(player.lastPracticeAt).getTime()) : 0;
    if (wait > 0) return reply(`⏳ You are still recovering from practice. Try again in *${duration(wait)}*.`);

    const xp = 20 + Math.floor(Math.random() * 16);
    const mana = 20 + Math.floor(Math.random() * 16);
    const levels = awardXp(player, xp);
    player.mana = Math.min(player.maxMana, player.mana + mana);
    player.lastPracticeAt = new Date();
    await player.save();
    return reply([
      '⚔️ *MOONLIGHT PRACTICE COMPLETE*',
      `✨ +${xp} XP`,
      `💧 +${mana} battle mana`,
      `📊 Level ${player.level} · XP ${player.xp}/${player.xpToNext}`,
      ...(levels.length ? [`🎉 Level up! You reached level ${levels.join(', ')}.`] : []),
    ].join('\n'));
  },
});

moon({
  name: 'quest',
  aliases: ['quests'],
  category: 'legacy',
  description: 'View or complete your Legacy quest reward cycle.',
  usage: '.quest | .quest complete',
  async execute(sock, jid, sender, args, m, { reply }) {
    const player = await findLegacyPlayer(sender);
    if (!player) return reply('❌ No Legacy account. Use *.genesis*.');
    const action = String(args[0] || '').toLowerCase();
    if (action !== 'complete') {
      const wait = player.lastQuestAt ? QUEST_COOLDOWN_MS - (Date.now() - new Date(player.lastQuestAt).getTime()) : 0;
      return reply([
        '📜 *MOONLIGHT LEGACY QUEST*',
        `*Quest:* ${player.currentQuest || 'Moonlit Training'}`,
        `*Objective:* ${player.currentObjective || 'Practice your class and report back with `.quest complete`.'}`,
        `*Completed quests:* ${player.questsCompleted || 0}`,
        wait > 0 ? `⏳ Next completion reward in *${duration(wait)}*.` : '✅ Your quest reward is ready. Use *.quest complete*.',
      ].join('\n'));
    }

    const wait = player.lastQuestAt ? QUEST_COOLDOWN_MS - (Date.now() - new Date(player.lastQuestAt).getTime()) : 0;
    if (wait > 0) return reply(`⏳ Your last quest reward is still on cooldown. Try again in *${duration(wait)}*.`);
    const xp = 60 + Math.floor(Math.random() * 41);
    const gold = 120 + Math.floor(Math.random() * 81);
    const mana = 25 + Math.floor(Math.random() * 16);
    const levels = awardXp(player, xp);
    player.gold += gold;
    player.mana = Math.min(player.maxMana, player.mana + mana);
    player.questsCompleted = (player.questsCompleted || 0) + 1;
    player.stageProgress = Math.min(100, (player.stageProgress || 0) + 10);
    player.lastQuestAt = new Date();
    player.currentQuest = 'Moonlit Training';
    player.currentObjective = 'Practice your class and report back with `.quest complete`.';
    if (player.questsCompleted >= 5 && !player.achievements.includes('Quest Adept')) player.achievements.push('Quest Adept');
    if (player.questsCompleted >= 20 && !player.achievements.includes('Quest Master')) player.achievements.push('Quest Master');
    await player.save();
    return reply([
      '✅ *QUEST COMPLETE*',
      `✨ +${xp} XP`,
      `💰 +${gold} Gold`,
      `💧 +${mana} battle mana`,
      `📜 Total completed: ${player.questsCompleted}`,
      ...(levels.length ? [`🎉 Level up! You reached level ${levels.join(', ')}.`] : []),
    ].join('\n'));
  },
});
