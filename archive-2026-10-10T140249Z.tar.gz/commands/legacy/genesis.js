const config = require('../../config');

moon({
  name: 'genesis',
  category: 'legacy',
  description: 'Open the Moonlight Legacy character-creation page.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const webUrl = String(config.WEB || process.env.WEB || '').replace(/\/$/, '');
    if (!webUrl) return reply('❌ The Legacy website link has not been configured yet.');

    const starterUrl = `${webUrl}/lagacy/new`;
    return sock.sendMessage(jid, {
      text: [
        '⚔️ *MOONLIGHT LEGACY — BEGIN YOUR JOURNEY*',
        '',
        'Create your Legacy character on the website, choose your class, and return to the bot to continue your adventure.',
        '',
        `🔗 ${starterUrl}`,
      ].join('\n'),
      contextInfo: {
        externalAdReply: {
          title: 'Start Moonlight Legacy',
          body: 'Create your character and choose your class',
          mediaType: 1,
          sourceUrl: starterUrl,
          renderLargerThumbnail: false,
        },
      },
    }, { quoted: m });
  },
});
