/**
 * commands/legacy/battle.js
 * .duelreq @user | .duel yes/no | .us/.a/.atc <skill>
 *
 * NOTE: The old ".use <skill>" battle command has been renamed to .us / .a / .atc
 *       ".use" is now reserved for consuming inventory items (see commands/shop/use.js).
 */

const { findLegacyPlayer } = require('../../utils/legacyUtils');
const LegacyPlayer = require('../../models/LegacyPlayer');
const LegacyBattle = require('../../models/LegacyBattle');
const { generateBattleCard, generateResultCard } = require('../../utils/legacyImageGen');
const { SKILLS } = require('../../utils/skillLibrary');
const { sendFullLinkPreview } = require('../../utils/linkPreview');
const Guild = require('../../models/athers/Guild');

// ── Battle timeout: 5 minutes ─────────────────────────────────────────────────
const BATTLE_TIMEOUT_MS = 5 * 60 * 1000;
// Map of battleId → timeout handle
const battleTimers = new Map();

function clearBattleTimer(battleId) {
  const t = battleTimers.get(String(battleId));
  if (t) {
    clearTimeout(t);
    battleTimers.delete(String(battleId));
  }
}

function setBattleTimer(sock, jid, m, battleId) {
  clearBattleTimer(battleId);
  const t = setTimeout(async () => {
    try {
      const battle = await LegacyBattle.findById(battleId);
      if (!battle || battle.status !== 'active') return;
      battle.status = 'finished';
      await battle.save();
      battleTimers.delete(String(battleId));
      await sock.sendMessage(jid, {
        text: 'No move was made in the last 5 minutes. This battle has ended.',
      }, { quoted: m });
    } catch {}
  }, BATTLE_TIMEOUT_MS);
  battleTimers.set(String(battleId), t);
}

// ── Battle lock: one active legacy battle per group ───────────────────────────
async function getActiveBattleInGroup(jid) {
  // Find any active battle where the groupJid matches
  return LegacyBattle.findOne({ groupJid: jid, status: 'active' });
}

function effectsFor(combatant) {
  if (!combatant.effects || typeof combatant.effects !== 'object') combatant.effects = {};
  return combatant.effects;
}

function consumeTurnBlock(combatant) {
  const effects = effectsFor(combatant);
  const blocks = { stun: 'stunned', freeze: 'frozen', paralyze: 'paralyzed', fear: 'afraid' };
  for (const [effect, label] of Object.entries(blocks)) {
    if ((effects[effect] || 0) > 0) {
      effects[effect] -= 1;
      return label;
    }
  }
  return null;
}

function applyDamage(attacker, defender, baseDamage) {
  const attackEffects = effectsFor(attacker);
  const defenseEffects = effectsFor(defender);
  if ((defenseEffects.invulnerable || 0) > 0) {
    defenseEffects.invulnerable -= 1;
    return { damage: 0, message: `${defender.name} is invulnerable and blocked all damage.` };
  }
  if ((defenseEffects.dodge || 0) > 0 || (defenseEffects.stealth || 0) > 0) {
    defenseEffects.dodge = Math.max(0, (defenseEffects.dodge || 0) - 1);
    defenseEffects.stealth = Math.max(0, (defenseEffects.stealth || 0) - 1);
    return { damage: 0, message: `${defender.name} evaded the attack.` };
  }
  const buff = attackEffects.buff_atk || 0;
  const critical = (attackEffects.crit_buff || 0) > 0 && Math.random() < 0.30;
  let damage = Math.max(1, Math.floor((baseDamage + buff) * (critical ? 1.5 : 1)));
  if ((defenseEffects.shield || 0) > 0) {
    defenseEffects.shield -= 1;
    damage = 0;
  }
  defender.hp = Math.max(0, defender.hp - damage);
  if (damage > 0 && (defenseEffects.reflect || 0) > 0) attacker.hp = Math.max(0, attacker.hp - Math.ceil(damage * .25));
  return { damage, message: critical ? 'Critical hit!' : '' };
}

function applySkillEffect(skill, attacker, defender) {
  if (!skill.effect || skill.effect === 'none' || skill.effect === 'multi_hit' || Math.random() > Number(skill.chance || 0)) return '';
  const attackerEffects = effectsFor(attacker);
  const defenderEffects = effectsFor(defender);
  const targetEffects = new Set(['stun', 'freeze', 'paralyze', 'fear', 'silence', 'blind', 'burn', 'poison', 'bleed', 'curse']);
  const selfEffects = { buff_atk: 3, buff_def: 3, dodge: 1, stealth: 1, crit_buff: 2, speed_buff: 2, shield: 2, invulnerable: 1, reflect: 2 };
  if (skill.effect === 'cleanse') {
    for (const effect of targetEffects) delete attackerEffects[effect];
    return `${attacker.name} cleansed all debuffs.`;
  }
  if (targetEffects.has(skill.effect)) {
    defenderEffects[skill.effect] = Math.max(defenderEffects[skill.effect] || 0, ['burn', 'poison', 'bleed', 'curse'].includes(skill.effect) ? 3 : 1);
    return `${defender.name} is affected by *${skill.effect}*.`;
  }
  if (Object.hasOwn(selfEffects, skill.effect)) {
    attackerEffects[skill.effect] = Math.max(attackerEffects[skill.effect] || 0, selfEffects[skill.effect]);
    return `${attacker.name} gained *${skill.effect.replace('_', ' ')}*.`;
  }
  return '';
}

// ─────────────────────────────────────────────────────────────────────────────

moon({
  name: 'duelreq',
  aliases: ['dr', 'dq', 'challenge-user'],
  category: 'legacy',
  description: 'Challenge a user to a Legacy duel',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!jid.endsWith('@g.us')) {
      return reply('❌ Duels can only be played in groups.');
    }

    // Group check
    const Group = require('../../models/athers/Group');
    const group = await Group.findOne({ groupId: jid });
    if (!group || !group.legacyBattlesEnabled) {
      const officialGroupLink = 'https://chat.whatsapp.com/FeNoHhQm1lvLSVKSS43Zaq';
      return sendFullLinkPreview(
        sock,
        jid,
        m,
        officialGroupLink,
        `❌ *Legacy Battles* are disabled in this group.\n\nJoin the official Legacy battle group to challenge other players:\n${officialGroupLink}`
      );
    }

    // Battle lock: only one active battle per group
    const activeBattle = await getActiveBattleInGroup(jid);
    if (activeBattle) {
      const p1Name = activeBattle.player1Data?.name || activeBattle.player1Id.split('@')[0];
      return reply(`Hold on @${sender.split('@')[0]}, there is already an active battle in this group.`, { mentions: [sender] });
    }

    const target =
      m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ||
      m.message?.extendedTextMessage?.contextInfo?.participant;

    if (!target) {
      return reply(
        '❌ Mention a user or reply to one of their messages.\n\n' +
        'Examples:\n' +
        '• .duelreq @user\n' +
        '• Reply to a user\'s message with .duelreq'
      );
    }

    if (target === sender) return reply('❌ You cannot duel yourself.');

    const p1 = await findLegacyPlayer(sender);
    const p2 = await findLegacyPlayer(target);

    if (!p1) return reply('❌ You need a Legacy account. Use *.genesis*.');
    if (!p2) return reply('❌ That user does not have a Legacy account.');
    if (!p1.class || !p2.class) return reply('❌ Both players must choose a class first.');

    // Check if either player is already in a battle
    const active = await LegacyBattle.findOne({
      $or: [{ player1Id: sender }, { player2Id: sender }, { player1Id: target }, { player2Id: target }],
      status: 'active'
    });
    if (active) return reply('⚠️ One of you is already in a battle!');

    await LegacyBattle.create({
      player1Id: sender,
      player2Id: target,
      groupJid: jid,
      player1Data: { name: p1.name, hp: p1.hp, maxHp: p1.maxHp, mana: p1.mana, maxMana: p1.maxMana, level: p1.level, rank: p1.rank },
      player2Data: { name: p2.name, hp: p2.hp, maxHp: p2.maxHp, mana: p2.mana, maxMana: p2.maxMana, level: p2.level, rank: p2.rank },
      status: 'pending',
      turn: target,
    });

    return reply(
      `⚔️ *DUEL CHALLENGE*\n\n@${sender.split('@')[0]} challenged @${target.split('@')[0]}!\n\nType *.duel yes* to accept or *.duel no* to decline.`,
      { mentions: [sender, target] }
    );
  }
});

moon({
  name: 'duel',
  category: 'legacy',
  async execute(sock, jid, sender, args, m, { reply }) {
    const choice = (args[0] || '').toLowerCase();
    const battle = await LegacyBattle.findOne({ player2Id: sender, status: 'pending' }).sort({ createdAt: -1 });

    if (!battle) return reply('❌ You have no pending duel requests.');

    if (choice === 'no') {
      battle.status = 'finished';
      await battle.save();
      return reply('❌ Duel declined.');
    }

    if (choice === 'yes') {
      battle.status = 'active';
      battle.round = 1;
      await battle.save();

      // Start battle timeout
      setBattleTimer(sock, jid, m, battle._id);

      let p1Av = null, p2Av = null;
      try { p1Av = await sock.profilePictureUrl(battle.player1Id, 'image'); } catch {}
      try { p2Av = await sock.profilePictureUrl(battle.player2Id, 'image'); } catch {}

      const img = await generateBattleCard(
        { ...battle.player1Data, avatarUrl: p1Av },
        { ...battle.player2Data, avatarUrl: p2Av },
        1,
        battle.player2Data.name
      );

      return await sock.sendMessage(jid, {
        image: img,
        caption: `⚔️ *DUEL ACCEPTED!* ⚔️\n\nRound 1\nIt is *${battle.player2Data.name}'s* turn!\nUse *.us <skill name>* to attack.`
      }, { quoted: m });
    }
  }
});

// ── Core battle action handler (shared by .us, .a, .atc) ─────────────────────
async function handleBattleAction(sock, jid, sender, args, m, reply) {
  try {
    const action = (args[0] || '').toLowerCase();

    // Handle run/leave
    if (action === 'run' || action === 'leave') {
      const battle = await LegacyBattle.findOne({
        $or: [{ player1Id: sender }, { player2Id: sender }],
        status: 'active'
      });
      if (!battle) return reply('❌ You are not in an active battle.');

      clearBattleTimer(battle._id);
      battle.status = 'finished';
      await battle.save();

      const playerData = battle.player1Id === sender ? battle.player1Data : battle.player2Data;
      return reply(`🏃 *${playerData.name}* fled from the battle!`);
    }

    const battle = await LegacyBattle.findOne({
      $or: [{ player1Id: sender }, { player2Id: sender }],
      status: 'active'
    });

    if (!battle) return reply('❌ You are not in an active battle.');
    if (battle.turn !== sender) {
      const waitingFor = battle.turn === battle.player1Id ? battle.player1Data.name : battle.player2Data.name;
      return reply(`⏳ It is not your turn! Waiting for *${waitingFor}*.`);
    }

    const skillName = args.join(' ').toLowerCase();
    const player = await findLegacyPlayer(sender);

    const skill = SKILLS.find(s => s.name.toLowerCase() === skillName);
    if (!skill) return reply('❌ Skill not found. Check *.skills* for your moves.');

    // Check if player has the skill
    if (!player.skills.includes(skill.name)) return reply(`❌ You haven't unlocked *${skill.name}* yet.`);

    const isP1 = battle.player1Id === sender;
    const attacker = isP1 ? battle.player1Data : battle.player2Data;
    const defender = isP1 ? battle.player2Data : battle.player1Data;

    const turnBlock = consumeTurnBlock(attacker);
    if (turnBlock) {
      battle.turn = isP1 ? battle.player2Id : battle.player1Id;
      battle.round += 1;
      await battle.save();
      return sendBattleUpdate(sock, jid, m, battle, `💫 *${attacker.name}* is ${turnBlock} and loses this turn!`);
    }

    const activeEffects = effectsFor(attacker);
    if ((activeEffects.silence || 0) > 0) {
      activeEffects.silence -= 1;
      battle.turn = isP1 ? battle.player2Id : battle.player1Id;
      battle.round += 1;
      await battle.save();
      return sendBattleUpdate(sock, jid, m, battle, `🔇 *${attacker.name}* is silenced and cannot use a skill this turn!`);
    }
    if (attacker.mana < skill.mana) return reply(`💧 Not enough mana! (Need ${skill.mana}, have ${attacker.mana})`);

    // Apply skill and persist declared status/buff effects.
    attacker.mana -= skill.mana;
    let log = `*${attacker.name}* used *${skill.name}*!\n`;

    if (skill.dmg > 0) {
      const baseDamage = Math.floor(skill.dmg * (1 + (attacker.level * 0.05)));
      const hits = skill.effect === 'multi_hit' ? Math.max(2, Number(skill.chance) || 2) : 1;
      let totalDamage = 0;
      for (let hit = 0; hit < hits && defender.hp > 0; hit += 1) {
        const outcome = applyDamage(attacker, defender, baseDamage);
        totalDamage += outcome.damage;
        if (outcome.message) log += `${outcome.message}\n`;
      }
      log += `💥 Dealt *${totalDamage}* damage to ${defender.name}${hits > 1 ? ` across ${hits} hits` : ''}!\n`;
    } else if (skill.dmg < 0) {
      const heal = Math.abs(skill.dmg);
      attacker.hp = Math.min(attacker.maxHp, attacker.hp + heal);
      log += `💚 Restored *${heal}* HP!\n`;
    }

    const effectLog = applySkillEffect(skill, attacker, defender);
    if (effectLog) log += `✨ ${effectLog}\n`;

    // Check for win
    if (defender.hp <= 0) {
      clearBattleTimer(battle._id);
      battle.status = 'finished';
      battle.winner = attacker.name;
      battle.loser = defender.name;
      await battle.save();
      return await handleWin(sock, jid, m, battle, isP1 ? sender : battle.player2Id, isP1 ? battle.player2Id : sender);
    }

    // Switch turn
    battle.turn = isP1 ? battle.player2Id : battle.player1Id;
    battle.round += 1;
    await battle.save();

    // Reset battle timeout on each move
    setBattleTimer(sock, jid, m, battle._id);

    // If PvE, trigger bot turn
    if (battle.isPvE && battle.turn === 'BOT_OPPONENT') {
      return await handleBotTurn(sock, jid, m, battle, log);
    }

    return await sendBattleUpdate(sock, jid, m, battle, log);

  } catch (err) {
    console.error('[BATTLE ACTION ERROR]', err);
    return reply('❌ Battle error. Please try again.');
  }
}

// .us — primary battle action command
moon({
  name: 'us',
  aliases: ['a', 'atc'],
  category: 'legacy',
  description: 'Use a skill in battle (.us <skill> | .us run | .us leave)',
  async execute(sock, jid, sender, args, m, { reply }) {
    return handleBattleAction(sock, jid, sender, args, m, reply);
  }
});

// ── Bot turn handler ──────────────────────────────────────────────────────────
async function handleBotTurn(sock, jid, m, battle, prevLog) {
  const bot = battle.player2Data;
  const player = battle.player1Data;

  const botSkills = ['Fireball', 'Slash', 'Heal', 'Heavy Strike'];
  const skillName = botSkills[Math.floor(Math.random() * botSkills.length)];
  const skill = SKILLS.find(s => s.name === skillName);

  let log = prevLog + `\n🤖 *Bot's Turn:*\n`;
  bot.mana = Math.min(bot.maxMana, bot.mana + 10);

  if (skill && bot.mana >= skill.mana) {
    bot.mana -= skill.mana;
    if (skill.dmg > 0) {
      const dmg = Math.floor(skill.dmg * (1 + (bot.level * 0.05)));
      player.hp = Math.max(0, player.hp - dmg);
      log += `🤖 Bot used *${skill.name}* and dealt *${dmg}* damage!\n`;
    } else {
      const heal = Math.abs(skill.dmg);
      bot.hp = Math.min(bot.maxHp, bot.hp + heal);
      log += `🤖 Bot used *${skill.name}* and healed *${heal}* HP!\n`;
    }
  } else {
    log += `🤖 Bot rested to recover mana.\n`;
  }

  if (player.hp <= 0) {
    clearBattleTimer(battle._id);
    battle.status = 'finished';
    battle.winner = 'Bot';
    battle.loser = player.name;
    await battle.save();
    return await handleWin(sock, jid, m, battle, 'BOT_OPPONENT', battle.player1Id);
  }

  battle.turn = battle.player1Id;
  battle.round += 1;
  await battle.save();

  return await sendBattleUpdate(sock, jid, m, battle, log);
}

async function sendBattleUpdate(sock, jid, m, battle, log) {
  let p1Av = null, p2Av = null;
  try { p1Av = await sock.profilePictureUrl(battle.player1Id, 'image'); } catch {}
  try { if (!battle.isPvE) p2Av = await sock.profilePictureUrl(battle.player2Id, 'image'); } catch {}

  const img = await generateBattleCard(
    { ...battle.player1Data, avatarUrl: p1Av },
    { ...battle.player2Data, avatarUrl: p2Av || 'https://files.catbox.moe/qxd31v.jpg' },
    battle.round,
    battle.turn === 'BOT_OPPONENT' ? 'Bot' : (battle.turn === battle.player1Id ? battle.player1Data.name : battle.player2Data.name)
  );

  const turnName = battle.turn === 'BOT_OPPONENT'
    ? 'Bot'
    : (battle.turn === battle.player1Id ? battle.player1Data.name : battle.player2Data.name);

  return await sock.sendMessage(jid, {
    image: img,
    caption: `⚔️ *BATTLE UPDATE* ⚔️\n\n${log}\nRound ${battle.round}\nIt is *${turnName}'s* turn!\nUse *.us <skill>* | *.us run* to flee`
  }, { quoted: m });
}

async function awardLegacyGuildReward(winnerId) {
  const normalized = String(winnerId || '').split('@')[0];
  const guild = await Guild.findOne({ members: { $in: [winnerId, normalized, `${normalized}@s.whatsapp.net`] } });
  if (!guild) return null;
  guild.xp = Number(guild.xp || 0) + 1;
  const threshold = Math.max(10, Number(guild.level || 1) * 10);
  if (guild.xp >= threshold) {
    guild.level = Number(guild.level || 1) + 1;
    guild.xp = 0;
  }
  await guild.save();
  return guild;
}

async function handleWin(sock, jid, m, battle, winnerId, loserId) {
  const isBotWinner = winnerId === 'BOT_OPPONENT';
  const isBotLoser = loserId === 'BOT_OPPONENT';

  const xpGain = 50 + (battle.round * 5);
  const goldGain = 100 + (battle.round * 10);

  let resultData = {
    name: isBotWinner ? 'Bot' : battle.player1Data.name,
    xpEarned: xpGain,
    goldEarned: goldGain,
    newLevel: null,
  };

  if (!isBotWinner) {
    const winner = await findLegacyPlayer(winnerId);
    if (winner) {
      winner.wins += 1;
      winner.xp += xpGain;
      winner.gold += goldGain;

      if (winner.xp >= winner.xpToNext) {
        winner.level += 1;
        winner.xp = 0;
        winner.xpToNext = Math.floor(winner.xpToNext * 1.2);
        resultData.newLevel = winner.level;

        if (winner.level % 5 === 0) {
          const newSkill = SKILLS.find(s => !winner.skills.includes(s.name));
          if (newSkill) winner.skills.push(newSkill.name);
        }
      }

      if (battle.isPvE) {
        winner.stageProgress += 25;
        if (winner.stageProgress >= 100) {
          winner.stage += 1;
          winner.stageProgress = 0;
        }
      }

      await winner.save();
      const guild = await awardLegacyGuildReward(winnerId);
      resultData.guildName = guild?.name || null;
      resultData.guildLevel = guild?.level || null;
      resultData.name = winner.name;
      resultData.level = winner.level;
      resultData.wins = winner.wins;
      resultData.losses = winner.losses;
      resultData.stage = winner.stage;
      resultData.stageProgress = winner.stageProgress;
    }
  }

  if (!isBotLoser && loserId !== 'BOT_OPPONENT') {
    const loser = await findLegacyPlayer(loserId);
    if (loser) {
      loser.losses += 1;
      await loser.save();
    }
  }

  let winnerAv = null;
  try { if (!isBotWinner) winnerAv = await sock.profilePictureUrl(winnerId, 'image'); } catch {}

  const img = await generateResultCard(isBotWinner ? 'defeat' : 'victory', { ...resultData, avatarUrl: winnerAv });

  return await sock.sendMessage(jid, {
    image: img,
    caption: isBotWinner
      ? `💀 *DEFEAT!* The Guardian was too strong.\nTry again after leveling up!`
      : `🏆 *VICTORY!* ${resultData.name} won the battle!\n\n✨ XP: +${xpGain}\n💰 Gold: +${goldGain}${resultData.newLevel ? `\n🎉 LEVEL UP: ${resultData.newLevel}!` : ''}${resultData.guildName ? `\n🏰 ${resultData.guildName} gained guild progress!` : ''}`
  }, { quoted: m });
}

// Export timer helpers so other battle systems can reuse them
module.exports = { clearBattleTimer, setBattleTimer, battleTimers };
