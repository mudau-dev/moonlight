const { checkCooldown, formatTime } = require('../../utils/cooldown');
const User = require('../../models/User');
const { resolveMessageTarget, resolvePhoneJid, sameIdentity } = require('../../utils/adminIdentity');

moon({
  name: "rob",
  category: "economy",
  description: "Attempt to rob another user using a pistol",
  usage: ".rob @user",
  cooldown: 3,

  async execute(sock, jid, sender, args, message, { reply }) {
    const ROB_CD = 30 * 60 * 1000;
    const MAX_STEAL = 5000;
    const normalizedSender = await resolvePhoneJid(sock, sender) || sender;
    const userId = normalizedSender.split('@')[0];

    try {
      const target = await resolveMessageTarget(sock, message, args);
      if (!target) return reply("❌ Mention, reply, phone JID, WhatsApp LID, or database ID could not be resolved.");
      if (sameIdentity(target, normalizedSender)) return reply("❌ You can't rob yourself.");

      const robber = await User.findOne({ $or: [{ userId }, { whatsappNumber: normalizedSender }, { phoneNumber: normalizedSender }] });
      if (!robber) return reply('❌ Your user record could not be found.');
      const targetId = target.split('@')[0];
      const victim = await User.findOne({ $or: [{ userId: targetId }, { whatsappNumber: target }, { phoneNumber: target }, { lid: target }] });

      if (!victim) return reply("❌ Target user was not found in the database.");
      const protectedRoles = new Set(['Owner', 'True Owner', 'Mod', 'Guardian']);
      const victimRole = String(victim.role || '').trim();
      if (protectedRoles.has(victimRole) || victim.isTrueOwner === true) {
        return reply(`🔒🌙 *anti lord protect*\noi.oi.oi how dare you use this command on a *moonLord* have some shame @${targetId}`, { mentions: [target] });
      }
      const victimId = String(victim.userId || victim.phoneNumber || targetId);

      // Check for Pistol
      const hasPistol = robber.inventory ? robber.inventory.some(item => item.name.toLowerCase().includes("pistol")) : false;
      if (!hasPistol) {
        return reply("❌ You need a *Pistol* to rob someone!\n🛒 Buy one at the `.shop` for 790 coins.");
      }

      const { onCooldown, remaining } = checkCooldown(robber.lastRob, ROB_CD);
      if (onCooldown) {
        return reply(`⏳ Wait *${formatTime(remaining)}* before robbing again.`);
      }

      if ((victim.balance || 0) < 100) {
        return reply(`❌ @${targetId} is too broke.`, { mentions: [target] });
      }

      const success = Math.random() < 0.45;
      await User.updateOne({ userId }, { $set: { lastRob: new Date() } });

      if (success) {
        let stolen = Math.floor((victim.balance || 0) * (0.05 + Math.random() * 0.15));
        stolen = Math.min(stolen, MAX_STEAL, victim.balance);

        await User.updateOne({ $or: [{ userId: victimId }, { whatsappNumber: victim.whatsappNumber }, { phoneNumber: victim.phoneNumber }] }, { $inc: { balance: -stolen } });
        await User.updateOne({ userId }, { $inc: { balance: stolen } });

        return reply(`🦹 *Robbery Success*\nYou stole *${stolen.toLocaleString()}* coins from @${victimId}\n💰 Your Balance: ${(robber.balance + stolen).toLocaleString()}`, { mentions: [target] });
      } else {
        let fine = Math.floor((robber.balance || 0) * 0.1);
        fine = Math.min(fine, 3000, robber.balance);

        await User.updateOne({ userId }, { $inc: { balance: -fine } });
        return reply(`🚔 *Robbery Failed*\nYou got caught and lost *${fine.toLocaleString()}* coins.\n💰 Your Balance: ${(robber.balance - fine).toLocaleString()}`);
      }
    } catch (err) {
      console.error("Rob error:", err);
      return reply("❌ Robbery system failed.");
    }
  }
});
