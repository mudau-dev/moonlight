const User = require('../../models/User');

function phoneOf(jid = '') {
  return String(jid).split(':')[0].split('@')[0].replace(/\D/g, '');
}

moon({
  name: 'richg',
  aliases: ['group-rich', 'grich'],
  category: 'economy',
  description: 'Show the richest members in this group.',
  usage: '.richg',
  groupOnly: true,
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const metadata = await sock.groupMetadata(jid);
      const numbers = [...new Set((metadata.participants || []).map((member) => phoneOf(member.id)).filter((number) => number.length >= 7))];
      if (!numbers.length) return reply('❌ No registered members were found in this group.');
      const users = await User.find({ $or: [{ whatsappNumber: { $in: numbers } }, { phoneNumber: { $in: numbers } }, { userId: { $in: numbers } }] }).lean();
      const byNumber = new Map();
      for (const user of users) for (const key of [user.whatsappNumber, user.phoneNumber, user.userId]) if (key) byNumber.set(phoneOf(key), user);
      const ranked = numbers.map((number) => ({ number, user: byNumber.get(number) })).filter(({ user }) => user && String(user.username || '').trim() && user.username !== 'Unknown').sort((a, b) => Number(b.user.balance || 0) + Number(b.user.bank || 0) - Number(a.user.balance || 0) - Number(a.user.bank || 0)).slice(0, 10);
      if (!ranked.length) return reply('❌ No registered group members were found.');
      const lines = ranked.map(({ user }, index) => `${index + 1}. *${user.username}* — ${((Number(user.balance) || 0) + (Number(user.bank) || 0)).toLocaleString()} coins`);
      return reply(`🏆 *MOONLIGHT HAVEN · GROUP RICH LIST*\n\n*${metadata.subject || 'This group'}*\nTop ${ranked.length} members by wallet + bank\n\n${lines.join('\n')}`);
    } catch (error) {
      console.error('[RICHG ERROR]', error);
      return reply('❌ I could not load this group rich list right now.');
    }
  },
});
