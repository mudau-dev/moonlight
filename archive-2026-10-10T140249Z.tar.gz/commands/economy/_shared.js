const { findOrCreateWhatsApp, updateUser } = require('../../database/users');
const { sendEconomyCard } = require('./economyCard');
const config = require('../../config');
function money(n) {
  return Math.floor(Number(n) || 0).toLocaleString();
}

function cleanAmount(raw) {
  if (raw === undefined || raw === null) return NaN;
  const str = String(raw).replace(/,/g, '').trim().toLowerCase();
  const suffixes = { k: 1e3, m: 1e6, b: 1e9, t: 1e12 };
  const match = str.match(/^(\d+(?:\.\d+)?)([kmbt])?$/);
  if (!match) return NaN;
  return Math.floor(Number(match[1]) * (suffixes[match[2]] || 1));
}

async function getUser(sender, message) {
  const pushName = message?.pushName || message?.verifiedBizName || 'User';
  return findOrCreateWhatsApp(sender, pushName);
}

function normalizeItemValue(value) {
  return String(value || '').trim().toLowerCase().replace(/[\s_]+/g, '-');
}

/**
 * Checks both historical name-only inventory records and current stable item IDs.
 * Web purchases store `{ id, name }`, while some older bot records may be strings.
 */
function hasInventoryItem(user, { id, name }) {
  const targetIds = new Set([normalizeItemValue(id), normalizeItemValue(name)]);
  return (Array.isArray(user?.inventory) ? user.inventory : []).some((entry) => {
    if (typeof entry === 'string') return targetIds.has(normalizeItemValue(entry));
    return targetIds.has(normalizeItemValue(entry?.id)) || targetIds.has(normalizeItemValue(entry?.name));
  });
}

/**
 * PLAIN TEXT MESSAGE SENDER
 * Removed externalAdReply (previews) because non-Business users often can't see them.
 */
async function preview(sock, jid, message, title, body, text, thumbJid) {
  try {
    await sock.sendMessage(jid, { text }, { quoted: message });
  } catch (err) {
    console.error('[ECONOMY] Plain text send error:', err);
  }
}

function parseWalletAmount(args, user) {
  const raw = String(args[0] || '').toLowerCase();
  if (raw === 'all' || raw === 'max') return Math.floor(Number(user.balance) || 0);
  if (raw === 'half') return Math.floor((Number(user.balance) || 0) / 2);
  return cleanAmount(raw);
}

function parseBankAmount(args, user) {
  const raw = String(args[0] || '').toLowerCase();
  if (raw === 'all' || raw === 'max') return Math.floor(Number(user.bank) || 0);
  if (raw === 'half') return Math.floor((Number(user.bank) || 0) / 2);
  return cleanAmount(raw);
}

function validAmount(amount) {
  return typeof amount === 'number' && !isNaN(amount) && amount > 0;
}

function webCommandLink(command) {
  const base = String(config.WEB || process.env.WEB || '').replace(/\/$/, '');
  return base ? `${base}/${String(command).replace(/^\//, '')}` : '';
}

function economyCaption(text, command) {
  return text;
}

function getMentionedJid(message, args) {
  const ctx = message?.message?.extendedTextMessage?.contextInfo || message?.message?.imageMessage?.contextInfo || message?.message?.videoMessage?.contextInfo || {};
  const mentioned = ctx.mentionedJid?.[0] || ctx.participant;
  if (mentioned) return mentioned;
  const raw = String(args[0] || '').replace(/[^0-9]/g, '');
  if (raw.length >= 7) return raw + '@s.whatsapp.net';
  return null;
}

module.exports = {
  money,
  getUser,
  updateUser,
  preview,
  sendEconomyCard,
  cleanAmount,
  hasInventoryItem,
  parseWalletAmount,
  parseBankAmount,
  validAmount,
  getMentionedJid,
  webCommandLink,
  economyCaption,
};
