const { money, getUser, sendEconomyCard, economyCaption } = require('./_shared');

moon({
  name: 'bank',
  aliases: ['bk'],
  category: 'economy',
  description: 'Check your bank account.',
  usage: '.bank',

  async execute(sock, jid, sender, args, message, { reply }) {
    try {
      const user = await getUser(sender, message);

            await sendEconomyCard(sock, jid, message, { profileJid: sender, title: 'BANK ACCOUNT', subtitle: 'Wallet + bank overview', lines: [{ label: 'Wallet', value: `$${money(user.balance)}` }, { label: 'Bank', value: `$${money(user.bank)}` }, { label: 'Total', value: `$${money(user.balance + user.bank)}` }], caption: economyCaption(`🏦 *ACCOUNT BALANCE*\n💰 *Wallet:* $${money(user.balance)}\n🏦 *Bank:* $${money(user.bank)}\n💎 *Total:* $${money(user.balance + user.bank)}`, 'bank') });

    } catch (err) {
      console.error("Bank error:", err);
      return reply("❌ Could not fetch your bank.");
    }
  }
});