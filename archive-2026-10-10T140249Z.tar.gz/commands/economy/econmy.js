// The economy overview is intentionally merged into commands/owner/dtb.js.
// This file remains as a compatibility placeholder so the loader does not
// register a second `.economy` implementation.
module.exports = {};
