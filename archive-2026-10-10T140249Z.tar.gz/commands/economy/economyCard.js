/**
 * Text-only economy response sender.
 * Deliberately avoids generated images and external-ad/URL preview cards.
 */
async function sendEconomyCard(sock, jid, message, { title, subtitle, lines = [], caption }) {
  const fallback = [
    `✦ *${title || 'MOONLIGHT HAVEN'}*`,
    subtitle ? `_${subtitle}_` : '',
    ...lines.map((line) => `${line.label}: *${line.value}*`),
  ].filter(Boolean).join('\n');
  return sock.sendMessage(jid, { text: caption || fallback }, { quoted: message });
}

module.exports = { sendEconomyCard };
