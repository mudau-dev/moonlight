const { money, getUser, sendEconomyCard, hasInventoryItem } = require('./_shared');
const { checkCooldown, formatTime } = require('../../utils/cooldown');

moon({
  name: 'fish',
  category: 'economy',
  description: 'Fish for coins. Requires a Fishing Rod.',
  usage: '.fish',
  async execute(sock, jid, sender, args, message, { reply }) {
    try {
      const user = await getUser(sender, message);
      if (!hasInventoryItem(user, { id: 'item:fishing-rod', name: 'Fishing Rod' })) {
        return reply('❌ You need a *Fishing Rod* to fish. Buy one from the shop first with `.shop`.');
      }

      const cooldown = 10 * 60 * 1000;
      const { onCooldown, remaining } = checkCooldown(user.lastFish ? new Date(user.lastFish) : null, cooldown);
      if (onCooldown) return reply(`⏳ The lake is quiet. Try again in *${formatTime(remaining)}*.`);

      const catches = [
        ['Small Fish', 60], ['Salmon', 120], ['Golden Carp', 250], ['Treasure Chest', 500], ['Legendary Tuna', 750],
      ];
      const caught = catches[Math.floor(Math.random() * catches.length)];
      const earned = caught[1] + Math.floor(Math.random() * 75);
      user.balance += earned;
      user.totalEarned += earned;
      user.lastFish = new Date();
      await user.save();

      return sendEconomyCard(sock, jid, message, { profileJid: sender, title: 'FISHING COMPLETE', subtitle: caught[0], lines: [{ label: 'Value', value: `+$${money(earned)}` }, { label: 'Wallet', value: `$${money(user.balance)}` }], caption: `🎣 *Caught:* ${caught[0]}\n💵 *Value:* +$${money(earned)}\n🪙 *Wallet:* $${money(user.balance)}` });
    } catch (err) {
      console.error('Fish error:', err);
      return reply('❌ Fishing failed. Please try again.');
    }
  },
});
