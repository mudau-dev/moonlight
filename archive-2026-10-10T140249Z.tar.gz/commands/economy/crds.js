const Cooldown = require('../../models/athers/Cooldowns');
const {
  CASINO_USE_LIMIT,
  CASINO_KEY_PREFIX,
  RACE_USE_LIMIT,
  RACE_RESET_MS,
  formatCooldownTime,
  getCasinoQuotaEntry,
} = require('../gambling/_shared');

// Registered commands in the gambling category. Each command has its own quota.
const CASINO_COMMANDS = [
  'bet', 'blackjack', 'casino', 'coinflip', 'db', 'dice',
    'gamble', 'jackpot', 'poker', 'roulette', 'slots',
];

moon({
  name: 'cds',
  aliases: ['cooldowns', 'casinoquota'],
  category: 'economy',
  description: 'View command cooldowns and casino daily-use quotas.',

  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const data = await Cooldown.findOne({ userId: sender });
      const now = Date.now();
      const commandEntries = data?.commands ? Array.from(data.commands.entries()) : [];
      const commandMap = new Map(commandEntries);

      const raceEntry = commandMap.get('casino:race:20h');
      const raceExpired = Boolean(raceEntry?.cooldownUntil && raceEntry.cooldownUntil <= now);
      const raceUsed = raceExpired ? 0 : Math.min(RACE_USE_LIMIT, Number(raceEntry?.count) || 0);
      const raceLocked = Boolean(raceEntry?.cooldownUntil && raceEntry.cooldownUntil > now);
      const raceLine = raceLocked
        ? `• .race — *${raceUsed}/${RACE_USE_LIMIT}* used · 🔒 reset in *${formatCooldownTime(raceEntry.cooldownUntil - now)}*`
        : `• .race — *${raceUsed}/${RACE_USE_LIMIT}* used · ${RACE_USE_LIMIT - raceUsed} left · 20h reset`;

      const casinoLines = CASINO_COMMANDS.map((command) => {
        const key = `${CASINO_KEY_PREFIX}${command}`;
        const quota = getCasinoQuotaEntry(key, commandMap.get(key), now);
        const base = `• \`.${command}\` — *${quota.used}/${CASINO_USE_LIMIT}* used · ${quota.remaining} left`;
        return quota.locked
          ? `${base}\n  ↳ 🔒 Reset in *${formatCooldownTime(quota.resetIn)}*`
          : base;
      });

      const activeCooldowns = [];
      for (const [command, entry] of commandEntries) {
        if (!entry || String(command).startsWith(CASINO_KEY_PREFIX)) continue;
        if ((entry.cooldownUntil || 0) > now) {
          activeCooldowns.push(
            `• \`.${command}\` — ready in *${formatCooldownTime(entry.cooldownUntil - now)}*`
          );
        }
      }

      const text = [
        '🌙 *MOONLIGHT STATUS*',
        '_Cooldowns and casino access_',
        '',
        `🎰 *CASINO QUOTAS* · ${CASINO_USE_LIMIT} uses each`,
        '_Each standard casino command has its own 5-hour reset._',
        ...casinoLines,
        '',
        `🏁 *RACE QUOTA* · ${RACE_USE_LIMIT} uses each · ${formatCooldownTime(RACE_RESET_MS)} reset`,
        raceLine,
        '',
        '⏱️ *ACTIVE COOLDOWNS*',
        ...(activeCooldowns.length ? activeCooldowns : ['• Everything is ready.']),
        '',
        '_Play smart in Moonlight Haven._',
      ].join('\n');

      return reply(text);
    } catch (error) {
      console.error('[CDS ERROR]', error);
      return reply('❌ Failed to fetch your cooldowns and casino quotas.');
    }
  },
});
