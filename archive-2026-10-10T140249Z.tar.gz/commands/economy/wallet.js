const { money, getUser, sendEconomyCard, economyCaption } = require('./_shared');

moon({
  name: 'balance',
  aliases: ['bal', 'money', 'wallet'],
  category: 'economy',
  description: 'Check your balance.',
  usage: '.bal',
  async execute(sock, jid, sender, args, message, { reply }) {
    try {
      const user = await getUser(sender, message);
      return sendEconomyCard(sock, jid, message, { profileJid: sender, title: 'ACCOUNT BALANCE', subtitle: 'Wallet + bank overview', lines: [{ label: 'Wallet', value: `$${money(user.balance)}` }, { label: 'Bank', value: `$${money(user.bank)}` }, { label: 'Total', value: `$${money(user.balance + user.bank)}` }], caption: economyCaption(`🪙 *Wallet:* $${money(user.balance)}\n🏦 *Bank:* $${money(user.bank)}\n💰 *Total:* $${money(user.balance + user.bank)}`, 'wallet') });
    } catch (err) {
      console.error('Balance error:', err);
      return reply('❌ Could not fetch your balance.');
    }
  }
});
