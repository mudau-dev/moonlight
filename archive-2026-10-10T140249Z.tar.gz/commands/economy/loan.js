const User = require('../../models/User');
const { findOrCreateWhatsApp } = require('../../database/users');

const TIER_LIMITS = { Common: 50000, Uncommon: 80000, Rare: 200000, Epic: 350000, Legendary: 700000, Mythic: 2000000 };

async function resolveUser(sender, pushName) {
  const raw = String(sender || '').trim();
  const digits = raw.replace(/[^0-9]/g, '');
  const candidates = [raw, digits].filter(Boolean);
  let user = await User.findOne({ $or: [
    ...candidates.flatMap((value) => [{ userId: value }, { whatsappNumber: value }, { phoneNumber: value }, { discordId: value }]),
  ] });
  if (!user && raw.includes('@')) user = await findOrCreateWhatsApp(raw, pushName).catch(() => null);
  return user;
}

function cardTier(card) { return card?.rarity || card?.tier || 'Common'; }
function dueAmount(loan) { return Math.max(0, Math.floor(Number(loan?.amount) || 0)); }

moon({
  name: 'loan',
  category: 'economy',
  description: 'Loan system using cards as collateral',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const user = await resolveUser(sender, pushName);
      if (!user) return reply('❌ User not found. Please link/register your account first.');
      const sub = String(args[0] || '').toLowerCase();

      if (sub === 'request') {
        const amount = Math.floor(Number(String(args[1] || '').replace(/,/g, '')));
        const cardIndex = Number(args[2]) - 1;
        if (!Number.isFinite(amount) || amount <= 0) return reply('❌ Usage: .loan request <amount> <card index>');
        if (!Number.isInteger(cardIndex) || !Array.isArray(user.cards) || !user.cards[cardIndex]) return reply('❌ Invalid card index.');
        if (dueAmount(user.loan) > 0) return reply('❌ You already have an active loan. Repay it first.');
        const card = user.cards[cardIndex];
        const tier = cardTier(card);
        const limit = TIER_LIMITS[tier] || 1000;
        if (amount > limit) return reply(`❌ ${tier} cards can only secure loans up to $${limit.toLocaleString()}.`);
        const interest = Math.ceil(amount * 0.1);
        const total = amount + interest;
        const collateral = { ...(typeof card.toObject === 'function' ? card.toObject() : card) };
        const result = await User.updateOne(
          { _id: user._id, $or: [{ loan: { $exists: false } }, { loan: null }, { 'loan.amount': { $lte: 0 } }], 'cards.instanceId': card.instanceId },
          { $pull: { cards: { instanceId: card.instanceId } }, $inc: { balance: amount }, $set: { loan: { amount: total, originalAmount: amount, interest, collateralCard: collateral, cardId: card.cardId, cardName: card.name, cardTier: tier, requestedAt: new Date() } } }
        );
        if (!result.modifiedCount) return reply('❌ Your card or loan state changed before approval. Please run the command again.');
        return reply(`🏦 *LOAN APPROVED*\n\n💰 Loan: $${amount.toLocaleString()}\n📈 Interest: $${interest.toLocaleString()} (10%)\n💳 Total Due: $${total.toLocaleString()}\n\n🎴 Collateral Taken: ${card.name}\n⭐ Rarity: ${tier}\n\n> Your card is safely recorded as collateral until repayment.`);
      }

      if (sub === 'repay' || sub === 'pay') {
        const loan = user.loan;
        const due = dueAmount(loan);
        if (!due || !loan?.collateralCard) return reply('❌ You have no active loan recorded. If collateral was removed by an interrupted old request, contact an owner before retrying.');
        if (Number(user.balance || 0) < due) return reply(`❌ Insufficient balance. You need $${(due - Number(user.balance || 0)).toLocaleString()} more.`);
        const restored = { ...loan.collateralCard };
        const result = await User.updateOne(
          { _id: user._id, 'loan.amount': due, balance: { $gte: due } },
          { $inc: { balance: -due }, $push: { cards: restored }, $unset: { loan: 1 } }
        );
        if (!result.modifiedCount) return reply('❌ Repayment could not be completed because your balance or loan changed. Run .loan status and try again.');
        return reply(`✅ Loan repaid successfully.\n\n🎴 ${restored.name || 'Your card'} has been returned to your collection.`);
      }

      if (sub === 'status') {
        const loan = user.loan;
        if (!dueAmount(loan)) return reply('ℹ️ You currently have no active loan.');
        return reply(`🏦 *LOAN STATUS*\n\n💳 Amount Due: $${dueAmount(loan).toLocaleString()}\n💰 Original Loan: $${Number(loan.originalAmount || 0).toLocaleString()}\n📈 Interest: $${Number(loan.interest || 0).toLocaleString()}\n🎴 Collateral: ${loan.cardName || loan.collateralCard?.name || 'Unknown'}\n⭐ Rarity: ${loan.cardTier || cardTier(loan.collateralCard)}\n📅 Requested: ${loan.requestedAt ? new Date(loan.requestedAt).toLocaleDateString() : 'Unknown'}`);
      }
      return reply(`💸 *Loan Command Usage*\n• *.loan request <amount> <card index>* — Request a loan.\n• *.loan repay* — Repay and restore collateral.\n• *.loan status* — Check your active loan.`);
    } catch (err) {
      console.error('LOAN ERROR:', err);
      return reply('❌ Loan system error. No card was removed unless the loan was saved successfully.');
    }
  },
});
