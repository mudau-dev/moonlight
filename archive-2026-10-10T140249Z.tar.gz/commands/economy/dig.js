const { money, getUser, sendEconomyCard, hasInventoryItem } = require('./_shared');
const { checkCooldown, formatTime } = require('../../utils/cooldown');

moon({
  name: 'dig',
  category: 'economy',
  description: 'Dig for coins and treasures. Requires a Shovel.',
  usage: '.dig',
  async execute(sock, jid, sender, args, message, { reply }) {
    try {
      const user = await getUser(sender, message);
      if (!hasInventoryItem(user, { id: 'item:shovel', name: 'Shovel' })) {
        return reply('❌ You need a *Shovel* to dig. Buy one from the shop first with `.shop`.');
      }

      const cooldown = 10 * 60 * 1000;
      const { onCooldown, remaining } = checkCooldown(user.lastDig ? new Date(user.lastDig) : null, cooldown);
      if (onCooldown) return reply(`⏳ Your shovel needs rest. Try again in *${formatTime(remaining)}*.`);

      const finds = [
        ['Old Bone', 50], ['Rusty Coin', 80], ['Silver Ring', 150], ['Gold Nugget', 300], ['Ancient Relic', 600],
      ];
      const found = finds[Math.floor(Math.random() * finds.length)];
      const earned = found[1] + Math.floor(Math.random() * 75);
      user.balance += earned;
      user.totalEarned += earned;
      user.lastDig = new Date();
      await user.save();

      return sendEconomyCard(sock, jid, message, { profileJid: sender, title: 'DIG COMPLETE', subtitle: found[0], lines: [{ label: 'Value', value: `+$${money(earned)}` }, { label: 'Wallet', value: `$${money(user.balance)}` }], caption: `⛏️ *Found:* ${found[0]}\n💵 *Value:* +$${money(earned)}\n🪙 *Wallet:* $${money(user.balance)}` });
    } catch (err) {
      console.error('Dig error:', err);
      return reply('❌ Dig failed. Please try again.');
    }
  },
});
