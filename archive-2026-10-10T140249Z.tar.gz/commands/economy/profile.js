const crypto = require('crypto');
const User = require('../../models/User');
const Guild = require('../../models/athers/Guild');
const moment = require('moment-timezone');
const { generateProfileImage, generateAnimatedProfileVideo, FRAMES, normalizeFrameId, DEFAULT_ICON } = require('../../utils/profileGenerator');
const { findOrCreateWhatsApp } = require('../../database/users');
const { getRealUserIdentity } = require('../../utils/whatsappIdentity');

function calcLevelXP(messageCount) { const count = Number(messageCount) || 0; return { level: Math.floor(count / 50) + 1, xp: count % 50, xpTarget: 50 }; }
function absoluteMedia(value, web) { if (!value) return null; try { return new URL(String(value), web || 'https://haven-moon.zone.id').toString(); } catch { return String(value); } }
async function getUserGuild(user) { try { const identities = [...new Set([user?.phoneNumber, user?.whatsappNumber?.split('@')[0], user?.userId, user?.moonId].filter(Boolean))]; return identities.length ? await Guild.findOne({ members: { $in: identities } }).lean() : null; } catch { return null; } }
function mediaKey(data, kind) { return crypto.createHash('sha256').update(JSON.stringify({ kind, username: data.username, role: data.role, level: data.level, xp: data.xp, xpTarget: data.xpTarget, wallet: data.wallet, bank: data.bank, guildName: data.guildName, cardCount: data.cardCount, messageCount: data.messageCount, bio: data.bio, profileImage: data.profileImage, bannerUrl: data.bannerUrl, videoBackground: data.videoBackground, profileFrame: data.profileFrame })).digest('hex'); }
async function cacheMedia(user, data, kind, render) {
  const key = mediaKey(data, kind);
  const cached = user?.profileMediaCache?.[kind];
  if (cached?.key === key && cached?.data) return { buffer: Buffer.from(cached.data, 'base64'), key, cached: true };
  const buffer = await render();
  void (async () => { try {
    const entry = { key, data: buffer.toString('base64'), mime: kind === 'video' ? 'video/mp4' : 'image/png', updatedAt: new Date() };
    await User.updateOne({ _id: user._id }, { $set: { [`profileMediaCache.${kind}`]: entry } });
  } catch (error) { console.warn('[PROFILE CACHE UPLOAD]', error.message); } })();
  return { buffer, key, cached: false };
}

moon({
  name: 'p', category: 'economy', aliases: ['profile', 'pf'], description: 'Show the website-backed Moonlight profile card.',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      await sock.sendMessage(jid, { react: { text: '👤', key: m.key } }).catch(() => null);
      const contextInfo = m?.message?.extendedTextMessage?.contextInfo || {};
      const rawTarget = contextInfo?.mentionedJid?.[0] || contextInfo?.participant || sender;
      const identity = await getRealUserIdentity(sock, rawTarget);
      if (!identity) return reply('❌ That WhatsApp LID could not be resolved to a real phone number.');
      const target = identity.phoneJid;
      const id = identity.phoneNumber;
      const web = String(process.env.WEB || process.env.MOON_WEB_URL || process.env.NEXT_PUBLIC_SITE_URL || 'https://haven-moon.zone.id').replace(/\/$/, '');
      const userDoc = await findOrCreateWhatsApp(target);
      const user = userDoc ? (userDoc.toObject ? userDoc.toObject() : userDoc) : null;
      const isRegistered = Boolean(user?.moonId && !String(user.moonId).startsWith('moon_'));
      const wallet = isRegistered ? Number(user.balance ?? user.wallet ?? 0) : 0;
      const bank = isRegistered ? Number(user.bank ?? 0) : 0;
      const displayRole = !isRegistered ? 'Unregistered' : (user.isTrueOwner === true ? 'True Owner' : (user.role || 'User'));
      const guild = isRegistered ? await getUserGuild(user) : null;
      const rank = isRegistered ? await User.countDocuments({ balance: { $gt: Number(user.balance || 0) }, moonId: { $exists: true, $nin: [null, ''] } }).then((count) => count + 1) : 0;
      const { level, xp, xpTarget } = calcLevelXP(user?.messageCount || 0);
      const frameId = normalizeFrameId(isRegistered ? (user.profileFrame || 'classic') : 'classic');
      const canUseAnimatedFrame = ['True Owner', 'Owner', 'Mod'].includes(displayRole) || user?.isTrueOwner === true;
      const requestedFrame = FRAMES[frameId] || FRAMES.classic;
      const frameInfo = requestedFrame.animated && !canUseAnimatedFrame ? FRAMES.classic : requestedFrame;
      const profileImage = absoluteMedia(isRegistered ? (user.profileImage || user.avatarUrl) : null, web) || DEFAULT_ICON;
      const bannerUrl = absoluteMedia(isRegistered ? (user.bannerUrl || user.backgroundImage) : null, web);
      const videoBackground = absoluteMedia(isRegistered ? user.videoBackground : null, web);
      const profileData = { username: isRegistered ? (user.username || id) : 'N/A', bank, wallet, balance: wallet, bio: isRegistered ? (user.bio && user.bio !== '.' ? user.bio : 'N/A') : 'N/A', rank, level, xp, xpTarget, role: displayRole, profileImage, bannerUrl, videoBackground, profileFrame: frameId, guildName: guild?.name || 'N/A', cardCount: Array.isArray(user?.cards) ? user.cards.length : 0, messageCount: isRegistered ? Number(user.messageCount || 0) : 0 };
      const animated = Boolean(frameInfo.animated || videoBackground);
      const kind = animated ? 'video' : 'image';
      const media = await cacheMedia(user, profileData, kind, () => animated ? generateAnimatedProfileVideo(profileData) : generateProfileImage(profileData));
      const profileLink = isRegistered ? `${web}/user/${encodeURIComponent(user.moonId)}` : 'N/A';
      const caption = [
        '𝚳OO𝚴 - 𝐏𝐑𝐎𝐅𝐈𝐋𝐄',
        profileLink,
        '┏━━━━━━━━━━━━⊱',
        `┣│ *Name:* ${profileData.username}`,
        `┣│ *Age:* ${isRegistered && user?.age ? user.age : 'N/A'}`,
        `┣│ *Role:* ${displayRole}`,
        `┣│ *Guild:* ${profileData.guildName}`,
        '┗│ *Bio:*',
        `> ${profileData.bio || 'N/A'}`,
        '',
        `┏│ *Level:* ${profileData.level}`,
        `┣│ *XP:* ${profileData.xp}/${profileData.xpTarget}`,
        `┣│ *Register:* ${user?.createdAt ? moment(user.createdAt).format('DD/MM/YYYY') : 'N/A'}`,
        `┣│ *baned:* ${user?.suspended ? 'yes' : 'no'}`,
        '┗━━━━━━━━━━━⊱',
      ].join('\n');
      const payload = kind === 'video'
        ? { video: media.buffer, mimetype: 'video/mp4', gifPlayback: true, caption, mentions: [target], ptv: false }
        : { image: media.buffer, mimetype: 'image/png', caption, mentions: [target] };
      await sock.sendMessage(jid, payload, { quoted: m });
    } catch (error) {
      console.error('PROFILE ERROR:', error);
      return reply('❌ Error loading profile. Please try again.');
    }
  },
});
