const { getUser, money, sendEconomyCard, economyCaption } = require('./_shared');

moon({
  name: 'orbs',
  aliases: ['moonorbs', 'orb'],
  category: 'economy',
  description: 'Check your Moon Orb balance.',
  usage: '.orbs',
  async execute(sock, jid, sender, args, message, { reply }) {
    try {
      const user = await getUser(sender, message);
      const count = Number(user.orbs || 0);
      const caption = economyCaption(`🔮 *You have ${money(count)} Moon Orbs*.`, 'orbs');
      return sendEconomyCard(sock, jid, message, {
        profileJid: sender,
        title: 'MOON ORBS',
        subtitle: 'Rare Haven currency',
        lines: [{ label: 'Orb Vault', value: money(count) }],
        caption,
        variant: 'orb',
      });
    } catch (error) {
      console.error('[ORBS ERROR]', error);
      return reply('❌ Could not fetch your Moon Orb balance.');
    }
  },
});
