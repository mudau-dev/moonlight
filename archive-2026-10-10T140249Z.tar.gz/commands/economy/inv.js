const { getUser } = require('./_shared');

const ITEM_EMOJIS = {
  'item:cake': '🍰',
  'item:pistol': '🔫',
  'item:lottery-ticket': '🎟️',
  'item:shovel': '⛏️',
  'item:fishing-rod': '🎣',
  'item:manas-100': '🌙',
  'item:guild-license': '🏰',
  'pokeball:poke-ball': '⚪',
  'pokeball:great-ball': '🔵',
  'pokeball:ultra-ball': '⚫',
  'pokeball:master-ball': '🟣',
  'pokeball:premier-ball': '⚪',
  'pokeball:heal-ball': '🩷',
  'pokeball:dusk-ball': '🌑',
  'pokeball:net-ball': '🟩',
  'pokeball:luxury-ball': '🟠',
  'pokeball:quick-ball': '🟡',
  'pokeball:beast-ball': '🔶',
};

function normalizeEntry(entry) {
  if (typeof entry === 'string') return { id: entry, name: entry, quantity: 1 };
  return {
    id: entry?.id || entry?.name || 'unknown',
    name: entry?.name || entry?.id || 'Unknown Item',
    quantity: Math.max(1, Number(entry?.qty || entry?.quantity || 1)),
    emoji: entry?.emoji,
  };
}

moon({
  name: 'inv',
  aliases: ['inventory', 'bag'],
  category: 'economy',
  description: 'View your inventory.',
  usage: '.inv',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const user = await getUser(sender, m);
      const inventory = Array.isArray(user.inventory) ? user.inventory : [];
      if (!inventory.length) {
        return reply([
          '╔══════════════════════╗',
          '║     🎒 INVENTORY      ║',
          '╚══════════════════════╝',
          '',
          '📭 Your bag is empty!',
          '',
          '💡 Visit the shop with `.shop` to buy general items and Poké Balls.',
        ].join('\n'));
      }

      const itemCounts = new Map();
      for (const rawItem of inventory) {
        const item = normalizeEntry(rawItem);
        const key = String(item.id).toLowerCase();
        const existing = itemCounts.get(key) || {
          id: item.id,
          name: item.name,
          emoji: item.emoji || ITEM_EMOJIS[key] || '📦',
          count: 0,
        };
        existing.count += item.quantity;
        itemCounts.set(key, existing);
      }

      const username = sender?.split('@')[0] || 'User';
      const lines = [
        '╔══════════════════════╗',
        '║     🎒 INVENTORY      ║',
        '╚══════════════════════╝',
        '',
        `👤 *@${username}'s Bag*`,
        `📦 *Total Items:* ${[...itemCounts.values()].reduce((total, item) => total + item.count, 0)}`,
        '',
        '━━━━━━━━━━━━━━━━━━━━━━',
        '',
      ];

      [...itemCounts.values()]
        .sort((left, right) => left.name.localeCompare(right.name))
        .forEach((item, index) => lines.push(`*${index + 1}.* ${item.emoji} *${item.name}* — \`x${item.count}\``));

      lines.push('', '━━━━━━━━━━━━━━━━━━━━━━', '> Use `.fish` with a Fishing Rod and `.dig` with a Shovel.');
      return sock.sendMessage(jid, { text: lines.join('\n'), mentions: [sender] }, { quoted: m });
    } catch (error) {
      console.error('[INV]', error);
      return reply('❌ Failed to fetch your inventory. Please try again.');
    }
  },
});
