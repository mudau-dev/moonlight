const { money, getUser, updateUser, sendEconomyCard, economyCaption, cleanAmount, validAmount } = require('./_shared');
const { resolveMessageTarget, sameIdentity, phoneNumberFromValue } = require('../../utils/adminIdentity');

moon({
  name: 'pay',
  aliases: ['give'],
  category: 'economy',
  description: 'Pay another user from your wallet.',
  usage: '.pay @user <amount> | reply .pay <amount>',
  async execute(sock, jid, sender, args, message, { reply }) {
    try {
      const contextInfo = message?.message?.extendedTextMessage?.contextInfo
        || message?.message?.imageMessage?.contextInfo
        || message?.message?.videoMessage?.contextInfo
        || {};
      const targetJid = await resolveMessageTarget(sock, message, args);
      const hasExplicitTarget = Boolean(
        contextInfo.mentionedJid?.[0]
        || contextInfo.participant
        || (/\d/.test(String(args[0] || '')) && String(args[0]).replace(/\D/g, '').length >= 7)
      );
      const amount = cleanAmount(args[hasExplicitTarget && !contextInfo.participant ? 1 : 0]);

      if (!targetJid || !validAmount(amount)) {
        return reply('❌ Usage: mention or reply to a user, then provide the amount. Example: reply `.pay 100`');
      }
      if (sameIdentity(targetJid, sender)) return reply('❌ You cannot pay yourself.');

      const payer = await getUser(sender, message);
      const recipient = await getUser(targetJid, message);
      if (!payer || !recipient) return reply('❌ Could not resolve the payer or recipient phone number.');
      if (payer.balance < amount) return reply('❌ You do not have enough coins in your wallet.');

      // Persist both sides using canonical phone JIDs, never a raw LID/device ID.
      const updatedPayer = await updateUser(payer.whatsappNumber, { $inc: { balance: -amount } });
      await updateUser(recipient.whatsappNumber, { $inc: { balance: amount, totalEarned: amount } });

      const recipientNumber = phoneNumberFromValue(recipient.whatsappNumber) || phoneNumberFromValue(targetJid);
      return sendEconomyCard(sock, jid, message, { profileJid: sender, title: 'PAYMENT SENT', subtitle: `To @${recipientNumber}`, lines: [{ label: 'Amount', value: `$${money(amount)}` }, { label: 'Wallet', value: `$${money(updatedPayer?.balance)}` }], caption: economyCaption(`✅ *Paid:* $${money(amount)}\n👤 *To:* @${recipientNumber}\n🪙 *Wallet:* $${money(updatedPayer?.balance)}`, 'pay') });
    } catch (err) {
      console.error('Pay error:', err);
      return reply('❌ Payment failed. Please mention or reply to a user and provide an amount.');
    }
  }
});
