const { getCardById, searchCardByName, rarityEmoji, formatCardStats } = require('../../utils/yugiohApi');

moon({
  name: 'yi', aliases: ['yinfo', 'ylookup'], category: 'Yu-gi-oh',
  description: 'Search for a Yu-Gi-Oh card and view its info and rarity.', usage: '.yi <card name | card ID>',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      if (!args.length) return reply('❌ Usage: *.yi <card name or ID>*\nExample: `.yi Dark Magician` or `.yi 46986414`');
      const query = args.join(' ').trim();
      let card = /^\d+$/.test(query) ? await getCardById(Number.parseInt(query, 10)) : null;
      if (!card) {
        const results = await searchCardByName(query);
        if (!results.length) return reply(`❌ No Yu-Gi-Oh card found matching *"${query}"*.\nTry a different name or use the exact card ID.`);
        if (results.length > 1) {
          const list = results.slice(0, 8).map((entry, index) => `[${index + 1}] *${entry.name}* — ${entry.type}`).join('\n');
          return reply(`🔍 *Multiple cards found for "${query}":*\n\n${list}\n\nUse *.yi <exact name>* or *.yi <card ID>* for details.`);
        }
        [card] = results;
      }
      const stats = formatCardStats(card);
      const text = `┌─❖\n│ 「 🃏 YU-GI-OH CARD INFO 」\n└┬❖ 「 ${card.name} 」\n   │\n   │ 📋 *Type:* ${card.type || 'Unknown'}\n   │ ${rarityEmoji(card.rarity)} *Rarity:* ${card.rarity}\n   │ 🆔 *Card ID:* ${card.cardId}\n${stats ? `${stats.split('\n').map((line) => `   │ ${line}`).join('\n')}\n` : ''}   │\n   │ 📖 *Description:*\n   │ ${(card.desc || 'No description.').slice(0, 300)}${(card.desc || '').length > 300 ? '…' : ''}\n   └────────────┈ ⳹`;
      if (card.imageUrl) return sock.sendMessage(jid, { image: { url: card.imageUrl }, caption: text }, { quoted: m });
      return reply(text);
    } catch (error) {
      console.error('[YI ERROR]', error);
      return reply('❌ Failed to fetch card info. The YGOPRODeck API may be temporarily unavailable.');
    }
  },
});
