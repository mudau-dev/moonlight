const config = require('../../config');

moon({
  name: 'uptime',
  aliases: ['up'],
  roles: [],
  category: 'Utility',
  description: 'Show how long this bot process has been online',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const total = Math.floor(process.uptime());
      const days = Math.floor(total / 86400);
      const hours = Math.floor((total % 86400) / 3600);
      const minutes = Math.floor((total % 3600) / 60);
      const seconds = total % 60;
      return reply(
        `*${config.BOT_NAME || 'Moonlight'} UPTIME*\n\n` +
        `✅ Online\n` +
        `⏱️ ${days}d ${hours}h ${minutes}m ${seconds}s\n` +
        `🧩 Process: ${process.pid}`
      );
    } catch (error) {
      console.error('[UPTIME]', error);
      return reply('❌ Could not read bot uptime.');
    }
  },
});
