const User = require('../../models/User');
function clean(value) { return String(value || '').replace(/\D/g, ''); }

moon({
  name: 'otp', aliases: [], category: 'Utility',
  description: 'Retrieve a pending Haven verification code.', usage: '.otp',
  async execute(sock, jid, sender, args, m, { reply }) {
    const number = clean(sender);
    const pending = await User.collection.findOne({ 'pendingNumberChange.newNumber': number });
    const pendingValid = pending?.otp && pending.otpExpires && new Date(pending.otpExpires).getTime() > Date.now();
    if (pendingValid) return reply(`*haven pass code:*\n${pending.otp}`);
    const current = await User.findOne({ $or: [{ moonId: number }, { phoneNumber: number }, { userId: number }, { whatsappNumber: sender }] });
    const currentValid = current?.otp && current.otpExpires && new Date(current.otpExpires).getTime() > Date.now();
    return reply(`*haven pass code:*\n${currentValid ? current.otp : '_'}`);
  },
});
