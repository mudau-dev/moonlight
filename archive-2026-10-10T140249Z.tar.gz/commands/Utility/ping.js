const config = require('../../config');

moon({
  name: 'ping',
  roles: [],
  category: 'Utility',
  description: 'Check the bot response speed.',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const startedAt = Date.now();
      const probe = await sock.sendMessage(jid, { text: '⚡ Checking response speed...' }, { quoted: m });
      const latency = Date.now() - startedAt;
      return sock.sendMessage(jid, { text: `*${config.BOT_NAME}* speed: \`${latency}\` ms`, edit: probe.key });
    } catch (error) {
      console.error('Ping error:', error);
      return reply('❌ Ping failed.');
    }
  },
});
