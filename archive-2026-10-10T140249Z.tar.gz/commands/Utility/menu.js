const axios = require('axios');
const config = require('../../config');
const ReadMore = '\u200e'.repeat(4001);

const CATEGORY_ORDER = [
  ['general', 'General', '🔍'], ['cards', 'Cards', '🎴'], ['economy', 'Economy', '🎮'], ['gambling', 'Gambling', '🎮'],
  ['website', 'Website', '✨️'], ['web', 'Website', '✨️'], ['pokemon', 'Pokémon', '🐲'], ['pokemons', 'Pokémon', '🐲'], ['pokémon', 'Pokémon', '🐲'],
  ['legacy', 'Lagacy', '🪽'], ['event', 'Event', '🏷'], ['events', 'Event', '🏷'], ['combat', 'Combat', '👑'],
  ['interaction', 'Interaction', '🥄'], ['intaraction', 'Interaction', '🥄'], ['downloaders', 'Downloaders', '🔍'], ['shop', 'Shop', '🛒'],
  ['moonlight', 'Moonlight', '✨️'], ['realms', 'Moonlight', '✨️'], ['group', 'Group', '🔒'], ['guilds', 'Guilds', '🏰'],
  ['admin', 'Admins', '🔒'], ['admins', 'Admins', '🔒'], ['utility', 'Utilities', '🔒'], ['utilities', 'Utilities', '🔒'],
  ['adventure', 'Adventure', '📰'], ['nsfw', 'Nsfw', '🔞'], ['yugioh', 'Yu-gi-oh', '🏳️‍🌈'], ['yu-gi-oh', 'Yu-gi-oh', '🏳️‍🌈'],
];

function normalize(value) { return String(value || '').trim().toLowerCase().replace(/^\./, ''); }
function uniqueCommands(commands) {
  const seen = new Set();
  const result = [];
  for (const command of commands.values()) {
    if (!command?.name) continue;
    const key = normalize(command.name);
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(command);
  }
  return result;
}
function categoryFor(category) { return CATEGORY_ORDER.find(([key]) => key === normalize(category)); }
function commandLine(prefix, command) { return `│⊱ ${prefix}${String(command.name).replace(/[_-]+/g, ' ')}`; }
function categoryHeader(label, icon) { return ['┣━━━━━━━━━━━', `┣⊱ ${icon} ${label} ${icon}`]; }
function renderCategory(prefix, label, icon, commands) {
  return [...categoryHeader(label, icon), ...commands.sort((a, b) => a.name.localeCompare(b.name)).map((command) => commandLine(prefix, command))].join('\n');
}

moon({
  name: 'menu', aliases: ['help', 'h', 'commands'], category: 'utility',
  description: 'Show the Moonlight Haven command menu by category.',
  usage: '.menu | .menu <category> | .help <command>', cooldown: 5,
  async execute(sock, jid, sender, args, m, { reply, commands }) {
    try {
      const prefix = config.PREFIX || '.';
      const all = uniqueCommands(commands || new Map());
      const requested = normalize(args[0]);
      if (requested) {
        const exact = all.find((command) => normalize(command.name) === requested || (command.aliases || []).some((alias) => normalize(alias) === requested));
        if (exact) {
          const meta = categoryFor(exact.category) || ['general', String(exact.category || 'General'), '✨️'];
          return reply([...categoryHeader(meta[1], meta[2]), commandLine(prefix, exact), `│⊱ ${exact.description || 'Moonlight Haven command.'}`].join('\n'));
        }
      }
      const grouped = new Map();
      for (const command of all) {
        const category = normalize(command.category || 'general');
        if (category === 'owner' || category === 'owners') continue;
        const meta = categoryFor(category);
        if (!meta) continue;
        if (!grouped.has(meta[1])) grouped.set(meta[1], { icon: meta[2], commands: [] });
        grouped.get(meta[1]).commands.push(command);
      }
      const sections = [];
      const used = new Set();
      for (const [, label, icon] of CATEGORY_ORDER) {
        if (used.has(label) || !grouped.has(label)) continue;
        used.add(label);
        sections.push(renderCategory(prefix, label, icon, grouped.get(label).commands));
      }
      const text = [
        '┏━━[𝚳OO𝚴𝐋𝚰𝐆𝚮𝚻]━━',
        `┃ꕥ  *Owner:* ${config.CREATOR_NAME || config.OWNER_NAME || 'Moonlight Haven'}`,
        `┃ꕥ  *Name:* ${config.BOT_NAME || 'Moonlight'}`,
        `┃ꕥ  *Prefix:* ${prefix}`,
        '┣━━━━━━━━━━━━━━',
        '┃ `.collab` fore our collab',
        '┃ `.support` fore our link',
        '┃ `.web` fore our website',
        '┃ `.pmenu` fore pokes',
        '',
        '> Read the hall of our commands in order to know and learn more of what 𝚳OO𝚴𝐋𝚰𝐆𝚮𝚻 set fore you.',
        ReadMore,
        sections.join('\n\n'),
      ].join('\n');
      if (!config.MENU_IMAGE) return reply(text);
      try {
        const media = await axios.get(config.MENU_IMAGE, { responseType: 'arraybuffer', timeout: 8000, maxContentLength: 15 * 1024 * 1024 });
        return sock.sendMessage(jid, { image: Buffer.from(media.data), caption: text, contextInfo: { mentionedJid: [sender] } }, { quoted: m });
      } catch (error) {
        console.warn('[MENU IMAGE FALLBACK]', config.MENU_IMAGE, error.message);
        return reply(text);
      }
    } catch (error) {
      console.error('[ORDERED MENU ERROR]', error);
      return reply('❌ The Moonlight menu could not be opened.');
    }
  },
});
