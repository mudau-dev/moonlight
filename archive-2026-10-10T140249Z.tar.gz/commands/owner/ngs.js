const { parseDuration, startGame, finishGame, games, clearGame, restoreGame } = require('../../utils/ngsGame');

moon({
  name: 'ngs',
  category: 'owner',
  roles: ['Owner', 'True Owner'],
  description: 'Start or stop a timed 1–150 number guessing game.',
  usage: '.ngs <number> <time> | .ngs draw | .ngs stop',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!jid.endsWith('@g.us')) return reply('❌ `.ngs` can only run in a group.');
    if (String(args[0] || '').toLowerCase() === 'draw') {
      const existing = games.get(jid) || await restoreGame(sock, jid);
      if (!existing) return reply('❌ No NGS game is running in this group.');
      await finishGame(sock, jid, existing, 'draw');
      return undefined;
    }
    if (String(args[0] || '').toLowerCase() === 'stop') {
      const existing = games.get(jid) || await restoreGame(sock, jid);
      if (!existing) return reply('❌ No NGS game is running in this group.');
      clearGame(jid);
      return reply('🛑 NGS game stopped.');
    }
    const target = Number(args[0]);
    const duration = parseDuration(args[1]);
    if (!Number.isInteger(target) || target < 1 || target > 150 || !duration) {
      return reply('❌ Usage: `.ngs <number 1-150> <time>`\nExample: `.ngs 6 1m`\nTime: 1m–5d.');
    }
    // Do not reply to or wait on deletion: the owner's command disappears while
    // the game announcement starts immediately. Metadata is best-effort only.
    sock.sendMessage(jid, { delete: m.key }).catch(() => {});
    const metadata = await sock.groupMetadata(jid).catch(() => null);
    const mentions = metadata?.participants?.map((participant) => participant.id).filter(Boolean) || [];
    startGame(sock, jid, null, target, duration, mentions);
    return undefined;
  },
});
