const { addMoney } = require('../../utils/economy');
const { cleanAmount } = require('../economy/_shared');
const { resolveMessageTarget } = require('../../utils/adminIdentity');

moon({
  name: 'gv',
  category: 'owner',
  roles: ["Mod", "Owner", "True Owner"],
  description: 'Give coins, Moon Orbs, or XP to a user',
  usage: '.gv <coins|orbs|xp> <amount> @user',

  async execute(sock, jid, sender, args, m, { reply, findOrCreateWhatsApp }) {
    try {
      const sub = String(args.find((value) => ['coins', 'coin', 'orbs', 'orb', 'xp'].includes(String(value).toLowerCase())) || 'coins').toLowerCase();
      const target = await resolveMessageTarget(sock, m, args);
      if (!target) return reply('❌ Mention, reply to, or provide the phone number of a user.');

      const amountToken = [...args].reverse().find((value) => /^\d+(?:\.\d+)?[kmbt]?$/i.test(String(value)));
      const amount = cleanAmount(amountToken);
      if (!Number.isSafeInteger(amount) || amount <= 0) return reply('❌ Please provide a valid positive amount.');

      const user = await findOrCreateWhatsApp(target, target.split('@')[0], true);
      if (!user) return reply('❌ User could not be resolved from that phone number.');

      if (sub === 'orbs' || sub === 'orb') {
        user.orbs = Math.max(0, Number(user.orbs || 0) + amount);
        await user.save();
        return reply(`✅ Added *${amount.toLocaleString()} Moon Orbs* to @${target.split('@')[0]}.`, { mentions: [target] });
      }
      if (sub === 'xp') {
        user.xp = Math.max(0, Number(user.xp || 0) + amount);
        await user.save();
        return reply(`✅ Added *${amount.toLocaleString()} XP* to @${target.split('@')[0]}.`, { mentions: [target] });
      }

      const credited = addMoney(user, amount);
      user.totalEarned = (user.totalEarned || 0) + credited;
      await user.save();
      return reply(`✅ Added *$${credited.toLocaleString()} coins* to @${target.split('@')[0]}.`, { mentions: [target] });
    } catch (err) {
      console.error('[GV ERROR]', err);
      return reply('❌ Failed to give coins. Please verify the target number and try again.');
    }
  },
});
