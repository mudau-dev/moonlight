const Group = require('../../models/athers/Group');
const System = require('../../models/System');

moon({
  name: 'gambling',
  category: 'owner',
  roles: ["Mod", "Owner", "True Owner"],
  usage: '.gambling on/off | .gambling web on/off',

  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const action = String(args[0] || '').toLowerCase();
      const subAction = String(args[1] || '').toLowerCase();

      if (action === 'web') {
        if (!['on', 'off'].includes(subAction)) return reply('Usage: .gambling web on / off');
        const enabled = subAction === 'on';
        await System.findOneAndUpdate(
          { key: 'gambling_web_enabled' },
          { $set: { value: { enabled }, updatedAt: new Date() } },
          { upsert: true, new: true }
        );
        return reply(enabled ? '✅ Web casinos enabled.' : '🚫 Web casinos disabled.\n\nCasino on webs are currently disabled');
      }

      if (!jid.endsWith('@g.us')) return reply('❌ This command only works in groups.');
      const group = await Group.findOneAndUpdate(
        { groupId: jid },
        { $setOnInsert: { groupId: jid, gamblingEnabled: false } },
        { upsert: true, new: true }
      );

      if (action === 'on') {
        if (group.gamblingEnabled === true) return reply('⚠️ Gambling is already enabled in this group.');
        group.gamblingEnabled = true;
        await group.save();
        return reply('✅ Bot gambling enabled in this group.');
      }

      if (action === 'off') {
        if (group.gamblingEnabled === false) return reply('⚠️ Gambling is already disabled in this group.');
        group.gamblingEnabled = false;
        await group.save();
        return reply('🚫 Bot gambling disabled in this group.');
      }

      return reply('Usage:\n.gambling on / off\n.gambling web on / off');
    } catch (error) {
      console.error('[GAMBLING OWNER CMD]', error);
      return reply("❌ You don't have permission to do that or the setting could not be saved.");
    }
  },
});
