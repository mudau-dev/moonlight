const { muteUser } = require('../../utils/muteStore');
const { resolveMessageTarget, phoneNumberFromValue } = require('../../utils/adminIdentity');
const { mentionTag } = require('../../handlers/_shared');

moon({
  name: 'cmute',
  category: 'owner',
  roles: ["Mod", "Owner", "True Owner"],
  description: 'Staff mute: delete every message sent by a user in this group',

  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      if (!jid.endsWith('@g.us')) return reply('❌ This command only works in groups.');
      const targetJid = await resolveMessageTarget(sock, m, args);
      if (!targetJid) return reply('❌ Tag, reply to, or provide the phone number of the user to mute.');
      if (phoneNumberFromValue(targetJid) === phoneNumberFromValue(sender)) return reply("❌ You can't mute yourself.");

      await muteUser(jid, targetJid);
      return sock.sendMessage(jid, {
        text: `🔇 ${mentionTag(targetJid)} has been muted by staff. Their messages, including commands, will be automatically deleted.`,
        mentions: [targetJid],
      }, { quoted: m });
    } catch (err) {
      console.error('[CMUTE ERROR]', err);
      return reply('❌ Failed to mute user.');
    }
  },
});
