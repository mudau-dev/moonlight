/**
 * commands/owner/akick.js
 *
 * .akick <role_number> — Owner-only auto-kick configuration for a group.
 * .akick c <roles>    — Community mode: kick silently inside a WhatsApp Community.
 *
 * Role numbers:
 *   1 = Citizens/Members (role: "User")
 *   2 = CDC
 *   3 = Moderators
 *   4 = Suspended users
 *
 * Uses config.BOT_JID for admin detection (same pattern as other admin commands).
 */
const GuildAutoKick    = require('../../models/athers/GuildAutoKick');
const User             = require('../../models/User');
const { findOrCreateWhatsApp } = require('../../database/users');
const config           = require('../../config');
const { getBotIdentity, findParticipantByIdentity, isParticipantAdmin } = require('../../utils/adminIdentity');

const ROLE_LABELS = {
  1: 'Citizens/Members',
  2: 'CDC',
  3: 'Moderators',
  4: 'Suspended users',
};

const ROLE_CHECKS = {
  1: (user) => !user || user.role === 'User',
  2: (user) => user?.isCDC === true || user?.role === 'CDC',
  3: (user) => user?.role === 'Mod',
  4: (user) => user?.suspended === true,
};

/**
 * Check if the bot is an admin using config.BOT_JID (same as other admin cmds).
 */
async function checkBotAdmin(sock, groupJid) {
  try {
    const metadata = await sock.groupMetadata(groupJid);
    const botIdentity = getBotIdentity(sock, config);
    return isParticipantAdmin(findParticipantByIdentity(metadata.participants, botIdentity));
  } catch (err) {
    console.error('[AKICK ADMIN CHECK]', err.message);
    return false;
  }
}

moon({
  name: 'akick',
  category: 'owner',
  description: 'Configure automatic kick by role for this group',
  usage: '.akick <1|2|3|4> | .akick c <roles>',
  roles: ["Mod", "Owner", "True Owner"],
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      if (!jid.endsWith('@g.us')) return reply('❌ This command can only be used in groups.');

      const requester = await findOrCreateWhatsApp(sender);
      const isTrueOwner = requester?.isTrueOwner === true || requester?.role === 'True Owner';
      if (!isTrueOwner) return reply('❌ Only a True Owner can configure auto-kick.');

      // Check bot is admin using config.BOT_JID
      const botIsAdmin = await checkBotAdmin(sock, jid);
      if (!botIsAdmin) return reply('❌ The bot must be a group admin to use auto-kick.');

      let config2 = await GuildAutoKick.findOne({ groupJid: jid });
      if (!config2) config2 = new GuildAutoKick({ groupJid: jid });

      const sub = (args[0] || '').toLowerCase();

      // ── Community mode: .akick c 1,2,3,4 ─────────────────────────────────
      if (sub === 'c') {
        const rolesArg = args[1] || '';
        if (!rolesArg) {
          return reply(
            '❌ Usage: `.akick c <roles>`\n' +
            'Example: `.akick c 1,2,3,4`\n\n' +
            'This enables silent auto-kick inside a WhatsApp Community.'
          );
        }
        const roles = rolesArg.split(',').map(r => parseInt(r.trim())).filter(r => ROLE_LABELS[r]);
        if (!roles.length) return reply('❌ Invalid roles. Use numbers 1–4.');
        config2.communityMode  = true;
        config2.communityRoles = roles;
        await config2.save();
        const roleNames = roles.map(r => `${r} (${ROLE_LABELS[r]})`).join(', ');
        return reply(
          `✅ *Community Auto-Kick enabled*\n\n` +
          `Roles that will be silently kicked: ${roleNames}\n\n` +
          `> The bot will automatically kick matching users when they join the community.`
        );
      }

      // ── Normal mode: .akick <number> ──────────────────────────────────────
      const roleNum = parseInt(sub);
      if (!ROLE_LABELS[roleNum]) {
        return reply(
          '❌ Usage: `.akick <1|2|3|4>`\n\n' +
          '*Role numbers:*\n' +
          '1 — Citizens/Members\n' +
          '2 — CDC\n' +
          '3 — Moderators\n' +
          '4 — Suspended users\n\n' +
          'Use `.akick c <roles>` for Community mode.'
        );
      }

      const idx = config2.kickRoles.indexOf(roleNum);
      if (idx !== -1) {
        config2.kickRoles.splice(idx, 1);
        await config2.save();
        return reply(
          `✅ Auto-kick for *${ROLE_LABELS[roleNum]}* has been *disabled* in this group.\n\n` +
          `Current auto-kick roles: ${config2.kickRoles.length ? config2.kickRoles.map(r => `${r} (${ROLE_LABELS[r]})`).join(', ') : 'None'}`
        );
      } else {
        config2.kickRoles.push(roleNum);
        await config2.save();
        return reply(
          `✅ Auto-kick for *${ROLE_LABELS[roleNum]}* has been *enabled* in this group.\n\n` +
          `Current auto-kick roles: ${config2.kickRoles.map(r => `${r} (${ROLE_LABELS[r]})`).join(', ')}`
        );
      }
    } catch (err) {
      console.error('[AKICK ERROR]', err);
      return reply('❌ Failed to configure auto-kick.');
    }
  },
});

/**
 * handleAutoKick — called from the group-participants.update handler
 */
async function handleAutoKick(sock, groupJid, userJid) {
  try {
    const config2 = await GuildAutoKick.findOne({ groupJid });
    if (!config2) return;

    const kickRoles = config2.communityMode ? config2.communityRoles : config2.kickRoles;
    if (!kickRoles || kickRoles.length === 0) return;

    const userDoc = await findOrCreateWhatsApp(userJid, 'Unknown');
    const user    = userDoc?.toObject ? userDoc.toObject() : userDoc;

    const shouldKick = kickRoles.some(roleNum => {
      const check = ROLE_CHECKS[roleNum];
      return check && check(user);
    });
    if (!shouldKick) return;

    // Check bot is admin using config.BOT_JID
    const botIsAdmin = await checkBotAdmin(sock, groupJid);
    if (!botIsAdmin) return;

    await sock.groupParticipantsUpdate(groupJid, [userJid], 'remove');

    if (!config2.communityMode) {
      const userNumber = userJid.split('@')[0];
      await sock.sendMessage(groupJid, {
        text: `Normal user joined and was kicked: @${userNumber}`,
        mentions: [userJid],
      });
    }
  } catch (err) {
    console.error('[AUTO-KICK ERROR]', err.message);
  }
}

module.exports = { handleAutoKick };
