const StaffApplication = require('../../models/StaffApplication');
const System = require('../../models/System');
const User = require('../../models/User');

const TYPE_ALIASES = { mod: 'mod', md: 'mod', moderator: 'mod', tester: 'tester', ts: 'tester' };

function normalizeType(value) { return TYPE_ALIASES[String(value || '').toLowerCase()] || null; }
function settingKey(type) { return `staff_applications_${type}_enabled`; }
function typeLabel(type) { return type === 'mod' ? 'Moderator' : 'Tester'; }

async function getPending(type = null) {
  const query = { status: 'pending' };
  if (type) query.applicationType = type;
  return StaffApplication.find(query).sort({ submittedAt: 1 });
}

async function applicationAt(index, type = null) {
  const applications = await getPending(type);
  return { application: applications[index - 1] || null, applications };
}

async function findApplicantUser(application) {
  return User.findOne({
    $or: [
      { moonId: application.moonId },
      { userId: application.userId },
      { whatsappNumber: application.userId },
    ],
  });
}

function notificationJid(user, application) {
  const raw = user?.whatsappNumber || user?.userId || application.userId;
  if (!raw) return null;
  return raw.includes('@') ? raw : `${String(raw).replace(/\D/g, '')}@s.whatsapp.net`;
}

moon({
  name: 'apl',
  category: 'owner',
  roles: ["Mod", "Owner", "True Owner"],
  usage: '.apl list [mod|tester] | .apl <index> | .apl mod|md on/off | .apl tester|ts on/off',
  description: 'Review staff applications and control web application availability.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const action = String(args[0] || '').toLowerCase();
    const configuredType = normalizeType(action);
    const toggle = String(args[1] || '').toLowerCase();

    if (configuredType && ['on', 'off'].includes(toggle)) {
      const enabled = toggle === 'on';
      await System.findOneAndUpdate(
        { key: settingKey(configuredType) },
        { $set: { value: { enabled }, updatedAt: new Date() } },
        { upsert: true, new: true }
      );
      return reply(enabled
        ? `✅ ${typeLabel(configuredType)} applications are now open on the website.`
        : `🚫 ${typeLabel(configuredType)} applications are now closed on the website.`);
    }

    if (action === 'list') {
      const filter = normalizeType(args[1]);
      const applications = await getPending(filter);
      if (!applications.length) return reply(`📭 No pending ${filter ? `${typeLabel(filter).toLowerCase()} ` : ''}applications.`);
      return reply([
        `📋 *PENDING ${filter ? `${typeLabel(filter).toUpperCase()} ` : ''}APPLICATIONS*`,
        '━━━━━━━━━━━━━━━━━━━━',
        ...applications.map((application, index) => `*${index + 1}.* ${application.username || application.moonId} — *${typeLabel(application.applicationType)}* · ${new Date(application.submittedAt || application.createdAt).toLocaleDateString()}`),
        '',
        '> Use `.apl <index>` to view a complete application.',
        '> Use `.aplreview <index> yes` to accept or `.api <index> no` to reject.',
      ].join('\n'));
    }

    const index = Number.parseInt(action, 10);
    if (Number.isInteger(index) && index > 0) {
      const { application } = await applicationAt(index);
      if (!application) return reply('❌ No pending application exists at that index. Use `.apl list`.');
      const answers = (application.answers || []).map((entry, answerIndex) => [
        `*${answerIndex + 1}. ${entry.question || entry.questionId || 'Question'}*`,
        entry.answer || 'No answer provided.',
      ].join('\n')).join('\n\n');
      return reply([
        `📝 *${typeLabel(application.applicationType).toUpperCase()} APPLICATION #${index}*`,
        '━━━━━━━━━━━━━━━━━━━━',
        `*Applicant:* ${application.username || 'Unknown'} (${application.moonId})`,
        `*Submitted:* ${new Date(application.submittedAt || application.createdAt).toLocaleString()}`,
        '', answers,
        '', `> Decide with *.api ${index} yes* or *.api ${index} no*.`,
      ].join('\n'));
    }

    const [modSetting, testerSetting] = await Promise.all([
      System.findOne({ key: settingKey('mod') }).lean(),
      System.findOne({ key: settingKey('tester') }).lean(),
    ]);
    return reply([
      '🛠️ *STAFF APPLICATION CONTROL*',
      '━━━━━━━━━━━━━━━━━━━━',
      `*Moderator applications:* ${modSetting?.value?.enabled === false ? 'OFF' : 'ON'}`,
      `*Tester applications:* ${testerSetting?.value?.enabled === false ? 'OFF' : 'ON'}`,
      '', '*Usage:*',
      '`.apl list [mod|tester]` — list pending applications',
      '`.apl <index>` — view a full application',
      '`.aplreview <index> yes/no` — accept or reject',
      '`.apl mod|md on/off` — set moderator form availability',
      '`.apl tester|ts on/off` — set tester form availability',
    ].join('\n'));
  },
});

moon({
  name: 'aplreview',
  category: 'owner',
  roles: ["Mod", "Owner", "True Owner"],
  usage: '.aplreview <pending_application_index> yes/no',
  description: 'Accept or reject a pending website staff application.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const index = Number.parseInt(args[0], 10);
    const decision = String(args[1] || '').toLowerCase();
    if (!Number.isInteger(index) || index < 1 || !['yes', 'no'].includes(decision)) return reply('❌ Usage: `.api <pending_application_index> yes/no`');

    const { application } = await applicationAt(index);
    if (!application) return reply('❌ No pending application exists at that index. Use `.apl list`.');
    const applicant = await findApplicantUser(application);

    if (decision === 'no') {
      await StaffApplication.deleteOne({ _id: application._id, status: 'pending' });
      const target = notificationJid(applicant, application);
      if (target) {
        try { await sock.sendMessage(target, { text: `Your Moonlight Haven ${typeLabel(application.applicationType)} application was not accepted this time. You may apply again when applications reopen.` }); } catch (error) { console.warn('[APL] rejection notification failed:', error.message); }
      }
      return reply(`🚫 Rejected and removed *${application.username || application.moonId}* from the pending application list.`);
    }

    if (!applicant) return reply('❌ The applicant user account could not be found, so no role was changed.');
    const role = application.applicationType === 'mod' ? 'Mod' : 'Tester';
    applicant.role = role;
    await applicant.save();
    await StaffApplication.updateOne(
      { _id: application._id, status: 'pending' },
      { $set: { status: 'approved', reviewedAt: new Date(), reviewedBy: sender } }
    );

    const target = notificationJid(applicant, application);
    if (target) {
      try { await sock.sendMessage(target, { text: `✅ Congratulations! Your Moonlight Haven ${typeLabel(application.applicationType)} application was accepted. Your role has been set to *${role}*.` }); } catch (error) { console.warn('[APL] approval notification failed:', error.message); }
    }
    return reply(`✅ Accepted *${application.username || application.moonId}* as *${role}*. Their role was updated automatically.`);
  },
});
