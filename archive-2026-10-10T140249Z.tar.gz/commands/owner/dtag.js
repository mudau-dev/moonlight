const System = require('../../models/System');

function ownerKey(sender) {
  const digits = String(sender || '').replace(/\D/g, '');
  return `dtag:${digits || String(sender || '').toLowerCase()}`;
}

moon({
  name: 'dtag',
  category: 'owner',
  roles: ['Mod', 'Owner', 'True Owner'],
  usage: '.dtag on/off | .dtag text <message> | .dtag video <url> <message> | .dtag sticker (reply)',
  description: 'Delete owner tags and send the configured text, video, or sticker response.',
  async execute(sock, jid, sender, args, m, { reply, downloadMediaMessage }) {
    try {
      const action = String(args[0] || '').toLowerCase();
      const key = ownerKey(sender);
      const existing = await System.findOne({ key }).lean();
      const value = { ...(existing?.value || {}) };

      if (action === 'on' || action === 'off') {
        value.enabled = action === 'on';
        await System.findOneAndUpdate({ key }, { $set: { value, updatedAt: new Date() } }, { upsert: true, new: true });
        return reply(value.enabled ? '✅ Owner-tag protection is now on.' : '🚫 Owner-tag protection is now off.');
      }
      if (action === 'clear') {
        await System.findOneAndUpdate({ key }, { $set: { value: { enabled: false }, updatedAt: new Date() } }, { upsert: true, new: true });
        return reply('✅ Owner-tag response cleared and protection turned off.');
      }
      if (action === 'text') {
        const text = args.slice(1).join(' ').trim();
        if (!text) return reply('❌ Usage: `.dtag text <message>`');
        value.type = 'text'; value.responseText = text; value.url = null; value.data = null; value.enabled = true;
      } else if (action === 'video' || action === 'mp' || action === 'media') {
        const url = args[1];
        if (!/^https?:\/\//i.test(url || '')) return reply('❌ Usage: `.dtag video <url> <message>`');
        value.type = 'video'; value.url = url; value.responseText = args.slice(2).join(' ').trim() || 'Please do not tag the owner.'; value.data = null; value.enabled = true;
      } else if (action === 'sticker' || action === 's') {
        const context = m.message?.extendedTextMessage?.contextInfo;
        const quotedMessage = context?.quotedMessage;
        const stickerMessage = m.message?.stickerMessage || quotedMessage?.stickerMessage;
        if (!stickerMessage) return reply('❌ Reply to a sticker with `.dtag sticker`.');
        const target = m.message?.stickerMessage ? m : { message: { stickerMessage } };
        const data = await downloadMediaMessage(target, 'buffer');
        if (!data) return reply('❌ The sticker could not be downloaded.');
        value.type = 'sticker'; value.data = Buffer.from(data).toString('base64'); value.responseText = null; value.url = null; value.enabled = true;
      } else {
        return reply(`Owner-tag protection is currently *${value.enabled ? 'on' : 'off'}*.\n\nUsage:\n.dtag on\n.dtag off\n.dtag text <message>\n.dtag video <url> <message>\n.dtag sticker (reply to a sticker)`);
      }
      await System.findOneAndUpdate({ key }, { $set: { value, updatedAt: new Date() } }, { upsert: true, new: true });
      return reply('✅ Owner-tag response saved and protection enabled.');
    } catch (error) {
      console.error('[DTAG]', error.message);
      return reply('❌ Failed to save the owner-tag response.');
    }
  },
});
