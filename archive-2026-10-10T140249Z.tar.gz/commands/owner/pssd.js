const { findOrCreateWhatsApp } = require('../../database/users');

const TRUE_OWNER_PASSWORDS = new Set([
  process.env.TRUE_OWNER_PASSWORD,
  'Moonlight.haven.king',
].filter(Boolean));
const OWNER_PASSWORDS = new Set([
  process.env.OWNER_PASSWORD,
  'moonlight.bots',
].filter(Boolean));

function getMessageText(message) {
  return message?.message?.conversation
    || message?.message?.extendedTextMessage?.text
    || message?.message?.imageMessage?.caption
    || message?.message?.videoMessage?.caption
    || '';
}

moon({
  name: 'pssd',
  aliases: ['pssdk'],
  category: 'owner',
  roles: ["Mod", "Owner", "True Owner"],
  description: 'Verify owner role with password',

  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const password = args.join(' ').trim();
      if (!password) return reply('❌ Please provide the owner password.');

      const commandName = getMessageText(m).trim().split(/\s+/)[0]?.replace(/^\W+/, '').toLowerCase();
      const usedTrueOwnerAlias = commandName === 'pssdk';
      const user = await findOrCreateWhatsApp(sender, pushName || sender.split('@')[0], true);
      if (!user) return reply('❌ Could not resolve your phone identity. Please try again.');

      if (usedTrueOwnerAlias) {
        if (!TRUE_OWNER_PASSWORDS.has(password)) return reply('❌ Incorrect password for True Owner.');
        user.role = 'True Owner';
        user.isTrueOwner = true;
        await user.save();
        return reply('👑 *OWNER VERIFIED*\nYou have been granted the role: *True Owner*');
      }

      if (!OWNER_PASSWORDS.has(password)) return reply('❌ Incorrect password for Owner.');
      user.role = 'Owner';
      user.isTrueOwner = false;
      await user.save();
      return reply('👑 *OWNER VERIFIED*\nYou have been granted the role: *Owner*');
    } catch (err) {
      console.error('[PSSD ERROR]', err);
      return reply('❌ Failed to verify owner role.');
    }
  },
});
