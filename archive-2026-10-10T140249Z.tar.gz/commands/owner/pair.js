const fs = require('fs');
const path = require('path');
const pino = require('pino');
const config = require('../../config');
const Bot = require('../../models/athers/Bot');
const { makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('../../utils/baileys');

const pairingJobs = new Map();
const PAIR_TIMEOUT_MS = 120000;

function phoneJid(number) { return `${String(number).replace(/\D/g, '')}@s.whatsapp.net`; }
function cleanName(value) { return String(value || '').trim().replace(/\s+/g, ' '); }

async function sendSessionToPairedNumber(sock, number, botName, tempDir, quoted) {
  const target = phoneJid(number);
  const credsPath = path.join(tempDir, 'creds.json');
  const status = `bot connected as *${botName}*\n> bot was connected and went offline use the under sessions to start the bot on the official haven bots hosting`;
  await sock.sendMessage(target, { text: status }, { quoted }).catch(() => {});
  if (fs.existsSync(credsPath)) {
    await sock.sendMessage(target, {
      document: fs.readFileSync(credsPath),
      mimetype: 'application/json',
      fileName: `${botName}-sessions.json`,
      caption: `*${botName} sessions*\nUse this sessions file on the official Haven Bots Hosting panel.`,
    }).catch(() => {});
  }
}

moon({
  name: 'pair',
  category: 'owner',
  roles: ['Mod', 'Owner', 'True Owner'],
  description: 'Create one guarded WhatsApp pairing session.',
  usage: '.pair <number> | .pair list',
  async execute(sock, jid, sender, args, m, { reply }) {
    const sub = String(args[0] || '').toLowerCase();
    if (!sub || sub === 'list') return reply('🤖 *PAIRING*\n\nUse `.pair <phone number>` to create one session for that number.\n> The completed session file is sent to that number in a DM.');
    const number = String(args.join('')).replace(/\D/g, '');
    if (number.length < 8) return reply('❌ Usage: `.pair <number>` with country code.');
    const botName = cleanName(config.BOT_NAME || 'Rem');
    if (pairingJobs.has(botName.toLowerCase())) return reply(`⏳ A pairing request for *${botName}* is already running. Please wait for it to finish or expire.`);

    const tempDir = path.join(process.cwd(), `temp_pair_${Date.now()}_${Math.random().toString(16).slice(2)}`);
    const job = { tempDir, startedAt: Date.now() };
    pairingJobs.set(botName.toLowerCase(), job);
    await reply(`⏳ Starting one pairing request for *${botName}*. Enter the code on WhatsApp before it expires.`);

    try {
      fs.mkdirSync(tempDir, { recursive: true });
      const { state, saveCreds } = await useMultiFileAuthState(tempDir);
      const { version } = await fetchLatestBaileysVersion();
      const tempSock = makeWASocket({ version, logger: pino({ level: 'silent' }), auth: state, browser: ['Ubuntu', 'Chrome', '20.0.04'] });
      job.sock = tempSock;
      tempSock.ev.on('creds.update', saveCreds);
      await new Promise((resolve, reject) => {
        let settled = false;
        const timer = setTimeout(() => { if (!settled) { settled = true; reject(new Error('Pairing connection did not become ready in time.')); } }, 15000);
        tempSock.ev.on('connection.update', (update) => {
          if (update.connection === 'connecting' || update.connection === 'open' || update.qr) { if (!settled) { settled = true; clearTimeout(timer); resolve(); } }
          if (update.connection === 'close' && !settled) { settled = true; clearTimeout(timer); reject(new Error('WhatsApp closed the pairing connection.')); }
        });
      });
      const code = await tempSock.requestPairingCode(number);
      const formatted = code?.match(/.{1,4}/g)?.join('-') || code;
      await reply(`🔑 *${botName} pairing code:* \`${formatted}\`\n> Link it in WhatsApp → Linked Devices → Link with phone number.`);

      await new Promise((resolve, reject) => {
        let settled = false;
        const finish = (error) => { if (settled) return; settled = true; clearTimeout(timer); error ? reject(error) : resolve(); };
        const timer = setTimeout(() => finish(new Error('Pairing timed out. Please try again.')), PAIR_TIMEOUT_MS);
        tempSock.ev.on('connection.update', (update) => {
          if (update.connection === 'open') finish();
          if (update.connection === 'close' && !settled) finish(new Error('WhatsApp closed the pairing connection before it completed.'));
        });
      });

      const credsPath = path.join(tempDir, 'creds.json');
      if (!fs.existsSync(credsPath)) throw new Error('Pairing completed but no sessions file was created.');
      await Bot.findOneAndUpdate({ name: botName }, { $set: { name: botName, lastSeen: new Date() } }, { upsert: true, new: true });
      await sendSessionToPairedNumber(sock, number, botName, tempDir, m);
      return reply(`✅ Pairing completed for *${botName}*. The sessions file was sent privately to the paired number.`);
    } catch (error) {
      console.error('[PAIR]', error.message);
      return reply(`❌ Pairing failed: ${error.message}`);
    } finally {
      try { job.sock?.end?.(); } catch {}
      pairingJobs.delete(botName.toLowerCase());
      setTimeout(() => fs.rmSync(tempDir, { recursive: true, force: true }), 1000);
    }
  },
});
