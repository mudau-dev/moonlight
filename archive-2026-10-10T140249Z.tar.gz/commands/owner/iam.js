const User = require('../../models/User');
function digits(value) { return String(value || '').replace(/\D/g, ''); }
function queryFor(sender) { const d = digits(sender); return { $or: [{ whatsappNumber: sender }, { userId: sender }, { phoneNumber: sender }, { phoneNumber: d }, { moonId: d }, { whatsappNumber: `${d}@s.whatsapp.net` }] }; }
moon({ name: 'iam', category: 'owner', roles: ['Owner', 'True Owner'], description: 'Set the private name the character handlers should use for you.', usage: '.iam kai | .iam luc | .iam riku', async execute(sock, jid, sender, args, m, { reply }) {
  const name = String(args?.[0] || '').trim().toLowerCase();
  if (!['kai', 'luc', 'riku'].includes(name)) return reply('❌ Use `.iam kai`, `.iam luc`, or `.iam riku` only.');
  const user = await User.findOne(queryFor(sender));
  if (!user) return reply('❌ Register first, then set your private identity.');
  user.aiIdentityName = name;
  await user.save();
  return reply(`✅ I will remember you as *${name}* in private character conversations.`);
}});
