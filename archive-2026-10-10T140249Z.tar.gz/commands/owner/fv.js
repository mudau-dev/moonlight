const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const youtubedl = require('youtube-dl-exec');

const MAX_BYTES = 120 * 1024 * 1024;
const DOWNLOAD_TIMEOUT = 180_000;
const SUPPORTED_HOSTS = new Set(['thisvid.com', 'www.thisvid.com', 'xhamster.com', 'www.xhamster.com', 'xhamster.desi', 'www.xhamster.desi']);

function supportedUrl(value) {
  try {
    const parsed = new URL(value);
    return /^https?:$/.test(parsed.protocol) && SUPPORTED_HOSTS.has(parsed.hostname.toLowerCase());
  } catch {
    return false;
  }
}

function safeName(value) {
  return String(value || 'moonlight-video')
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80) || 'moonlight-video';
}

moon({
  name: 'fv',
  category: 'owner',
  roles: ['True Owner'],
  usage: '.fv <url>',
  description: 'Fetch a video from supported hosts.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const url = String(args?.[0] || '').trim();
    if (!supportedUrl(url)) return reply('provide a url only');

    const workdir = fs.mkdtempSync(path.join(os.tmpdir(), 'moon-fv-'));
    const output = path.join(workdir, `${crypto.randomUUID()}.%(ext)s`);

    try {
      await sock.sendMessage(jid, { react: { text: '⏳', key: m.key } });
      const info = await youtubedl(url, {
        dumpSingleJson: true,
        noPlaylist: true,
        noWarnings: true,
        noCheckCertificates: true,
        skipDownload: true,
      }, { timeout: 45_000 });

      const parsedInfo = typeof info === 'string' ? JSON.parse(info) : info;
      const title = safeName(parsedInfo?.title);
      const downloadPath = path.join(workdir, `${title}.%(ext)s`);
      await youtubedl(url, {
        output: downloadPath,
        format: 'best[ext=mp4][height<=720]/best[height<=720]/best',
        mergeOutputFormat: 'mp4',
        noPlaylist: true,
        noWarnings: true,
        noCheckCertificates: true,
        restrictFilenames: true,
        maxFilesize: `${MAX_BYTES}B`,
      }, { timeout: DOWNLOAD_TIMEOUT });

      const files = fs.readdirSync(workdir).filter((file) => /\.(mp4|webm|mkv|mov)$/i.test(file));
      if (!files.length) throw new Error('No video file was produced.');
      const filePath = path.join(workdir, files[0]);
      const stat = fs.statSync(filePath);
      if (stat.size <= 0 || stat.size > MAX_BYTES) throw new Error('Video exceeds the size limit.');

      await sock.sendMessage(jid, {
        video: fs.createReadStream(filePath),
        mimetype: 'video/mp4',
        fileName: `${title}.mp4`,
        caption: title,
      }, { quoted: m });
      await sock.sendMessage(jid, { react: { text: '✅', key: m.key } });
    } catch (error) {
      console.error('[FV ERROR]', error?.message || error);
      await sock.sendMessage(jid, { react: { text: '❌', key: m.key } });
      return reply('❌ Failed to fetch video.');
    } finally {
      fs.rmSync(workdir, { recursive: true, force: true });
    }
  },
});
