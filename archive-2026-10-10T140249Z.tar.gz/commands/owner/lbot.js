const Bot = require('../../models/athers/Bot');

moon({
  name: 'lbot',
  category: 'owner',
  roles: ['True Owner'],
  description: 'Add or remove bot names from the database fleet list.',
  usage: '.lbot add <name> | .lbot remove <name>',
  async execute(sock, jid, sender, args, m, { reply }) {
    const action = String(args[0] || '').toLowerCase();
    const name = String(args.slice(1).join(' ') || '').trim().replace(/\s+/g, ' ');
    if (!['add', 'remove', 'del', 'delete'].includes(action) || !name || name.length > 40) return reply('❌ Usage: `.lbot add <name>` or `.lbot remove <name>`.');
    const normalized = name.toLowerCase();
    if (action === 'add') {
      const existing = await Bot.findOne({ name: new RegExp(`^${normalized.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')}$`, 'i') }).lean();
      if (existing) return reply(`ℹ️ *${existing.name}* is already in the bot database.`);
      await Bot.create({ name, lastSeen: new Date() });
      return reply(`✅ Added *${name}* to the bot database. It now appears in \.bots.`);
    }
    const removed = await Bot.deleteOne({ name: new RegExp(`^${normalized.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')}$`, 'i') });
    if (!removed.deletedCount) return reply(`❌ Bot *${name}* was not found in the database.`);
    return reply(`✅ Removed *${name}* from the bot database list.`);
  },
});
