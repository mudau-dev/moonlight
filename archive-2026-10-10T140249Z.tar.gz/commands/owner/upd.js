/**
 * commands/owner/upd.js
 *
 * .upd — Fetch the latest updates from Git and restart the bot.
 *
 * Restart strategy (in order of preference):
 *   1. PM2 (if running under PM2): pm2 restart <name>
 *   2. Forever: forever restart <script>
 *   3. Fallback: process.exit(0) — relies on the hosting platform to restart
 *
 * process.exit(0) alone is NOT a permanent shutdown — it signals the process
 * manager to restart the bot. If the bot is running without a process manager,
 * the hosting platform (e.g., Railway, Heroku, VPS with systemd) will restart it.
 */

const { exec } = require('child_process');
const path = require('path');

function detectProcessManager() {
  // PM2 sets this env variable
  if (process.env.PM2_HOME || process.env.pm_id !== undefined || process.env.PM2_USAGE) {
    return 'pm2';
  }
  // Forever sets this
  if (process.env.FOREVER_ROOT) {
    return 'forever';
  }
  return 'exit';
}

function restartBot(rootDir) {
  const manager = detectProcessManager();
  console.log(`[UPD] Restarting via: ${manager}`);

  if (manager === 'pm2') {
    const appName = process.env.PM2_APP_NAME || process.env.name || 'moon-bot';
    exec(`pm2 restart "${appName}"`, { cwd: rootDir }, (err) => {
      if (err) {
        console.error('[UPD] PM2 restart failed, falling back to exit:', err.message);
        setTimeout(() => process.exit(0), 500);
      }
    });
    return;
  }

  if (manager === 'forever') {
    const script = path.join(rootDir, 'index.js');
    exec(`forever restart "${script}"`, { cwd: rootDir }, (err) => {
      if (err) {
        console.error('[UPD] Forever restart failed, falling back to exit:', err.message);
        setTimeout(() => process.exit(0), 500);
      }
    });
    return;
  }

  // Default: exit with code 0 — process manager / hosting platform will restart
  setTimeout(() => process.exit(0), 500);
}

moon({
  name: 'upd',
  category: 'owner',
  roles: ["Mod", "Owner", "True Owner"],
  description: 'Fetch the latest updates from Git and restart the bot automatically.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const rootDir = path.join(__dirname, '../../');

    // Step 1: Announce
    const sentMessage = await sock.sendMessage(
      jid,
      { text: '🔄 *1.* Fetching new updates…' },
      { quoted: m }
    );

    const edit = (text) =>
      sock.sendMessage(jid, { text, edit: sentMessage.key }).catch(() => {});

    exec('git pull --ff-only origin main', { cwd: rootDir, timeout: 60_000 }, async (error, stdout, stderr) => {
      // Step 2: Handle errors
      if (error) {
        const detail = (stderr || error.message).slice(0, 500);
        return edit(`❌ *Update failed*\n\n\`\`\`${detail}\`\`\``);
      }

      // Step 3: Already up to date
      if (stdout.includes('Already up to date.')) {
        return edit(
          `✅ *No new updates found*\n\n` +
          `The bot is already running the latest version.\n` +
          `> No restart needed.`
        );
      }

      // Step 4: Updates found
      const changes = stdout.slice(0, 800).trim();
      await edit(
        `✅ *New updates found!*\n\n` +
        `\`\`\`${changes}\`\`\`\n\n` +
        `🔄 Bot is restarting itself…`
      );

      // Step 5: Final message then restart
      setTimeout(async () => {
        try {
          await edit(
            `✅ *Bot fetched new updates and updated itself!*\n\n` +
            `\`\`\`${changes}\`\`\`\n\n` +
            `♻️ Restarting now — back in a moment!`
          );
        } catch {}
        // Give WhatsApp a moment to deliver the edit before restarting
        setTimeout(() => restartBot(rootDir), 2_000);
      }, 1_500);
    });
  },
});
