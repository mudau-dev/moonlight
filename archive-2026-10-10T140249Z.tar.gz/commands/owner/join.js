const config = require('../../config');
const { markIntentionalJoin } = require('../../handlers/Bot');

function normaliseParticipant(value) {
  return typeof value === 'string' ? value : (value?.id || value?.jid || value?.participant || '');
}

function mentionLabel(jid) {
  return String(jid || '').split('@')[0].split(':')[0].replace(/[^0-9A-Za-z_-]/g, '') || 'member';
}

function chunks(text, size = 3500) {
  return String(text || '').match(new RegExp(`[\\s\\S]{1,${size}}`, 'g')) || [''];
}

moon({
  name: 'join',
  category: 'owner',
  roles: ['Mod', 'Owner', 'True Owner'],
  description: 'Make the bot join a group via invite link',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const inviteLink = args[0];
      if (!inviteLink) return reply('❌ Please provide a WhatsApp group invite link.');
      const match = inviteLink.match(/chat\.whatsapp\.com\/(?:invite\/)?([a-zA-Z0-9_-]{20,26})/);
      const inviteCode = match ? match[1] : null;
      if (!inviteCode) return reply('❌ Invalid invite link format. Please provide a full chat.whatsapp.com link.');

      let info;
      try { info = await sock.groupGetInviteInfo(inviteCode); }
      catch (err) {
        const message = String(err?.message || err);
        if (/406|not-authorized/i.test(message)) return reply('❌ Could not join: the bot may be banned or the invite is restricted.');
        if (/410|gone|expired/i.test(message)) return reply('❌ Could not join: this invite link has expired or been reset.');
        return reply(`❌ Could not inspect this invite: ${message}`);
      }
      if (info?.joinApprovalMode === true || info?.approvalMode === true || info?.membershipApprovalMode === true) {
        return reply('❌ This group requires admin approval. I did not request to join.');
      }

      let groupJid;
      try {
        if (info?.id) markIntentionalJoin(info.id);
        groupJid = await sock.groupAcceptInvite(inviteCode);
        if (!groupJid) groupJid = info?.id;
      } catch (err) {
        const message = String(err?.message || err);
        if (/406|not-authorized/i.test(message)) return reply('❌ Could not join: the bot may be banned or the invite is restricted.');
        if (/410|gone|expired/i.test(message)) return reply('❌ Could not join: this invite link has expired or was reset.');
        if (/409|conflict|already/i.test(message)) return reply('ℹ️ The bot is already a member of this group.');
        if (/429|rate/i.test(message)) return reply('❌ Rate limited: too many join attempts. Please try again later.');
        return reply(`❌ Could not join group: ${message}`);
      }
      if (!groupJid) return reply('❌ The group ID was not returned after joining.');

      const metadata = await sock.groupMetadata(groupJid).catch(() => null);
      const participants = (metadata?.participants || []).map(normaliseParticipant).filter(Boolean);
      const adminParticipants = (metadata?.participants || []).filter((participant) => Boolean(participant.admin));
      const botName = config.BOT_NAME || 'Moonlight';
      const groupName = metadata?.subject || info?.subject || 'Unknown group';
      const ownerName = config.OWNER_NAME || '𓆩ᥫ𝐑𝐢𝐤𝐮𓆪';
      const status = metadata?.announce === true ? 'closed' : 'open';

      const welcome = [
        '☆ ▪︎ -------[𝐌𝐨𝐨𝐧𝐥𝐢𝐠𝐡𝐭]-------▪︎ ☆',
        `Hy everyone i am *${botName}*`,
        '> Thank you for adding me to your group!',
        '',
        "- If you'd like to participate in our community games,or have any questions simply use the command *.support*.",
        '',
        '- To register with the bot, please use *.reg* command.',
        '',
        '- fore help use `.mods` command.',
        '',
        '- Make sure to make me admin.',
        '',
        '- *DO NOT dm the bot at any cost or horrible things will happen.*',
        '',
        '☆ ▪︎ -------------------------▪︎ ☆',
        '> *Website:* https://haven-moon.zone.id',
      ].join('\n');

      const messageOptions = { mentions: participants };
      try {
        if (config.MENU_IMAGE) await sock.sendMessage(groupJid, { image: { url: config.MENU_IMAGE }, caption: welcome, ...messageOptions });
        else await sock.sendMessage(groupJid, { text: welcome, ...messageOptions });
        // The welcome image/caption itself carries the participant mentions as a hidetag.
        // Do not send a second visible @member list into the group.
      } catch (err) {
        console.error('[JOIN WELCOME]', err.message);
        await sock.sendMessage(groupJid, { text: welcome, ...messageOptions }).catch(() => {});
      }

      const summary = [
        '☆ ▪︎ -------[𝐌𝐨𝐨𝐧𝐥𝐢𝐠𝐡𝐭]-------▪︎ ☆',
        'bot joined the group',
        `*Name:* ${groupName}`,
        `*participants:* ${participants.length}`,
        `*admins:* ${adminParticipants.length}`,
        `*status:* >${status}`,
      ].join('\n');
      await reply(summary);
    } catch (err) {
      console.error('[JOIN COMMAND]', err);
      return reply('❌ An unexpected error occurred while trying to join.');
    }
  },
});
