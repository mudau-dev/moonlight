const GroupCategoryLock = require('../../models/athers/GroupCategoryLock');

function getCategories(commands) {
  const set = new Set();
  for (const cmd of commands.values()) {
    const category = String(cmd?.category || '').trim().toLowerCase();
    if (category && category !== 'owner' && category !== 'admin') set.add(category);
  }
  return [...set].sort((a, b) => a.localeCompare(b));
}

moon({
  name: 'gctg',
  category: 'owner',
  roles: ['True Owner'],
  description: 'Lock or open command categories for the current group',
  usage: '.gctg list | .gctg lock all | .gctg open <index>',
  async execute(sock, jid, sender, args, m, { reply, commands }) {
    try {
      if (!jid.endsWith('@g.us')) return reply('❌ This command can only be used inside a group.');
      const categories = getCategories(commands);
      const sub = String(args[0] || '').toLowerCase();
      const target = String(args[1] || '').toLowerCase();

      if (!sub || sub === 'help' || sub === 'menu') {
        return reply([
          '🌙 *MOONLIGHT GROUP CATEGORY CONTROL*',
          '',
          '`.gctg list` — show category locks',
          '`.gctg lock all` — lock all non-owner categories',
          '`.gctg open all` — open all categories',
          '`.gctg open <index>` — open one category',
          '`.gctg lock <index>` — lock one category',
          '',
          'Only the *True Owner* can change these settings.',
        ].join('\n'));
      }

      const locks = await GroupCategoryLock.find({ groupId: jid }).lean();
      const lockMap = new Map(locks.map((row) => [row.category, row.locked === true]));
      if (sub === 'list') {
        const rows = categories.map((category, index) => `${index + 1}. ${lockMap.get(category) ? '🔒' : '🔓'} ${category}`);
        return reply(`🌙 *GROUP CATEGORY STATUS*\n\n${rows.join('\n') || 'No categories found.'}`);
      }

      if (!['lock', 'open'].includes(sub)) return reply('❌ Unknown option. Use `.gctg` for help.');
      if (target === 'all') {
        await GroupCategoryLock.bulkWrite(categories.map((category) => ({
          updateOne: {
            filter: { groupId: jid, category },
            update: { $set: { locked: sub === 'lock', lockedBy: sender } },
            upsert: true,
          },
        })));
        return reply(`✅ ${sub === 'lock' ? 'All command categories are now locked' : 'All command categories are now open'} for this group.`);
      }

      const index = Number.parseInt(target, 10);
      if (!Number.isInteger(index) || index < 1 || index > categories.length) {
        return reply('❌ Invalid category index. Use `.gctg list` first.');
      }
      const category = categories[index - 1];
      await GroupCategoryLock.findOneAndUpdate(
        { groupId: jid, category },
        { $set: { locked: sub === 'lock', lockedBy: sender } },
        { upsert: true, new: true },
      );
      return reply(`✅ Category *${category}* is now ${sub === 'lock' ? 'locked' : 'open'} for this group.`);
    } catch (error) {
      console.error('[GCTG ERROR]', error);
      return reply('❌ Group category settings could not be updated.');
    }
  },
});
