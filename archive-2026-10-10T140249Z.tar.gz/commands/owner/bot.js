const config = require('../../config');
const Bot = require('../../models/athers/Bot');
const BotGroup = require('../../models/athers/BotGroup');
const BotAction = require('../../models/athers/BotAction');
const User = require('../../models/User');
const { findParticipantByIdentity, isParticipantAdmin, getBotIdentity, sameIdentity } = require('../../utils/adminIdentity');

const STAFF_ROLES = new Set(['Guardian', 'Mod', 'Owner', 'True Owner', 'CDC']);

async function liveGroups(sock) {
  try {
    const groups = await sock.groupFetchAllParticipating();
    return Object.values(groups || {}).filter((group) => group?.id && !group.isCommunity && !group.isCommunityAnnounce && !/community|announcement/i.test(String(group.subject || ''))).map((group) => ({
      id: group.id,
      subject: group.subject || 'Unknown',
      participantCount: group.participants?.length || 0,
      isAdmin: isParticipantAdmin(findParticipantByIdentity(group.participants || [], getBotIdentity(sock, config))),
    }));
  } catch { return []; }
}

async function fleetGroups(sock) {
  const records = await BotGroup.find({ isCommunity: { $ne: true }, isCommunityAnnounce: { $ne: true }, subject: { $not: /community|announcement/i } }).sort({ botName: 1, subject: 1 }).lean();
  const grouped = new Map();
  for (const row of records) {
    if (!grouped.has(String(row.botName).toLowerCase())) grouped.set(String(row.botName).toLowerCase(), []);
    grouped.get(String(row.botName).toLowerCase()).push(row);
  }
  const currentName = String(config.BOT_NAME || 'Rem').toLowerCase();
  if (!grouped.get(currentName)?.length) grouped.set(currentName, await liveGroups(sock));
  return grouped;
}

function chunks(text, size = 3500) { return text.match(new RegExp(`[\\s\\S]{1,${size}}`, 'g')) || [text]; }

async function botInfo(sock, botName, grouped) {
  const record = await Bot.findOne({ name: new RegExp(`^${String(botName).replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')}$`, 'i') }).lean();
  const groups = grouped.get(String(botName).toLowerCase()) || [];
  const number = sock?.user?.id ? String(sock.user.id).split(':')[0].split('@')[0] : 'Not connected';
  return [`*Name:* ${record?.name || botName}`, `*Owner:* Haven / Moonlight`, `*Groups:* ${groups.length || record?.groups?.length || 0}`, `*Id:* ${record?._id || 'Not registered'}`, `*Number:* ${number}`, '', '*Sub commands:*', '`.bot groups` — list all bot groups', '`.bot group <index>` — show group info', '`.bot leave <index>` — leave a group', '`.bot cmds` — list bot commands'].join('\n');
}

function flattenGroups(grouped) {
  const rows = [];
  for (const [botName, list] of grouped.entries()) for (const group of list || []) rows.push({ ...group, botName });
  return rows;
}

async function groupInfo(sock, jid, groupId, botName, index) {
  let metadata;
  try { metadata = await sock.groupMetadata(groupId); } catch (error) {
    return sock.sendMessage(jid, { text: `🔎 *BOT GROUP INFO*\n🤖 Bot: *${botName}*\n🆔 Stored group index: *${index}*\n⚠️ Live group information is temporarily unavailable. The group is still present in the bot snapshot.` }, { quoted: null });
  }
  const bot = findParticipantByIdentity(metadata.participants || [], getBotIdentity(sock, config));
  const participantIds = (metadata.participants || []).map((participant) => participant.id).filter(Boolean);
  const staffUsers = await User.find({ $or: [{ role: { $in: [...STAFF_ROLES] } }, { isTrueOwner: true }, { isCDC: true }] }).select('name pushName role isTrueOwner isCDC whatsappNumber phoneNumber userId').lean();
  const staff = [];
  const mentions = [];
  for (const user of staffUsers) {
    const identity = user.whatsappNumber || user.phoneNumber || user.userId;
    const participant = (metadata.participants || []).find((entry) => sameIdentity(entry, identity));
    if (!participant) continue;
    const mention = participant.id;
    if (mention && !mentions.includes(mention)) {
      mentions.push(mention);
      const participantLabel = participant.notify || participant.name || user.name || user.pushName || 'Haven Staff';
      staff.push(`@${participantLabel} · ${user.isTrueOwner ? 'True Owner' : user.isCDC ? 'CDC' : user.role}`);
    }
  }
  const adminParticipants = (metadata.participants || []).filter((participant) => isParticipantAdmin(participant));
  const admins = adminParticipants.map((participant) => `@${participant.notify || participant.name || participant.id.split('@')[0]}`);
  const adminMentions = adminParticipants.map((participant) => participant.id);
  const text = [`🔎 *BOT GROUP INFO*`, `🤖 Bot: *${botName}*`, `📛 Group: *${metadata.subject || 'Unknown'}*`, `👥 Members: *${metadata.participants?.length || 0}*`, `🛡️ Bot admin: *${isParticipantAdmin(bot) ? 'YES' : 'NO'}*`, `👑 *GROUP ADMINS*`, admins.length ? admins.join(' · ') : 'None', '', `🌙 *HAVEN TEAM IN THIS GROUP*`, staff.length ? staff.join('\n') : 'None of our support team is in this group.', '', `Use *.bot groups* to list all bot groups.`].join('\n');
  return sock.sendMessage(jid, { text, mentions: [...new Set([...mentions, ...adminMentions])] }, { quoted: null });
}

moon({
  name: 'bot',
  aliases: ['pbot'],
  category: 'owner',
  roles: ['Mod', 'Owner', 'True Owner'],
  description: 'Manage the fleet bot group list and group controls.',
  subcommands: ['groups', 'group', 'leave', 'cmds'],
  async execute(sock, jid, sender, args, m, { reply, commands }) {
    try {
      const sub = String(args[0] || '').toLowerCase();
      const currentBot = String(config.BOT_NAME || 'Rem').toLowerCase();
      const grouped = await fleetGroups(sock);
      if (sub === 'del' || sub === 'delete' || sub === 'remove') {
        const name = String(args.slice(1).join(' ') || '').trim();
        if (!name) return reply('❌ Usage: `.pbot del <bot name>`.');
        const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const matcher = new RegExp(`^${escaped}$`, 'i');
        const matches = await Bot.find({ name: matcher }).select('_id name').lean();
        if (!matches.length) return reply(`❌ Bot *${name}* was not found.`);
        const canonical = matches[0].name;
        await Bot.updateMany({ name: matcher }, { $set: { disabled: true } });
        await BotGroup.deleteMany({ botName: matcher });
        await BotAction.deleteMany({ botName: matcher, status: 'pending' });
        return reply(`✅ Bot *${canonical}* was removed from \.bots and disabled from automatic re-creation.`);
      }
      if (!sub) {
        const caption = await botInfo(sock, currentBot, grouped);
        if (config.MENU_IMAGE) return sock.sendMessage(jid, { image: { url: config.MENU_IMAGE }, caption }, { quoted: m });
        return reply(caption);
      }
      if (sub === 'groups' || sub === 'gcs') {
        let number = 1;
        const lines = ['📋 *MOONLIGHT BOT GROUPS*', ''];
        for (const [bot, list] of grouped.entries()) {
          lines.push(`*${bot.toUpperCase()}*`);
          if (!list.length) lines.push('  _No group snapshot yet._');
          else for (const group of list) lines.push(`${number++}. ${group.subject || 'Unknown'} · ${group.participantCount || 0} members${group.isAdmin ? ' · bot admin' : ''}`);
          lines.push('');
        }
        for (const part of chunks(lines.join('\n'))) await reply(part);
        return;
      }
      if (sub === 'group' || sub === 'info' || sub === 'gnf') {
        let botName = currentBot;
        let indexArg = args[1];
        if (grouped.has(String(args[1] || '').toLowerCase())) { botName = String(args[1]).toLowerCase(); indexArg = args[2]; }
        const index = Number(indexArg);
        if (!Number.isInteger(index) || index < 1) return reply('❌ Usage: `.bot group <index>` or `.bot group <bot> <index>`.');
        const allGroups = flattenGroups(grouped);
        const target = args[1] && grouped.has(String(args[1] || '').toLowerCase())
          ? (grouped.get(botName) || [])[index - 1]
          : allGroups[index - 1];
        if (!target) return reply('❌ Group index not found. Use `.bot groups` first.');
        if (String(target.botName || botName).toLowerCase() !== currentBot) {
          const text = [`🔎 *BOT GROUP INFO*`, `🤖 Bot: *${String(target.botName || botName).toUpperCase()}*`, `📛 Group: *${target.subject || 'Unknown'}*`, `👥 Members: *${target.participantCount || 0}*`, `🛡️ Bot admin: *${target.isAdmin ? 'YES' : 'NO'}*`, '', '🌙 *HAVEN TEAM*', 'Use this command on the bot currently in this group for live admin and staff tags.'].join('\n');
          return reply(text);
        }
        return groupInfo(sock, jid, target.groupId || target.id, currentBot, index);
      }
      if (sub === 'leave') {
        let botName = currentBot;
        let indexArg = args[1];
        if (grouped.has(String(args[1] || '').toLowerCase())) { botName = String(args[1]).toLowerCase(); indexArg = args[2]; }
        const index = Number(indexArg);
        if (!Number.isInteger(index) || index < 1) return reply('❌ Usage: `.bot leave <index>` or `.bot leave <bot> <index>`.');
        const target = (botName === currentBot ? flattenGroups(grouped) : (grouped.get(botName) || []))[index - 1];
        if (!target) return reply('❌ Group index not found. Use `.bot groups` first.');
        if (botName === currentBot) { await reply(`👋 Leaving *${target.subject || 'selected group'}*...`); return sock.groupLeave(target.groupId || target.id); }
        await BotAction.create({ botName, action: 'leave', groupId: target.groupId || target.id, requestedBy: sender });
        return reply(`✅ Leave request sent to *${botName}* for *${target.subject || 'selected group'}*. It will leave on the next bot sync.`);
      }
      if (sub === 'cmds' || sub === 'commands') {
        const categories = {};
        for (const command of commands.values()) (categories[command.category || 'general'] ||= []).push(command.name);
        return reply(Object.entries(categories).sort().map(([category, names]) => `*${category.toUpperCase()}*\n> ${[...new Set(names)].sort().join(', ')}`).join('\n\n'));
      }
      return reply(await botInfo(sock, currentBot, grouped));
    } catch (error) {
      console.error('[BOT CMD ERROR]', error.message);
      return reply('❌ Failed to execute bot management command.');
    }
  },
});
