const axios = require('axios');
const config = require('../../config');

const PANEL_API_BASE = config.PANEL_API_BASE || 'https://control.bot-hosting.net/api/client/servers';
const PANEL_API_TOKEN = config.PANEL_API_TOKEN || '';
const APPROVED_BOTS = {
  Rem: '5bea48d5',
  rimuru: 'c2573fdd',
  Elaina: '4a86f73d',
  Cid: '934069ee',
  Lain: '78976de0',
  Frieren: '53acc665',
  Oreki: 'd47d45c4',
};

async function restartBot(name, serverId) {
  try {
    await axios.post(`${PANEL_API_BASE}/${serverId}/power`, { signal: 'restart' }, {
      headers: {
        Authorization: `Bearer ${PANEL_API_TOKEN}`,
        Accept: 'Application/vnd.pterodactyl.v1+json',
        'Content-Type': 'application/json',
      },
      timeout: 30_000,
    });
    return { name, ok: true };
  } catch (error) {
    console.error(`[RSB] ${name}:`, error.response?.status || error.message);
    return { name, ok: false };
  }
}

moon({
  name: 'rsb',
  category: 'owner',
  roles: ['True Owner'],
  description: 'Restart all approved Moonlight Haven bots and report the result.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!PANEL_API_TOKEN) return reply('❌ Panel restart token is not configured on this bot.');
    await reply('🔄 Restarting the approved Moonlight Haven bots. No stop/start cycle is being used.');
    const results = await Promise.all(Object.entries(APPROVED_BOTS).map(([name, id]) => restartBot(name, id)));
    const restarted = results.filter((result) => result.ok).map((result) => result.name);
    const failed = results.filter((result) => !result.ok).map((result) => result.name);
    return reply([
      `✅ *Restarted ${restarted.length}/${results.length} bots*`,
      '',
      '*Restarted bots:*',
      restarted.length ? restarted.map((name) => `• ${name}`).join('\n') : '• None',
      '',
      '*Bots that were not restarted:*',
      failed.length ? failed.map((name) => `• ${name}`).join('\n') : '• None',
    ].join('\n'));
  },
});

module.exports = { APPROVED_BOTS, restartBot };
