const { resolveMessageTarget, phoneNumberFromValue } = require('../../utils/adminIdentity');

moon({
  name: 'mod',
  aliases: ['moderator'],
  category: 'owner',
  roles: ["Mod", "Owner", "True Owner"],
  description: 'Manage moderators',
  usage: '.mod set/del @user | number | reply',

  async execute(sock, jid, sender, args, m, { reply, findOrCreateWhatsApp }) {
    try {
      const senderUser = await findOrCreateWhatsApp(sender, sender.split('@')[0], true);
      if (!senderUser || !['Owner', 'True Owner'].includes(senderUser.role)) {
        return reply("❌ You don't have permission to do that.");
      }

      const action = String(args[0] || '').toLowerCase();
      if (!['set', 'add', 'del', 'remove'].includes(action)) {
        return reply('❌ Usage: `.mod set @user` or `.mod del @user`');
      }

      const target = await resolveMessageTarget(sock, m, args.slice(1));
      if (!target) return reply('❌ Mention, reply to, or provide the phone number of a user.');

      const user = await findOrCreateWhatsApp(target, target.split('@')[0], true);
      if (!user) return reply('❌ User could not be resolved from that phone number.');
      const targetNumber = phoneNumberFromValue(target);

      if (['set', 'add'].includes(action)) {
        if (['True Owner', 'Owner'].includes(user.role)) return reply('❌ You cannot modify an owner.');
        user.role = 'Mod';
        await user.save();
        return reply(`🛡️ *Moderator Added*\n\n👤 @${targetNumber}\nStatus: Promoted to Mod`, { mentions: [target] });
      }

      if (user.role !== 'Mod') return reply('❌ This user is not a moderator.');
      user.role = 'User';
      await user.save();
      return reply(`⚠️ *Moderator Removed*\n\n👤 @${targetNumber}\nStatus: Demoted to User`, { mentions: [target] });
    } catch (err) {
      console.error('[MOD ERROR]', err);
      return reply('❌ Failed to update moderator.');
    }
  },
});
