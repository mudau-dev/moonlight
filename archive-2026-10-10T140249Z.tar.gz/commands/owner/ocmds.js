const User = require('../../models/User');
const config = require('../../config');

moon({
  name: "cmds",
  category: "owner",
  roles: ["Mod", "Owner", "True Owner"],
  description: "Show owner commands and uncategorized commands",

  async execute(sock, jid, sender, args, m, { reply, commands }) {

    try {

      if (!commands || typeof commands.values !== "function") {
        return reply("❌ Command system not ready.");
      }

      const ownerCmds = [];
      const noCatCmds = [];
      const seenOwner = new Set();
      const seenNoCat = new Set();

      for (const c of commands.values()) {
        if (!c?.name) continue;
        const name = String(c.name).trim().toLowerCase();
        const cat = String(c.category || '').trim().toLowerCase();
        if (cat === 'owner' && !seenOwner.has(name)) {
          seenOwner.add(name);
          ownerCmds.push(name);
        }
        if (!cat && !seenNoCat.has(name)) {
          seenNoCat.add(name);
          noCatCmds.push(name);
        }
      }
      ownerCmds.sort();
      noCatCmds.sort();

      const text =
`🌙 *MOONLIGHT COMMANDS*

👑 *OWNER COMMANDS*
${ownerCmds.length ? ownerCmds.map(v => `• .${v}`).join("\n") : "• None available"}

🧭 *GENERAL COMMANDS*
${noCatCmds.length ? noCatCmds.map(v => `• .${v}`).join("\n") : "• None available"}

_Use .help <command> for details._`;

      if (config.MENU_IMAGE) {
        return sock.sendMessage(jid, {
          image: { url: config.MENU_IMAGE },
          caption: text,
          mentions: [sender]
        }, { quoted: m });
      }

      return reply(text);

    } catch (err) {
      console.error("cmds error:", err);
      return reply("❌ Error loading cmds.");
    }
  }
});