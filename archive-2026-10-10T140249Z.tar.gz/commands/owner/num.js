const User = require('../../models/User');
const { migrateNumber, deleteNumberAccount, aliasesFor } = require('../../utils/numberMigration');
function clean(value) { return String(value || '').replace(/\D/g, ''); }
function identityQuery(number) { const value = clean(number); return { $or: [{ moonId: value }, { phoneNumber: value }, { userId: value }, { whatsappNumber: value }, { whatsappNumber: `${value}@s.whatsapp.net` }] }; }
function currentMatch(user, value) { const needle = clean(value); return aliasesFor(user).some((entry) => clean(entry) === needle); }
function owner(user) { return user?.isTrueOwner === true || ['Owner', 'True Owner'].includes(String(user?.role || '')); }
moon({ name: 'num', aliases: ['number'], category: 'owner', roles: ['Owner', 'True Owner'], description: 'View connections or perform owner account migration.', usage: '.num | .num change <old> x <new> | .num off', async execute(sock, jid, sender, args, m, { reply }) {
  const actor = await User.findOne(identityQuery(sender));
  if (!actor) return reply('❌ This WhatsApp number is not registered.');
  const input = Array.isArray(args) ? args.join(' ').trim() : String(args || '').trim();
  if (!input) {
    const link = actor.discordId ? await User.db.collection('discord_links').findOne({ discordId: actor.discordId, status: 'active' }) : null;
    return reply(['📱 *USER CONNECTIONS*','━━━━━━━━━━━━━━━━━━',`WhatsApp: *${actor.phoneNumber || clean(sender)}*`,`Moon ID: *${actor.moonId || '—'}*`,`Discord: ${actor.discordId ? `*${link?.discordUsername || actor.discordId}* 🟢` : '*Not connected*'}`, '', '`.num change <old> x <new>` — owner-only full account migration', '`.num del <number>` — owner-only permanent account deletion', '`.num off` — disconnect Discord from WhatsApp'].join('\n'));
  }
  if (/^off$/i.test(input)) {
    if (!actor.discordId) return reply('ℹ️ No Discord account is linked to this WhatsApp account.');
    await User.db.collection('discord_links').updateMany({ discordId: actor.discordId, status: 'active' }, { $set: { status: 'revoked' } });
    const discordId = actor.discordId; actor.discordId = null; await actor.save();
    return reply(`✅ Discord account *${discordId}* was disconnected from WhatsApp. The Discord link is revoked and the Discord identity is unregistered from this WhatsApp account.`);
  }
  const deleteMatch = input.match(/^del(?:ete)?\s+(.+)$/i);
  if (deleteMatch) {
    if (!owner(actor)) return reply('❌ Only an Owner or True Owner can use `.num del`.');
    const number = clean(deleteMatch[1]);
    if (!number || number.length < 7) return reply('❌ Enter a valid phone number with country code.');
    const target = await User.findOne(identityQuery(number));
    if (!target) return reply(`❌ No account is linked to *${number}*.`);
    if (target.isTrueOwner === true || ['True Owner', 'CDC'].includes(String(target.role || ''))) {
      return reply('❌ Protected True Owner and CDC accounts cannot be permanently deleted.');
    }
    const result = await deleteNumberAccount(target);
    return reply(`🗑️ *ACCOUNT PERMANENTLY DELETED*\n\nNumber: *${number}*\nUser record: ${result.userDeleted ? 'deleted' : 'not found'}\nLinked account data and shared references were removed. The number must use \.reg again to create a new account.`);
  }
  const match = input.match(/^change\s+(.+?)\s+x\s+(.+)$/i);
  if (!match) return reply('❌ Usage: `.num` | `.num change <old> x <new>` | `.num off`');
  if (!owner(actor)) return reply('❌ Only an Owner or True Owner can use `.num change`.');
  const oldNumber = clean(match[1]); const newNumber = clean(match[2]);
  if (!oldNumber || !newNumber || oldNumber.length < 7 || newNumber.length < 7) return reply('❌ Enter valid old and new WhatsApp numbers with country codes.');
  if (oldNumber === newNumber) return reply('❌ The new number must be different from the old number.');
  const target = await User.findOne(identityQuery(oldNumber));
  if (!target) return reply('❌ No user account was found for the old number.');
  if (!currentMatch(target, oldNumber)) return reply('❌ The old number does not match the target account.');
  const duplicate = await User.findOne({ ...identityQuery(newNumber), _id: { $ne: target._id } }).lean();
  if (duplicate) return reply(`❌ The new number *${newNumber}* is already linked to another account. Delete that account first with \.num del ${newNumber}, then run the migration again.`);
  await migrateNumber(target, newNumber);
  return reply(`✅ *Account migrated successfully by owner.*\n\nAll Pokémon, party, PC, guilds, inventory, cards, balances, progress, battles, requests, notifications, and connections now belong to *${newNumber}*.\n\nThe old account no longer needs to send a command. Discord remains linked.`);
}});
