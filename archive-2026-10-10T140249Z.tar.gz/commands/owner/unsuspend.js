const { unsuspendUser } = require('../../utils/modTools');
const { resolveMessageTarget } = require('../../utils/adminIdentity');

moon({
  name: "unsuspend",
  category: "owner",
  roles: ["Mod", "Owner", "True Owner"],
  description: "Unsuspend a user",
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
     
      const target = await resolveMessageTarget(sock, m, args);
      if (!target) return reply("❌ Mention, reply, phone JID, WhatsApp LID, or database ID could not be resolved.");
      const targetNumber = target.split('@')[0];
      const res = await unsuspendUser(target);
      if (!res.ok) return reply(res.message);
      
      return sock.sendMessage(jid, {
        text: `✅ *USER UNSUSPENDED*\n👤 *Target:* @${targetNumber}`,
        mentions: [target]
      }, { quoted: m });
    } catch (err) {
      console.error("UNSUSPEND ERROR:", err);
      return reply("❌ Failed to unsuspend user.");
    }
  }
});
