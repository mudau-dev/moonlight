const User = require('../../models/User');
const { getRealUserIdentity } = require('../../utils/whatsappIdentity');

const ROLE_INDEX_MAP = { '1': 'Owner', '2': 'Tester', '3': 'Mod', '4': 'Guardian', '5': 'True Owner' };

function digits(value) {
  return String(value || '').replace(/[^0-9]/g, '');
}

async function resolveTarget(sock, m, rawValue) {
  const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
  if (mentioned) {
    const identity = await getRealUserIdentity(sock, mentioned).catch(() => null);
    if (identity?.phoneJid) return { phoneJid: identity.phoneJid, number: identity.phoneNumber };
  }
  const number = digits(rawValue);
  if (!number) return null;
  return { phoneJid: `${number}@s.whatsapp.net`, number };
}

moon({
  name: 'role',
  category: 'owner',
  roles: ['True Owner'],
  description: 'Manage user roles',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const sub = args[0]?.toLowerCase();
      if (!['add', 'del', 'remove'].includes(sub)) {
        return reply('❌ Usage:\n.role add @user <role>\n.role del @user\n\nRoles:\nOwner, Tester, Mod, Guardian, True Owner\nYou may also use indices 1–5.');
      }

      const target = await resolveTarget(sock, m, args[1]);
      if (!target) return reply('❌ Mention a user or provide their phone number.');
      const targetUser = await User.findOne({ $or: [
        { whatsappNumber: target.phoneJid },
        { phoneNumber: target.number },
        { userId: target.number },
        { moonId: target.number },
      ] });
      if (!targetUser) return reply('❌ User not found by phone identity.');

      if (sub === 'add') {
        const requested = String(args[2] || args[1] || '').trim();
        const newRole = ROLE_INDEX_MAP[requested] || ['Owner', 'Tester', 'Mod', 'Guardian', 'True Owner'].find((role) => role.toLowerCase() === requested.toLowerCase());
        if (!newRole) return reply('❌ Invalid role. Use Owner, Tester, Mod, Guardian, True Owner, or indices 1–5.');
        targetUser.role = newRole;
        if (newRole === 'True Owner') targetUser.isTrueOwner = true;
        await targetUser.save();
        return reply(`✅ Role for @${target.number} set to *${newRole}*`, { mentions: [target.phoneJid] });
      }

      targetUser.role = 'User';
      targetUser.isTrueOwner = false;
      await targetUser.save();
      return reply(`✅ Role for @${target.number} reset to *User*`, { mentions: [target.phoneJid] });
    } catch (err) {
      console.error('ROLE COMMAND ERROR:', err);
      return reply('❌ Failed to manage role.');
    }
  },
});
