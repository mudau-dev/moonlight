const axios = require('axios');
const config = require('../../config');
const System = require('../../models/System');

const API_BASE = config.PANEL_API_BASE || 'https://control.bot-hosting.net/api/client/servers';
const AUTH = config.PANEL_API_TOKEN ? `Bearer ${config.PANEL_API_TOKEN}` : '';

const BOT_SERVERS = {
  'rem': '5bea48d5',
  'rimuru': 'c2573fdd',
  'saber': '4a86f73d',
  'cid': '934069ee',
  'kurumi': '78976de0',
  'frieren': '53acc665'
};

async function restartServer(serverId) {
  try {
    await axios.post(`${API_BASE}/${serverId}/power`, { signal: 'restart' }, {
      headers: {
        'Authorization': AUTH,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });
    return true;
  } catch (e) {
    console.error(`RESTART ERROR (${serverId}):`, e.message);
    return false;
  }
}

moon({
  name: "restart",
  category: "owner",
  roles: ["Mod", "Owner", "True Owner"],
  description: "Restart the current bot, all bots, or a specific bot",
  subcommands: ["all", "rem", "rimuru", "saber", "cid", "kurumi", "frieren"],

  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      if (!AUTH) return reply('❌ Panel restart token is not configured on this bot.');
      const target = (args[0] || "").toLowerCase();

      // ── .restart all ──
      if (target === "all") {
        await reply("🔄 *Restarting all bots in the network...*");
        const results = [];
        for (const [name, id] of Object.entries(BOT_SERVERS)) {
          const ok = await restartServer(id);
          results.push(`${ok ? '✅' : '❌'} ${name.toUpperCase()}`);
        }
        return reply(`🚀 *Restart Sequence Initiated:*\n\n${results.join('\n')}`);
      }

      // ── .restart <bot name> ──
      if (BOT_SERVERS[target]) {
        await reply(`🔄 *Restarting ${target.toUpperCase()}...*`);
        const ok = await restartServer(BOT_SERVERS[target]);
        return reply(ok ? `✅ *${target.toUpperCase()}* is restarting.` : `❌ Failed to restart *${target.toUpperCase()}*.`);
      }

      // ── .restart (current) ──
      const currentBotName = (config.BOT_NAME || "Rem").toLowerCase();
      const currentId = BOT_SERVERS[currentBotName] || BOT_SERVERS['rem'];

      const notice = await sock.sendMessage(jid, { text: `🔄 *${currentBotName.toUpperCase()} is restarting now. I will edit this message when I am back online.*` }, { quoted: m });
      await System.findOneAndUpdate(
        { key: `restartNotice:${currentBotName}` },
        { $set: { value: { jid, messageKey: notice?.key, createdAt: new Date() }, updatedAt: new Date() } },
        { upsert: true }
      );
      const ok = await restartServer(currentId);
      if (!ok) {
        await System.deleteOne({ key: `restartNotice:${currentBotName}` }).catch(() => {});
        return sock.sendMessage(jid, { text: `❌ Failed to restart ${currentBotName.toUpperCase()} through the panel.` }, { edit: notice?.key });
      }
      return;

    } catch (err) {
      console.error("RESTART CMD ERROR:", err);
      return reply("❌ Error executing restart.");
    }
  }
});
