const crypto = require('crypto');
const User = require('../../models/User');
const LegacyPlayer = require('../../models/LegacyPlayer');
const Pokemon = require('../../models/pokemon');
const { getRealUserIdentity } = require('../../utils/whatsappIdentity');

function amount(value) {
  const parsed = Number(String(value || '').replace(/,/g, ''));
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : null;
}

async function resolveUsers(sock, sender, args, m) {
  const mention = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message?.extendedTextMessage?.contextInfo?.participant;
  const all = String(args[0] || '').toLowerCase() === 'all';
  if (all) return User.find({ moonId: { $exists: true, $ne: null } });
  const identity = await getRealUserIdentity(sock, mention || sender);
  if (!identity) return null;
  const user = await User.findOne({ $or: [{ whatsappNumber: identity.phoneJid }, { phoneNumber: identity.phoneNumber }, { moonId: identity.phoneNumber }] });
  return user ? [user] : [];
}

function cleanArgs(args) {
  const cleaned = args.filter((arg) => !arg.startsWith('@'));
  if (String(cleaned[0] || '').toLowerCase() === 'all') cleaned.shift();
  return cleaned;
}

async function changeResource(users, resource, rawArgs, direction) {
  const args = cleanArgs(rawArgs);
  const sub = String(args[1] || '').toLowerCase();
  const value = amount(args[2] || args[1]);
  let changed = 0;
  for (const user of users) {
    if (resource === 'money') {
      if (!value) throw new Error('Use a positive money amount.');
      user.balance = Math.max(0, (user.balance || 0) + direction * value);
      if (direction > 0) user.totalEarned = (user.totalEarned || 0) + value;
      if (direction < 0) user.totalLost = (user.totalLost || 0) + value;
      await user.save(); changed += 1; continue;
    }
    if (resource === 'cards') {
      if (direction > 0) {
        const cardName = args.slice(1).join(' ') || 'Moonlight Reward Card';
        user.cards.push({ instanceId: `owner-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`, cardId: 'owner-reward', name: cardName, description: 'Granted by a True Owner.', tier: 'Special', price: 0, obtainedAt: new Date(), level: 1, xp: 0, locked: false, inAuction: false });
      } else {
        const index = String(args[1] || '').toLowerCase() === 'all' ? -1 : Number(args[1]) - 1;
        if (index === -1) user.cards = [];
        else if (Number.isInteger(index) && index >= 0 && index < user.cards.length) user.cards.splice(index, 1);
        else continue;
      }
      await user.save(); changed += 1; continue;
    }
    if (resource === 'pokemon') {
      if (direction > 0) {
        const name = args.slice(1).join(' ') || 'Moonling';
        await Pokemon.create({ pokemonId: `owner-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`, userId: user.whatsappNumber, pokedexNumber: 0, name, level: 1, type1: 'Mystic', hp: 50, attack: 15, defense: 15, spAtk: 15, spDef: 15, speed: 15, iv: {}, rarity: 'Special', caughtLocation: 'Owner Grant', location: 'pc' });
      } else {
        const selector = String(args[1] || '').toLowerCase();
        const query = { userId: user.whatsappNumber };
        if (selector === 'all') await Pokemon.deleteMany(query);
        else if (selector) await Pokemon.findOneAndDelete({ ...query, $or: [{ pokemonId: selector }, { name: new RegExp(`^${selector}$`, 'i') }] });
        else throw new Error('Choose a Pokémon name, ID, or `all`.');
      }
      changed += 1; continue;
    }
    if (resource === 'rpg') {
      if (!['gold', 'mana', 'xp'].includes(sub) || !value) throw new Error('Use `.senpai @user rpg gold|mana|xp <amount>`.');
      const player = await LegacyPlayer.findOne({ whatsappId: user.whatsappNumber });
      if (!player) continue;
      player[sub] = Math.max(0, (player[sub] || 0) + direction * value);
      await player.save(); changed += 1;
    }
  }
  return changed;
}

async function resetResource(users, resource) {
  let changed = 0;
  for (const user of users) {
    if (resource === 'money') { user.balance = 0; user.bank = 0; await user.save(); changed += 1; }
    else if (resource === 'cards') { user.cards = []; await user.save(); changed += 1; }
    else if (resource === 'pokemon') { await Pokemon.deleteMany({ userId: user.whatsappNumber }); changed += 1; }
    else if (resource === 'rpg') {
      const player = await LegacyPlayer.findOne({ whatsappId: user.whatsappNumber });
      if (player) { player.gold = 500; player.xp = 0; player.level = 1; player.mana = player.maxMana; await player.save(); changed += 1; }
    }
  }
  return changed;
}

async function executeOwnerResourceCommand(sock, sender, args, m, reply, direction, resetMode = false) {
  const users = await resolveUsers(sock, sender, args, m);
  if (!users) return reply('❌ A mentioned WhatsApp LID could not be resolved. No data changed.');
  if (!users.length) return reply('❌ No registered target user was found.');
  const clean = cleanArgs(args);
  const resource = String(clean[0] || '').toLowerCase();
  if (!['money', 'rpg', 'cards', 'pokemon'].includes(resource)) return reply('❌ Choose `money`, `rpg`, `cards`, or `pokemon`.');
  try {
    const changed = resetMode ? await resetResource(users, resource) : await changeResource(users, resource, args, direction);
    return reply(`✅ ${resetMode ? 'Reset' : direction > 0 ? 'Added' : 'Removed'} *${resource}* for ${changed} user${changed === 1 ? '' : 's'}.`);
  } catch (error) { return reply(`❌ ${error.message}`); }
}

moon({ name: 'kaizuru', category: 'owner', roles: ["Mod", "Owner", "True Owner"], usage: '.kaizuru @user|all money <amount> | rpg gold|mana|xp <amount> | cards <index|all> | pokemon <name|id|all>', description: 'Remove player resources.', async execute(sock, jid, sender, args, m, { reply }) { return executeOwnerResourceCommand(sock, sender, args, m, reply, -1); } });
moon({ name: 'reset', category: 'owner', roles: ["Mod", "Owner", "True Owner"], usage: '.reset @user|all money|rpg|cards|pokemon', description: 'Reset one player resource category.', async execute(sock, jid, sender, args, m, { reply }) { return executeOwnerResourceCommand(sock, sender, args, m, reply, 0, true); } });
