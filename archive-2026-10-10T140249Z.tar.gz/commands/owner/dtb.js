const os = require('os');
const mongoose = require('mongoose');
const User = require('../../models/User');
const Card = require('../../models/Card');


moon({
  name: "economy",
  aliases: ["dtb", "eco", "econ"],
  category: "owner",
  roles: ["Mod", "Owner", "True Owner"],
  description: "Moonlight diagnostic dashboard (polo style)",

  async execute(sock, jid, sender, args, m) {
    try {


      
      // ================= SYSTEM =================
      const mem = process.memoryUsage();

      const rss = mem.rss / 1024 / 1024;
      const heapUsed = mem.heapUsed / 1024 / 1024;
      const heapTotal = mem.heapTotal / 1024 / 1024;

      const uptime = process.uptime();

      const load = os.loadavg();
      const cpuCount = os.cpus().length;

      const cpuPressure = load[0] / cpuCount;

      // ================= DATABASE =================
      const users = await User.countDocuments();
      const cards = await Card.countDocuments();

      const db = mongoose.connection.db;
      const stats = await db.stats();

      const toMB = (v) => (v / (1024 * 1024));

      const usedMB = toMB(stats.dataSize);
      const storageMB = toMB(stats.storageSize);
      const indexMB = toMB(stats.indexSize);

      // ================= ECONOMY =================
      const allUsers = await User.find({}, 'balance bank');

      let totalEconomy = 0;
      for (const u of allUsers) {
        totalEconomy += (u.balance || 0) + (u.bank || 0);
      }

      // ================= CAP SETTINGS =================
      const DB_CAP_MB = 500;
      const USER_CAP = 100000;

      const dbLeft = Math.max(DB_CAP_MB - usedMB, 0);
      const userIndex = (users / USER_CAP) * 100;
      const formatUptime = (seconds) => {
        const h = Math.floor(seconds / 3600);
        const min = Math.floor((seconds % 3600) / 60);
        return `${h}h ${min}m`;
      };

      // ================= STATUS =================
      let status = "🟢 Healthy";
      if (cpuPressure > 3) status = "🔴 High Load";
      else if (cpuPressure > 1.5) status = "🟠 Medium Load";

      const text = [
        '🌙 *MOONLIGHT HAVEN · DTB / ECONOMY*',
        '_Owner and Mod system dashboard_',
        '',
        '┌─ *DATABASE*',
        `│ 👥 Users       ${users.toLocaleString()}`,
        `│ 🃏 Cards       ${cards.toLocaleString()}`,
        `│ 💰 Total wealth $${Math.floor(totalEconomy).toLocaleString()}`,
        `│ 🗄️ Data        ${usedMB.toFixed(1)} MB used · ${dbLeft.toFixed(1)} MB free`,
        `│ 🧾 Index       ${indexMB.toFixed(1)} MB`,
        '└────────────────────',
        '',
        '┌─ *RUNTIME*',
        `│ 🧠 Heap        ${heapUsed.toFixed(1)} / ${heapTotal.toFixed(1)} MB`,
        `│ ⚡ CPU         ${(cpuPressure * 100).toFixed(1)}% pressure`,
        `│ ⏱️ Uptime      ${formatUptime(uptime)}`,
        `│ 📈 User cap    ${userIndex.toFixed(1)}% of 100K`,
        `│ ${status}`,
        '└────────────────────',
        '',
        '✅ *Dashboard is online.*',
      ].join('\n');

      return sock.sendMessage(jid, { text }, { quoted: m });

    } catch (err) {
      console.error("DTB error:", err);
    }
  }
});