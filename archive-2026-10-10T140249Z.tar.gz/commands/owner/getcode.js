/**
 * commands/owner/getcode.js
 *
 * .getcode / .gcd <code> <coins> <max_members> — Create a promo code (True Owner only)
 * .get <code>                                   — Claim a promo code (any registered user)
 * .delcode <code>                               — Delete a promo code (True Owner only)
 * .listcodes                                    — List all active promo codes (True Owner only)
 *
 * Codes are stored in MongoDB so all bot instances share the same data.
 */

const PromoCode = require('../../models/PromoCode');

function money(n) {
  return Math.floor(Number(n) || 0).toLocaleString();
}

// ── .getcode / .gcd — Create a promo code ─────────────────────────────────────
moon({
  name: 'getcode',
  aliases: ['gcd'],
  category: 'owner',
  description: 'Create a promo code that users can claim for coins (True Owner only).',
  usage: '.gcd <code> <coins> <max_members>',
  roles: ["Mod", "Owner", "True Owner"],
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const code = (args[0] || '').toUpperCase().trim();
      const coins = parseInt(args[1], 10);
      const maxMembers = parseInt(args[2], 10);

      if (!code || isNaN(coins) || isNaN(maxMembers) || coins <= 0 || maxMembers <= 0) {
        return reply(
          '❌ Usage: `.gcd <code> <coins> <max_members>`\n\n' +
          'Example: `.gcd MOON1 1000000 3`\n' +
          '> Users claim it with `.get MOON1`'
        );
      }

      const existing = await PromoCode.findOne({ code });
      if (existing) {
        return reply(
          `⚠️ Code *${code}* already exists!\n\n` +
          `💰 Coins: ${money(existing.coins)}\n` +
          `👥 Max: ${existing.maxMembers}\n` +
          `✅ Claimed: ${existing.claimed.length}/${existing.maxMembers}`
        );
      }

      await PromoCode.create({
        code,
        coins,
        maxMembers,
        claimed: [],
        createdBy: sender,
        active: true,
      });

      return reply(
        `✅ *PROMO CODE CREATED!*\n\n` +
        `🎟️ *Code:* \`${code}\`\n` +
        `💰 *Reward:* ${money(coins)} coins\n` +
        `👥 *Max Claims:* ${maxMembers}\n\n` +
        `> Users can claim it with \`.get ${code}\``
      );
    } catch (err) {
      console.error('[GETCODE ERROR]', err);
      return reply('❌ Failed to create promo code.');
    }
  },
});

// ── .delcode — Delete a promo code (True Owner only) ─────────────────────────
moon({
  name: 'delcode',
  category: 'owner',
  description: 'Delete a promo code (True Owner only).',
  usage: '.delcode <code>',
  roles: ["Mod", "Owner", "True Owner"],
  async execute(sock, jid, sender, args, m, { reply }) {
    const code = (args[0] || '').toUpperCase().trim();
    if (!code) return reply('❌ Usage: `.delcode <code>`');
    const deleted = await PromoCode.findOneAndDelete({ code });
    if (!deleted) return reply(`❌ Code *${code}* does not exist.`);
    return reply(`✅ Code *${code}* has been deleted.`);
  },
});

// ── .listcodes — List all active promo codes (True Owner only) ─────────────────
moon({
  name: 'listcodes',
  category: 'owner',
  description: 'List all active promo codes (True Owner only).',
  roles: ["Mod", "Owner", "True Owner"],
  async execute(sock, jid, sender, args, m, { reply }) {
    const codes = await PromoCode.find({ active: true }).sort({ createdAt: -1 });
    if (!codes.length) return reply('📭 No active promo codes.');
    const lines = codes.map(promo =>
      `• \`${promo.code}\` — ${money(promo.coins)} coins | ${promo.claimed.length}/${promo.maxMembers} claimed`
    );
    return reply(`🎟️ *ACTIVE PROMO CODES*\n\n${lines.join('\n')}`);
  },
});
