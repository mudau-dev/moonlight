const User = require("../../models/User");
const { getRealUserIdentity } = require("../../utils/whatsappIdentity");
const { resolveMessageTarget, phoneNumberFromValue } = require("../../utils/adminIdentity");

moon({
  name: "pssd",
  category: "owner",
  roles: ["Mod", "Owner", "True Owner"],
  description: "Set True Owner by password and phone number",
  usage: ".pssd <password> [phone number] | reply .pssd <password>",

  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const password = args.join(" ").trim().normalize("NFKC");
      const MASTER_PASSWORD = "Moonlight.haven.king";

      if (!password) return reply("❌ Provide password.");
      if (password !== MASTER_PASSWORD) return reply("❌ Wrong password.");

      const callerIdentity = await getRealUserIdentity(sock, sender);
      if (!callerIdentity?.phoneJid) {
        return reply("❌ Your WhatsApp phone number could not be resolved safely.");
      }

      // Target precedence: replied-to user, explicit mention/number, then caller.
      const targetJid = await resolveMessageTarget(sock, m, args.slice(1)) || callerIdentity.phoneJid;
      const targetIdentity = await getRealUserIdentity(sock, targetJid);
      if (!targetIdentity?.phoneJid) {
        return reply("❌ The target WhatsApp phone number could not be resolved.");
      }

      const phoneJid = targetIdentity.phoneJid;
      const phoneNumber = phoneNumberFromValue(phoneJid);
      if (!phoneNumber) return reply("❌ Invalid target phone number.");

      const user = await User.findOneAndUpdate(
        {
          $or: [
            { whatsappNumber: phoneJid },
            { phoneNumber },
            { userId: phoneNumber },
            { moonId: phoneNumber },
          ],
        },
        {
          $set: {
            whatsappNumber: phoneJid,
            phoneNumber,
            userId: phoneNumber,
            role: "True Owner",
            isTrueOwner: true,
          },
          $setOnInsert: { username: m.pushName || "Unknown" },
        },
        { new: true, upsert: true, setDefaultsOnInsert: true }
      );

      try {
        await sock.sendMessage(jid, { delete: m.key });
      } catch (e) {
        console.log("Delete failed:", e.message);
      }

      return sock.sendMessage(jid, {
        text: `👑 *Access granted.*\n@${phoneNumber} has been verified as *True Owner* by phone number.`,
        mentions: [phoneJid],
      }, { quoted: m });
    } catch (err) {
      console.error("pssd error:", err.message);
      return reply("❌ Failed to set True Owner.");
    }
  }
});
