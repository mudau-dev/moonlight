const Game = require('../../models/Games');
const { isValidWord, drawTTT, drawC4 } = require('../../utils/Games');
const { handleHeistMove } = require('./heist');

function mention(jid) { return `@${String(jid || '').split('@')[0]}`; }
function nextTurn(game, sender) {
  const index = game.players.findIndex((player) => player.jid === sender);
  game.turn = game.players[(index + 1) % game.players.length].jid;
}
function c4Lines(board) {
  return [`  1 2 3 4 5 6 7`, ...board.map((row) => `  ${row.map((cell) => cell || '·').join(' ')}`)].join('\n');
}
function c4Move(board, column, symbol) {
  for (let row = board.length - 1; row >= 0; row -= 1) {
    if (!board[row][column]) { board[row][column] = symbol; return row; }
  }
  return -1;
}
function hasC4Win(board, row, column, symbol) {
  const directions = [[1, 0], [0, 1], [1, 1], [1, -1]];
  return directions.some(([dr, dc]) => {
    let count = 1;
    for (const sign of [-1, 1]) {
      let r = row + dr * sign; let c = column + dc * sign;
      while (r >= 0 && r < board.length && c >= 0 && c < board[0].length && board[r][c] === symbol) { count += 1; r += dr * sign; c += dc * sign; }
    }
    return count >= 4;
  });
}
function fenToBoard(fen) {
  return String(fen || '').split(' ')[0].split('/').map((rank) => {
    const row = [];
    for (const char of rank) {
      if (/\d/.test(char)) for (let i = 0; i < Number(char); i += 1) row.push(null);
      else row.push(char);
    }
    return row;
  });
}
function boardToText(board) {
  return board.map((row, index) => `${8 - index} ${row.map((piece) => piece || '·').join(' ')}`).join('\n') + '\n  a b c d e f g h';
}
function square(value) {
  const match = /^([a-h])([1-8])$/.exec(String(value || '').toLowerCase());
  return match ? { row: 8 - Number(match[2]), col: match[1].charCodeAt(0) - 97 } : null;
}
function chessPathClear(board, from, to) {
  const dr = Math.sign(to.row - from.row); const dc = Math.sign(to.col - from.col);
  let row = from.row + dr; let col = from.col + dc;
  while (row !== to.row || col !== to.col) { if (board[row][col]) return false; row += dr; col += dc; }
  return true;
}
function validChessMove(board, from, to, piece) {
  const dr = to.row - from.row; const dc = to.col - from.col; const adr = Math.abs(dr); const adc = Math.abs(dc);
  if (!piece || (board[to.row][to.col] && board[to.row][to.col].toUpperCase() === piece.toUpperCase())) return false;
  switch (piece.toLowerCase()) {
    case 'p': {
      const direction = piece === piece.toUpperCase() ? -1 : 1;
      const start = piece === piece.toUpperCase() ? 6 : 1;
      if (dc === 0 && dr === direction && !board[to.row][to.col]) return true;
      if (dc === 0 && dr === 2 * direction && from.row === start && !board[to.row][to.col] && !board[from.row + direction][from.col]) return true;
      return adc === 1 && dr === direction && Boolean(board[to.row][to.col]);
    }
    case 'n': return (adr === 2 && adc === 1) || (adr === 1 && adc === 2);
    case 'b': return adr === adc && chessPathClear(board, from, to);
    case 'r': return (dr === 0 || dc === 0) && chessPathClear(board, from, to);
    case 'q': return (dr === 0 || dc === 0 || adr === adc) && chessPathClear(board, from, to);
    case 'k': return adr <= 1 && adc <= 1;
    default: return false;
  }
}

moon({ name: 'wcg', category: 'games', description: 'Word Chain Game', async execute(sock, jid, sender, args, m, { reply }) {
  const sub = (args[0] || '').toLowerCase();
  let game = await Game.findOne({ jid, gameType: 'wcg', status: { $ne: 'finished' } });
  if (sub === 'start') {
    if (game) return reply('❌ A game is already in progress.');
    game = await Game.create({ jid, gameType: 'wcg', status: 'waiting', players: [{ jid: sender, name: m.pushName || 'Player 1' }], state: { words: [], lastLetter: '' } });
    return reply('✅ WCG Started! Use `.wcg join` to join. Need at least 2 players.');
  }
  if (sub === 'join') {
    if (!game) return reply('❌ No game waiting.');
    if (game.status !== 'waiting') return reply('❌ Game already started.');
    if (game.players.find((player) => player.jid === sender)) return reply('❌ Already joined.');
    game.players.push({ jid: sender, name: m.pushName || 'Player' });
    if (game.players.length >= 2) { game.status = 'playing'; game.turn = game.players[0].jid; }
    await game.save();
    return reply(game.status === 'playing' ? `✅ Game Started!\nTurn: ${mention(game.turn)}\nUse \\.m <word>.` : `✅ Joined! (${game.players.length}/2)`, { mentions: game.players.map((player) => player.jid) });
  }
  return reply('📌 Usage:\n.wcg start\n.wcg join\n.m <word>');
}});

moon({ name: 'm', category: 'games', description: 'Make a move in the current game', async execute(sock, jid, sender, args, m, { reply }) {
  if (await handleHeistMove(sock, jid, sender, args, m, reply)) return;
  const move = String(args[0] || '').toLowerCase();
  const game = await Game.findOne({ jid, status: 'playing', 'players.jid': sender });
  if (!game) return reply('❌ You are not in an active game in this group.');
  if (move === 'leave') { game.status = 'finished'; game.winner = game.players.find((player) => player.jid !== sender)?.jid || 'No one'; await game.save(); return reply(`👋 ${mention(sender)} left the game. Game over!`, { mentions: [sender] }); }
  if (game.turn !== sender) return reply("❌ It's not your turn!");
  if (!move) return reply('❌ Please provide a move.');

  if (game.gameType === 'wcg') {
    const words = game.state.words || []; const lastLetter = game.state.lastLetter || '';
    if (lastLetter && !move.startsWith(lastLetter)) return reply(`❌ Word must start with "${lastLetter.toUpperCase()}".`);
    if (words.includes(move)) return reply('❌ Word already used!');
    if (!(await isValidWord(move))) return reply('❌ Not a real word!');
    words.push(move); game.state = { words, lastLetter: move.slice(-1) }; nextTurn(game, sender); game.markModified('state'); await game.save();
    return reply(`✅ Nice! Next word starts with "${game.state.lastLetter.toUpperCase()}"\nTurn: ${mention(game.turn)}`, { mentions: [game.turn] });
  }

  if (game.gameType === 'ttt') {
    const pos = Number.parseInt(move, 10) - 1;
    if (pos < 0 || pos > 8 || Number.isNaN(pos)) return reply('❌ Move must be 1-9.');
    if (game.state.board[pos]) return reply('❌ Position already taken!');
    const symbol = game.players[0].jid === sender ? 'X' : 'O'; game.state.board[pos] = symbol; game.markModified('state.board');
    const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    const winner = wins.some((line) => line.every((index) => game.state.board[index] === symbol));
    if (winner) { game.status = 'finished'; game.winner = sender; await game.save(); return sock.sendMessage(jid, { image: await drawTTT(game.state.board), caption: `🎉 ${mention(sender)} WON!`, mentions: [sender] }, { quoted: m }); }
    if (game.state.board.every(Boolean)) { game.status = 'finished'; await game.save(); return sock.sendMessage(jid, { image: await drawTTT(game.state.board), caption: "🤝 It's a DRAW!" }, { quoted: m }); }
    nextTurn(game, sender); await game.save(); return sock.sendMessage(jid, { image: await drawTTT(game.state.board), caption: `✅ Move accepted!\nTurn: ${mention(game.turn)}`, mentions: [game.turn] }, { quoted: m });
  }

  if (game.gameType === 'c4') {
    const column = Number.parseInt(move, 10) - 1;
    if (column < 0 || column > 6 || Number.isNaN(column)) return reply('❌ Move must be 1-7.');
    const symbol = game.players[0].jid === sender ? '🔴' : '🟡'; const row = c4Move(game.state.board, column, symbol);
    if (row < 0) return reply('❌ That column is full.');
    game.markModified('state.board');
    if (hasC4Win(game.state.board, row, column, symbol)) { game.status = 'finished'; game.winner = sender; await game.save(); return sock.sendMessage(jid, { image: await drawC4(game.state.board), caption: `🎉 ${mention(sender)} WON Connect Four!`, mentions: [sender] }, { quoted: m }); }
    if (game.state.board[0].every(Boolean)) { game.status = 'finished'; await game.save(); return sock.sendMessage(jid, { image: await drawC4(game.state.board), caption: "🤝 Connect Four is a draw!" }, { quoted: m }); }
    nextTurn(game, sender); await game.save(); return sock.sendMessage(jid, { image: await drawC4(game.state.board), caption: `✅ Move accepted!\nTurn: ${mention(game.turn)}`, mentions: [game.turn] }, { quoted: m });
  }

  if (game.gameType === 'chess') {
    const match = move.match(/^([a-h][1-8])([a-h][1-8])([qrbn])?$/i);
    if (!match) return reply('❌ Chess move format: `.m e2e4` (optional promotion: q, r, b, n).');
    const board = game.state.board || fenToBoard(game.state.fen); const from = square(match[1]); const to = square(match[2]); const piece = board[from.row]?.[from.col];
    const whiteTurn = game.players[0].jid === sender;
    if (!piece || (whiteTurn !== (piece === piece.toUpperCase()))) return reply('❌ That piece cannot move now.');
    if (!validChessMove(board, from, to, piece)) return reply('❌ Illegal move.');
    board[to.row][to.col] = match[3] ? (piece === piece.toUpperCase() ? match[3].toUpperCase() : match[3].toLowerCase()) : piece; board[from.row][from.col] = null;
    game.state = { ...game.state, board, lastMove: move }; game.markModified('state'); nextTurn(game, sender); await game.save();
    return reply(`✅ Move accepted: ${move}\n\n${boardToText(board)}\nTurn: ${mention(game.turn)}`, { mentions: [game.turn] });
  }
  return reply('❌ This game does not support moves yet.');
}});
