const Game = require('../../models/Games');
const User = require('../../models/User');
const { findOrCreateWhatsApp } = require('../../database/users');

const ENTRY_FEE = 1500;
const MIN_PLAYERS = 5;
const MAX_PLAYERS = 50;
const PRIZE = 1500000;
const ROUND_MS = 30 * 1000;
const NEXT_ROUND_DELAY_MS = 5 * 1000;
const MAX_NO_VOTE_EXTENSIONS = 2;

function mention(jid) { return `@${String(jid || '').split('@')[0]}`; }
function playerLine(player, index) { return `${index + 1}. ${mention(player.jid)}`; }
function activePlayers(game) { return (game.players || []).filter((player) => !player.eliminated); }
function mentions(players) { return players.map((player) => player.jid); }
function stateOf(game) { return game.state || {}; }
function lobbyText(game) {
  const players = game.players || [];
  return [
    '🏴‍☠️ *HAVEN HEIST MASTERS*',
    '',
    `Participants: *${players.length}/${MAX_PLAYERS}*`,
    `Entry fee: *${ENTRY_FEE.toLocaleString()} coins*`,
    `Minimum players: *${MIN_PLAYERS}*`,
    `Prize reward: *${PRIZE.toLocaleString()} coins*`,
    '',
    players.length ? players.map(playerLine).join('\n') : 'No players have joined yet.',
    '',
    '`.heist join` to join · `.heist leave` to leave · `.heist start` to begin',
  ].join('\n');
}
function activeText(game) {
  const players = activePlayers(game);
  return [
    '🏴‍☠️ *HAVEN HEIST MASTERS*',
    `Round ${Number(stateOf(game).round || 1)} · ${players.length} players remain`,
    '',
    players.map(playerLine).join('\n'),
    '',
    stateOf(game).final ? '🏆 Final showdown: use `.m <index>`.' : 'Use `.m <index>` to knock out a player.',
  ].join('\n');
}
async function findGame(jid) {
  return Game.findOne({ jid, gameType: 'heist', status: { $ne: 'finished' } }).sort({ createdAt: -1 });
}
async function refund(player) {
  if (!player?.jid || player.refunded) return;
  const updated = await User.findOneAndUpdate({ whatsappNumber: player.jid }, { $inc: { balance: ENTRY_FEE } }, { new: true }).catch(() => null);
  if (updated) player.refunded = true;
}
async function creditWinner(game) {
  const state = stateOf(game);
  if (!state.winner || state.payoutStatus === 'complete') return;
  if (state.payoutStatus !== 'processing') {
    state.payoutStatus = 'processing';
    game.markModified('state');
    await game.save();
  }
  const user = await User.findOneAndUpdate({ whatsappNumber: state.winner }, { $inc: { balance: PRIZE, totalEarned: PRIZE } }, { new: true }).catch(() => null);
  if (!user) return;
  state.payoutStatus = 'complete';
  game.markModified('state');
  await game.save();
}
function scheduleNextRound(sock, jid, gameId) {
  setTimeout(async () => {
    const game = await Game.findById(gameId).catch(() => null);
    if (!game || game.status !== 'playing') return;
    const state = stateOf(game);
    if (state.nextRoundAt && Date.now() < new Date(state.nextRoundAt).getTime()) return;
    state.round = Number(state.round || 1) + 1;
    state.votes = {};
    state.voters = [];
    state.tieCandidates = [];
    state.noVoteExtensions = 0;
    state.roundEndsAt = new Date(Date.now() + ROUND_MS);
    state.nextRoundAt = null;
    state.final = activePlayers(game).length === 2;
    game.markModified('state');
    await game.save();
    await sock.sendMessage(jid, { text: state.final ? '🏆 *HAVEN HEIST MASTERS — FINAL SHOWDOWN*\n\nOnly two crew members remain!\nThe first valid `.m <index>` wins.' : activeText(game), mentions: mentions(activePlayers(game)) });
  }, NEXT_ROUND_DELAY_MS);
}
async function finishRound(sock, jid, game) {
  const state = stateOf(game);
  if (state.nextRoundAt && new Date(state.nextRoundAt).getTime() > Date.now()) return;
  const players = activePlayers(game);
  if (players.length <= 2) {
    state.final = true;
    state.roundEndsAt = null;
    game.markModified('state');
    await game.save();
    return;
  }
  const votes = state.votes || {};
  const counts = players.map((player) => ({ player, count: Number(votes[player.jid] || 0) }));
  const highest = Math.max(...counts.map((item) => item.count));
  if (!highest) {
    state.noVoteExtensions = Number(state.noVoteExtensions || 0) + 1;
    if (state.noVoteExtensions <= MAX_NO_VOTE_EXTENSIONS) {
      state.roundEndsAt = new Date(Date.now() + ROUND_MS);
      game.markModified('state');
      await game.save();
      await sock.sendMessage(jid, { text: `⏳ Nobody voted. The round has been extended for another 30 seconds (${state.noVoteExtensions}/${MAX_NO_VOTE_EXTENSIONS}).` });
    }
    return;
  }
  const tied = counts.filter((item) => item.count === highest).map((item) => item.player.jid);
  if (tied.length > 1) {
    state.tieCandidates = tied;
    state.votes = {};
    state.voters = [];
    state.roundEndsAt = new Date(Date.now() + ROUND_MS);
    game.markModified('state');
    await game.save();
    const tiedPlayers = players.filter((player) => tied.includes(player.jid));
    await sock.sendMessage(jid, { text: `⚖️ The vote is tied. Revote between:\n${tiedPlayers.map(playerLine).join('\n')}\n\nUse \\.m <index> within 30 seconds.`, mentions: mentions(tiedPlayers) });
    return;
  }
  const eliminated = counts.find((item) => item.count === highest).player;
  eliminated.eliminated = true;
  state.votes = {};
  state.voters = [];
  state.tieCandidates = [];
  state.roundEndsAt = null;
  state.nextRoundAt = new Date(Date.now() + NEXT_ROUND_DELAY_MS);
  game.markModified('players');
  game.markModified('state');
  await game.save();
  const remaining = activePlayers(game);
  await sock.sendMessage(jid, { text: `🏴 *PLAYER ELIMINATED*\n\n${mention(eliminated.jid)} was knocked off by ${highest} player${highest === 1 ? '' : 's'}!\n\nContinuing players:\n${remaining.map(playerLine).join('\n')}\n\nStarting in 5 seconds.`, mentions: [eliminated.jid, ...mentions(remaining)] });
  scheduleNextRound(sock, jid, game._id);
}

async function handleHeistMove(sock, jid, sender, args, m, reply) {
  const game = await findGame(jid);
  if (!game || game.status !== 'playing') return false;
  const state = stateOf(game);
  const actor = (game.players || []).find((player) => player.jid === sender);
  if (!actor || actor.eliminated) { await reply('❌ Eliminated or non-participants cannot vote.'); return true; }
  if (state.final || activePlayers(game).length === 2) {
    const index = Number(args[0]) - 1;
    const target = activePlayers(game)[index];
    if (!target || target.jid === sender) { await reply('❌ Choose the other remaining player by index.'); return true; }
    state.winner = sender;
    state.final = false;
    game.status = 'finished';
    game.winner = sender;
    game.markModified('state');
    await game.save();
    await creditWinner(game);
    await sock.sendMessage(jid, { text: `🏆 *HEIST COMPLETED!*\n\nCongratulations ${mention(sender)}!\n\nYou successfully claimed the Haven Heist!\nReward: *${PRIZE.toLocaleString()} coins*.`, mentions: [sender] });
    return true;
  }
  const index = Number(args[0]) - 1;
  const players = activePlayers(game);
  const target = players[index];
  if (!target || (state.tieCandidates?.length && !state.tieCandidates.includes(target.jid))) { await reply('❌ Invalid vote index for this round.'); return true; }
  if (target.jid === sender) { await reply('❌ You cannot vote for yourself.'); return true; }
  state.voters = state.voters || [];
  if (state.voters.includes(sender)) { await reply('❌ You have already voted this round.'); return true; }
  state.voters.push(sender);
  state.votes = state.votes || {};
  state.votes[target.jid] = Number(state.votes[target.jid] || 0) + 1;
  game.markModified('state');
  await game.save();
  await reply(`✅ Your vote was recorded for ${mention(target.jid)}. Waiting for other players...`);
  return true;
}

moon({ name: 'heist', category: 'games', description: 'Play Haven Heist Masters.', async execute(sock, jid, sender, args, m, { reply, pushName }) {
  if (!jid.endsWith('@g.us')) return reply('❌ Haven Heist Masters can only be played in a group.');
  const sub = String(args[0] || '').toLowerCase();
  let game = await findGame(jid);
  if (!game && ['','join','start','status'].includes(sub)) {
    game = await Game.create({ jid, gameType: 'heist', status: 'waiting', players: [], state: { round: 0, votes: {}, voters: [], paidOut: false } });
  }
  if (!game) return reply('❌ There is no active heist. Use `.heist join` to open one.');
  if (sub === 'join') {
    if (game.status !== 'waiting') return reply('❌ This heist has already started.');
    if ((game.players || []).length >= MAX_PLAYERS) return reply('❌ The lobby is full.');
    if ((game.players || []).some((player) => player.jid === sender)) return reply('❌ You already joined this heist.');
    const user = await findOrCreateWhatsApp(sender, pushName).catch(() => null);
    if (!user?.moonId) return reply('❌ You must be registered before joining. Use `.reg` first.');
    const charged = await User.findOneAndUpdate({ _id: user._id, balance: { $gte: ENTRY_FEE } }, { $inc: { balance: -ENTRY_FEE } }, { new: true }).catch(() => null);
    if (!charged) return reply(`❌ You need at least ${ENTRY_FEE.toLocaleString()} coins.`);
    game.players.push({ jid: sender, name: pushName || user.username || 'Player', eliminated: false, refunded: false });
    game.markModified('players');
    await game.save();
    return reply(`✅ ${mention(sender)} joined and paid ${ENTRY_FEE.toLocaleString()} coins.\n\n${lobbyText(game)}`, { mentions: [sender, ...mentions(game.players)] });
  }
  if (sub === 'leave') {
    if (game.status !== 'waiting') return reply('❌ You can only leave before the heist starts.');
    const player = (game.players || []).find((item) => item.jid === sender);
    if (!player) return reply('❌ You are not in this lobby.');
    game.players = game.players.filter((item) => item.jid !== sender);
    await refund(player);
    if (!game.players.length) await game.deleteOne();
    else { game.markModified('players'); await game.save(); }
    return reply(`✅ You left the lobby and your ${ENTRY_FEE.toLocaleString()} coins were refunded.`);
  }
  if (sub === 'start') {
    if (game.status !== 'waiting') return reply('❌ This heist has already started.');
    if ((game.players || []).length < MIN_PLAYERS) return reply(`❌ At least ${MIN_PLAYERS} players are required.`);
    game.status = 'playing';
    game.lastMoveAt = new Date();
    game.state = { round: 1, votes: {}, voters: [], tieCandidates: [], roundEndsAt: new Date(Date.now() + ROUND_MS), final: game.players.length === 2, payoutStatus: 'pending' };
    game.markModified('state');
    await game.save();
    return sock.sendMessage(jid, { text: `🏴‍☠️ *HAVEN HEIST MASTERS*\n\nThe heist has officially started!\n\nParticipants:\n${game.players.map(playerLine).join('\n')}\n\nUse \\.m <index> to knock a player out.`, mentions: mentions(game.players) }, { quoted: m });
  }
  if (sub === 'status' || !sub) {
    if (game.status === 'playing' && stateOf(game).roundEndsAt && Date.now() >= new Date(stateOf(game).roundEndsAt).getTime()) await finishRound(sock, jid, game);
    return reply(game.status === 'waiting' ? lobbyText(game) : activeText(game), { mentions: mentions(activePlayers(game)) });
  }
  return reply('Usage: `.heist`, `.heist join`, `.heist leave`, `.heist start`, `.heist status`');
}});

module.exports = { handleHeistMove, finishRound, creditWinner };
