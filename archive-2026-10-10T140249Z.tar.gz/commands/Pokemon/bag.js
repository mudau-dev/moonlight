const { findOrCreateWhatsApp } = require('../../database/users');
const BALLS = new Map([['pokeball:poke-ball','Poké Ball'],['pokeball:great-ball','Great Ball'],['pokeball:ultra-ball','Ultra Ball'],['pokeball:master-ball','Master Ball'],['pokeball:premier-ball','Premier Ball'],['pokeball:heal-ball','Heal Ball'],['pokeball:dusk-ball','Dusk Ball'],['pokeball:net-ball','Net Ball'],['pokeball:luxury-ball','Luxury Ball'],['pokeball:quick-ball','Quick Ball'],['pokeball:beast-ball','Beast Ball'],['pokeball:timer-ball','Timer Ball'],['pokeball:repeat-ball','Repeat Ball'],['pokeball:moon-ball','Moon Ball'],['pokeball:friend-ball','Friend Ball'],['pokeball:fast-ball','Fast Ball'],['pokeball:heavy-ball','Heavy Ball'],['pokeball:lure-ball','Lure Ball'],['pokeball:dive-ball','Dive Ball'],['pokeball:level-ball','Level Ball'],['pokeball:love-ball','Love Ball']]);
function count(entries, id) { return entries.reduce((n, item) => n + (String(item?.id || '').toLowerCase() === id ? Number(item?.quantity || item?.count || 1) : 0), 0); }
moon({ name: 'bag', aliases: ['pokemonbag'], category: 'Pokémon', description: 'Open the Pokémon items and Poké Balls you own.', usage: '.bag', async execute(sock, jid, sender, args, m, { reply, pushName }) {
  const user = await findOrCreateWhatsApp(sender, pushName); if (!user) return reply('❌ Send `.reg` first.');
  const entries = [...(user.inventory || []), ...(user.pokeballs || []), ...(user.pokemonItems || [])];
  const ownedBalls = [...BALLS.entries()].map(([id, name]) => ({ id, name, count: count(entries, id) })).filter((item) => item.count > 0);
  const known = new Set([...BALLS.keys()]); const other = new Map();
  for (const item of entries) { if (!item?.id || known.has(String(item.id).toLowerCase())) continue; const key = String(item.id).toLowerCase(); const current = other.get(key) || { name: item.name || key, count: 0 }; current.count += Number(item.quantity || item.count || 1); other.set(key, current); }
  const ballLines = ownedBalls.length ? ownedBalls.map((item) => `├─ ${item.name}: *${item.count}*`) : ['└─ No Poké Balls owned'];
  const itemLines = other.size ? [...other.values()].filter((item) => item.count > 0).map((item) => `├─ ${item.name}: *${item.count}*`) : ['└─ No Pokémon items owned'];
  return reply([`🎒 *${String(pushName || user.username || 'Trainer')} — POKÉMON BAG*`, '━━━━━━━━━━━━━━━━━━━━', '', '❖ *POKÉ BALLS YOU OWN*', ...ballLines, '', '❖ *POKÉMON ITEMS YOU OWN*', ...itemLines, '', 'Use `.use <item> [party slot]` to use an item.', 'Use `.ball` to view every Poké Ball.'].join('\n'));
}});
