const { manualDrop } = require('../../handler/PokemonSpawn');

moon({
  name: 'pdrop',
  aliases: ['pokemondrop'],
  category: 'Pokémon',
  description: 'Drop a random wild Pokémon in this group. Any member can use it every 90 minutes.',
  usage: '.pdrop',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const result = await manualDrop(sock, jid);
      return reply(result.message);
    } catch (error) {
      console.error('[PDROP]', error.message);
      return reply('❌ Pokémon drop failed. Please try again later.');
    }
  },
});
