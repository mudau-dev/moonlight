const { findOrCreateWhatsApp } = require('../../database/users');
const Pokemon = require('../../models/pokemon');
const { listPokemon, getCurrentHp, getMaxHp } = require('../../utils/pokemonStorage');
const EFFECTS = { potion: 20, 'super potion': 50, 'hyper potion': 120, 'max potion': 99999, 'full restore': 99999, 'revive': 0, 'max revive': 0 };
function norm(s) { return String(s || '').toLowerCase().replace(/^pokemon:/, '').replace(/[-_]/g, ' ').trim(); }
moon({ name: 'use', aliases: ['useitem'], category: 'Pokémon', description: 'Use a Pokémon item on a party Pokémon.', usage: '.use <item> [party slot]', async execute(sock, jid, sender, args, m, { reply, pushName }) {
  const raw = (Array.isArray(args) ? args.join(' ') : String(args || '')).trim(); if (!raw) return reply('❌ Usage: `.use <item name> [party slot]`\nExample: `.use Super Potion 1`\nUse `.bag` to see your inventory.');
  const slotMatch = raw.match(/(?:^|\s)([1-6])$/); const slot = slotMatch ? Number(slotMatch[1]) : 1; const itemName = norm(slotMatch ? raw.slice(0, slotMatch.index) : raw);
  const user = await findOrCreateWhatsApp(sender, pushName); if (!user) return reply('❌ Send `.reg` first.');
  const entries = Array.isArray(user.inventory) ? user.inventory : []; const index = entries.findIndex((item) => norm(item?.name || item?.id).includes(itemName) || itemName.includes(norm(item?.name || item?.id)));
  if (index < 0) return reply(`❌ You do not have *${itemName}*. Use \.bag to see your Pokémon items.`);
  const item = entries[index]; const party = await listPokemon(sender, 'party', 6); const target = party.pokemons?.[slot - 1];
  if (!target) return reply(`❌ No Pokémon exists in party slot ${slot}. Use `.party` to see your party.`);
  const key = norm(item.name || item.id); const heal = EFFECTS[key]; if (heal === undefined) return reply(`❌ *${item.name || item.id}* cannot be used directly. It is a held, crafting, evolution, or capture item.`);
  if (key.includes('revive')) { if (getCurrentHp(target) > 0) return reply(`❌ *${target.name}* has not fainted.`); target.hp = Math.max(1, Math.floor(getMaxHp(target) / (key.includes('max') ? 1 : 2))); target.status = 'Healthy'; } else { if (getCurrentHp(target) >= getMaxHp(target)) return reply(`❌ *${target.name}* already has full HP.`); target.hp = Math.min(getMaxHp(target), getCurrentHp(target) + heal); target.status = 'Healthy'; }
  await target.save(); const qty = Number(item.quantity || item.count || 1); if (qty > 1) item.quantity = qty - 1; else entries.splice(index, 1); user.markModified('inventory'); await user.save();
  return reply(`✅ @${sender.split('@')[0]} used *${item.name || item.id}* on *${target.name}*.\n💚 HP: ${Math.round(getCurrentHp(target))}/${Math.round(getMaxHp(target))}`, { mentions: [sender] });
}});
