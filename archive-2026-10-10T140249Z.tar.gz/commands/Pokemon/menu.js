function normalizeCategory(value) { return String(value || '').toLowerCase().replace(/[éó]/g, (char) => char === 'é' ? 'e' : 'o'); }

moon({
  name: 'pmenu',
  aliases: ['menup'],
  category: 'Pokémon',
  description: 'Show every Pokémon command.',
  usage: '.pmenu',
  async execute(sock, jid, sender, args, m, { reply, config: runtimeConfig, commands }) {
    const prefix = runtimeConfig?.PREFIX || '.';
    const pokemonCommands = new Map();
    for (const command of commands.values()) {
      if (!command?.name || !['pokemon', 'pokemons'].includes(normalizeCategory(command.category))) continue;
      const name = String(command.name).trim().toLowerCase();
      if (!pokemonCommands.has(name)) pokemonCommands.set(name, command);
    }
    const sorted = [...pokemonCommands.values()].sort((a, b) => String(a.name).localeCompare(String(b.name)));
    const lines = [
      '□-------[ 𝐌𝐨𝐨𝐧𝐥𝐢𝐠𝐡𝐭 ]-------□',
      '',
      `${runtimeConfig?.WEB || ''}/battle/`,
      `${runtimeConfig?.WEB || ''}/poke/start-journey`,
      '',
      '□-----------------------------------□',
      '',
      '> Here is the Pokémon commands list',
      '',
      '┏━━━━━━━━━⊱',
      ...sorted.map((command) => `┣│ ${prefix}${command.name}`),
      '┗━━━━━━━━━⊱',
    ];
    return reply(lines.join('\n'));
  },
});
