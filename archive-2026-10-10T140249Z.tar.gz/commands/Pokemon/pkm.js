const config = require('../../config');

moon({
  name: 'pkm',
  aliases: ['pokemon', 'pokem', 'pokemons'],
  category: 'Pokémon',
  description: 'Learn how to start, train, battle, and manage Pokémon.',
  usage: '.pkm',
  async execute(sock, jid, sender, args, m, { reply }) {
    const web = String(config.WEB || process.env.WEB || '').replace(/\/$/, '');
    const journey = web ? `${web}/poke/new` : '/poke/new';
    return reply([
      '╭━━━[ *POKÉMON GUIDE* ]━━━',
      '',
      '🌱 *START YOUR JOURNEY*',
      '> Begin with 3 starter Pokémon and build your team.',
      `> Web guide: ${journey}`,
      '',
      '🎒 *COLLECT & TRAIN*',
      '> `.party` — view your active team',
      '> `.pc` — view stored Pokémon',
      '> `.plearn <pc_index> p <move>` — learn a move',
      '> `.t2party <pc_index>` — move a Pokémon to your party',
      '',
      '⚔️ *BATTLE*',
      '> `.pduel @user` — challenge a trainer',
      '> `.pd web @user` — create a web duel',
      '> `.catch` — fight a wild Pokémon drop',
      '> `.catch web` — enter a web wild battle',
      '',
      'Use `.pmenu` for the Pokémon command menu.',
      '╰━━━━━━━━━━━━━━━━━━━━',
    ].join('\n'));
  },
});
