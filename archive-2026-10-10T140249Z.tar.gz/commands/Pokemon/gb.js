const User = require('../../models/User');
const Guild = require('../../models/athers/Guild');
const Group = require('../../models/athers/Group');
const Pokemon = require('../../models/pokemon');
const config = require('../../config');
const { normalizeJid, groupAllowed, partyFor, levelData } = require('../../utils/gym');
const { normalizeMoveList, normalizeMoveName, readableMoveName } = require('../../utils/pokemonUtils');
const { isGuildMember } = require('../../utils/guildAccess');
const { renderGymBattle } = require('../../utils/gymBattleRender');
const { identityKeys } = require('../../utils/guildAccess');
const { POKE_BALLS, inventoryId } = require('../../utils/pokeBalls');

function userQuery(sender) { return { $or: identityKeys(sender).flatMap((key) => [{ whatsappNumber: key }, { phoneNumber: key }, { userId: key }]) }; }
function damage(move, level) { return Math.min(50, Math.max(1, Math.floor((String(move).length * 2) + Number(level || 1) * 0.8))); }
function groupError() { return `${config.POKEMON_LINK || ''}\n\n> In order to play or use this command, join this group and have fun.`; }
function gymLog(active, battle, moveLabel, dealt, taken, sender, party) {
  const opponentMove = Array.isArray(battle.opponent.moves) && battle.opponent.moves.length ? readableMoveName(battle.opponent.moves[Math.floor(Math.random() * battle.opponent.moves.length)]) : 'a move';
  const lines = ['━━ ⚔️ *BATTLE LOG* ⚔️ ━━', '', `💨 ${battle.opponent.name} used ${opponentMove}!`, `> It dealt ${taken} damage!`, '', `💨 ${active.name} used ${moveLabel}!`, `> It dealt ${dealt} damage!`, '', '━━━━━━━━━━━━━━━━━━', '📊 *Current Status*', `💚 ${active.name}: ${Math.max(0, Math.round(battle.playerHp))}/${Math.max(1, Math.round(battle.playerMaxHp || active.hp || 1))} HP`, `❤️ Leader ${battle.opponent.name}: ${Math.max(0, Math.round(battle.opponent.hp))}/${Math.max(1, Math.round(battle.opponent.maxHp))} HP`, '', `🎯 *Your Turn, @${String(sender).split('@')[0]}!*`, ...normalizeMoveList(active.moves).slice(0, 4).map((move, index) => `${index + 1}. ${readableMoveName(move)}`), '', '> 💡 _Options: .gb <1-4> | .gb switch <#> | .gb forfeit_'];
  return { text: lines.join('\n'), mentions: [sender] };
}

moon({
  name: 'gb',
  aliases: ['gymbattle'],
  category: 'pokemon',
  description: 'Use moves and switch Pokémon during a Gym battle.',
  usage: '.gb <move index|move name|switch|run>',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!groupAllowed(jid) || !jid.endsWith('@g.us')) return reply(groupError());
    const group = await Group.findOne({ groupId: jid }).lean();
    if (group?.pokemonSpawnEnabled !== true) return reply(groupError());
    if (!(await isGuildMember(sender))) return reply('❌ You must be a member of a guild before using Gym battles.');
    const user = await User.findOne(userQuery(sender));
    const battle = user?.gymBattle;
    if (!user || !battle?.stage?.index) return reply('❌ You are not in a Gym battle. Use `.gym <index>` to enter your current stage.');
    const input = String(args[0] || '').toLowerCase();
    if (!input) return reply('❌ Choose a move index. Use `.gb 1`, `.gb switch`, or `.gb run`.');
    if (['run', 'forfeit'].includes(input)) { user.gymBattle = null; user.gymPending = null; await user.save(); return reply('🏃 You left the Gym battle. Your stage was not advanced.'); }
    const party = await partyFor(sender);
    const active = party.find((pokemon) => String(pokemon._id) === String(battle.playerPokemonId)) || party[0];
    if (!active) return reply('❌ You need a Pokémon in your party to continue.');
    const moves = normalizeMoveList(active.moves);
    if (!moves.length) moves.push('tackle');
    if (input === 'moves') {
      const moveList = moves.length ? moves.map((move, index) => `${index + 1}. *${readableMoveName(move)}*`).join('\n') : '1. *Tackle*';
      return reply(`□------------------------------□\n⚔️ *${active.name} · available moves*\n\n${moveList}\n\nUse *.gb <move index>* to attack.\n□------------------------------□`);
    }
    if (input === 'switch') {
      const index = Number(args[1]);
      if (!Number.isInteger(index) || index < 1 || index > party.length) return reply(`🔁 Choose a party slot from 1 to ${party.length}.`);
      const next = party[index - 1];
      const stageRules = levelData(battle.stage.index);
      const requiredLevel = Number(stageRules.requiredLevel || 1);
      const nextLevel = Number.parseInt(String(next.level ?? 1), 10) || 1;
      if (nextLevel < requiredLevel) return reply(`🚫 This Pokémon needs level *${requiredLevel}* or higher for Gym stage *${battle.stage.index}*.\n> Detected level: *${nextLevel}* for *${next.name}*.`);
      battle.playerPokemonId = String(next._id); battle.playerHp = Number(next.hp || 100); battle.playerMaxHp = Math.max(1, Number(next.maxHp || next.hp || 100)); battle.turn = Number(battle.turn || 1) + 1;
      user.markModified('gymBattle'); await user.save();
      try { return await renderGymBattle(sock, jid, m, battle, next, `━━ ⚔️ *BATTLE LOG* ⚔️ ━━\n\n${String(sender).split('@')[0]} withdrew ${active.name}!\nGo, ${next.name}!\n\n━━━━━━━━━━━━━━━━━━\n📊 *Current Status*\n💚 ${next.name}: ${Math.max(0, Math.round(battle.playerHp))}/${Math.max(1, Math.round(battle.playerMaxHp))} HP\n❤️ Leader ${battle.opponent.name}: ${Math.max(0, Math.round(battle.opponent.hp))}/${Math.max(1, Math.round(battle.opponent.maxHp))} HP\n\n🎯 *Your Turn, @${String(sender).split('@')[0]}!*\n\n> 💡 _Options: .gb <1-4> | .gb switch <#> | .gb forfeit_`, { mentions: [sender] }); } catch { return reply(`🔁 You sent out *${next.name}*.`, { mentions: [sender] }); }
    }
    const moveIndex = /^\d+$/.test(input) ? Number(input) - 1 : moves.findIndex((move) => normalizeMoveName(move) === normalizeMoveName(input) || readableMoveName(move).toLowerCase() === input);
    if (moveIndex < 0 || !moves[moveIndex]) return reply(`❌ That move was not found. ${active.name} currently knows *${moves.join(', ')}*. Use \.gb <move index>.`);
    const move = moves[moveIndex];
    const moveLabel = readableMoveName(move);
    const dealt = damage(move, active.level);
    const opponentMaxHp = Math.min(15000, Math.max(Number(battle.opponent.maxHp || 0), 250 + Number(battle.stage.index || 1) * 35));
    battle.opponent.maxHp = opponentMaxHp;
    battle.opponent.hp = Math.max(0, Number(battle.opponent.hp || opponentMaxHp) - dealt);
    const round = Number(battle.turn || 1);
    const damageLine = `⚔️ *${active.name}* used *${moveLabel}* and dealt *${dealt} damage*.`;
    if (battle.opponent.hp <= 0) {
      const stage = levelData(battle.stage.index);
      if (battle.mode === 'trail' && battle.guildId) {
        const guild = await Guild.findById(battle.guildId);
        if (!guild) return reply(`${damageLine}\n\n❌ The shared guild Trail could not be loaded. Your battle was not advanced.`);
        guild.trailProgress = guild.trailProgress || { current: 1, completed: [], wins: [] };
        const progress = guild.trailProgress;
        if (!Array.isArray(progress.completed)) progress.completed = [];
        if (!Array.isArray(progress.wins)) progress.wins = [];
        const firstClear = !progress.completed.includes(stage.index);
        if (firstClear) {
          progress.completed.push(stage.index);
          progress.current = Math.max(Number(progress.current || 1), stage.index + 1);
          progress.wins.push({ stage: stage.index, trainer: sender, at: new Date() });
          guild.xp = Number(guild.xp || 0) + stage.index * 25;
          await guild.save();
        }
        const xp = firstClear ? Math.max(15, stage.index * 10) : 5;
        user.xp = Number(user.xp || 0) + xp;
        const partyPokemon = await Pokemon.findOne({ _id: battle.playerPokemonId });
        if (partyPokemon) {
          partyPokemon.xp = Number(partyPokemon.xp || 0) + xp;
          partyPokemon.level = Number(partyPokemon.level || 1) + (firstClear ? 1 : 0);
          await partyPokemon.save();
        }
        if (firstClear) {
          if (!Array.isArray(user.inventory)) user.inventory = [];
          for (let i = 0; i < 5; i += 1) {
            const ball = POKE_BALLS[Math.floor(Math.random() * POKE_BALLS.length)];
            if (ball) user.inventory.push({ id: inventoryId(ball), name: ball.name, quantity: 1, boughtAt: new Date() });
          }
          user.markModified('inventory');
        }
        user.gymBattle = null;
        await user.save();
        const next = progress.current <= 16 ? `Next shared round: *${progress.current}* — use *.trail* for the board.` : '🏆 Your guild completed every listed Trail round!';
        return reply(`━━ 🧭 *TRAIL BATTLE LOG* 🧭 ━━\n\n${damageLine}\n💀 *${battle.opponent.name}* was defeated after a real multi-turn battle.\n\n${firstClear ? `✅ *${stage.name}* cleared for every guild member.\n🎒 5 random Poké Balls awarded.` : 'ℹ️ This Trail was already cleared by the guild.'}\n☆ Personal reward: *+${xp} XP*${firstClear ? ' · Pokémon +1 level' : ''}\n\n${next}`);
      }
      user.gymProgress = user.gymProgress || { current: 1, points: 0, completed: 0 };
      user.gymProgress.current = Math.min(251, Number(user.gymProgress.current || 1) + 1);
      user.gymProgress.completed = Number(user.gymProgress.completed || 0) + 1;
      user.gymProgress.points = Number(user.gymProgress.points || 0) + stage.points;
      user.balance = Number(user.balance || 0) + stage.index * 250;
      user.xp = Number(user.xp || 0) + stage.index * 10;
      user.gymBattle = null;
      user.markModified('gymProgress');
      user.markModified('gymBattle');
      await user.save();
      const milestone = stage.index % 5 === 0 ? '\n🎁 You have been given a special Pokémon milestone prize.' : '';
      return reply(`□------------------------------□\n${damageLine}\n💀 *${battle.opponent.name}* was knocked out immediately at *0/${opponentMaxHp} HP*.\n\n✅ Stage *${stage.index}* cleared — moving to the next stage.\n□------------------------------□\n\nYou have been given *${stage.prize}*.${milestone}`);
    }
    const taken = Math.min(50, Math.max(1, Math.floor(Number(battle.opponent.level || 1) * 0.45)));
    battle.playerHp = Math.max(0, Number(battle.playerHp || active.hp || 100) - taken);
    battle.turn = round + 1;
    if (battle.playerHp <= 0) { user.gymBattle = null; await user.save(); return reply(`${damageLine}\n*${battle.opponent.name}* HP: *${battle.opponent.hp}/${opponentMaxHp}*\n💥 *${active.name}* fainted after taking *${taken} damage*. The Gym battle is over; your stage remains locked until you try again.`); }
    user.markModified('gymBattle'); await user.save();
    const turnText = `⚔️ Turn ${round}\n\n${damageLine}\n*${battle.opponent.name}* HP: *${battle.opponent.hp}/${opponentMaxHp}*\n\n*${battle.opponent.name}* struck back for *${taken} damage*.\n\n*Trainer:* @${String(sender).split('@')[0]}\n*Pokémon:* *${active.name}*\n*Health:* ${Math.max(0, Math.round(battle.playerHp))}/${Math.max(1, Math.round(battle.playerMaxHp || active.hp || 100))} HP\n\nUse *.gb <move index>* for the next turn or *.gb switch <slot>*.`;
    const formatted = gymLog(active, battle, moveLabel, dealt, taken, sender, party);
    return reply(formatted.text, { mentions: formatted.mentions });
  },
});
