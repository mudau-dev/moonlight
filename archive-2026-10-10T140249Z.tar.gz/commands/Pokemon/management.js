const Pokemon = require('../../models/pokemon');
const User = require('../../models/User');
const { generateRentalImage } = require('../../utils/rentalGenerator');
const { fetchPokemonData, getEvolutionTarget, generateIVs, calculateStat, getMoveInfo, readableMoveName } = require('../../utils/pokemonUtils');
const { generateEvolutionImage } = require('../../utils/evolutionGenerator');
const { getPokemonByIndex, listPokemon, resolvePokemonOwner, cleanupExpiredRentals } = require('../../utils/pokemonStorage');
const { battles } = require('../../utils/battleEngine');

const RENTAL_NAMES = ['Mewtwo', 'Rayquaza', 'Arceus', 'Lucario', 'Garchomp', 'Greninja', 'Charizard'];
const RENTAL_DURATION_MS = 30 * 60 * 1000;

function formatRemaining(ms) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}m ${seconds}s`;
}

function typeLabel(move) {
  return String(move?.type || 'normal').toUpperCase();
}

function formatMoveInfo(move, index) {
  const title = `${index ? `MOVE ${index}: ` : ''}${move.displayName || readableMoveName(move.name)}`;
  const damageClass = String(move.damageClass || 'status').toUpperCase();
  const power = move.damageClass === 'status' ? '— (status move)' : move.power;
  const effectChance = Number.isFinite(Number(move.effectChance)) ? `\n*Effect Chance:* ${move.effectChance}%` : '';

  return [
    `📖 *${title.toUpperCase()}*`,
    '━━━━━━━━━━━━━━━━━━━━',
    `*Type:* ${typeLabel(move)}`,
    `*Category:* ${damageClass}`,
    `*Power:* ${power}`,
    `*Accuracy:* ${move.accuracy ?? '—'}%`,
    `*PP:* ${move.pp ?? '—'}`,
    `*Priority:* ${move.priority ?? 0}`,
    `*Battle Energy:* ${move.energy ?? '—'}`,
    '',
    '*How it works:*',
    move.effect || 'No additional effect information is available.',
    effectChance,
    '',
    '> Use this exact move name with `.pb <move name>` while this Pokémon is active in battle.',
  ].filter(Boolean).join('\n');
}

function normalizedItem(value) {
  return String(value || '').toLowerCase().replace(/[\s_-]+/g, '');
}

function isFullHealItem(item) {
  const key = normalizedItem(`${item?.id || ''} ${item?.name || ''}`);
  if (!key || key.includes('revive')) return false;
  return ['fullrestore', 'maxpotion', 'maxheal', 'hyperpotion', 'superpotion', 'hppotion', 'healthpotion', 'potion', 'healpotion']
    .some((name) => key.includes(name));
}

function consumeInventoryItem(user, item) {
  const inventory = Array.isArray(user.inventory) ? user.inventory : [];
  const index = inventory.indexOf(item);
  if (index < 0) return false;
  const quantity = Number(item.quantity || item.count || 1);
  if (quantity > 1) item.quantity = quantity - 1;
  else inventory.splice(index, 1);
  user.markModified('inventory');
  return true;
}

function healingRequirement(previousHp, maxHp, status) {
  const normalizedStatus = String(status || 'Healthy').toLowerCase();
  if (normalizedStatus !== 'healthy' || previousHp <= 0) return { name: 'Full Restore', tier: 5, reason: normalizedStatus === 'healthy' ? 'fainted' : normalizedStatus };
  const ratio = maxHp > 0 ? previousHp / maxHp : 1;
  if (ratio >= 0.8) return { name: 'Potion', tier: 1, reason: 'minor HP damage' };
  if (ratio >= 0.5) return { name: 'Super Potion', tier: 2, reason: 'moderate HP damage' };
  if (ratio >= 0.25) return { name: 'Hyper Potion', tier: 3, reason: 'heavy HP damage' };
  return { name: 'Max Potion', tier: 4, reason: 'critical HP damage' };
}

function healingTier(item) {
  const key = normalizedItem(`${item?.id || ''} ${item?.name || ''}`);
  if (key.includes('fullrestore') || key.includes('maxheal')) return 5;
  if (key.includes('maxpotion')) return 4;
  if (key.includes('hyperpotion')) return 3;
  if (key.includes('superpotion')) return 2;
  if (key.includes('potion') || key.includes('hppotion') || key.includes('healthpotion') || key.includes('healpotion')) return 1;
  return 0;
}

moon({
  name: 'pgrow',
  aliases: ['evolve', 'pevolve'],
  category: 'Pokémon',
  description: 'Evolve a party Pokémon when it reaches its required level.',
  usage: '.pgrow <party index>',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    const index = Number.parseInt(args[0], 10);
    if (!Number.isInteger(index) || index < 1) return reply('❌ Usage: `.pgrow <party_index>`');
    const entry = await getPokemonByIndex(sender, 'party', index);
    if (!entry) return reply('❌ No Pokémon exists at that party index.');
    const pokemon = entry.pokemon;
    const target = await getEvolutionTarget(pokemon.name);
    if (!target) return reply(`✨ *${pokemon.name}* has no further level-based evolution.`);
    const level = Number(pokemon.level || 1);
    if (level < target.requiredLevel) return reply(`❌ *${pokemon.name}* must reach level *${target.requiredLevel}* before it can evolve into *${target.name}*.\n> Current level: *${level}*.`);

    const before = await fetchPokemonData(pokemon.name);
    const after = await fetchPokemonData(target.name);
    const oldMaxHp = Math.max(1, calculateStat(before.stats.hp, pokemon.iv?.hp || 0, pokemon.ev?.hp || 0, level, true));
    const newMaxHp = Math.max(1, calculateStat(after.stats.hp, pokemon.iv?.hp || 0, pokemon.ev?.hp || 0, level, true));
    const hpRatio = Math.max(0, Math.min(1, Number(pokemon.hp || oldMaxHp) / oldMaxHp));
    pokemon.pokedexNumber = after.pokedexNumber;
    pokemon.name = after.name;
    pokemon.type1 = after.type1;
    pokemon.type2 = after.type2 || null;
    pokemon.attack = calculateStat(after.stats.attack, pokemon.iv?.attack || 0, pokemon.ev?.attack || 0, level);
    pokemon.defense = calculateStat(after.stats.defense, pokemon.iv?.defense || 0, pokemon.ev?.defense || 0, level);
    pokemon.spAtk = calculateStat(after.stats.spAtk, pokemon.iv?.spAtk || 0, pokemon.ev?.spAtk || 0, level);
    pokemon.spDef = calculateStat(after.stats.spDef, pokemon.iv?.spDef || 0, pokemon.ev?.spDef || 0, level);
    pokemon.speed = calculateStat(after.stats.speed, pokemon.iv?.speed || 0, pokemon.ev?.speed || 0, level);
    pokemon.hp = Math.max(1, Math.round(newMaxHp * hpRatio));
    pokemon.status = 'Healthy';
    pokemon.isEvolved = true;
    pokemon.evolvesInto = null;
    await pokemon.save();

    const caption = `🌟 *EVOLUTION COMPLETE!*\n\n*${before.name}* evolved into *${after.name}*!\n> Level: *${level}*\n> HP: *${pokemon.hp}/${newMaxHp}*`;
    try {
      const image = await generateEvolutionImage({ before, after, level });
      return sock.sendMessage(jid, { image, caption }, { quoted: m });
    } catch (error) {
      console.warn('[PGROW IMAGE]', error.message);
      return reply(caption);
    }
  },
});

moon({
  name: 'heal',
  aliases: ['pheal'],
  category: 'Pokémon',
  description: 'Use a shop healing potion to fully restore your party.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const activeBattle = [...battles.values()].find((battle) => battle?.status === 'active' && battle.players?.includes(sender));
    if (activeBattle) return reply('⚔️ You cannot use `.heal` or `.pheal` while you are in a battle. Finish the battle first.');
    const firstArg = String(args[0] || '').toLowerCase();
    const selectedIndex = /^\d+$/.test(firstArg) ? Number(firstArg) : null;
    const requestedItem = selectedIndex ? args.slice(1).join(' ') : (firstArg === 'full' ? args.slice(1).join(' ') : args.join(' '));
    const user = await User.findOne({ $or: [{ whatsappNumber: sender }, { phoneNumber: sender }, { userId: sender }] });
    if (!user) return reply('❌ Send `.reg` first.');
    const { pokemons: party } = await listPokemon(sender, 'party', 6);
    if (!party.length) return reply('❌ Your party is empty!');

    const selectedParty = selectedIndex ? party.filter((pokemon) => Number(party.indexOf(pokemon) + 1) === selectedIndex) : party;
    if (selectedIndex && !selectedParty.length) return reply(`❌ No Pokémon exists at party slot ${selectedIndex}.`);
    const prepared = await Promise.all(selectedParty.map(async (pokemon) => {
      const data = await fetchPokemonData(pokemon.name);
      const maxHp = calculateStat(data.stats.hp, pokemon.iv?.hp || 0, pokemon.ev?.hp || 0, pokemon.level, true);
      const previousHp = Math.max(0, Number(pokemon.hp) || 0);
      const status = String(pokemon.status || 'Healthy').toLowerCase();
      const needsRestore = previousHp < maxHp || previousHp <= 0 || status !== 'healthy';
      return { pokemon, maxHp, previousHp, status, needsRestore, requirement: needsRestore ? healingRequirement(previousHp, maxHp, status) : null };
    }));
    const needsHealing = prepared.filter((entry) => entry.needsRestore);
    if (!needsHealing.length) return reply('✅ Your entire party is already at full HP and healthy.');

    const healedLines = [];
    const skippedLines = [];
    for (const { pokemon, maxHp, previousHp, requirement } of needsHealing) {
      const inventory = Array.isArray(user.inventory) ? user.inventory : [];
      const potion = inventory.find((item) => {
        if (!isFullHealItem(item) || healingTier(item) < requirement.tier) return false;
        return !requestedItem || normalizedItem(`${item.id || ''} ${item.name || ''}`).includes(normalizedItem(requestedItem));
      });
      if (!potion) {
        skippedLines.push(`  ⚠️ *${(pokemon.nickname || pokemon.name).toUpperCase()}* — needs *${requirement.name}* (${requirement.reason})`);
        continue;
      }
      consumeInventoryItem(user, potion);
      const wasFainted = previousHp <= 0 || String(pokemon.status || '').toLowerCase() === 'fainted';
      pokemon.hp = maxHp;
      pokemon.status = 'Healthy';
      await pokemon.save();
      healedLines.push(`  💖 *${(pokemon.nickname || pokemon.name).toUpperCase()}* — ${previousHp} → ${maxHp} HP · used *${potion.name || requirement.name}*${wasFainted ? ' · recovered' : ''}`);
    }

    if (!healedLines.length) return reply(['🧪 *HEALING REQUIRED*', '━━━━━━━━━━━━━━━━━━', ...skippedLines, '', '> Buy the listed potion(s) from `.shop`, then use `.heal` again.'].join('\n'));

    await user.save();
    const lines = [
      '🏥 *POKÉMON CENTER · FULL RESTORE*',
      '■━━━━━━━━━━━━━━━━━━■',
      `🧪 Treatment items used: *${healedLines.length}*`,
      `☆ Restored: *${healedLines.length} Pokémon*`,
      '',
      ...healedLines,
      ...(skippedLines.length ? ['', '⚠️ *Still needs treatment:*', ...skippedLines] : []),
      '',
      '■━━━━━━━━━━━━━━━━━━■',
      '》 Your party is ready for battle! ◇',
    ];
    return reply(lines.join('\n'));
  },
});

moon({
  name: 'pgive',
  category: 'Pokémon',
  description: 'Give a Pokémon from your party to another user.',
  usage: '.pgive <party_index> <@user>',
  async execute(sock, jid, sender, args, m, { reply }) {
    const requestedIndex = Number.parseInt(args[0], 10);
    const target = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    if (!Number.isInteger(requestedIndex) || requestedIndex < 1 || !target) return reply('❌ Usage: `.pgive <party_index> <@user>`');

    const entry = await getPokemonByIndex(sender, 'party', requestedIndex);
    if (!entry) return reply('❌ Pokémon not found in your party!');

    entry.pokemon.userId = target;
    entry.pokemon.location = 'pc';
    entry.pokemon.partyPosition = null;
    await entry.pokemon.save();
    return reply(`✅ You gave *${String(entry.pokemon.nickname || entry.pokemon.name).toLowerCase()}* to @${target.split('@')[0]}!`, { mentions: [target] });
  },
});

moon({
  name: 'prent',
  category: 'Pokémon',
  description: 'View the rental roster or rent one Pokémon for 30 minutes.',
  usage: '.prent [index]',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const requestedIndex = args[0] ? Number.parseInt(args[0], 10) : null;
      if (args[0] && (!Number.isInteger(requestedIndex) || requestedIndex < 1)) return reply('❌ Usage: `.prent <rental_index>`');

      const roster = await Promise.all(RENTAL_NAMES.map((name) => fetchPokemonData(name)));
      if (!requestedIndex) {
        const image = await generateRentalImage({ pokemon: roster });
        const text = [
          '🏢 *POKÉMON RENTAL CENTER*',
          '',
          ...roster.map((pokemon, index) => `*${index + 1}.* ${pokemon.name.toUpperCase()} · Lv.100`),
          '',
          '> Every rental lasts 30 minutes. You can only hold one rental Pokémon at a time.',
          '> Use `.prent <index>` to rent one.',
        ].join('\n');
        return sock.sendMessage(jid, { image, caption: text }, { quoted: m });
      }

      const rental = roster[requestedIndex - 1];
      if (!rental) return reply(`❌ Invalid rental index. Choose a number from 1 to ${roster.length}.`);

      const { owner } = await cleanupExpiredRentals(sender);
      const activeRental = await Pokemon.findOne({
        userId: { $in: owner.identifiers },
        isRental: true,
        rentalExpiresAt: { $gt: new Date() },
      });
      if (activeRental) {
        return reply(`❌ You currently have a rented Pokémon: *${(activeRental.nickname || activeRental.name).toUpperCase()}*.\n> Pokémon will be taken in \`${formatRemaining(new Date(activeRental.rentalExpiresAt).getTime() - Date.now())}\`, then you can rent another Pokémon.`);
      }

      const { pokemons: party } = await listPokemon(sender, 'party', 6);
      if (party.length >= 6) return reply('❌ Your party is full. Move a Pokémon to your PC with `.t2pc <party_index>` before renting one.');

      const ivs = { hp: 31, attack: 31, defense: 31, spAtk: 31, spDef: 31, speed: 31 };
      const level = 100;
      const expiresAt = new Date(Date.now() + RENTAL_DURATION_MS);
      const rentedPokemon = await Pokemon.create({
        pokemonId: `RENT-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        userId: owner.primaryId,
        pokedexNumber: rental.pokedexNumber,
        name: rental.name,
        level,
        type1: rental.type1,
        type2: rental.type2 || null,
        hp: calculateStat(rental.stats.hp, ivs.hp, 0, level, true),
        attack: calculateStat(rental.stats.attack, ivs.attack, 0, level),
        defense: calculateStat(rental.stats.defense, ivs.defense, 0, level),
        spAtk: calculateStat(rental.stats.spAtk, ivs.spAtk, 0, level),
        spDef: calculateStat(rental.stats.spDef, ivs.spDef, 0, level),
        speed: calculateStat(rental.stats.speed, ivs.speed, 0, level),
        iv: ivs,
        moves: rental.moves,
        location: 'party',
        partyPosition: party.length + 1,
        isRental: true,
        rentalExpiresAt: expiresAt,
      });

      const timeLeft = formatRemaining(expiresAt.getTime() - Date.now() - 1000);
      return sock.sendMessage(jid, {
        image: { url: rental.sprite },
        caption: [
          `🎉 You have rented a *${rentedPokemon.name.toUpperCase()}*!`,
          `> You have \`${timeLeft}\` to use and/or learn it.`,
          '> Use `.party` to view your full team or `.pmove <party_index>` to learn its moves.',
        ].join('\n'),
      }, { quoted: m });
    } catch (error) {
      console.error('[PRENT]', error);
      return reply('❌ The rental center is unavailable right now. Please try again.');
    }
  },
});

moon({
  name: 'pmove',
  category: 'Pokémon',
  description: 'List a party Pokémon’s learned moves or view detailed information about one move.',
  usage: '.pmove <party_index> [move_index]',
  async execute(sock, jid, sender, args, m, { reply }) {
    const partyIndex = Number.parseInt(args[0], 10);
    const moveIndex = args[1] ? Number.parseInt(args[1], 10) : null;
    if (!Number.isInteger(partyIndex) || partyIndex < 1 || (args[1] && (!Number.isInteger(moveIndex) || moveIndex < 1))) {
      return reply('❌ Usage: `.pmove <party_index>` or `.pmove <party_index> <move_index>`');
    }

    const entry = await getPokemonByIndex(sender, 'party', partyIndex);
    if (!entry) return reply('❌ Pokémon not found in your party!');
    const moves = Array.isArray(entry.pokemon.moves) ? entry.pokemon.moves : [];
    if (!moves.length) return reply(`❌ *${String(entry.pokemon.nickname || entry.pokemon.name).toLowerCase()}* has no learned moves yet.`);

    if (!moveIndex) {
      const lines = [
        `📚 *${String(entry.pokemon.nickname || entry.pokemon.name).toLowerCase()} — LEARNED MOVES*`,
        '━━━━━━━━━━━━━━━━━━━━',
      ];
      for (let index = 0; index < moves.length; index += 1) {
        const move = await getMoveInfo(moves[index]);
        lines.push(`*${index + 1}.* ${move ? move.displayName : readableMoveName(moves[index])}${move ? ` · ${typeLabel(move)} ${String(move.damageClass).toUpperCase()} · Power ${move.damageClass === 'status' ? '—' : move.power}` : ''}`);
      }
      lines.push('', `> Use \.pb <index> in battle, or \.plearn info ${partyIndex} <move_index> for move information.`);
      return reply(lines.join('\n'));
    }

    const selectedMove = moves[moveIndex - 1];
    if (!selectedMove) return reply(`❌ No move exists at index ${moveIndex}. Use \`.pmove ${partyIndex}\` to list this Pokémon’s moves.`);
    const move = await getMoveInfo(selectedMove);
    if (!move) return reply(`❌ I could not load information for *${readableMoveName(selectedMove)}* right now.`);
    return reply(formatMoveInfo(move, moveIndex));
  },
});

moon({
  name: 'pchange',
  category: 'Pokémon',
  description: 'Swap two positions in your active party.',
  usage: '.pchange <party_index> <party_index>',
  async execute(sock, jid, sender, args, m, { reply }) {
    const fromIndex = Number.parseInt(args[0], 10);
    const toIndex = Number.parseInt(args[1], 10);
    if (!Number.isInteger(fromIndex) || !Number.isInteger(toIndex) || fromIndex < 1 || toIndex < 1) {
      return reply('❌ Usage: `.pchange <party_index> <party_index>`\n> Example: `.pchange 1 4`');
    }
    if (fromIndex === toIndex) return reply('❌ Choose two different party positions.');

    const { pokemons: party } = await listPokemon(sender, 'party', 6);
    const first = party[fromIndex - 1];
    const second = party[toIndex - 1];
    if (!first || !second) return reply('❌ Both party positions must contain a Pokémon. Use `.party` to view your active team.');

    await Promise.all([
      Pokemon.updateOne({ _id: first._id }, { $set: { partyPosition: toIndex } }),
      Pokemon.updateOne({ _id: second._id }, { $set: { partyPosition: fromIndex } }),
    ]);

    return reply(`✅ Swapped *${(first.nickname || first.name).toUpperCase()}* in slot ${fromIndex} with *${(second.nickname || second.name).toUpperCase()}* in slot ${toIndex}.`);
  },
});
