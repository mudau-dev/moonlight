/**
 * commands/Pokemon/pdel.js
 *
 * .pdel <index> — Delete a Pokémon from your PC or party.
 *
 * Flow:
 *   1. User runs .pdel <index>
 *   2. Bot asks for confirmation: "Are you sure? Reply yes or no."
 *   3. If user replies "yes" → delete the Pokémon.
 *   4. If user replies "no" → cancel.
 *   5. Confirmation expires after 60 seconds.
 */

const Pokemon = require('../../models/pokemon');
const { getPokemonByIndex, listPokemon, displayName } = require('../../utils/pokemonStorage');
const { findOrCreateWhatsApp } = require('../../database/users');

// Pending confirmations: senderJid → { pokemonId, pokemonName, expiresAt }
const pendingDeletions = new Map();
const CONFIRM_TIMEOUT_MS = 60 * 1000; // 60 seconds

moon({
  name: 'pdel',
  aliases: ['pokedelete', 'deletepoke'],
  category: 'Pokémon',
  description: 'Delete a Pokémon from your PC (with confirmation)',
  usage: '.pdel <pc_index>',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const indexArg = args[0];

      // ── Handle confirmation reply ──────────────────────────────────────
      if (!indexArg || indexArg.toLowerCase() === 'yes' || indexArg.toLowerCase() === 'no') {
        const pending = pendingDeletions.get(sender);

        if (!pending) {
          if (!indexArg) return reply('❌ Usage: `.pdel <pc_index>`\nExample: `.pdel 3`');
          return reply('❌ No pending deletion. Use `.pdel <pc_index>` first.');
        }

        // Check expiry
        if (Date.now() > pending.expiresAt) {
          pendingDeletions.delete(sender);
          return reply('⏰ Confirmation expired. Use `.pdel <pc_index>` again to try.');
        }

        if (indexArg?.toLowerCase() === 'no') {
          pendingDeletions.delete(sender);
          return reply('✅ Deletion cancelled.');
        }

        if (indexArg?.toLowerCase() === 'yes') {
          // Perform deletion
          const deleted = await Pokemon.findOneAndDelete({ pokemonId: pending.pokemonId });
          pendingDeletions.delete(sender);

          if (!deleted) return reply('❌ Pokémon no longer exists (may have already been deleted).');
          return reply(`🗑️ *${pending.pokemonName}* has been permanently deleted.`);
        }

        return reply('❌ Usage: `.pdel <pc_index>`');
      }

      // ── Initial deletion request ───────────────────────────────────────
      const entry = await getPokemonByIndex(sender, 'pc', indexArg);
      if (!entry) {
        return reply(`❌ No Pokémon found at PC slot *${indexArg}*.\nUse \`.pc\` to view your stored Pokémon.`);
      }

      const { pokemon } = entry;
      const name = displayName(pokemon);

      // Store pending confirmation
      pendingDeletions.set(sender, {
        pokemonId: pokemon.pokemonId,
        pokemonName: name,
        expiresAt: Date.now() + CONFIRM_TIMEOUT_MS,
      });

      // Auto-expire
      setTimeout(() => {
        const p = pendingDeletions.get(sender);
        if (p && p.pokemonId === pokemon.pokemonId) {
          pendingDeletions.delete(sender);
        }
      }, CONFIRM_TIMEOUT_MS);

      return reply(
        `⚠️ *Are you sure you want to delete this Pokémon?*\n\n` +
        `🐾 *${name}*\n` +
        `📊 Level ${pokemon.level ?? 1} | ${pokemon.type1?.toUpperCase() || 'UNKNOWN'}\n\n` +
        `Reply with *yes* or *no*.\n` +
        `> This action cannot be undone. Confirmation expires in 60 seconds.`
      );

    } catch (err) {
      console.error('[PDEL ERROR]', err);
      return reply('❌ Failed to process deletion. Please try again.');
    }
  },
});

// ── Listen for yes/no replies ─────────────────────────────────────────────────
// This is handled by the command itself when called with 'yes' or 'no' as args.
// The handler/cmds.js will route ".yes" and ".no" to this command if pending.
// Alternatively, we hook into the message handler for plain "yes"/"no" replies.

/**
 * handlePdelReply — called from the main message handler for non-command messages.
 * If the user has a pending deletion and sends "yes" or "no", process it.
 */
async function handlePdelReply(sock, jid, sender, body, m) {
  const text = (body || '').trim().toLowerCase();
  if (text !== 'yes' && text !== 'no') return false;

  const pending = pendingDeletions.get(sender);
  if (!pending) return false;

  if (Date.now() > pending.expiresAt) {
    pendingDeletions.delete(sender);
    await sock.sendMessage(jid, { text: '⏰ Confirmation expired. Use `.pdel <pc_index>` again.' }, { quoted: m });
    return true;
  }

  if (text === 'no') {
    pendingDeletions.delete(sender);
    await sock.sendMessage(jid, { text: '✅ Deletion cancelled.' }, { quoted: m });
    return true;
  }

  if (text === 'yes') {
    const deleted = await Pokemon.findOneAndDelete({ pokemonId: pending.pokemonId });
    pendingDeletions.delete(sender);
    if (!deleted) {
      await sock.sendMessage(jid, { text: '❌ Pokémon no longer exists.' }, { quoted: m });
    } else {
      await sock.sendMessage(jid, { text: `🗑️ *${pending.pokemonName}* has been permanently deleted.` }, { quoted: m });
    }
    return true;
  }

  return false;
}

module.exports = { handlePdelReply };
