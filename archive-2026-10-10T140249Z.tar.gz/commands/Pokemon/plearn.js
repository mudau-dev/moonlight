/**
 * .plearn <party_index>                 — List learnable moves, page 1
 * .plearn <party_index> page <page>     — Open a move page
 * .plearn <pokemon> p <page>            — Open a move page by Pokémon name
 * .plearn <party_index> <move_index>   — Teach a move (1h cooldown)
 */
const axios = require('axios');
const { getPokemonByIndex, listPokemon } = require('../../utils/pokemonStorage');
const { normalizeMoveName, readableMoveName, getMoveInfo } = require('../../utils/pokemonUtils');
const Cooldowns = require('../../models/athers/Cooldowns');

const PLEARN_COOLDOWN_MS = 60 * 60 * 1000;
const MOVES_PER_PAGE = 35;

async function fetchLearnableMoves(pokemonName) {
  const query = String(pokemonName).toLowerCase().trim().replace(/\s+/g, '-');
  const { data } = await axios.get(`https://pokeapi.co/api/v2/pokemon/${encodeURIComponent(query)}`, { timeout: 15000 });
  return [...new Set((data.moves || []).map((entry) => String(entry.move.name).replace(/-/g, ' ')))];
}

async function resolvePokemon(sender, token) {
  if (/^\d+$/.test(String(token || ''))) return getPokemonByIndex(sender, 'party', Number(token));
  const { owner, pokemons } = await listPokemon(sender, 'party');
  const query = String(token || '').trim().toLowerCase().replace(/-/g, ' ');
  const index = pokemons.findIndex((pokemon) => [pokemon.name, pokemon.nickname].filter(Boolean).some((name) => String(name).toLowerCase() === query || String(name).toLowerCase().replace(/-/g, ' ') === query));
  const pokemon = index >= 0 ? pokemons[index] : null;
  return pokemon ? { owner, pokemon, index: index + 1, total: pokemons.length } : null;
}

function formatTime(ms) {
  const seconds = Math.max(0, Math.floor(ms / 1000));
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
}

function pageNumber(value, fallback = 1) {
  const parsed = Number.parseInt(value, 10);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

moon({
  name: 'plearn',
  aliases: ['learnmove', 'pmove-learn'],
  category: 'Pokémon',
  description: 'View learnable Pokémon moves by page or teach a move.',
  usage: '.plearn <pokemon|party_index> [page|p <page_index>|move_index]',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const token = args[0];
      if (!token) {
        return reply('❌ Usage:\n• `.plearn <pokemon|party_index>` — View page 1\n• `.plearn <pokemon|party_index> page <page>` — Open a page\n• `.plearn <pokemon|party_index> p <page>` — Short page syntax\n• `.plearn <party_index> <move_index>` — Teach a move');
      }

      const infoRequest = String(token).toLowerCase() === 'info';
      const pokemonToken = infoRequest ? args[1] : token;
      const entry = await resolvePokemon(sender, pokemonToken);
      if (!entry) return reply(`❌ I could not find *${pokemonToken}* in your party. Use *.party* to see your party positions.`);
      const pokemon = entry.pokemon;
      const pokemonName = String(pokemon.nickname || pokemon.name || 'pokemon').toLowerCase();
      if (infoRequest) {
        const moveIndex = Number.parseInt(args[2], 10);
        const moves = Array.isArray(pokemon.moves) ? pokemon.moves : [];
        if (!Number.isInteger(moveIndex) || moveIndex < 1 || !moves[moveIndex - 1]) return reply('❌ Usage: `.plearn info <party_index> <move_index>`');
        const move = await getMoveInfo(moves[moveIndex - 1]);
        if (!move) return reply('❌ Move information is unavailable right now.');
        return reply(`□------------------------------□\n*${move.displayName.toLowerCase()}*\n\n*Type:* ${move.type}\n*Power:* ${move.power || 'status'}\n*Accuracy:* ${move.accuracy}%\n*Energy:* ${move.energy}\n*Effect:* ${move.effect}\n\n> Use it with \.pb ${moveIndex} during a battle.\n□------------------------------□`);
      }

      let learnableMoves;
      try {
        learnableMoves = await fetchLearnableMoves(pokemon.name);
      } catch (error) {
        console.error('[PLEARN FETCH]', error.message);
        return reply(`❌ Could not fetch moves for *${pokemonName}*. Please try again.`);
      }
      if (!learnableMoves.length) return reply(`❌ No learnable moves found for *${pokemonName}*.`);

      const second = String(args[1] || '').toLowerCase();
      const isPageRequest = second === 'page' || second === 'p';
      const page = isPageRequest ? pageNumber(args[2]) : 1;
      const moveArg = Number.parseInt(args[1], 10);

      if (isPageRequest || !args[1] || !Number.isInteger(moveArg)) {
        const totalPages = Math.max(1, Math.ceil(learnableMoves.length / MOVES_PER_PAGE));
        const safePage = Math.min(page, totalPages);
        const start = (safePage - 1) * MOVES_PER_PAGE;
        const pageItems = learnableMoves.slice(start, start + MOVES_PER_PAGE);
        const currentMoves = Array.isArray(pokemon.moves) && pokemon.moves.length ? pokemon.moves.map(readableMoveName).join(', ') : 'None';
        const lines = [
          `📚 *${pokemonName} — LEARNABLE MOVES*`,
          `> Party slot: ${entry.index}  •  Page ${safePage}/${totalPages}`,
          `> Showing ${pageItems.length} moves  •  Total: ${learnableMoves.length}`,
          `> Current moves: ${currentMoves}`,
          '',
          ...pageItems.map((move, index) => `*${start + index + 1}.* ${readableMoveName(move)}`),
          '',
          `> Teach a move: \.plearn ${entry.index} <move_index>`,
          totalPages > 1 && safePage > 1 ? `> Previous: \.plearn ${entry.index} page ${safePage - 1}` : '',
          totalPages > safePage ? `> Next: \.plearn ${entry.index} page ${safePage + 1}` : '',
        ].filter(Boolean);
        return reply(lines.join('\n'));
      }

      if (moveArg < 1 || moveArg > learnableMoves.length) return reply(`❌ Move index must be between 1 and ${learnableMoves.length}.`);
      let cooldown = await Cooldowns.findOne({ userId: sender });
      if (!cooldown) cooldown = new Cooldowns({ userId: sender });
      const cd = cooldown.safeGet('plearn');
      const now = Date.now();
      if (cd.cooldownUntil > now) return reply(`⏳ *Move Learning Cooldown*\n\nYou can teach *${pokemonName}* a new move in *${formatTime(cd.cooldownUntil - now)}*.\n> One move can be learned per hour.`);

      const chosenMove = learnableMoves[moveArg - 1];
      const chosenMoveData = await getMoveInfo(chosenMove);
      const requiredLevel = Math.max(1, Math.ceil(Number(chosenMoveData?.energy || 10) / 5));
      const currentEnergy = Number.isFinite(Number(pokemon.energy)) ? Number(pokemon.energy) : 100;
      if (Number(pokemon.level || 1) < requiredLevel) return reply(`❌ *${pokemonName}* needs to reach level *${requiredLevel}* before learning *${readableMoveName(chosenMove).toLowerCase()}*.`);
      if (currentEnergy < Number(chosenMoveData?.energy || 0)) return reply(`❌ *${pokemonName}* does not have enough energy to learn this move. Required: *${chosenMoveData.energy}*, available: *${currentEnergy}*.`);
      const currentMoves = Array.isArray(pokemon.moves) ? pokemon.moves : [];
      if (currentMoves.some((move) => normalizeMoveName(move) === normalizeMoveName(chosenMove))) return reply(`✅ *${pokemonName}* already knows *${readableMoveName(chosenMove)}*!`);
      const newMoves = currentMoves.length < 6 ? [...currentMoves, chosenMove] : [...currentMoves.slice(1, 6), chosenMove];
      pokemon.moves = newMoves;
      pokemon.energy = Math.max(0, currentEnergy - Number(chosenMoveData?.energy || 0));
      await pokemon.save();
      cooldown.setCommand('plearn', { count: (cd.count || 0) + 1, cooldownUntil: now + PLEARN_COOLDOWN_MS });
      await cooldown.save();
      const replaced = currentMoves.length >= 6 ? `\n\n> The oldest move, *${readableMoveName(currentMoves[0])}*, was forgotten to keep the six-move limit.` : '';
      return reply(`🎓 *MOVE LEARNED!*\n\n*${pokemonName}* learned *${readableMoveName(chosenMove)}*.${replaced}\n\n*Current moves:*\n${newMoves.map((move, index) => `${index + 1}. ${readableMoveName(move)}`).join('\n')}\n\n> Next move can be learned in *1 hour*.`);
    } catch (error) {
      console.error('[PLEARN ERROR]', error);
      return reply('❌ Failed to process move learning. Please try again.');
    }
  },
});
