const Pokemon = require('../../models/pokemon');
const SpawnControl = require('../../models/athers/SpawnControl');
const User = require('../../models/User');
const { Battle, battles } = require('../../utils/battleEngine');

// ── Battle lock: one active Pokémon battle per group ────────────────────────────
// groupJid → { sender, timer }
const pokeBattleLocks = new Map();
const POKE_TIMEOUT_MS = 5 * 60 * 1000;
const battleOperationQueues = new Map();
const battleStartLocks = new Set();

async function withBattleLock(battle, operation) {
  const key = battle.id || `${battle.players.join(':')}:${battle.groupId || ''}`;
  const previous = battleOperationQueues.get(key) || Promise.resolve();
  let release;
  const pending = new Promise((resolve) => { release = resolve; });
  const queued = previous.catch(() => {}).then(() => pending);
  battleOperationQueues.set(key, queued);
  await previous.catch(() => {});
  try {
    return await operation();
  } finally {
    release();
    if (battleOperationQueues.get(key) === queued) battleOperationQueues.delete(key);
  }
}

function clearPokeTimer(groupJid) {
  const entry = pokeBattleLocks.get(groupJid);
  if (entry?.timer) clearTimeout(entry.timer);
}

function setPokeTimer(sock, jid, originalMsg, groupJid, sender) {
  clearPokeTimer(groupJid);
  const t = setTimeout(async () => {
    const battle = battles.get(sender);
    if (battle) {
      battle.status = 'finished';
      removeBattle(battle);
    }
    pokeBattleLocks.delete(groupJid);
    try {
      await sock.sendMessage(jid, {
        text: 'No move was made in the last 5 minutes. This battle has ended.',
      }, { quoted: originalMsg });
    } catch {}
  }, POKE_TIMEOUT_MS);
  pokeBattleLocks.set(groupJid, { sender, timer: t });
}

function releasePokelock(groupJid) {
  clearPokeTimer(groupJid);
  pokeBattleLocks.delete(groupJid);
}
const { generateBattleImage } = require('../../utils/battleGenerator');
const { fetchPokemonData, fetchPokemonSpecies, generateIVs, rollGender, calculateStat, getMoveData, calculateDamage, normalizeMoveName, normalizeMoveList, readableMoveName } = require('../../utils/pokemonUtils');
const { listPokemon, getCurrentHp } = require('../../utils/pokemonStorage');
const { POKE_BALLS, getPokeBall, getCatchMultiplier, inventoryId, inventoryBallMatches, normalizeBallName } = require('../../utils/pokeBalls');
const { generateOutcomeImage } = require('../../utils/outcomeGenerator');
const { createWildBattle, battleUrl } = require('../../utils/webBattle');

async function cancelWebBattles(identity) {
  const base = String(process.env.WEB || 'https://haven.nett.to').replace(/\/$/, '');
  const token = String(process.env.WEB_BATTLE_BOT_TOKEN || '').trim();
  if (!token) return 0;
  try {
    const response = await fetch(`${base}/api/battles/cancel`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-moon-bot-token': token }, body: JSON.stringify({ userId: String(identity).split('@')[0] }) });
    if (!response.ok) return 0;
    return Number((await response.json()).cancelled || 0);
  } catch { return 0; }
}

function getBattleForUser(sender) {
  const direct = battles.get(sender);
  if (direct?.status === 'active') return direct;
  for (const battle of battles.values()) {
    if (battle.status === 'active' && battle.players.includes(sender)) return battle;
  }
  return null;
}

function getPlayerIndex(battle, sender) {
  return battle.players[0] === sender ? 0 : battle.players[1] === sender ? 1 : -1;
}

function toBattlePokemon(document, data) {
  const iv = document.iv || {};
  const ev = document.ev || {};
  const level = document.level || 1;

  // Use proper calculated stats — this is the fix for trainer dealing only 1 damage.
  // calculateStat returns the full base stat when IVs/EVs are provided.
  const maxHp = calculateStat(data.stats.hp, iv.hp || 0, ev.hp || 0, level, true);
  // Recalculate all battle stats from the Pokémon's base stats, level, IVs, and EVs.
  // Stored values can be absent or stale on Pokémon created before the stat fields existed.
  const attack = calculateStat(data.stats.attack, iv.attack || 0, ev.attack || 0, level);
  const defense = calculateStat(data.stats.defense, iv.defense || 0, ev.defense || 0, level);
  const spAtk = calculateStat(data.stats.spAtk, iv.spAtk || 0, ev.spAtk || 0, level);
  const spDef = calculateStat(data.stats.spDef, iv.spDef || 0, ev.spDef || 0, level);
  const speed = calculateStat(data.stats.speed, iv.speed || 0, ev.speed || 0, level);

  // Use stored moves if available, otherwise fall back to API moves.
  // This fixes the 'no moves found' bug where battle couldn't find moves
  // because document.moves was empty but data.moves had them.
  const storedMoves = normalizeMoveList(document.moves).length
    ? normalizeMoveList(document.moves)
    : (normalizeMoveList(data.moves).length ? normalizeMoveList(data.moves) : ['tackle']);

  return {
    ...document.toObject(),
    sprite: data.sprite,
    // Ensure all combat stats are populated from the Pokémon's actual values
    attack,
    defense,
    spAtk,
    spDef,
    speed,
    maxHp,
    hp: Number.isFinite(Number(document.hp))
      ? Math.min(maxHp, Math.max(0, Number(document.hp)))
      : maxHp,
    energy: 100,
    // Always ensure moves is populated
    moves: storedMoves,
  };
}

function battleBox(lines) {
  return ['■━━━━━□━━━━━■', ...lines, '■━━━━━□━━━━━■'].join('\n');
}

function trainerLabel(battle, jid, fallback) {
  if (jid === 'wild') return 'Wild Pokémon';
  return `@${battle.trainerNames?.[jid] || String(jid || fallback || '').split('@')[0]}`;
}

function formatPendingBattleMove(battle, playerIndex, move, damage) {
  const pokemon = battle.activePokemon[playerIndex];
  const opponent = battle.players[1 - playerIndex];
  return battleBox([
    `*${pokemon.name}* used *${readableMoveName(move)}* and dealt *${damage} damage*`,
    `> waiting for ${opponent === 'wild' ? 'the wild Pokémon' : `@${String(opponent).split('@')[0]}`} to make a move`,
  ]);
}

function battleHeader(round) { return `⚔️ *BATTLE LOG · ROUND ${Number(round || 1)}*`; }
function hpLine(icon, label, hp, maxHp, status) {
  return `${icon} ${label}: ${Math.max(0, Math.round(hp || 0))}/${Math.max(1, Math.round(maxHp || hp || 1))}${status ? ` [${String(status).toUpperCase()}]` : ''}`;
}
function displayMove(move) { return readableMoveName(move || 'Tackle'); }
function hpBar(hp, maxHp, size = 10) { const ratio = Math.max(0, Math.min(1, Number(hp || 0) / Math.max(1, Number(maxHp || 1)))); const filled = Math.round(ratio * size); return `${'▰'.repeat(filled)}${'▱'.repeat(size - filled)}`; }
function detailedLines(details) {
  const lines = [];
  for (const detail of details) {
    lines.push(`💨 ${detail.attacker} used ${displayMove(detail.move)}!`);
    if (detail.missed) lines.push('> The move missed!');
    else if (Number(detail.damage || 0) > 0) lines.push(`> It dealt ${Math.round(detail.damage)} damage!`);
    else lines.push('> It caused no direct damage!');
    if (detail.effectiveness > 1) lines.push("It's extremely effective!");
    else if (detail.effectiveness > 0 && detail.effectiveness < 1) lines.push("It's not very effective...");
  }
  return lines;
}
function moveMenu(pokemon) {
  const moves = normalizeMoveList(pokemon?.moves).slice(0, 4);
  return ['🎯 *Your Turn!*', ...(moves.length ? moves.map((move, index) => `${index + 1}. ${displayMove(move)}`) : ['1. Tackle']), '', '> 💡 Options: .pb <1-4> | .pb switch <#> | .pb forfeit'];
}
function formatWildTurn(battle, lastAction) {
  const player = battle.activePokemon[0];
  const wild = battle.activePokemon[1];
  const details = [...(battle.lastTurn || [])].sort((a, b) => a.index - b.index);
  const lines = [battleHeader(battle.turn), '', '✦ *ROUND ACTIONS*', ...detailedLines(details)];
  if (!details.length && lastAction) lines.push(String(lastAction));
  lines.push('', '📊 *STATUS BOARD*', `💚 *${player?.nickname || player?.name || 'Your Pokémon'}*  ${hpBar(battle.hp[0], player?.maxHp)}  ${Math.max(0, Math.round(battle.hp[0] || 0))}/${Math.max(1, Math.round(player?.maxHp || 1))} [${String(player?.status || (battle.hp[0] > 0 ? 'Healthy' : 'Fainted')).toUpperCase()}]`, `❤️ *Wild ${wild?.nickname || wild?.name || 'Pokémon'}*  ${hpBar(battle.hp[1], wild?.maxHp)}  ${Math.max(0, Math.round(battle.hp[1] || 0))}/${Math.max(1, Math.round(wild?.maxHp || 1))} [${String(wild?.status || (battle.hp[1] > 0 ? 'Healthy' : 'Fainted')).toUpperCase()}]`);
  if (Number(battle.hp[0]) <= 0) lines.push('', '💀 *Oh no! Your Pokémon fainted!*', '🔄 *Choose a replacement:*', '> Use `.pb switch <number>`');
  else lines.push('', ...moveMenu(player));
  return lines.join('\n');
}
function formatBattleTurn(battle) {
  const details = [...(battle.lastTurn || [])].sort((a, b) => a.index - b.index);
  const lines = [battleHeader(battle.turn), '', '✦ *ROUND ACTIONS*', ...detailedLines(details), '', '📊 *STATUS BOARD*'];
  for (const index of [0, 1]) {
    const pokemon = battle.activePokemon[index];
    if (!pokemon) continue;
    lines.push(`${index === 0 ? '💚' : '❤️'} *${trainerLabel(battle, battle.players[index], 'Trainer')} · ${pokemon.nickname || pokemon.name}*  ${hpBar(battle.hp[index], pokemon.maxHp)}  ${Math.max(0, Math.round(battle.hp[index] || 0))}/${Math.max(1, Math.round(pokemon.maxHp || 1))} [${String(pokemon.status || (battle.hp[index] > 0 ? 'Healthy' : 'Fainted')).toUpperCase()}]`);
  }
  lines.push('', '🎯 *Trainers, choose your next move!*', '> Options: .pb <move> | .pb switch <#>');
  return lines.join('\n');
}
function formatForcedSwitch(party, command = 'pb', battle = null, faintedIndex = 0) {
  const healthy = party.filter((pokemon) => getCurrentHp(pokemon) > 0);
  const fainted = battle?.activePokemon?.[faintedIndex];
  const details = [...(battle?.lastTurn || [])].sort((a, b) => a.index - b.index);
  const log = details.length ? detailedLines(details) : [];
  return [
    '━━ ⚔️ *BATTLE LOG* ⚔️ ━━',
    ...log,
    '━━━━━━━━━━━━━━━━━━',
    `💀 *Oh no! Your ${(fainted?.nickname || fainted?.name || 'Pokémon').toString()} fainted!*`,
    '',
    '🔄 *Choose a replacement:*',
    `> Use .${command} switch <number>`,
    '',
    ...healthy.map((pokemon) => `[ ${party.indexOf(pokemon) + 1} ] ⚔️ *${pokemon.nickname || pokemon.name}* (${Math.max(0, Math.round(getCurrentHp(pokemon)))}/${Math.max(1, Math.round(getMaxHp(pokemon)))} HP)`),
  ].join('\n');
}

async function renderBattle(sock, jid, message, battle, lastAction, logImage = false) {
  for (const pokemon of battle.activePokemon) {
    if (!pokemon.sprite) {
      try {
        pokemon.sprite = (await fetchPokemonData(pokemon.name)).sprite;
      } catch (error) {
        console.warn('[BATTLE SPRITE]', error.message);
      }
    }
  }

  battle.activePokemon[0].hp = battle.hp[0];
  battle.activePokemon[1].hp = battle.hp[1];
  battle.activePokemon[0].energy = battle.energy[0];
  battle.activePokemon[1].energy = battle.energy[1];

  const mentions = battle.type === 'pvp' ? (battle.players || []).filter((player) => player && player !== 'wild') : [];
  const switching = String(lastAction || '').startsWith('🔄');
  const caption = battle.type === 'wild'
    ? (switching ? `${lastAction}\n\n${formatWildTurn(battle, '')}` : ((battle.needsSwitch?.[0] && String(lastAction || '').includes('Oh no!')) ? lastAction : formatWildTurn(battle, lastAction)))
    : (switching ? `${lastAction}\n\n${formatBattleTurn(battle)}` : (logImage ? formatBattleTurn(battle) : lastAction));
  // Images are restored by default. Set FAST_BATTLE_MESSAGES=true only on a
  // constrained deployment to use the text-only emergency path.
  if (process.env.FAST_BATTLE_MESSAGES === 'true') return sock.sendMessage(jid, { text: caption, mentions }, { quoted: message });

  try {
    const image = await generateBattleImage({
      player: battle.activePokemon[0],
      opponent: battle.activePokemon[1],
      lastAction,
      weather: battle.weather,
      logImage,
      droppedItem: battle.droppedItem,
      thrownBall: battle.thrownBall,
      playerName: battle.trainerNames?.[battle.players?.[0]] || 'Trainer',
      opponentName: battle.trainerNames?.[battle.players?.[1]] || (battle.type === 'wild' ? 'Wild Pokémon' : 'Opponent'),
    });
    return sock.sendMessage(jid, { image, caption, mentions }, { quoted: message });
  } catch (error) {
    console.error('[BATTLE IMAGE]', error.message);
    const mentions = battle.type === 'pvp' ? (battle.players || []).filter((player) => player && player !== 'wild') : [];
    const text = battle.type === 'wild'
      ? (switching ? `${lastAction}\n\n${formatWildTurn(battle, '')}` : ((battle.needsSwitch?.[0] && String(lastAction || '').includes('Oh no!')) ? lastAction : formatWildTurn(battle, lastAction)))
      : (switching ? `${lastAction}\n\n${formatBattleTurn(battle)}` : (logImage ? formatBattleTurn(battle) : lastAction));
    return sock.sendMessage(jid, { text, mentions }, { quoted: message });
  }
}

async function persistBattleLog(battle, text) {
  if (battle.type !== 'pvp' || !text) return;
  const entry = { turn: Number(battle.turn || 1), text: String(text), createdAt: new Date() };
  const ids = [...new Set((battle.players || []).filter((player) => player && player !== 'wild'))];
  await User.updateMany(
    { $or: ids.flatMap((id) => [{ whatsappNumber: id }, { phoneNumber: id }, { userId: id }]) },
    { $push: { lastPokemonBattleLogs: { $each: [entry], $slice: -20 } } },
  );
}

async function persistBattleHp(battle) {
  const updates = battle.activePokemon
    .filter((pokemon, index) => battle.players[index] && battle.players[index] !== 'wild' && pokemon?.pokemonId)
    .map((pokemon, index) => {
      const newHp = Math.max(0, Math.round(battle.hp[index]));
      // Keep HP and status consistent in every persisted battle result.
      // This prevents a recovered Pokémon from retaining a stale Fainted flag.
      const update = { $set: { hp: newHp, status: newHp <= 0 ? 'Fainted' : 'Healthy' } };
      return Pokemon.updateOne({ pokemonId: pokemon.pokemonId }, update);
    });
  await Promise.all(updates);
}

function removeBattle(battle) {
  battle.players.filter(Boolean).forEach((player) => battles.delete(player));
  // Release group battle lock
  if (battle.groupId) releasePokelock(battle.groupId);
}

async function captureWildPokemon(sender, battle, ball) {
  const spawn = await SpawnControl.findOne({ groupId: battle.groupId });
  if (!spawn?.active || !spawn.pokemon) return { success: false, message: '❌ The wild Pokémon is no longer available.' };

  const data = await fetchPokemonData(spawn.pokemon);
  let species = { captureRate: null, genderRate: -1 };
  try {
    species = await fetchPokemonSpecies(spawn.pokemon);
  } catch (error) {
    console.warn('[CATCH SPECIES]', error.message);
  }

  const ivs = generateIVs();
  const maxHp = calculateStat(data.stats.hp, ivs.hp, 0, spawn.level, true);
  const caughtPokemon = await Pokemon.create({
    pokemonId: `PKMN-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    userId: sender,
    pokedexNumber: data.pokedexNumber,
    name: data.name,
    level: spawn.level,
    type1: data.type1,
    type2: data.type2 || null,
    hp: ball.healOnCatch ? maxHp : Math.max(1, Math.round(maxHp * 0.65)),
    attack: calculateStat(data.stats.attack, ivs.attack, 0, spawn.level),
    defense: calculateStat(data.stats.defense, ivs.defense, 0, spawn.level),
    spAtk: calculateStat(data.stats.spAtk, ivs.spAtk, 0, spawn.level),
    spDef: calculateStat(data.stats.spDef, ivs.spDef, 0, spawn.level),
    speed: calculateStat(data.stats.speed, ivs.speed, 0, spawn.level),
    iv: ivs,
    moves: data.moves,
    captureRate: species.captureRate,
    gender: rollGender(species.genderRate),
    happiness: ball.happinessOnCatch || 0,
    location: 'pc',
  });

  spawn.active = false;
  await spawn.save();
  battle.status = 'finished';
  battle.winnerIndex = 0;
  battle.finishedReason = 'captured';
  if (Array.isArray(battle.players)) removeBattle(battle);

  return {
    success: true,
    pokemon: caughtPokemon,
    sprite: data.sprite,
    message: `🎉 *CAUGHT!*\n\n${ball.emoji} ${ball.name} caught *${data.name.toUpperCase()}*!\nIt was sent to your PC. Use \.pc\` to view it and \.t2party <index>\` to move it into your party.`,
  };
}

async function awardBattleWinRewards(winnerId, activePokemon) {
  const result = { xp: 0, levels: 0, ball: null };
  if (!winnerId || !activePokemon?.pokemonId) return result;
  try {
    const pokemon = await Pokemon.findOne({ pokemonId: activePokemon.pokemonId });
    if (!pokemon) return result;
    result.xp = Math.floor(Math.random() * 6) + 10;
    result.levels = Math.floor(Math.random() * 4) + 2;
    const nextLevel = Number(pokemon.level || activePokemon.level || 1) + result.levels;
    const data = await fetchPokemonData(pokemon.name);
    const maxHp = calculateStat(data.stats.hp, pokemon.iv?.hp || 0, pokemon.ev?.hp || 0, nextLevel, true);
    pokemon.level = nextLevel;
    pokemon.xp = Number(pokemon.xp || 0) + result.xp;
    pokemon.maxHp = maxHp;
    pokemon.attack = calculateStat(data.stats.attack, pokemon.iv?.attack || 0, pokemon.ev?.attack || 0, nextLevel);
    pokemon.defense = calculateStat(data.stats.defense, pokemon.iv?.defense || 0, pokemon.ev?.defense || 0, nextLevel);
    pokemon.spAtk = calculateStat(data.stats.spAtk, pokemon.iv?.spAtk || 0, pokemon.ev?.spAtk || 0, nextLevel);
    pokemon.spDef = calculateStat(data.stats.spDef, pokemon.iv?.spDef || 0, pokemon.ev?.spDef || 0, nextLevel);
    pokemon.speed = calculateStat(data.stats.speed, pokemon.iv?.speed || 0, pokemon.ev?.speed || 0, nextLevel);
    pokemon.hp = Math.max(1, Math.min(maxHp, Number(pokemon.hp) || maxHp));
    pokemon.status = 'Healthy';
    await pokemon.save();
    activePokemon.level = nextLevel;
    activePokemon.maxHp = maxHp;
    activePokemon.hp = pokemon.hp;

    const user = await User.findOne({ $or: [{ whatsappNumber: winnerId }, { phoneNumber: winnerId }, { userId: winnerId }] });
    const ball = POKE_BALLS[Math.floor(Math.random() * POKE_BALLS.length)];
    if (user && ball) {
      if (!Array.isArray(user.inventory)) user.inventory = [];
      user.inventory.push({ id: inventoryId(ball), name: ball.name, quantity: 1, boughtAt: new Date() });
      user.markModified('inventory');
      await user.save();
      result.ball = ball;
    }
  } catch (error) {
    console.error('[BATTLE REWARD]', error);
  }
  return result;
}

function rewardText(reward) {
  if (!reward?.xp) return '';
  return `\n\n■ ☆ *REWARDS* ☆ ■\n¤ +${reward.xp} XP · Level +${reward.levels}\n》 🎒 Random Poké Ball: *${reward.ball?.name || 'added to your bag'}*`;
}

async function throwPokeBall(sender, battle, ballName) {
  if (battle.type !== 'wild') return '❌ Poké Balls can only be used in wild battles.';
  let ball = getPokeBall(ballName);
  let owner;
  const listed = await listPokemon(sender);
  owner = listed.owner;
  const inventory = Array.isArray(owner.user.inventory) ? owner.user.inventory : [];

  if (!ball) {
    const query = normalizeBallName(ballName);
    const custom = inventory.find((item) => {
      const data = item?.ballData;
      if (!data) return false;
      return [item.name, item.id, data.name, data.displayName, data.id, ...(data.aliases || [])]
        .some((value) => normalizeBallName(value) === query);
    });
    if (custom?.ballData) {
      ball = {
        ...custom.ballData,
        id: custom.ballData.id || String(custom.id || '').replace(/^pokeball:/i, ''),
        name: custom.ballData.name || custom.name || custom.ballData.displayName,
      };
    }
  }
  if (!ball) return '❌ Unknown Poké Ball. Usage: `.pb pokeball <ball>`';

  const inventoryIndex = inventory.findIndex((item) => inventoryBallMatches(item, ball));
  if (inventoryIndex < 0) return `❌ You do not own a ${ball.name}. Visit the shop to buy one.`;
  const owned = inventory[inventoryIndex];
  const quantity = Number(owned.quantity || owned.count || 1);
  if (quantity > 1) owned.quantity = quantity - 1;
  else inventory.splice(inventoryIndex, 1);
  owner.user.markModified('inventory');
  await owner.user.save();

  const wildPokemon = battle.activePokemon[1];
  const hpRatio = Math.max(0, Math.min(1, battle.hp[1] / Math.max(1, wildPokemon.maxHp)));
  const multiplier = getCatchMultiplier(ball, wildPokemon, battle.turn);
  const baseChance = 0.18 + (1 - hpRatio) * 0.58;
  const caught = Number.isFinite(multiplier) ? Math.random() < Math.min(0.95, baseChance * multiplier) : true;

  if (!caught) {
    return `${ball.emoji} *${ball.name}* shook and broke free!\n> Lower the wild Pokémon's HP before trying again.`;
  }

  const captured = await captureWildPokemon(sender, battle, ball);
  return captured.message;
}

moon({
  name: 'catch',
  category: 'Pokémon',
  description: 'Start a battle with the wild Pokémon in this group.',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const spawn = await SpawnControl.findOne({ groupId: jid });
      if (!spawn?.active || !spawn.pokemon) return reply('❌ No wild Pokémon has spawned here.');
      if (getBattleForUser(sender)) return reply('❌ You are already in an active Pokémon battle.');
      // Battle lock: one active Pokémon battle per group
      if (pokeBattleLocks.has(jid) || battleStartLocks.has(jid)) {
        return reply(`Hold on @${sender.split('@')[0]}, there is already an active battle in this group.`, { mentions: [sender] });
      }
      battleStartLocks.add(jid);

      const { pokemons } = await listPokemon(sender, 'party', 6);
      const active = pokemons.find((pokemon) => getCurrentHp(pokemon) > 0);
      if (!active) return reply('❌ You need a healthy Pokémon in your party to battle. Use `.party` or `.t2party <pc_index>`.');

      const webRequested = ['web', 'wb'].includes(String(args[0] || '').toLowerCase());
      const directBallRequested = ['ball', 'pokeball'].includes(String(args[0] || '').toLowerCase());
      if (directBallRequested) {
        const requestedBall = args.slice(1).join(' ').trim();
        let directBall = getPokeBall(requestedBall);
        const owner = (await listPokemon(sender)).owner;
        const inventory = Array.isArray(owner.user.inventory) ? owner.user.inventory : [];
        if (!directBall) {
          const query = normalizeBallName(requestedBall);
          const custom = inventory.find((item) => item?.ballData && [item.name, item.id, item.ballData.name, item.ballData.displayName, item.ballData.id, ...(item.ballData.aliases || [])].some((value) => normalizeBallName(value) === query));
          if (custom?.ballData) directBall = { ...custom.ballData, id: custom.ballData.id || String(custom.id || '').replace(/^pokeball:/i, ''), name: custom.ballData.name || custom.name || custom.ballData.displayName };
        }
        if (!directBall) return reply('❌ Unknown Poké Ball. Use `.ball` to see the catalog.');
        const inventoryIndex = inventory.findIndex((item) => inventoryBallMatches(item, directBall));
        if (inventoryIndex < 0) return reply(`❌ You do not own a ${directBall.name}. Buy one first, then try again.`);
        const owned = inventory[inventoryIndex];
        const quantity = Number(owned.quantity || owned.count || 1);
        if (quantity > 1) owned.quantity = quantity - 1; else inventory.splice(inventoryIndex, 1);
        owner.user.markModified('inventory');
        await owner.user.save();
        const catchMultiplier = Math.max(1, Number(directBall.multiplier || 1));
        const caught = Math.random() < Math.min(0.25, 0.02 * catchMultiplier);
        if (!caught) return reply(`${directBall.emoji || '⚪'} *${directBall.name}* missed the wild Pokémon.\n> Direct capture is difficult (base chance: *2%*). Use *.catch* to battle and lower its HP.`);
        const captured = await captureWildPokemon(sender, { groupId: jid }, directBall);
        if (!captured.success) return reply(captured.message || '❌ The wild Pokémon could not be captured.');
        const caption = `🎉 *DIRECT CATCH SUCCESS!*\n\n${directBall.emoji || '⚪'} *${captured.pokemon.name.toUpperCase()}* was caught with *${directBall.name}* and sent to your PC!`;
        return reply(caption);
      }
      const [playerData, wildData] = await Promise.all([
        fetchPokemonData(active.name),
        fetchPokemonData(spawn.pokemon),
      ]);
      if (webRequested) {
        const wildLevel = Math.max(Number(spawn.level || 1), Number(active.level || 1) + 2);
        const wildMaxHp = Math.floor(calculateStat(wildData.stats.hp, 20, 0, wildLevel, true) * 1.35);
        const webBattle = await createWildBattle({
          creatorId: sender.split('@')[0],
          groupJid: jid,
          playerPokemon: active,
          wildPokemon: { ...wildData, level: wildLevel, hp: wildMaxHp, maxHp: wildMaxHp, moves: wildData.moves || ['tackle'] },
        });
        spawn.active = false;
        await spawn.save();
        return reply(`🌐 *WEB WILD BATTLE READY*\n\n@${sender.split('@')[0]} entered a web battle against *${spawn.pokemon.toUpperCase()}* (Lv.${wildLevel}).\n\n🔗 ${battleUrl('wild', webBattle.code)}\n\nOpen the link to battle live.`, { mentions: [sender] });
      }
      const player = toBattlePokemon(active, playerData);
      const wildMaxHp = Math.floor(calculateStat(wildData.stats.hp, 20, 0, Math.max(spawn.level, (player.level || 1) + 2), true) * 1.35);
      const wild = {
        ...wildData,
        level: Math.max(spawn.level, (player.level || 1) + 2),
        maxHp: wildMaxHp,
        hp: wildMaxHp,
        energy: 100,
      };

      const battle = new Battle(player, wild);
      battle.damageScale = 0.72;
      battle.minimumTurns = 0;
      battle.activePokemon = [player, wild];
      battle.players = [sender, 'wild'];
      battle.type = 'wild';
      battle.needsSwitch = [false, false];
      battle.groupId = jid;
      await battle.start();
      battles.set(sender, battle);
      setPokeTimer(sock, jid, m, jid, sender);

      const caption = [
        '⚔️ *WILD BATTLE*',
        '',
        `A wild *${spawn.pokemon.toUpperCase()}* appeared at Lv.${spawn.level}!`,
        'Use `.pb <move>` to attack.',
        'Use `.pb pokeball <ball>` to throw a Poké Ball.',
        'Use `.catch ball <ball>` for a hard 2% direct-catch attempt.',
        'Use `.pb switch <party_index>` to swap your active Pokémon.',
        'Use `.pb run` to leave the encounter.',
      ].join('\n');
      return renderBattle(sock, jid, m, battle, caption);
    } catch (error) {
      console.error('[CATCH]', error);
      return reply('❌ Failed to start the battle. Please try again.');
    } finally {
      battleStartLocks.delete(jid);
    }
  },
});

moon({
  name: 'pb',
  aliases: ['battle'],
  category: 'Pokémon',
  description: 'Use a move, throw a Poké Ball, switch Pokémon, or leave an active battle.',
  usage: '.pb <move> | .pb pokeball <ball> | .pb switch <index> | .pb run',
  async execute(sock, jid, sender, args, m, { reply, commands, pushName }) {
    const battle = getBattleForUser(sender);
    if (!battle) {
      const duel = commands?.get('pduel');
      if (duel?.execute) return duel.execute(sock, jid, sender, args, m, { reply, pushName });
      return reply('> You are currently not in a battle. Start one by:\n`.pb @Trainer`\n`.pb <replying to a Trainer message>`');
    }
    return withBattleLock(battle, async () => {
      try {
      if (battle.status !== 'active') return reply('❌ This battle has already ended.');
      const playerIndex = getPlayerIndex(battle, sender);
      if (playerIndex < 0) return reply('❌ You are not a player in this battle.');
      const activeSide = battle.activePokemon?.[playerIndex];
      const opponentSide = battle.activePokemon?.[1 - playerIndex];
      const activeFainted = !activeSide || Number(battle.hp?.[playerIndex] ?? activeSide.hp) <= 0 || String(activeSide.status || '').toLowerCase() === 'fainted';
      const opponentFainted = !opponentSide || Number(battle.hp?.[1 - playerIndex] ?? opponentSide.hp) <= 0 || String(opponentSide.status || '').toLowerCase() === 'fainted';
      if (activeFainted) {
        battle.needsSwitch = battle.needsSwitch || [false, false];
        battle.needsSwitch[playerIndex] = true;
        return reply(`💀 *${activeSide?.nickname || activeSide?.name || 'Your Pokémon'} has fainted!\n\n🔄 Choose a healthy replacement with *.pb switch <party_index>*.\n🏳️ Or use *.pb run* to leave the battle.`);
      }
      if (opponentFainted) {
        battle.status = 'finished'; battle.finishedReason = 'opponent_fainted'; removeBattle(battle);
        return reply('🏁 This battle has already ended because the opposing Pokémon fainted. Start a new battle with `.pb @Trainer`.');
      }

      const rentalExpiry = battle.activePokemon[playerIndex]?.rentalExpiresAt;
      if (rentalExpiry && new Date(rentalExpiry).getTime() <= Date.now()) {
        battle.status = 'finished';
        battle.finishedReason = 'rental_expired';
        removeBattle(battle);
        return reply('⌛ Your rental Pokémon has been returned because its 30-minute rental period ended.');
      }

      const subcommand = String(args[0] || '').toLowerCase();
      const forcedSwitchIndex = Array.isArray(battle.needsSwitch) ? battle.needsSwitch.findIndex(Boolean) : -1;
      if (forcedSwitchIndex >= 0 && subcommand !== 'switch') {
        if (forcedSwitchIndex === playerIndex) return reply('💀 Your active Pokémon fainted. You must use `.pb switch <party_index>` before making another move.');
        return reply('⏳ The other trainer must choose a replacement Pokémon before the next round can begin.');
      }

      // ── Run / flee ──────────────────────────────────────────────────────
      if (['run', 'leave', 'flee'].includes(subcommand)) {
        battle.status = 'finished';
        battle.finishedReason = 'left';
        removeBattle(battle);
        const webCancelled = await cancelWebBattles(sender.split('@')[0]);
        return reply(`🏃 You safely left the battle${webCancelled ? ` and cleared ${webCancelled} stale web battle${webCancelled === 1 ? '' : 's'}` : ''}. The wild Pokémon is still available for another trainer.`);
      }

      // ── Throw a Poké Ball ───────────────────────────────────────────────
      if (['pokeball', 'ball'].includes(subcommand)) {
        const result = await throwPokeBall(sender, battle, args.slice(1).join(' '));
        if (battle.status === 'finished') {
          battle.thrownBall = { caught: true, color: '#ef4444', side: 'right' };
          await renderBattle(sock, jid, m, battle, `🔃 Battle log made.\n${result}`);
          return undefined;
        }
        battle.thrownBall = { caught: false, color: '#ef4444', side: 'right' };
        await renderBattle(sock, jid, m, battle, `🔃 Battle log made.\n${result}`);
        battle.thrownBall = null;
        return undefined;
      }

      // ── Switch active Pokémon ───────────────────────────────────────────
      if (subcommand === 'switch') {
        const switchIndex = Number.parseInt(args[1], 10);
        if (!Number.isInteger(switchIndex) || switchIndex < 1 || switchIndex > 6) {
          return reply('❌ Usage: `.pb switch <party_index>` (1–6)');
        }

        const { pokemons } = await listPokemon(sender, 'party', 6);
        const target = pokemons[switchIndex - 1];
        if (!target) return reply(`❌ No Pokémon in party slot ${switchIndex}.`);
        if (getCurrentHp(target) <= 0) return reply(`❌ *${(target.nickname || target.name).toUpperCase()}* has fainted and cannot battle.`);

        const currentActive = battle.activePokemon[playerIndex];
        if (target.pokemonId === currentActive?.pokemonId) {
          return reply(`❌ *${(target.nickname || target.name).toUpperCase()}* is already your active Pokémon.`);
        }

        // Persist current HP back to the outgoing Pokémon
        if (currentActive?.pokemonId) {
          await Pokemon.updateOne(
            { pokemonId: currentActive.pokemonId },
            { $set: { hp: Math.max(0, Math.round(battle.hp[playerIndex])) } }
          );
        }

        // Load fresh data for the incoming Pokémon
        const incomingData = await fetchPokemonData(target.name);
        const incoming = toBattlePokemon(target, incomingData);
        // Restore the Pokémon's current HP (not max)
        incoming.hp = Math.max(0, Number(target.hp) || incoming.maxHp);

        battle.activePokemon[playerIndex] = incoming;
        battle.hp[playerIndex] = incoming.hp;
        battle.energy[playerIndex] = 100;
        battle.needsSwitch = battle.needsSwitch || [false, false];
        battle.needsSwitch[playerIndex] = false;
        // A faint ends the previous round. Do not carry a winner's early move into the new round.
        battle.moves = [null, null];
        battle.status = 'active';
        battle.winnerIndex = null;

        const switchMsg = `🔄 *${(currentActive?.name || '???').toUpperCase()}*, come back!\nGo, *${incoming.name.toUpperCase()}*!`;
        return renderBattle(sock, jid, m, battle, switchMsg);
      }

      // ── Use a move ──────────────────────────────────────────────────────
      const moveInput = args.join(' ').trim();
      if (!moveInput) {
        return reply('❌ Usage: `.pb <move or index>`\n> You can also use `.pb pokeball <ball>`, `.pb switch <index>`, or `.pb run`.');
      }

      const activePokemon = battle.activePokemon[playerIndex];
      const learnedMoves = normalizeMoveList(activePokemon?.moves);
      const requestedIndex = /^\d+$/.test(moveInput) ? Number.parseInt(moveInput, 10) : null;
      let selectedMove = requestedIndex ? learnedMoves[requestedIndex - 1] : learnedMoves.find((move) => normalizeMoveName(move) === normalizeMoveName(moveInput));
      if (!selectedMove) {
        const fallback = learnedMoves[0] || 'tackle';
        return reply(`□------------------------------□\nYou try using the skill of number ${requestedIndex || moveInput}\n> But that move was not found. Your Pokémon still knows *${readableMoveName(fallback).toLowerCase()}*.\n□------------------------------□`);
      }

      const selectedMoveData = await getMoveData(selectedMove);
      if (!selectedMoveData) {
        return reply(`❌ I could not verify \`${readableMoveName(selectedMove)}\` right now. Please try again shortly.`);
      }

      if (battle.type === 'wild') {
        const wildMoves = normalizeMoveList(battle.activePokemon[1]?.moves).length
          ? normalizeMoveList(battle.activePokemon[1].moves)
          : ['tackle'];
        battle.moves[0] = selectedMove;
        battle.moves[1] = wildMoves[Math.floor(Math.random() * wildMoves.length)] || 'tackle';
      } else {
        if (battle.moves[playerIndex] !== null) {
          return reply('⏳ Your move for this round is already locked in. Wait for the other trainer.');
        }
        battle.moves[playerIndex] = selectedMove;
        if (battle.moves[0] === null || battle.moves[1] === null) {
          const scale = Number(battle.damageScale) > 0 ? Number(battle.damageScale) : 1;
          const preview = calculateDamage(activePokemon, battle.activePokemon[1 - playerIndex], selectedMoveData);
          const estimatedDamage = Math.max(0, Math.floor((Number(preview.total) || 0) * scale));
          const waitingText = formatPendingBattleMove(battle, playerIndex, selectedMove, estimatedDamage);
          const opponent = battle.players[1 - playerIndex];
          return opponent !== 'wild' ? reply(waitingText, { mentions: [opponent] }) : reply(waitingText);
        }
      }

      const results = await battle.resolveTurn();
      await persistBattleHp(battle);
      battle.thrownBall = null;
      const faintedIndex = battle.hp[0] <= 0 ? 0 : battle.hp[1] <= 0 ? 1 : -1;
      if (battle.status === 'finished' && faintedIndex >= 0) {
        const faintedSender = battle.players[faintedIndex];
        if (faintedSender !== 'wild') {
          const partyResult = await listPokemon(faintedSender, 'party', 6).catch(() => ({ pokemons: [] }));
          const party = Array.isArray(partyResult?.pokemons) ? partyResult.pokemons : [];
          if (party.some((pokemon) => getCurrentHp(pokemon) > 0)) {
            battle.needsSwitch = battle.needsSwitch || [false, false];
            battle.needsSwitch[faintedIndex] = true;
            battle.status = 'active';
            battle.winnerIndex = null;
            const switchText = formatForcedSwitch(party, 'pb', battle, faintedIndex);
            const mentions = battle.type === 'pvp' ? [faintedSender] : [];
            return sock.sendMessage(jid, { text: switchText, mentions }, { quoted: m });
          }
        }
      }

      // Terminal battles send only the outcome image. This prevents the old
      // fainted battle image followed by a second catch message.
      if (battle.status === 'finished') {
        const winnerIndex = Number.isInteger(battle.winnerIndex) ? battle.winnerIndex : (battle.hp[0] > battle.hp[1] ? 0 : 1);
        battle.winnerIndex = winnerIndex;
        if (battle.type === 'wild' && winnerIndex === 0) {
          const reward = await awardBattleWinRewards(sender, battle.activePokemon[playerIndex]);
          const captured = await captureWildPokemon(sender, battle, { name: 'Battle Capture', emoji: '⚪', healOnCatch: false });
          if (!captured.success) {
            removeBattle(battle);
            return reply(captured.message || '❌ The wild Pokémon could not be captured.');
          }
          const caughtName = captured.pokemon?.name || battle.activePokemon[1]?.name || 'Pokémon';
          const caption = `🎉 *POKÉMON CAUGHT!*\n\n⚪ *${String(caughtName).toUpperCase()}* was caught and sent to your PC!${rewardText(reward)}\n\n◇ Use *.pc* to view it and *.t2party <index>* to add it to your party.`;
          try {
            const image = await generateOutcomeImage({ capture: true, pokemon: { ...(captured.pokemon?.toObject ? captured.pokemon.toObject() : captured.pokemon), sprite: captured.sprite }, pcIndex: null, xpGained: reward.xp });
            return sock.sendMessage(jid, { image, caption }, { quoted: m });
          } catch (error) {
            console.warn('[PB CAPTURE IMAGE]', error.message);
            return reply(caption);
          }
        }

        if (battle.type === 'pvp') {
          const winnerId = battle.players[winnerIndex];
          const loserId = battle.players[1 - winnerIndex];
          const reward = await awardBattleWinRewards(winnerId, battle.activePokemon[winnerIndex]);
          try {
            const winnerImage = await generateOutcomeImage({ pokemon: battle.activePokemon[winnerIndex], opponent: battle.activePokemon[1 - winnerIndex], won: true, weather: battle.weather, reason: 'Knockout' });
            const loserImage = await generateOutcomeImage({ pokemon: battle.activePokemon[1 - winnerIndex], opponent: battle.activePokemon[winnerIndex], won: false, weather: battle.weather, reason: 'Knockout' });
            await sock.sendMessage(jid, { image: winnerImage, caption: `🏆 *${battle.activePokemon[winnerIndex].name} WON THE BATTLE!*${rewardText(reward)}` }, { quoted: m });
            await sock.sendMessage(jid, { image: loserImage, caption: `💀 *${battle.activePokemon[1 - winnerIndex].name} WAS DEFEATED!*` }, { quoted: m });
          } catch (error) { console.warn('[PB OUTCOME IMAGES]', error.message); }
          removeBattle(battle);
          return sock.sendMessage(jid, { text: `🏆 *DUEL OVER!*\n\n🥇 Winner: @${winnerId.split('@')[0]}${rewardText(reward)}\n💀 Loser: @${loserId.split('@')[0]}`, mentions: [winnerId, loserId] }, { quoted: m });
        }

        try {
          const image = await generateOutcomeImage({ pokemon: battle.activePokemon[playerIndex], opponent: battle.activePokemon[1 - playerIndex], won: false, weather: battle.weather, reason: 'Knockout' });
          await sock.sendMessage(jid, { image, caption: `💀 *${battle.activePokemon[playerIndex].name} WAS DEFEATED!*` }, { quoted: m });
        } catch (error) { console.warn('[PB DEFEAT IMAGE]', error.message); }
        removeBattle(battle);
        return reply('💤 Your Pokémon fainted. Buy a healing potion and use `.heal full` before battling again.');
      }

      const turnText = battle.type === 'pvp'
        ? formatBattleTurn(battle)
        : formatWildTurn(battle, `💨 ${activePokemon.name} used ${readableMoveName(selectedMove)}!`);
      if (battle.type === 'pvp') await persistBattleLog(battle, turnText);
      await renderBattle(sock, jid, m, battle, turnText, true);
      return undefined;
      } catch (error) {
        console.error('[PB]', error);
        const side = battle.activePokemon?.[getPlayerIndex(battle, sender)];
        const sideHp = battle.hp?.[getPlayerIndex(battle, sender)];
        if (battle.status !== 'active' || !side || Number(sideHp ?? side.hp) <= 0 || String(side.status || '').toLowerCase() === 'fainted') {
          battle.status = 'finished'; battle.finishedReason = battle.finishedReason || 'stale_or_fainted'; removeBattle(battle);
          return reply(`🏁 *BATTLE CLOSED*\n\n💀 ${side?.nickname || side?.name || 'Your Pokémon'} is fainted or this battle has already ended.\n> Start a new battle with *.pb @Trainer*.`);
        }
        return reply('⚠️ That move could not be processed safely. Your battle is still active; choose a valid move or switch Pokémon.');
      }
    });
  },
});

moon({
  name: 'm',
  category: 'Pokémon',
  description: 'Pick up or use a dropped battle item.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const battle = getBattleForUser(sender);
    if (!battle) return reply('❌ You are not in a battle.');
    const playerIndex = getPlayerIndex(battle, sender);
    const subcommand = String(args[0] || '').toLowerCase();

    if (['c', 'catch'].includes(subcommand)) return reply(battle.catchItem(playerIndex));
    if (subcommand === 'use') {
      const result = battle.useItem(playerIndex);
      await persistBattleHp(battle);
      return reply(result);
    }
    return reply('❌ Usage: `.m catch` to pick up an item or `.m use` to use one.');
  },
});
