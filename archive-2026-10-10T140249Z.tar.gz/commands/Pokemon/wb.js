/**
 * commands/Pokemon/wb.js
 *
 * .wb — Start a wild Pokémon battle.
 *
 * Requirements:
 *   - User must be a guild member.
 *   - 15-minute cooldown per user.
 *   - Only one active Pokémon battle per group (battle lock).
 *   - 5-minute timeout: if no move is made, the battle ends automatically.
 *
 * Rewards on win:
 *   - Guild receives 1 XP.
 *   - Every guild member receives 2 XP.
 *   - The user's active Pokémon receives a small amount of XP/level progress.
 */

const Pokemon = require('../../models/pokemon');
const SpawnControl = require('../../models/athers/SpawnControl');
const Guild = require('../../models/athers/Guild');
const User = require('../../models/User');
const { Battle, battles } = require('../../utils/battleEngine');
const { generateBattleImage } = require('../../utils/battleGenerator');
const {
  fetchPokemonData, fetchPokemonSpecies, generateIVs, rollGender,
  calculateStat, getMoveData, normalizeMoveName, normalizeMoveList, readableMoveName,
} = require('../../utils/pokemonUtils');
const { listPokemon, getCurrentHp, getMaxHp } = require('../../utils/pokemonStorage');
const { findOrCreateWhatsApp } = require('../../database/users');
const { createWildBattle, battleUrl } = require('../../utils/webBattle');

// ── Constants ─────────────────────────────────────────────────────────────────
const WB_COOLDOWN_MS = 15 * 60 * 1000;   // 15 minutes
const WEB_WB_COOLDOWN_MS = 60 * 60 * 1000; // 1 hour
const BATTLE_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes

// ── In-memory stores ──────────────────────────────────────────────────────────
// wbCooldowns: userId → timestamp of last .wb use
const wbCooldowns = new Map();
// wbBattles: groupJid → { battle, timer, originalMessage }
const wbBattles = new Map();

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatMs(ms) {
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

async function getUserGuild(user) {
  const ids = [
    user.moonId,
    user.userId,
    user.whatsappNumber?.split('@')[0],
    user.phoneNumber,
  ].filter(Boolean);
  return Guild.findOne({ members: { $in: ids } });
}

function toBattlePokemon(document, data) {
  const iv = document.iv || {};
  const ev = document.ev || {};
  const level = document.level || 1;
  const maxHp = calculateStat(data.stats.hp, iv.hp || 0, ev.hp || 0, level, true);
  return {
    ...document.toObject(),
    sprite: data.sprite,
    attack: calculateStat(data.stats.attack, iv.attack || 0, ev.attack || 0, level),
    defense: calculateStat(data.stats.defense, iv.defense || 0, ev.defense || 0, level),
    spAtk: calculateStat(data.stats.spAtk, iv.spAtk || 0, ev.spAtk || 0, level),
    spDef: calculateStat(data.stats.spDef, iv.spDef || 0, ev.spDef || 0, level),
    speed: calculateStat(data.stats.speed, iv.speed || 0, ev.speed || 0, level),
    maxHp,
    hp: Number.isFinite(Number(document.hp)) ? Math.min(maxHp, Math.max(0, Number(document.hp))) : maxHp,
    energy: 100,
    moves: normalizeMoveList(document.moves).length
      ? normalizeMoveList(document.moves)
      : (normalizeMoveList(data.moves).length ? normalizeMoveList(data.moves) : ['tackle']),
  };
}

async function renderWbBattle(sock, jid, message, battle, lastAction) {
  for (const pokemon of battle.activePokemon) {
    if (!pokemon?.sprite) { try { pokemon.sprite = (await fetchPokemonData(pokemon.name)).sprite; } catch {} }
  }
  battle.activePokemon[0].hp = battle.hp[0];
  battle.activePokemon[1].hp = battle.hp[1];
  const player = battle.activePokemon[0];
  const wild = battle.activePokemon[1];
  const details = [...(battle.lastTurn || [])].sort((a, b) => a.index - b.index);
  const lines = ['━━ ⚔️ *BATTLE LOG* ⚔️ ━━', '', ...details.flatMap((detail) => [`💨 ${detail.attacker} used ${readableMoveName(detail.move)}!`, detail.missed ? '> The move missed!' : `> It dealt ${Math.round(detail.damage || 0)} damage!`, ...(detail.effectiveness > 1 ? ["It's extremely effective!"] : detail.effectiveness > 0 && detail.effectiveness < 1 ? ["It's not very effective..."] : [])]), ...(details.length ? [] : [lastAction || 'A wild Pokémon appeared.']), '', '━━━━━━━━━━━━━━━━━━', '📊 *Current Status*', `💚 ${player.nickname || player.name}: ${Math.max(0, Math.round(battle.hp[0]))}/${Math.max(1, Math.round(player.maxHp || battle.hp[0]))} HP${player.status && player.status !== 'Healthy' ? ` [${String(player.status).toUpperCase()}]` : ''}`, `❤️ Wild ${wild.nickname || wild.name}: ${Math.max(0, Math.round(battle.hp[1]))}/${Math.max(1, Math.round(wild.maxHp || battle.hp[1]))} HP`, '', '🎯 *Your Turn!*', ...normalizeMoveList(player.moves).slice(0, 4).map((move, index) => `${index + 1}. ${readableMoveName(move)}`), '', '> 💡 _Options: .pb <1-4> | .pb pokeball <ball> | .pb switch <#> | .pb run_'].join('\n');
  if (process.env.FAST_BATTLE_MESSAGES === 'true') return sock.sendMessage(jid, { text: lines }, { quoted: message });
  const img = await generateBattleImage({ player, opponent: wild, weather: battle.weather, lastAction: lines });
  await sock.sendMessage(jid, { image: img, caption: lines }, { quoted: message });
}

function clearWbTimer(groupJid) {
  const entry = wbBattles.get(groupJid);
  if (entry?.timer) clearTimeout(entry.timer);
}

function setWbTimer(sock, jid, originalMsg, groupJid) {
  clearWbTimer(groupJid);
  const t = setTimeout(async () => {
    const entry = wbBattles.get(groupJid);
    if (!entry) return;
    entry.battle.status = 'finished';
    wbBattles.delete(groupJid);
    try {
      await sock.sendMessage(jid, {
        text: 'No move was made in the last 5 minutes. This battle has ended.',
      }, { quoted: originalMsg });
    } catch {}
  }, BATTLE_TIMEOUT_MS);
  const entry = wbBattles.get(groupJid);
  if (entry) entry.timer = t;
}

// ── Award guild XP on win ─────────────────────────────────────────────────────
async function awardGuildXp(guild) {
  guild.xp = (guild.xp || 0) + 1;
  await guild.save();

  // Award 2 XP to every guild member's User record
  const memberIds = guild.members || [];
  if (memberIds.length > 0) {
    await User.updateMany(
      {
        $or: [
          { moonId: { $in: memberIds } },
          { userId: { $in: memberIds } },
          { whatsappNumber: { $in: memberIds.map(id => `${id}@s.whatsapp.net`) } },
        ],
      },
      { $inc: { xp: 2 } }
    );
  }
}

// ── .wb command ───────────────────────────────────────────────────────────────
moon({
  name: 'wb',
  aliases: ['wildbattle'],
  category: 'Pokémon',
  description: 'Start a wild Pokémon battle (guild members only)',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      if (!jid.endsWith('@g.us')) return reply('❌ Wild battles can only be started in groups.');

      // ── Guild membership check ─────────────────────────────────────────
      const userDoc = await findOrCreateWhatsApp(sender, pushName);
      const user = userDoc.toObject();
      const guild = await getUserGuild(user);
      if (!guild) {
        return reply('❌ You must be a guild member to start wild battles.\n> Join a guild first with `.guild`.');
      }

      const isTrueOwner = user.isTrueOwner === true || user.role === 'True Owner';
      const wantsWeb = String(args[0] || '').toLowerCase() === 'web';
      const webLastUsed = wbCooldowns.get(`${sender}:web`) || 0;
      const elapsed = Date.now() - webLastUsed;
      if (wantsWeb) {
        if (!isTrueOwner && elapsed < WEB_WB_COOLDOWN_MS) return reply(`⏳ Your web battle is on cooldown for *${formatMs(WEB_WB_COOLDOWN_MS - elapsed)}*.`);
        const { pokemons } = await listPokemon(sender, 'party', 6);
        const active = pokemons.find(p => getCurrentHp(p) > 0 && p.status !== 'Fainted');
        if (!active) return reply('❌ You need a healthy Pokémon in your party to start a web battle.');
        const wildNames = ['pikachu', 'charmander', 'bulbasaur', 'squirtle', 'eevee', 'gengar', 'lucario', 'garchomp', 'snorlax'];
        const wildName = wildNames[Math.floor(Math.random() * wildNames.length)];
        const wildData = await fetchPokemonData(wildName);
        const wildPokemon = { pokemonId: `WILD-${Date.now()}`, name: wildData.name, level: Math.max(1, (active.level || 1) + Math.floor(Math.random() * 5) - 2), sprite: wildData.sprite, type1: wildData.type1, type2: wildData.type2 || null, hp: Math.max(30, Number(active.hp || 50)), attack: Math.max(10, Number(active.attack || 20) - 2), defense: Math.max(8, Number(active.defense || 15) - 2), moves: wildData.moves?.slice(0, 4) || ['tackle'] };
        const webBattle = await createWildBattle({ creatorId: user.moonId || sender.split('@')[0], groupJid: jid, guildId: guild._id, playerPokemon: active, wildPokemon });
        if (!isTrueOwner) wbCooldowns.set(`${sender}:web`, Date.now());
        return reply(`🌐 *WEB BATTLE READY*\n\nYour wild Pokémon battle is waiting in the Moonlight Arena.\n\n🔗 ${battleUrl('wild', webBattle.code)}\n\nYou can use the animated web arena to attack, switch Pokémon, and use Poké Balls.`);
      }

      // ── Cooldown check ─────────────────────────────────────────────────
      const botLastUsed = wbCooldowns.get(`${sender}:bot`) || 0;
      const botElapsed = Date.now() - botLastUsed;
      if (botElapsed < WB_COOLDOWN_MS) {
        return reply(`⏳ You can start another wild battle in *${formatMs(WB_COOLDOWN_MS - botElapsed)}*.`);
      }

      // ── Battle lock: one active wild battle per group ──────────────────
      if (wbBattles.has(jid)) {
        return reply(`Hold on @${sender.split('@')[0]}, there is already an active battle in this group.`, { mentions: [sender] });
      }

      // ── Check party ────────────────────────────────────────────────────
      const { pokemons } = await listPokemon(sender, 'party', 6);
      const active = pokemons.find(p => getCurrentHp(p) > 0 && p.status !== 'Fainted');
      if (!active) {
        return reply(
          '❌ You need a healthy Pokémon in your party to battle.\n' +
          '> Use `.party` to check your team or `.heal` to heal them.'
        );
      }

      // ── Spawn a wild Pokémon ───────────────────────────────────────────
      const wildNames = [
        'pikachu', 'charmander', 'bulbasaur', 'squirtle', 'eevee',
        'gengar', 'snorlax', 'mewtwo', 'lucario', 'garchomp',
        'dragonite', 'tyranitar', 'alakazam', 'machamp', 'golem',
      ];
      const wildName = wildNames[Math.floor(Math.random() * wildNames.length)];
      const wildLevel = Math.max(1, (active.level || 1) + Math.floor(Math.random() * 5) - 2);

      const [playerData, wildData] = await Promise.all([
        fetchPokemonData(active.name),
        fetchPokemonData(wildName),
      ]);

      const playerPokemon = toBattlePokemon(active, playerData);
      const wildIvs = generateIVs();
      const wildMaxHp = calculateStat(wildData.stats.hp, wildIvs.hp, 0, wildLevel, true);
      const wildPokemon = {
        pokemonId: `WILD-${Date.now()}`,
        name: wildData.name,
        nickname: null,
        level: wildLevel,
        sprite: wildData.sprite,
        type1: wildData.type1,
        type2: wildData.type2 || null,
        maxHp: wildMaxHp,
        hp: wildMaxHp,
        attack: calculateStat(wildData.stats.attack, wildIvs.attack, 0, wildLevel),
        defense: calculateStat(wildData.stats.defense, wildIvs.defense, 0, wildLevel),
        spAtk: calculateStat(wildData.stats.spAtk, wildIvs.spAtk, 0, wildLevel),
        spDef: calculateStat(wildData.stats.spDef, wildIvs.spDef, 0, wildLevel),
        speed: calculateStat(wildData.stats.speed, wildIvs.speed, 0, wildLevel),
        iv: wildIvs,
        energy: 100,
        moves: wildData.moves?.slice(0, 4) || ['tackle'],
        isWild: true,
      };

      // ── Create battle ──────────────────────────────────────────────────
      const battle = new Battle(sender, 'WILD');
      battle.type = 'wild';
      battle.activePokemon = [playerPokemon, wildPokemon];
      battle.hp = [playerPokemon.hp, wildPokemon.hp];
      battle.energy = [100, 100];
      battle.status = 'active';
      battle.turn = 1;
      battle.groupJid = jid;
      battle.guildId = guild._id;

      // Register battle
      battles.set(sender, battle);
      wbBattles.set(jid, { battle, timer: null, sender, originalMsg: m });
      wbCooldowns.set(`${sender}:bot`, Date.now());

      // Start timeout
      setWbTimer(sock, jid, m, jid);

      const caption =
        `□━━━[ ⚔️ WILD POKÉMON BATTLE ⚔️ ]━━━□\n` +
        `☆ ${String(wildData.name).toUpperCase()} appeared from the wild! ☆\n\n` +
        `◇ *YOUR POKÉMON*\n` +
        `▪︎ ${String(active.nickname || active.name).toLowerCase()} · Lv.${active.level}\n` +
        `▪︎ HP ${getCurrentHp(active)}/${getMaxHp(active)}\n\n` +
        `◇ *WILD OPPONENT*\n` +
        `▪︎ ${String(wildData.name).toLowerCase()} · Lv.${wildLevel}\n` +
        `▪︎ HP ${wildPokemon.hp}/${wildPokemon.maxHp}\n\n` +
        `□-■------[ *CHOOSE YOUR MOVE* ]------■-□\n` +
        `> Use .pb <move> to attack\n` +
        `> Use .pb switch <index> to change Pokémon\n` +
        `> Use .pb run to flee\n` +
        `□━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━□`;

      await renderWbBattle(sock, jid, m, battle, caption);

    } catch (err) {
      console.error('[WB ERROR]', err);
      return reply('❌ Failed to start wild battle. Please try again.');
    }
  },
});

// ── Handle wild battle win — called from Pokemon/battle.js after battle ends ──
async function handleWbWin(sock, jid, sender, battle) {
  try {
    const entry = wbBattles.get(jid);
    if (!entry) return;

    clearWbTimer(jid);
    wbBattles.delete(jid);

    // Award guild XP
    const guild = await Guild.findById(battle.guildId);
    if (guild) await awardGuildXp(guild);

    // Award Pokémon XP
    const playerPokemon = battle.activePokemon[0];
    if (playerPokemon?.pokemonId) {
      const xpGain = 20 + (battle.turn || 1) * 2;
      await Pokemon.updateOne(
        { pokemonId: playerPokemon.pokemonId },
        { $inc: { xp: xpGain } }
      );
    }

    await sock.sendMessage(jid, {
      text:
        `🏆 *WILD BATTLE WON!*\n\n` +
        `🏰 *${guild?.name || 'Your guild'}* received +1 XP!\n` +
        `👥 All guild members received +2 XP!\n` +
        `✨ Your Pokémon gained some experience!`,
    });
  } catch (err) {
    console.error('[WB WIN ERROR]', err);
  }
}

module.exports = { wbBattles, handleWbWin };
