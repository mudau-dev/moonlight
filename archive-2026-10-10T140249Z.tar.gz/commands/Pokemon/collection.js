const { listPokemon, getPokemonByIndex, getCurrentHp, getMaxHp, formatPokemonDetails, resolvePokemonOwner } = require('../../utils/pokemonStorage');
const { fetchPokemonData, fetchPokemonSpecies, rollGender } = require('../../utils/pokemonUtils');
const { generatePartyImage } = require('../../utils/partyGenerator');
const Pokemon = require('../../models/pokemon');

async function enrichDetailMetadata(pokemon) {
  if (pokemon.captureRate != null && pokemon.gender && pokemon.gender !== 'Unknown') return pokemon;

  try {
    const species = await fetchPokemonSpecies(pokemon.name);
    let changed = false;
    if (pokemon.captureRate == null && species.captureRate != null) {
      pokemon.captureRate = species.captureRate;
      changed = true;
    }
    if (!pokemon.gender || pokemon.gender === 'Unknown') {
      pokemon.gender = rollGender(species.genderRate);
      changed = true;
    }
    if (changed) await pokemon.save();
  } catch (error) {
    console.warn('[POKEMON METADATA]', error.message);
  }

  return pokemon;
}

function partyOverviewText(party, trainerName) {
  const lines = [`@${trainerName}'s active haven party`, '━━━━━━━━━━━━━━'];
  for (let index = 0; index < 6; index += 1) {
    const pokemon = party[index];
    if (!pokemon) { lines.push(`*${index + 1}.*`); continue; }
    const label = String(pokemon.nickname || pokemon.name).toLowerCase();
    const fainted = pokemon.status === 'Fainted' || getCurrentHp(pokemon) <= 0;
    lines.push(`*${index + 1}.* ${label}${fainted ? ' - ⚠️ fainted' : ''}`);
  }
  lines.push('━━━━━━━━━━━━━━', '> Use *.party <index>* to see that specific pokemon');
  return lines.join('\n');
}

function pcOverview(pokemons, trainerName, mode = 'default') {
  const title = `@${trainerName}'s currently pc`;
  const lines = [title, '━━━━━━━━━━━━'];
  if (!pokemons.length) lines.push('Your PC is empty.');
  else {
    const sorted = [...pokemons].sort((a, b) => {
      if (mode === 'level') return Number(b.level || 0) - Number(a.level || 0);
      if (mode === 'rank') return String(b.rarity || 'Common').localeCompare(String(a.rarity || 'Common')) || String(a.name).localeCompare(String(b.name));
      return new Date(a.caughtAt || 0) - new Date(b.caughtAt || 0);
    });
    sorted.forEach((pokemon, index) => {
      const name = String(pokemon.nickname || pokemon.name).toLowerCase();
      const suffix = mode === 'level' ? ` · Lv.${pokemon.level || 1}` : mode === 'rank' ? ` · ${pokemon.rarity || 'Common'}` : '';
      lines.push(`*${index + 1}.* ${name}${suffix}`);
    });
  }
  lines.push('━━━━━━━━━━━━', '> `.pc types/type` to see all pokes in order', '> `.pc lv` to see all pokes by level', '> `.pc rp` to see copy pokes by ranks');
  return lines.join('\n');
}

moon({
  name: 'party',
  category: 'Pokémon',
  description: 'View your active party or detailed stats for a party slot.',
  usage: '.party [index]',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    const selectedIndex = Number.parseInt(args[0], 10);

    if (args[0] && (!Number.isInteger(selectedIndex) || selectedIndex < 1)) {
      return reply('❌ Usage: `.party` or `.party <party_index>`');
    }

    // ── Featured Pokémon detail view ──────────────────────────────────────
    if (selectedIndex) {
      const entry = await getPokemonByIndex(sender, 'party', selectedIndex);
      if (!entry) return reply('❌ No Pokémon exists at that party index.');

      const pokemon = await enrichDetailMetadata(entry.pokemon);
      const caption = formatPokemonDetails(pokemon, {
        title: `PARTY SLOT ${selectedIndex}: ${String(pokemon.nickname || pokemon.name).toLowerCase()}`,
      });

      try {
        const { pokemons: fullParty } = await listPokemon(sender, 'party', 6);
        const image = await generatePartyImage({
          pokemons: fullParty,
          trainerName: pushName || 'Trainer',
          featuredIndex: selectedIndex,
        });
        return sock.sendMessage(jid, { image, caption }, { quoted: m });
      } catch (imageError) {
        console.warn('[PARTY FEATURED IMAGE]', imageError.message);
        return reply(caption);
      }
    }

    // ── Full party image view ─────────────────────────────────────────────
    const { pokemons } = await listPokemon(sender, 'party', 6);
    if (!pokemons.length) {
      return reply('❌ Your party is empty. Use `.t2party <pc_index>` to add a Pokémon from your PC.');
    }

    // Enrich metadata for all party members
    await Promise.all(pokemons.map((pokemon) => enrichDetailMetadata(pokemon)));

    // Try to generate the party image card
    try {
      const imageBuffer = await generatePartyImage({
        pokemons,
        trainerName: pushName || 'Trainer',
      });
      const caption = partyOverviewText(pokemons, pushName || 'Trainer');
      return sock.sendMessage(jid, { image: imageBuffer, caption }, { quoted: m });
    } catch (imgErr) {
      console.warn('[PARTY IMAGE]', imgErr.message);
      // Fallback to text if image generation fails
      return reply(partyOverviewText(pokemons, pushName || 'Trainer'));
    }
  },
});

moon({
  name: 'pc',
  category: 'Pokémon',
  description: 'View your PC or detailed stats for a stored Pokémon.',
  usage: '.pc [index]',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    const mode = String(args[0] || '').toLowerCase();
    if (['types', 'type', 'lv', 'level', 'rp'].includes(mode)) {
      const { pokemons } = await listPokemon(sender, 'pc');
      if (!pokemons.length) return reply('❌ Your PC is empty.');
      if (mode === 'types' || mode === 'type') {
        const grouped = new Map();
        for (const pokemon of pokemons) for (const type of [pokemon.type1, pokemon.type2].filter(Boolean)) { const key = String(type).replace(/^./, c => c.toUpperCase()); if (!grouped.has(key)) grouped.set(key, []); grouped.get(key).push(pokemon); }
        return reply([...grouped.entries()].sort().map(([type, items]) => [`⊱ *${type}*`, ...items.map(p => `- ${p.nickname || p.name}`)].join('\n')).join('\n\n'));
      }
      if (mode === 'rp') {
        const groups = new Map();
        for (const pokemon of pokemons) {
          const key = String(pokemon.name || '').trim().toLowerCase();
          if (!key) continue;
          if (!groups.has(key)) groups.set(key, []);
          groups.get(key).push(pokemon);
        }
        const duplicateGroups = [...groups.entries()].filter(([, items]) => items.length > 1);
        if (!duplicateGroups.length) return reply('✅ No duplicate Pokémon species were found in your PC.');
        const removals = [];
        const lines = [`@${pushName || 'Trainer'} — *DUPLICATE POKÉMON*`, '━━━━━━━━━━━━━━━━━━'];
        for (const [name, items] of duplicateGroups.sort((a, b) => a[0].localeCompare(b[0]))) {
          const ordered = [...items].sort((a, b) => Number(b.level || 1) - Number(a.level || 1) || new Date(a.caughtAt || 0) - new Date(b.caughtAt || 0));
          const keep = ordered[0];
          const lower = ordered.slice(1);
          lines.push(`*${name}* — keep Lv.${keep.level || 1}`);
          for (const pokemon of lower) {
            removals.push(pokemon);
            lines.push(`  • remove Lv.${pokemon.level || 1} · ${pokemon.pokemonId || 'no-id'}`);
          }
        }
        const action = String(args[1] || '').toLowerCase();
        if (action === 'all' || (['delete', 'del'].includes(action) && String(args[2] || '').toLowerCase() === 'all')) {
          const result = await Pokemon.deleteMany({ _id: { $in: removals.map((pokemon) => pokemon._id) }, location: 'pc' });
          return reply(`${lines.join('\\n')}\\n━━━━━━━━━━━━━━━━━━\\n✅ Deleted *${result.deletedCount || 0}* lower-level duplicate Pokémon.\\n> The highest-level copy of each species was kept.`);
        }
        return reply(`${lines.join('\\n')}\\n━━━━━━━━━━━━━━━━━━\\n> Use *.pc rp delete all* (or *.pc rp del all*) to remove all listed lower-level duplicates.`);
      }
      return reply(pcOverview(pokemons, pushName || 'Trainer', mode === 'lv' || mode === 'level' ? 'level' : 'default'));
    }
    const infoMode = mode === 'info';
    const selectedIndex = Number.parseInt(infoMode ? args[1] : args[0], 10);

    if ((args[0] && !Number.isInteger(selectedIndex)) || (Number.isInteger(selectedIndex) && selectedIndex < 1)) {
      return reply('❌ Usage: `.pc`, `.pc <pc_index>`, or `.pc info <pc_index>`');
    }

    if (infoMode && selectedIndex) {
      const entry = await getPokemonByIndex(sender, 'pc', selectedIndex);
      if (!entry) return reply('❌ No Pokémon exists at that PC index.');
      const pokemon = await enrichDetailMetadata(entry.pokemon);
      const moves = Array.isArray(pokemon.moves) ? pokemon.moves : [];
      return reply(`□------------------------------□\n*Name:* ${String(pokemon.nickname || pokemon.name).toLowerCase()}\n*Gender:* ${String(pokemon.gender || 'unknown').toLowerCase()}\n*Id:* ${pokemon.pokemonId}\n\n*□- pokemon description:- □*\n> ${String(pokemon.caughtLocation || 'pc storage').toLowerCase()}\n\n*□- pokemon moves: -□*\n*Current moves:* ${moves.length ? moves.map((move) => String(move).toLowerCase()).join(', ') : 'none'}\n*Can learn moves:* use \.plearn ${selectedIndex} p 1\n*Total moves:* ${moves.length}\n\n*Owners:* ${pokemon.userId}\n□------------------------------□`);
    }

    if (selectedIndex) {
      const entry = await getPokemonByIndex(sender, 'pc', selectedIndex);
      if (!entry) return reply('❌ No Pokémon exists at that PC index.');

      const pokemon = await enrichDetailMetadata(entry.pokemon);
      let sprite;
      try {
        sprite = (await fetchPokemonData(pokemon.name)).sprite;
      } catch (error) {
        console.warn('[PC DETAIL SPRITE]', error.message);
      }

      const caption = formatPokemonDetails(pokemon, {
        title: `PC SLOT ${selectedIndex}: ${String(pokemon.nickname || pokemon.name).toLowerCase()}`,
      });
      if (sprite) {
        return sock.sendMessage(jid, { image: { url: sprite }, caption }, { quoted: m });
      }
      return reply(caption);
    }

    const { pokemons } = await listPokemon(sender, 'pc');
    return reply(pcOverview(pokemons, pushName || 'Trainer'));
  },
});

moon({
  name: 'pokem',
  aliases: ['pkm', 'pokemóns', 'pokemons', 'pkinfo', 'pokeinfo'],
  category: 'Pokémon',
  description: 'Look up a Pokémon by name and see its full info with image.',
  usage: '.pokem <name>',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    // If no args, show trainer profile
    if (!args.length) {
      const { pokemons } = await listPokemon(sender);
      const party = pokemons.filter((pokemon) => pokemon.location === 'party').slice(0, 6);
      const shinies = pokemons.filter((pokemon) => pokemon.isShiny).length;
      const ownedNames = [...new Set(pokemons.map((p) => p.name))];
      return reply([
        `🌙 *${(pushName || 'Trainer').toUpperCase()} — POKÉMON TRAINER PROFILE*`,
        '━━━━━━━━━━━━━━━━━━━━',
        `*Total Pokémon:* ${pokemons.length}`,
        `*Active Party:* ${party.length}/6`,
        `*Shiny Pokémon:* ${shinies}`,
        '',
        '> Use `.party` to view your active team and `.pc` to view stored Pokémon.',
        '> Use `.pokem <name>` to look up any Pokémon.',
      ].join('\n'));
    }

    // Look up a specific Pokémon by name
    const pokemonName = args.join(' ');
    try {
      const data = await fetchPokemonData(pokemonName);

      // Count how many the user owns
      const { pokemons } = await listPokemon(sender);
      const owned = pokemons.filter((p) => p.name.toLowerCase() === data.name.toLowerCase());
      const partySlots = owned.filter((p) => p.location === 'party').map((p) => p.partyPosition).filter(Boolean);
      const pcSlots = owned.filter((p) => p.location === 'pc').length;

      const types = [data.type1, data.type2].filter(Boolean)
        .map((t) => t.charAt(0).toUpperCase() + t.slice(1))
        .join(', ');

      // Fetch abilities from API
      let abilities = 'Unknown';
      try {
        const { data: rawData } = await require('axios').get(
          `https://pokeapi.co/api/v2/pokemon/${data.name}`, { timeout: 8000 }
        );
        abilities = rawData.abilities
          .map((a) => a.ability.name.replace(/-/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase()))
          .join(', ');
      } catch { /* ignore */ }

      const caption = [
        `*Name:* ${data.name.charAt(0).toUpperCase() + data.name.slice(1)}`,
        `*Pokédex ID:* ${data.pokedexNumber}`,
        `*Types:* ${types}`,
        `*Abilities:* ${abilities}`,
        '',
        `*Owned:* ${owned.length}`,
        `*Party slots:* ${partySlots.length ? partySlots.join(', ') : 'None'}`,
        `*PC slots:* ${pcSlots || 'None'}`,
      ].join('\n');

      if (data.sprite) {
        return sock.sendMessage(jid, { image: { url: data.sprite }, caption }, { quoted: m });
      }
      return reply(caption);
    } catch (err) {
      console.error('[POKEMON CMD]', err.message);
      return reply(`❌ Could not find Pokémon *${pokemonName}*. Check the spelling and try again.`);
    }
  },
});

moon({
  name: 'poke',
  category: 'Pokémon',
  description: 'View a Pokémon you own by its unique ID.',
  usage: '.poke <pokemon_id>',
  async execute(sock, jid, sender, args, m, { reply }) {
    const query = String(args.join(' ') || '').trim();
    if (!query) return reply('❌ Usage: `.poke <pokemon_id | name | party index>`');

    const owner = await resolvePokemonOwner(sender);
    if (!owner?.identifiers?.length) return reply('❌ Your Pokémon account could not be resolved. Send `.start` first.');
    const ownedFilter = { userId: { $in: owner.identifiers } };
    const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const exact = new RegExp(`^${escaped}$`, 'i');
    let pokemon = await Pokemon.findOne({ ...ownedFilter, pokemonId: exact });
    if (!pokemon) pokemon = await Pokemon.findOne({ ...ownedFilter, $or: [{ name: exact }, { nickname: exact }] }).sort({ location: 1, partyPosition: 1, caughtAt: 1 });
    if (!pokemon && /^\d+$/.test(query)) {
      const index = Number(query);
      const { pokemons } = await listPokemon(sender, 'party');
      pokemon = pokemons[index - 1] || null;
    }
    if (!pokemon) return reply('❌ Pokémon not found in your collection.');

    await enrichDetailMetadata(pokemon);
    let sprite;
    try {
      sprite = (await fetchPokemonData(pokemon.name)).sprite;
    } catch (error) {
      console.warn('[POKE DETAIL SPRITE]', error.message);
    }

    const caption = formatPokemonDetails(pokemon);
    if (sprite) return sock.sendMessage(jid, { image: { url: sprite }, caption }, { quoted: m });
    return reply(caption);
  },
});
