const config = require('../../config');
const Group = require('../../models/athers/Group');
const Guild = require('../../models/athers/Guild');
const Pokemon = require('../../models/pokemon');
const { getProgress, levelData, partyFor, battleFor, groupAllowed } = require('../../utils/gym');
const { isGuildMember, identityKeys } = require('../../utils/guildAccess');
const { renderGymBattle } = require('../../utils/gymBattleRender');
const { getPending, clearPending, setPending } = require('../../utils/gymPending');
const { POKE_BALLS, inventoryId } = require('../../utils/pokeBalls');

const RANKS = [
  { name: 'S-RANK TRAILS', icon: '🔥', level: 90, places: ['Mt. Silver', 'Sky Pillar', 'Whirl Islands'], codes: ['EAI0', '1XLQ', 'H64M'] },
  { name: 'A-RANK TRAILS', icon: '⚡', level: 60, places: ['Shoal Cave', 'Seafoam Islands', 'Safari Zone', 'Giant Chasm'], codes: ['LC8Y', 'QBTT', 'KQEK', 'FM1X'] },
  { name: 'B-RANK TRAILS', icon: '🌊', level: 40, places: ["Diglett's Cave", 'Pokémon Tower', 'Pokémon Tower', "Diglett's Cave"], codes: ['TJTF', 'N286', 'OO02', '69DA'] },
  { name: 'C-RANK TRAILS', icon: '🌲', level: 20, places: ['Viridian Forest'], codes: ['C-RANK'] },
];
const BOARD_SIZE = RANKS.reduce((sum, rank) => sum + rank.places.length, 0);
function gymLevel(gym, base) { return Math.min(100, base + (Math.max(1, gym) - 1) * 2); }
function challengeFor(gym, slot) {
  let offset = 0;
  for (const rank of RANKS) {
    for (let i = 0; i < rank.places.length; i += 1) {
      offset += 1;
      if (offset === slot) return { slot, code: rank.codes[i] || `G${gym}-${String(offset).padStart(2, '0')}`, rank: rank.name, icon: rank.icon, place: rank.places[i], level: gymLevel(gym, rank.level), stageIndex: (gym - 1) * BOARD_SIZE + slot };
    }
  }
  return null;
}
function challengeByCode(gym, code) {
  const wanted = String(code || '').toUpperCase();
  for (let slot = 1; slot <= BOARD_SIZE; slot += 1) { const challenge = challengeFor(gym, slot); if (challenge?.code === wanted) return challenge; }
  return null;
}
function currentGym(progress) { return Math.max(1, Math.min(16, Math.ceil(Number(progress.current || 1) / BOARD_SIZE))); }
function weekLabel() { const now = new Date(); const first = new Date(Date.UTC(now.getUTCFullYear(), 0, 1)); const week = Math.ceil((((now - first) / 86400000) + first.getUTCDay() + 1) / 7); return `${now.getUTCFullYear()}-W${String(week).padStart(2, '0')}`; }
function boardText(progress, gym) {
  const current = Number(progress.current || 1);
  const start = (gym - 1) * BOARD_SIZE + 1;
  const lines = [`📜 *MOONLIGHT TRAIL BOARD GYM - ${gym}*`, weekLabel(), '', '⏳ Resets Monday 12:00 AM', '', '🔓 Available · ✅ Completed · 🔒 Locked', ''];
  let slot = 0;
  for (const rank of RANKS) {
    lines.push(`${rank.icon} *${rank.name} · Lv. ${gymLevel(gym, rank.level)}*`);
    for (let i = 0; i < rank.places.length; i += 1) {
      slot += 1;
      const challenge = challengeFor(gym, slot);
      const done = challenge.stageIndex < current;
      const available = challenge.stageIndex === current && gym === currentGym(progress);
      const status = done ? '✅' : available ? '🔓' : '🔒';
      const label = done ? `~*[${challenge.code}] ${challenge.place}*~` : `[${challenge.code}] ${challenge.place}`;
      lines.push(`> ${status} ${label}`);
    }
    if (rank === RANKS[RANKS.length - 1]) lines.push('> Infinite');
    lines.push('');
  }
  lines.push(`☆ Current Gym: *${currentGym(progress)}*`, `》 Use *.gym <code>* to enter the available challenge.`);
  return lines.join('\n');
}
function groupError() { return `${config.POKEMON_LINK || ''}\n> This cmd can only be used in the Pokémon Gym group.`; }
function confirmationError() { return '❌ No Gym round is waiting for confirmation. Use `.gym <code>` first, then `.gym yes`.'; }

moon({
  name: 'gym', aliases: ['pokegym'], category: 'pokemon', description: 'View the level-based Gym board or enter a coded challenge.', usage: '.gym | .gym <gym number> | .gym <code>',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!groupAllowed(jid) || !jid.endsWith('@g.us')) return reply(groupError());
    const group = await Group.findOne({ groupId: jid }).lean();
    if (group?.pokemonSpawnEnabled !== true) return reply(groupError());
    const { user, progress } = await getProgress(sender);
    if (!user) return reply('❌ Create your Pokémon profile first with `.start`.');
    const raw = String(args[0] || '').trim();
    const lower = raw.toLowerCase();
    if (!raw) return reply(boardText(progress, currentGym(progress)));
    if (lower === 'page' || lower === 'pages') return reply('❌ `.gym page <index>` has been removed. Gym boards now move automatically when you complete the current board. Use `.gym` to view your current Gym.');
    if (lower === 'claim') {
      const claimIndex = Number(args[1]);
      const guild = await Guild.findOne({ $or: identityKeys(sender).flatMap((key) => [{ ownerId: key }, { guards: key }]) });
      if (!guild) return reply('❌ Only a guild owner or guard can claim Gym rewards.');
      const completed = Array.isArray(guild.trailProgress?.completed) ? guild.trailProgress.completed : [];
      if (!Number.isInteger(claimIndex) || !completed.includes(claimIndex)) return reply('❌ That Gym stage is not cleared in the shared guild record.');
      if (!Array.isArray(user.inventory)) user.inventory = [];
      for (let i = 0; i < 5; i += 1) { const ball = POKE_BALLS[Math.floor(Math.random() * POKE_BALLS.length)]; if (ball) user.inventory.push({ id: inventoryId(ball), name: ball.name, quantity: 1, boughtAt: new Date() }); }
      const party = await Pokemon.find({ userId: { $in: identityKeys(sender) }, location: 'party' }).limit(6); const xp = Math.max(10, claimIndex * 10);
      for (const pokemon of party) { pokemon.xp = Number(pokemon.xp || 0) + xp; pokemon.level = Number(pokemon.level || 1) + 1; await pokemon.save(); }
      user.xp = Number(user.xp || 0) + xp; user.markModified('inventory'); await user.save();
      return reply(`🎁 *GYM CLAIM COMPLETE*\n\n✅ Stage *${claimIndex}* claimed by an authorized guild leader.\n🎒 5 random Poké Balls added\n☆ +${xp} XP and +1 level applied to your party.`);
    }
    const numericGym = /^\d+$/.test(raw) ? Number(raw) : 0;
    if (numericGym >= 1 && numericGym <= 16) return reply(boardText(progress, numericGym));
    if (!(await isGuildMember(sender))) return reply('❌ You must belong to a Moonlight Haven guild before using the Gym.');
    if (['switch', 'run'].includes(lower)) return reply(`🔁 Use *.gb ${lower === 'switch' ? 'switch <party slot>' : 'run'}* during a Gym battle.`);
    if (lower === 'no') { clearPending(sender); user.gymPendingStage = null; user.gymPendingAt = null; user.gymPending = null; await user.save(); return reply('✅ Gym entry cancelled.'); }
    const gym = currentGym(progress); const requested = lower === 'yes' ? '' : raw.toUpperCase(); const pendingMemory = getPending(sender); const pendingStage = Number(user.gymPendingStage || user.gymPending || pendingMemory?.stage || 0);
    const challenge = lower === 'yes' ? challengeFor(gym, pendingStage - ((gym - 1) * BOARD_SIZE)) : challengeByCode(gym, requested);
    if (lower === 'yes' && (!pendingStage || !challenge)) return reply(confirmationError());
    if (!challenge) return reply(`❌ That code is not on Gym *${gym}*. Use *.gym* to view the current level-based board.`);
    if (challenge.stageIndex !== Number(progress.current || 1)) return reply(`🔒 Your next available challenge is *${challengeFor(gym, Number(progress.current || 1) - (gym - 1) * BOARD_SIZE)?.code || 'the current board'}*. It unlocks only after the previous challenge is cleared.`);
    const stage = levelData(challenge.stageIndex); stage.name = challenge.place; stage.opponentLevel = challenge.level; stage.requiredLevel = Math.max(1, challenge.level - 20); stage.points = challenge.level * 10;
    if (lower !== 'yes') { setPending(sender, challenge.stageIndex); user.gymPendingStage = challenge.stageIndex; user.gymPendingAt = new Date(); user.gymPending = challenge.stageIndex; await user.save(); return reply(`🏟️ *${challenge.rank}* · ${challenge.place}\n\n👑 Master: *${stage.master}*\n⚔️ Opponent level: *${challenge.level}*\n\nReply *.gym yes* to enter or *.gym no* to cancel.`); }
    clearPending(sender); user.gymPendingStage = null; user.gymPendingAt = null; user.gymPending = null;
    if (user.gymBattle?.stage?.index) return reply(`⚔️ You already have a Gym battle for stage ${user.gymBattle.stage.index}. Use *.gb <move>* or *.gb run*.`);
    const party = await partyFor(sender); const usable = party.find((pokemon) => Number.parseInt(String(pokemon.level ?? 1), 10) >= Number(stage.requiredLevel || 1));
    if (!usable) return reply(`❌ You need a party Pokémon at level *${stage.requiredLevel}* or higher.`);
    const battle = battleFor(user, stage); battle.playerPokemonId = String(usable._id); battle.playerHp = Number(usable.hp || 100); battle.playerMaxHp = Math.max(1, Number(usable.maxHp || usable.hp || 100)); user.gymBattle = battle; await user.save();
    const caption = `🏟️ *GYM ${gym} · ${challenge.code}*\n\n📍 ${challenge.place}\n⚔️ ${usable.name} versus ${battle.opponent.name} · Lv.${battle.opponent.level}\n\nUse *.gb 1–4* for a move, *.gb switch <slot>* to switch, or *.gb run* to leave.`;
    try { return await renderGymBattle(sock, jid, m, battle, usable, caption); } catch { return reply(caption); }
  },
});
