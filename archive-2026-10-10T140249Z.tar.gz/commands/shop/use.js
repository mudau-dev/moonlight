/**
 * commands/shop/use.js
 *
 * .use <item name> — Consume an item from the user's inventory/bag.
 * Card packs are opened here: the pack is removed and random cards are awarded.
 *
 * NOTE: The old battle-action ".use <skill>" has been moved to .us / .a / .atc
 *       (see commands/legacy/battle.js).
 */

const User = require('../../models/User');
const { findOrCreateWhatsApp } = require('../../database/users');
const { fetchRandomCard, getTierLabel } = require('../../utils/cardGenerator');

// ── Pack definitions ─────────────────────────────────────────────────────────
// Maps inventory item id → { tier, count }
const PACK_CONFIG = {
  'card:pack-tier1':    { tier: '1', count: 5 },
  'card:pack-tier2':    { tier: '2', count: 5 },
  'card:pack-tier3':    { tier: '3', count: 5 },
  'card:pack-tier4':    { tier: '4', count: 5 },
  'card:pack-tier5':    { tier: '5', count: 5 },
  'card:pack-mythic':   { tier: 'S', count: 5 },
  'card:pack-common':   { tier: '1', count: 10 },
  'card:pack-premium':  { tier: '4', count: 10 },
  'card:pack-ultimate': { tier: '5', count: 10 },
  // Legacy pack IDs kept for backward compatibility
  'card:pack-basic':     { tier: '1', count: 5 },
  'card:pack-legendary': { tier: '5', count: 5 },
};

// ── Helper: find inventory item by partial name or exact id ──────────────────
function findInventoryItem(inventory, query) {
  const q = query.toLowerCase();
  return inventory.find(
    (item) =>
      (item.id && item.id.toLowerCase().includes(q)) ||
      (item.name && item.name.toLowerCase().includes(q))
  );
}

// ── Helper: remove one instance of an item from inventory array ──────────────
function removeOneItem(inventory, id, name) {
  const idx = inventory.findIndex(
    (item) => item.id === id || item.name === name
  );
  if (idx !== -1) inventory.splice(idx, 1);
}

moon({
  name: 'use',
  aliases: [],
  category: 'shop',
  description: 'Use or open an item from your inventory',
  usage: '.use <item name>',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const query = args.join(' ').trim();
      if (!query) {
        return reply(
          '❌ Usage: `.use <item name>`\n\n' +
          'Example: `.use Tier 1 Card Pack`\n' +
          'Use `.inv` to see your inventory.'
        );
      }

      const user = await findOrCreateWhatsApp(sender, pushName);
      if (!user) return reply('❌ Could not find your account. Use `.reg` first.');

      const inventory = user.inventory || [];
      if (!inventory.length) return reply('🎒 Your inventory is empty.');

      // Find the item in inventory
      const item = findInventoryItem(inventory, query);
      if (!item) {
        return reply(
          `❌ You do not have *${query}* in your inventory.\n` +
          'Use `.inv` to see what you have.'
        );
      }

      // ── Card Pack ──────────────────────────────────────────────────────────
      const packCfg = PACK_CONFIG[item.id];
      if (packCfg) {
        // Remove the pack from inventory first
        removeOneItem(user.inventory, item.id, item.name);
        await User.updateOne(
          { _id: user._id },
          { $set: { inventory: user.inventory } }
        );

        await reply(
          `🎴 *Opening ${item.name}…*\n\n` +
          `You are about to receive *${packCfg.count} cards*!\n` +
          `Generating your cards now…`
        );

        // Generate cards
        const obtained = [];
        const errors = [];
        for (let i = 0; i < packCfg.count; i++) {
          try {
            const card = await fetchRandomCard(packCfg.tier);
            if (card) {
              // Award card to user
              const cardEntry = {
                instanceId: `pack-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 7)}`,
                cardId: card.cardId,
                name: card.name,
                description: card.description || '',
                tier: card.tier,
                price: card.price || 0,
                series: card.series || '',
                creator: card.creator || '',
                media: card.media || null,
                mediaType: card.mediaType || 'image',
                mediaMime: card.mediaMime || '',
                obtainedAt: new Date(),
                level: 1,
                xp: 0,
                locked: false,
                inAuction: false,
              };
              await User.updateOne(
                { _id: user._id },
                { $push: { cards: cardEntry } }
              );
              obtained.push(`  ${i + 1}. *${card.name}* (${getTierLabel(card.tier)})`);
            }
          } catch (cardErr) {
            console.error('[USE PACK CARD ERROR]', cardErr.message);
            errors.push(i + 1);
          }
        }

        const lines = [
          `🎉 *${item.name} Opened!*`,
          '',
          `*Cards received (${obtained.length}/${packCfg.count}):*`,
          ...obtained,
        ];
        if (errors.length) {
          lines.push('', `⚠️ ${errors.length} card(s) could not be generated (API error).`);
        }
        lines.push('', '> Use `.cards` to view your collection.');

        return reply(lines.join('\n'));
      }

      // ── Mana consumables ───────────────────────────────────────────────────
      // Shop mana items use stable IDs such as `item:manas-100`. Older items
      // with a mana name are also supported without altering card-pack logic.
      const itemId = String(item.id || '').toLowerCase();
      const itemName = String(item.name || '').toLowerCase();
      if (itemId.includes('mana') || itemName.includes('mana')) {
        const amountMatch = `${itemId} ${itemName}`.match(/(\d{1,9})/);
        const manaAmount = Math.max(1, Number(amountMatch?.[1] || 100));
        removeOneItem(user.inventory, item.id, item.name);
        user.manas = Math.max(0, Number(user.manas) || 0) + manaAmount;
        await user.save();
        return reply(`🌙 Used *${item.name}*.\n\n+${manaAmount.toLocaleString()} Manas\n💎 New mana balance: ${(user.manas || 0).toLocaleString()}`);
      }

      // ── Other consumable items ─────────────────────────────────────────────
      return reply(
        `📦 *${item.name}*\n\n` +
        `This item cannot be used directly from the bot.\n` +
        `Some items (like Poké Balls) are used automatically during battles or catching.\n` +
        `Visit the website to manage your inventory.`
      );
    } catch (err) {
      console.error('[USE CMD ERROR]', err);
      return reply('❌ Failed to use item. Please try again.');
    }
  },
});
