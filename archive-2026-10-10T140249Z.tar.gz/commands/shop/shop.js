const config = require('../../config');
const NEW_RECIPES = [
  { name: 'Aurora Ball', description: 'A cool-toned fusion ball with a shimmering northern-light finish.', ingredients: ['Great Ball', 'Ultra Ball'], multiplier: 1.8 },
  { name: 'Eclipse Ball', description: 'A shadow-and-light fusion ball for dramatic encounters.', ingredients: ['Ultra Ball', 'Master Ball'], multiplier: 2 },
  { name: 'Nova Ball', description: 'A bright stellar ball that bursts with capture energy.', ingredients: ['Premier Ball', 'Safari Ball'], multiplier: 2.2 },
  { name: 'Prism Ball', description: 'A refracting ball that blends several capture effects.', ingredients: ['Net Ball', 'Dive Ball'], multiplier: 2.4 },
  { name: 'Celestial Ball', description: 'A rare sky-forged ball with a premium capture field.', ingredients: ['Dusk Ball', 'Timer Ball'], multiplier: 2.8 },
];
moon({ name: 'shop', aliases: ['cmarket'], category: 'shop', description: 'Open the Moonlight Haven shop.', usage: '.shop | .shop new <index>', async execute(sock, jid, sender, args, m, { reply }) {
  const input = Array.isArray(args) ? args.join(' ').trim() : String(args || '').trim(); const match = input.match(/^new(?:\s+(\d+))?$/i);
  if (match) { if (!match[1]) return reply(['🧪 *NEW POKÉ BALL FORGE*','━━━━━━━━━━━━━━━━━━',...NEW_RECIPES.map((recipe, index) => `${index + 1}. ✦ *${recipe.name}* — ${recipe.ingredients.join(' + ')}`),'','Use `.shop new <index>` for recipe information.','Use `.ball new make <index>` to craft one.'].join('\n')); const recipe = NEW_RECIPES[Number(match[1]) - 1]; if (!recipe) return reply(`❌ Recipe not found. Choose 1-${NEW_RECIPES.length}.`); return reply(`🧪 *${recipe.name}*\n━━━━━━━━━━━━━━━━━━\n${recipe.description}\n\n🎲 Catch multiplier: *${recipe.multiplier}×*\n🎒 Required balls: ${recipe.ingredients.join(' + ')}\n\nTo create it, use .ball new make ${match[1]}. You must own every required ball in your bag.`); }
  return reply(`🛒 *MOONLIGHT HAVEN MALL*\n\n${config.WEB}/shop\n> Here is our Haven Mall for all things.`);
}});
moon({ name: 'cshop', aliases: ['card-shop'], category: 'shop', description: 'Open the card market.', usage: '.cshop', async execute(sock, jid, sender, args, m, { reply }) { return reply('🎴 *MOONLIGHT HAVEN CARD MARKET*\n\nUse the card market command to browse listed cards.'); } });
