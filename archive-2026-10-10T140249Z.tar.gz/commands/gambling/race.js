const {
  getUser,
  parseBet,
  validateBet,
  money,
  win,
  lose,
  pick,
} = require('./_shared');

const RACE_COOLDOWN_MS = 20 * 60 * 60 * 1000;
const MIN_BET = 10_000;
const MAX_BET = 700_000;
const LANES = ['🐎', '🐺', '🐉', '🦊'];

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function frame(positions, label) {
  const track = (position, racer) => `${'·'.repeat(position)}${racer}${'·'.repeat(Math.max(0, 16 - position))}🏁`;
  return [
    `🏁 *MOONLIGHT HAVEN RACE* — ${label}`,
    '',
    `1 ${track(positions[0], LANES[0])}`,
    `2 ${track(positions[1], LANES[1])}`,
    `3 ${track(positions[2], LANES[2])}`,
    `4 ${track(positions[3], LANES[3])}`,
  ].join('\n');
}

moon({
  name: 'race',
  category: 'gambling',
  description: 'Bet 10K–700K on a moving Moonlight race.',
  usage: '.race <10k-700k>',
  async execute(sock, jid, sender, args, m, { reply }) {
    const user = await getUser(sender, m);
    const bet = parseBet(args, user);
    const invalid = validateBet(bet, user);
    if (invalid) return reply(invalid);
    if (bet < MIN_BET || bet > MAX_BET) {
      return reply(`❌ Race bets must be between *$${money(MIN_BET)}* and *$${money(MAX_BET)}*.`);
    }

    const status = await sock.sendMessage(jid, {
      text: frame([0, 0, 0, 0], `Bet: $${money(bet)}\nThe gates are opening...`),
    }, { quoted: m });

    const positions = [0, 0, 0, 0];
    for (let step = 1; step <= 5; step += 1) {
      for (let i = 0; i < positions.length; i += 1) {
        positions[i] += Math.floor(Math.random() * 4) + 1;
      }
      await sleep(850);
      await sock.sendMessage(jid, {
        text: frame(positions, `Lap ${step}/5\nBet: $${money(bet)}`),
        edit: status.key,
      });
    }

    const winnerIndex = positions.indexOf(Math.max(...positions));
    const winner = LANES[winnerIndex];
    const playerWon = Math.random() < 0.5;
    if (playerWon) {
      const profit = await win(user, bet, 1.5, 'race');
      return sock.sendMessage(jid, {
        text: `${frame(positions, `Winner: ${winner}`)}\n\n🏆 You backed the winning lane!\n💰 Profit: +$${money(profit)}\n👛 Wallet: $${money(user.balance)}`,
        edit: status.key,
      });
    }

    await lose(user, bet, 'race');
    return sock.sendMessage(jid, {
      text: `${frame(positions, `Winner: ${winner}`)}\n\n💥 The race slipped away.\n💸 Lost: -$${money(bet)}\n👛 Wallet: $${money(user.balance)}`,
      edit: status.key,
    });
  },
});

module.exports = { RACE_COOLDOWN_MS };
