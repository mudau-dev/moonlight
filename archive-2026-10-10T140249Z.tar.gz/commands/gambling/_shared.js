const { findOrCreateWhatsApp } = require('../../database/users');
const EventProgress = require('../../models/EventProgress');
const Cooldown = require('../../models/athers/Cooldowns');

// ─── ECONOMY CAPS ────────────────────────────────────────────────────────────
// Winning odds are determined by the bet table. A visible win must always pay
// its stated result; the explicit per-session cap prevents one game from
// destabilizing the economy without silently zeroing high-wealth players.
// Per-session win cap: max profit per single gambling session
const MAX_SESSION_WIN = 50_000_000; // 50M per win

function money(n) {
  return Math.floor(Number(n) || 0).toLocaleString();
}

function cleanAmount(raw) {
  if (typeof raw !== 'string') return NaN;
  const normalized = raw.replace(/,/g, '').trim().toLowerCase();
  if (!normalized) return NaN;
  const suffixes = { k: 1e3, m: 1e6, b: 1e9, t: 1e12 };
  const match = normalized.match(/^(\d+(?:\.\d+)?)([kmbt])?$/);
  if (!match) return NaN;
  return Math.floor(Number(match[1]) * (suffixes[match[2]] || 1));
}

function parseBet(args, user, index = 0) {
  const raw = String(args[index] || '').toLowerCase();
  if (raw === 'all' || raw === 'max') return Math.floor(Number(user.balance) || 0);
  if (raw === 'half') return Math.floor((Number(user.balance) || 0) / 2);
  return cleanAmount(raw);
}

function validateBet(bet, user) {
  if (!Number.isFinite(bet) || bet <= 0) return '❌ Enter a valid bet amount.';
  if ((Number(user.balance) || 0) < bet) return '❌ You do not have enough coins in your wallet.';
  return null;
}

/* =========================
   WIN CHANCE TABLE
   Chance never increases as bet increases.
========================= */
function getWinChance(bet) {
  if (bet <= 50000)   return 1.00;  // $1 – $50K      → 100%
  if (bet <= 80000)   return 0.95;  // $60K – $80K    → 95%
  if (bet <= 150000)  return 0.90;  // $90K – $150K   → 90%
  if (bet <= 260000)  return 0.80;  // $160K – $260K  → 80%
  if (bet <= 370000)  return 0.70;  // $270K – $370K  → 70%
  if (bet <= 700000)  return 0.50;  // $380K – $700K  → 50%
  if (bet <= 1000000) return 0.25;  // $750K – $1M    → 25%
  if (bet <= 15000000) return 0.05; // $2M – $15M     → 5%
  return 0.02;                      // $16M+           → 2%
}

function roll(chance) {
  return Math.random() < chance;
}

/* =========================
   MULTIPLIER COOLDOWNS
   5x  → 2 min
   10x → 5 min
   15x → 10 min
   Any net gain > 3M is also blocked.
========================= */
const MULTIPLIER_COOLDOWNS = [
  { threshold: 15, ms: 10 * 60 * 1000 }, // 15x → 10 minutes
  { threshold: 10, ms:  5 * 60 * 1000 }, // 10x → 5 minutes
  { threshold:  5, ms:  2 * 60 * 1000 }, // 5x  → 2 minutes
];

function getMultiplierCooldown(multiplier) {
  for (const rule of MULTIPLIER_COOLDOWNS) {
    if (multiplier >= rule.threshold) return rule.ms;
  }
  return 0;
}

function formatCooldownTime(ms) {
  if (!ms || ms <= 0) return '0s';
  const totalSec = Math.ceil(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const parts = [];
  if (h > 0) parts.push(`${h}h`);
  if (m > 0) parts.push(`${m}m`);
  if (s > 0 || parts.length === 0) parts.push(`${s}s`);
  return parts.join(' ');
}

/**
 * Check if a multiplier cooldown is active for a user+command.
 * Returns the cooldown message string if blocked, or null if allowed.
 */
async function checkMultiplierCooldown(sender, cmdName) {
  const now = Date.now();
  let cd = await Cooldown.findOne({ userId: sender });
  if (!cd) return null;
  const c = cd.safeGet(cmdName);
  if (!c || !c.cooldownUntil || c.cooldownUntil <= now) return null;
  const left = c.cooldownUntil - now;
  return `> 🕑 you have used *${cmdName}* and reached your max. wait *${formatCooldownTime(left)}* in order to use the command again`;
}

/**
 * Apply a multiplier cooldown after a win, if applicable.
 */
async function applyMultiplierCooldown(sender, cmdName, multiplier) {
  const cdMs = getMultiplierCooldown(multiplier);
  if (!cdMs) return;
  const now = Date.now();
  let cd = await Cooldown.findOne({ userId: sender });
  if (!cd) cd = new Cooldown({ userId: sender, commands: new Map() });
  cd.setCommand(cmdName, { count: 0, cooldownUntil: now + cdMs });
  await cd.save();
}

/* =========================
   CASINO DAILY COMMAND LIMIT

   Every command in the gambling category has its own quota:
   - 15 command uses
   - When the 15th use is consumed, that command is unavailable for 5 hours
   - After 5 hours, that command starts again at 0/15
========================= */
const CASINO_USE_LIMIT = 15;
const CASINO_RESET_MS = 5 * 60 * 60 * 1000;
const CASINO_KEY_PREFIX = 'casino:';
const RACE_USE_LIMIT = 5;
const RACE_RESET_MS = 20 * 60 * 60 * 1000;

function casinoCooldownKey(cmdName = 'casino') {
  return `${CASINO_KEY_PREFIX}${String(cmdName).toLowerCase()}`;
}

async function consumeRaceUse(sender) {
  const now = Date.now();
  const key = 'casino:race:20h';
  let cooldown = await Cooldown.findOne({ userId: sender });
  if (!cooldown) cooldown = new Cooldown({ userId: sender, commands: new Map() });
  let entry = cooldown.safeGet(key);
  if (entry.cooldownUntil && entry.cooldownUntil <= now) entry = { count: 0, cooldownUntil: 0 };
  if (entry.cooldownUntil && entry.cooldownUntil > now) {
    return { allowed: false, used: RACE_USE_LIMIT, remaining: 0, resetIn: entry.cooldownUntil - now };
  }
  if ((entry.count || 0) >= RACE_USE_LIMIT) {
    const resetAt = now + RACE_RESET_MS;
    cooldown.setCommand(key, { count: RACE_USE_LIMIT, cooldownUntil: resetAt });
    await cooldown.save();
    return { allowed: false, used: RACE_USE_LIMIT, remaining: 0, resetIn: RACE_RESET_MS };
  }
  const used = (entry.count || 0) + 1;
  const resetAt = used >= RACE_USE_LIMIT ? now + RACE_RESET_MS : 0;
  cooldown.setCommand(key, { count: used, cooldownUntil: resetAt });
  await cooldown.save();
  return { allowed: true, used, remaining: RACE_USE_LIMIT - used, resetIn: resetAt ? RACE_RESET_MS : 0 };
}

function raceLimitMessage(status) {
  return `> 🏁 *race* has reached its limit.\n> Uses: *${RACE_USE_LIMIT}/${RACE_USE_LIMIT}*\n> Reset: *${formatCooldownTime(status.resetIn)}*`;
}

/**
 * Consume one use for a casino command.
 * This is called once by handler/cmds.js before any gambling command executes.
 */
async function consumeCasinoUse(sender, cmdName = 'casino') {
  const now = Date.now();
  const key = casinoCooldownKey(cmdName);
  let cooldown = await Cooldown.findOne({ userId: sender });
  if (!cooldown) cooldown = new Cooldown({ userId: sender, commands: new Map() });

  let entry = cooldown.safeGet(key);

  // The 14-hour reset completed: return the command to a fresh 0/20 quota.
  if (entry.cooldownUntil && entry.cooldownUntil <= now) {
    entry = { count: 0, cooldownUntil: 0 };
  }

  if (entry.cooldownUntil && entry.cooldownUntil > now) {
    return {
      allowed: false,
      command: cmdName,
      used: CASINO_USE_LIMIT,
      remaining: 0,
      resetIn: entry.cooldownUntil - now,
      resetAt: entry.cooldownUntil,
    };
  }

  // Handles pre-existing data safely if an older runtime recorded a count of 20.
  if ((entry.count || 0) >= CASINO_USE_LIMIT) {
    const resetAt = now + CASINO_RESET_MS;
    cooldown.setCommand(key, { count: CASINO_USE_LIMIT, cooldownUntil: resetAt });
    await cooldown.save();
    return {
      allowed: false,
      command: cmdName,
      used: CASINO_USE_LIMIT,
      remaining: 0,
      resetIn: CASINO_RESET_MS,
      resetAt,
    };
  }

  const used = (entry.count || 0) + 1;
  const resetAt = used >= CASINO_USE_LIMIT ? now + CASINO_RESET_MS : 0;
  cooldown.setCommand(key, { count: used, cooldownUntil: resetAt });
  await cooldown.save();

  return {
    allowed: true,
    command: cmdName,
    used,
    remaining: CASINO_USE_LIMIT - used,
    resetIn: resetAt ? CASINO_RESET_MS : 0,
    resetAt,
  };
}

function casinoLimitMessage(status) {
  return [
    `> 🎰 *${status.command}* has reached its casino limit.`,
    `> Uses: *${CASINO_USE_LIMIT}/${CASINO_USE_LIMIT}*`,
    `> Reset: *${formatCooldownTime(status.resetIn)}*`,
    '> Each casino command has its own 15-use limit and 5-hour reset.',
  ].join('\n');
}

function getCasinoQuotaEntry(command, entry, now = Date.now()) {
  const expired = Boolean(entry?.cooldownUntil && entry.cooldownUntil <= now);
  const isLocked = Boolean(entry?.cooldownUntil && entry.cooldownUntil > now);
  const used = expired ? 0 : Math.min(CASINO_USE_LIMIT, Number(entry?.count) || 0);

  return {
    command: command.replace(CASINO_KEY_PREFIX, ''),
    used,
    remaining: Math.max(0, CASINO_USE_LIMIT - used),
    locked: isLocked,
    resetIn: isLocked ? entry.cooldownUntil - now : 0,
    resetAt: isLocked ? entry.cooldownUntil : 0,
  };
}

/* =========================
   USER
========================= */
async function getUser(sender, message) {
  const pushName = message?.pushName || message?.verifiedBizName || 'User';
  const user = await findOrCreateWhatsApp(sender, pushName);
  user.balance = Number(user.balance) || 0;
  user.bank = Number(user.bank) || 0;
  user.totalEarned = Number(user.totalEarned) || 0;
  user.totalLost = Number(user.totalLost) || 0;
  return user;
}

/* =========================
   EVENT STATS
========================= */
async function updateEventStats(userId, type, amount = 1) {
  try {
    EventProgress.findOneAndUpdate(
      { userId },
      {
        $inc: {
          [`stats.${
            type === 'gamble' ? 'gamblesWon'
            : type === 'coin'  ? 'coinsFlipped'
            : type === 'card'  ? 'cardsHunted'
            : type === 'battle'? 'battlesWon'
            : 'messagesSent'
          }`]: amount
        }
      }
    ).catch(() => {});
  } catch {}
}

/* =========================
   HISTORY
========================= */
function recordHistory(user, type, bet, outcome, amount) {
  if (!user.history) user.history = [];
  user.history.push({ type, bet, outcome, amount, time: new Date() });
  if (user.history.length > 20) user.history = user.history.slice(-20);
}

/* =========================
   WIN / LOSE
   A game command that reports a win must always credit its stated payout.
   Economy limits belong in pre-bet validation, never as a hidden loss after
   the result has already been selected and presented to the player.
========================= */
async function win(user, bet, multiplier, cmdName = 'gamble') {
  let profit = Math.max(0, Math.floor(Number(bet) * Number(multiplier)));

  // Do not turn a declared win into zero profit because of existing wealth.
  // High-value bets are already made harder by the win-chance table above.
  profit = Math.min(profit, MAX_SESSION_WIN);

  user.balance += profit;
  user.totalEarned += profit;
  recordHistory(user, cmdName, bet, 'win', profit);
  await user.save();
  updateEventStats(user.whatsappNumber || user.userId, 'gamble', 1);

  // Apply multiplier cooldown if applicable
  await applyMultiplierCooldown(user.whatsappNumber || user._id?.toString(), cmdName, multiplier);

  return profit;
}

async function lose(user, bet, cmdName = 'gamble') {
  user.balance = Math.max(0, user.balance - bet);
  user.totalLost += bet;
  recordHistory(user, cmdName, bet, 'loss', bet);
  await user.save();
  return -bet;
}

/* =========================
   RANDOM PICK
========================= */
function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

/* =========================
   EXPORTS
========================= */
module.exports = {
  money,
  parseBet,
  validateBet,
  getWinChance,
  roll,
  getUser,
  win,
  lose,
  pick,
  recordHistory,
  updateEventStats,
  checkMultiplierCooldown,
  applyMultiplierCooldown,
  formatCooldownTime,
  CASINO_USE_LIMIT,
  CASINO_RESET_MS,
  CASINO_KEY_PREFIX,
  consumeCasinoUse,
  casinoLimitMessage,
  getCasinoQuotaEntry,
  RACE_USE_LIMIT,
  RACE_RESET_MS,
  consumeRaceUse,
  raceLimitMessage,
};
