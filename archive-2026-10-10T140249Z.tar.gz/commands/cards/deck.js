const User = require('../../models/User');
const config = require('../../config');
const { getTierLabel } = require('../../utils/cardGenerator');
const { createDeckImage, createDeckVideo } = require('../../utils/deckImage');

const READ_MORE = String.fromCharCode(8206).repeat(4001);
const PAGE_SIZE = 12;

moon({
  name: 'deck',
  aliases: ['dk', 'mycards'],
  category: 'cards',
  description: 'View your active card deck with real card images.',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const user = await User.findOne({ $or: [{ whatsappNumber: sender }, { userId: sender.split('@')[0] }, { phoneNumber: sender.split('@')[0] }] });
      const cards = Array.isArray(user?.cards) ? user.cards : [];
      if (!cards.length) return reply(`❌ You do not have an active deck yet. Claim or collect cards first.\n\nEdit deck: ${config.WEB}/deck/edit`);
      const totalPages = Math.max(1, Math.ceil(cards.length / PAGE_SIZE));
      let page = Number.parseInt(args[0], 10) || 1;
      page = Math.min(Math.max(page, 1), totalPages);
      const start = (page - 1) * PAGE_SIZE;
      const slice = cards.slice(start, start + PAGE_SIZE);
      let deckMedia;
      let deckIsVideo = false;
      try {
        deckMedia = await createDeckVideo(slice, page, totalPages);
        deckIsVideo = true;
      } catch (error) {
        console.warn('[DECK MEDIA] video fallback:', error.message);
        deckMedia = await createDeckImage(slice, page, totalPages);
      }
      let details = `${READ_MORE}\n🌙 *YOUR CURRENT DECK* 🌙\n> Deck ${page}/${totalPages}\n> Total active cards: ${cards.length}\n\n`;
      slice.forEach((card, index) => {
        details += `${start + index + 1}. *${card.name || 'Unknown Card'}*\n   *Tier:* ${getTierLabel(card.tier) || card.tier || 'Common'}\n   *Index:* ${start + index + 1}\n   *Id:* ${card.cardId || 'unknown'}\n\n`;
      });
      details += `Edit your deck: ${config.WEB}/deck/edit`;
      const caption = `🌙 *MOONLIGHT HAVEN · ACTIVE DECK*\n> Your current deck ${page}/${totalPages}\n> ${cards.length} active card${cards.length === 1 ? '' : 's'}\n\n${details}`;
      return sock.sendMessage(jid, deckIsVideo ? { video: deckMedia, gifPlayback: true, mimetype: 'video/mp4', caption } : { image: deckMedia, caption }, { quoted: m });
    } catch (error) {
      console.error('[DECK ERROR]', error);
      return reply(`❌ Failed to load your deck. Try again shortly.\n\nEdit deck: ${config.WEB}/deck/edit`);
    }
  },
});
