const Card = require('../../models/Card');
const User = require('../../models/User');
const { buildCardPreviewPayload, resolveCardMedia, getTierLabel, normalizeTier, searchCards } = require('../../utils/cardGenerator');
function jidOf(user) { const raw = user.whatsappNumber || user.phoneNumber || user.userId || ''; return String(raw).includes('@') ? String(raw) : `${String(raw).replace(/[^0-9]/g, '')}@s.whatsapp.net`; }
function esc(value) { return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
moon({ name: 'ci', aliases: ['cardinfo', 'card-info'], category: 'cards', description: 'View a card by name and tier, or use an ID for a specific duplicate', async execute(sock, jid, sender, args, m, { reply }) {
  try {
    const input = args.join(' ').trim();
    if (!input) return reply('❌ Usage: `.ci <card name> <tier>`\nFor a specific duplicate, use `.ci <card ID>`.');
    let card = null;
    const exactId = args.length === 1 && (/^[a-f0-9]{6}$/i.test(input) || /^EC-[A-Z0-9]+$/i.test(input) || input.length > 20);
    if (exactId) card = await Card.findOne({ $or: [{ cardId: input }, { issueId: input }] });
    if (!card) {
      if (args.length < 2) {
        const query = input;
        let closest = await Card.find({ $or: [{ name: new RegExp(esc(query), 'i') }, { series: new RegExp(esc(query), 'i') }] }).sort({ name: 1 }).limit(10);
        if (!closest.length) { try { closest = await searchCards(query, 10); } catch (_) {} }
        if (!closest.length) return reply('> do i look like Google if i am tell me so i can think the tier fore you baka');
        const list = closest.map((entry, index) => `${index + 1}. *${entry.name}* — ${getTierLabel(entry.tier)}\n   ID: ${entry.cardId}`).join('\n');
        return reply(`> do i look like Google if i am tell me so i can think the tier fore you baka\n\n*Closest results:*\n${list}\n\nUse \.ci <Card name> <tier>`);
      }
      const tier = normalizeTier(args[args.length - 1], null);
      const name = args.slice(0, -1).join(' ').trim();
      if (!tier || !name) return reply('> do i look like Google if i am tell me so i can think the tier fore you baka');
      card = await Card.findOne({ name: new RegExp(`^${esc(name)}$`, 'i'), tier });
      if (!card) card = await Card.findOne({ name: new RegExp(esc(name), 'i'), tier });
    }
    if (!card) return reply(`❌ Card not found: ${input}`);
    const users = await User.find({ 'cards.cardId': card.cardId }).select('username pushName userId whatsappNumber phoneNumber cards').lean();
    const ownerRows = []; const mentions = [];
    for (const user of users) {
      const entries = (user.cards || []).filter((entry) => entry.cardId === card.cardId);
      const userJid = jidOf(user); if (userJid && !mentions.includes(userJid)) mentions.push(userJid);
      for (const entry of entries) ownerRows.push(`${ownerRows.length + 1}. @${userJid.split('@')[0]} • ${entry.cardId || card.cardId}`);
    }
    const caption = ['───⋆⋅☆⋅⋆───', `*Name:* ${card.name}`, `*Tier:* ${getTierLabel(card.tier)}`, `*Series:* ${card.series || 'Unknown'}`, `*Card Owners:* ${users.length}`, `*Issues:* ${ownerRows.length}`, '───⋆⋅☆⋅⋆───', '*⧉ Card Owners ⧉*', ownerRows.length ? ownerRows.slice(0, 50).join('\n') : 'No owners yet.'].join('\n');
    const payload = await buildCardPreviewPayload(card, caption, await resolveCardMedia(card));
    if (payload) return sock.sendMessage(jid, { ...payload, mentions }, { quoted: m });
    return reply(caption, { mentions });
  } catch (error) { console.error('[CI ERROR]', error); return reply('❌ Card info failed.'); }
}});
