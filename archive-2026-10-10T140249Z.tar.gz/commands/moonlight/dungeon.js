const MoonlightDungeonPlayer = require('../../models/MoonlightDungeonPlayer');
const System = require('../../models/System');
const Guild = require('../../models/athers/Guild');
const {
  ACHIEVEMENTS, applyExperience, awardLoot, capCost, createEncounter,
  forfeitPenalty, resolveDungeonFight, updateAchievements,
} = require('../../utils/moonlightDungeon');

const STAFF_ROLES = ['True Owner', 'Owner', 'Mod', 'Tester'];
const DUNGEON_GROUP_KEY = 'moonlight_dungeon_group';
const MARKET = {
  hp: { label: 'HP Capacity Charm', price: 25_000, description: '+20 maximum HP permanently' },
  mana: { label: 'Mana Capacity Charm', price: 25_000, description: '+12 maximum mana permanently' },
  totem: { label: 'Extra Life Totem', price: 50_000, description: 'Prevents one dungeon defeat' },
};

function playerName(sender) { return String(sender || 'Unknown').split('@')[0]; }
function number(value) { return new Intl.NumberFormat('en-US').format(Math.max(0, Math.floor(Number(value) || 0))); }
function toKey(value) { return String(value || '').trim().toLowerCase(); }

async function getPlayer(sender) {
  return MoonlightDungeonPlayer.findOneAndUpdate(
    { userId: sender },
    { $setOnInsert: { userId: sender, username: playerName(sender) } },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );
}

async function requireDungeonGroup(jid, reply) {
  if (!String(jid).endsWith('@g.us')) {
    await reply('❌ The Abyssal Dungeon can only be used in the configured dungeon group.');
    return false;
  }
  const setting = await System.findOne({ key: DUNGEON_GROUP_KEY }).lean();
  if (!setting?.value?.jid) {
    await reply('❌ The dungeon group has not been configured. A True Owner must use `.moonsetup` in the dungeon group first.');
    return false;
  }
  if (setting.value.jid !== jid) {
    await reply('❌ This is not the configured *Abyssal Dungeon | Moonlight Hell* group.');
    return false;
  }
  return true;
}

function dungeonHelp() {
  return [
    '🌙 *ABYSSAL DUNGEON | MOONLIGHT HELL*',
    '━━━━━━━━━━━━━━━━━━━━',
    'Only True Owners, Owners, Mods, and Testers may use Moonlight dungeon commands.',
    '',
    '` .moonstart ` — enter the dungeon and create your profile',
    '` .moonrun ` — fight the monster on your current floor',
    '` .moonstatus ` — view stats, coins, level cap, and loot',
    '` .moonforfeit ` — leave the floor and lose a portion of current XP',
    '` .moonmarket ` / ` .moonmarket buy hp|mana|totem ` — buy capacity charms or lives',
    '` .moonsell <loot name|all> ` — sell dungeon valuables for coins',
    '` .moonupgrade cap ` — pay coins to raise your level cap by five',
    '` .moonweekly ` — challenge the weekly guild boss',
    '` .moontransfer coins|xp <amount> @user ` — transfer coins or unspent XP',
    '` .moonachievements ` — view your kill and level achievements',
    '',
    '> Bosses appear every fifth floor. Defeat bosses for bonus loot and treasure chests.',
  ].join('\n');
}

moon({
  name: 'moonsetup',
  category: 'moonlight',
  roles: ['True Owner'],
  description: 'Configure the current group as Abyssal Dungeon | Moonlight Hell.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!String(jid).endsWith('@g.us')) return reply('❌ Use `.moonsetup` inside the group that should become the dungeon.');
    await System.findOneAndUpdate(
      { key: DUNGEON_GROUP_KEY },
      { $set: { value: { jid, title: 'Abyssal Dungeon | Moonlight Hell', setBy: sender }, updatedAt: new Date() } },
      { upsert: true, new: true }
    );
    try { await sock.groupUpdateSubject(jid, 'Abyssal Dungeon | Moonlight Hell'); } catch (error) { console.warn('[MOONLIGHT] Unable to rename group:', error.message); }
    return reply(`✅ This group is now configured as *Abyssal Dungeon | Moonlight Hell*.\n\n${dungeonHelp()}`);
  },
});

moon({
  name: 'moonhelp',
  aliases: ['moonlight'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'Show all Moonlight dungeon commands.',
  async execute(sock, jid, sender, args, m, { reply }) { return reply(dungeonHelp()); },
});

moon({
  name: 'moonstart',
  aliases: ['moonjoin'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'Create or view your Moonlight dungeon profile.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const player = await getPlayer(sender);
    return reply([
      `🌙 *${player.username.toUpperCase()} ENTERS THE ABYSS*`,
      '━━━━━━━━━━━━━━━━━━━━',
      `*Level:* ${player.level}/${player.levelCap}  ·  *Floor:* ${player.floor}`,
      `*HP:* ${player.hp}/${player.maxHp}  ·  *Mana:* ${player.mana}/${player.maxMana}`,
      `*Coins:* ${number(player.coins)}`,
      '',
      '> Use `.moonrun` to confront the monster waiting on your current floor.',
    ].join('\n'));
  },
});

moon({
  name: 'moonrun',
  aliases: ['moonfight', 'moonhunt'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'Fight the monster on your current Abyssal Dungeon floor.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const player = await getPlayer(sender);
    if (player.hp <= 0) {
      player.hp = Math.max(1, Math.round(player.maxHp * .45));
      player.mana = Math.max(0, Math.round(player.maxMana * .40));
      await player.save();
      return reply('💀 You are recovering at the dungeon gate. Your HP and mana were partially restored; use `.moonrun` again to continue.');
    }

    const encounter = createEncounter(player.floor);
    const result = resolveDungeonFight(player, encounter);
    if (!result.won) {
      if (player.extraLifeTotems > 0) {
        player.extraLifeTotems -= 1;
        player.hp = Math.max(1, Math.round(player.maxHp * .35));
        player.mana = Math.max(0, Math.round(player.maxMana * .35));
        await player.save();
        return reply(`🗿 *${encounter.name.toUpperCase()}* defeated you, but an *Extra Life Totem* shattered and saved you.\n> HP restored to ${player.hp}/${player.maxHp}. Totems left: ${player.extraLifeTotems}.`);
      }
      player.deaths += 1;
      player.floor = Math.max(1, player.floor - 1);
      player.hp = Math.max(1, Math.round(player.maxHp * .40));
      player.mana = Math.max(0, Math.round(player.maxMana * .35));
      await player.save();
      return reply(`💀 *${encounter.name.toUpperCase()}* overwhelmed you after ${result.rounds} rounds.\n> You retreat to floor ${player.floor}; HP and mana partially recover. Use charms or return stronger.`);
    }

    player.kills += 1;
    if (encounter.boss) player.bossesDefeated += 1;
    player.coins += encounter.coins;
    const xp = applyExperience(player, encounter.xp);
    const loot = awardLoot(player, encounter.boss);
    const achievements = updateAchievements(player);
    player.floor += 1;
    player.hp = Math.min(player.maxHp, player.hp + Math.round(player.maxHp * .14));
    player.mana = Math.min(player.maxMana, player.mana + Math.round(player.maxMana * .12));
    await player.save();

    const levelText = xp.gainedLevels.length ? `\n⬆️ *Level up:* ${xp.gainedLevels.join(', ')}` : '';
    const capText = xp.capped ? '\n⚠️ *Level cap reached:* raise it with `.moonupgrade cap` to keep earning levels.' : '';
    const achievementText = achievements.length ? `\n🏅 *Achievement unlocked:* ${achievements.join(', ')}` : '';
    return reply([
      `${encounter.boss ? '👑 *BOSS SLAIN*' : '⚔️ *MONSTER SLAIN*'} — *${encounter.name.toUpperCase()}*`,
      '━━━━━━━━━━━━━━━━━━━━',
      `*Floor:* ${encounter.floor}  ·  *Rounds:* ${result.rounds}`,
      `*Rewards:* +${number(encounter.xp)} XP  ·  +${number(encounter.coins)} coins`,
      `*Loot:* ${loot.map((item) => `${item.name} (${item.rarity})`).join(', ')}`,
      `*HP:* ${player.hp}/${player.maxHp}  ·  *Mana:* ${player.mana}/${player.maxMana}`,
      levelText + capText + achievementText,
      '',
      `> Floor ${player.floor} awaits. Use *.moonrun* when ready.`,
    ].filter(Boolean).join('\n'));
  },
});

moon({
  name: 'moonstatus',
  aliases: ['moonme'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'View Moonlight dungeon stats and progression.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const player = await getPlayer(sender);
    return reply([
      `🌙 *${player.username.toUpperCase()} — ABYSSAL STATUS*`,
      '━━━━━━━━━━━━━━━━━━━━',
      `*Level:* ${player.level}/${player.levelCap}  ·  *XP:* ${number(player.xp)}/${number(player.xpToNext)}`,
      `*Floor:* ${player.floor}  ·  *Kills:* ${number(player.kills)}  ·  *Bosses:* ${number(player.bossesDefeated)}`,
      `*HP:* ${player.hp}/${player.maxHp}  ·  *Mana:* ${player.mana}/${player.maxMana}`,
      `*Attack:* ${player.attack}  ·  *Defense:* ${player.defense}`,
      `*Coins:* ${number(player.coins)}  ·  *Loot stacks:* ${player.loot.length}`,
      `*Charms:* ${player.hpCharms} HP · ${player.manaCharms} Mana · ${player.extraLifeTotems} Totems`,
      `*Next cap cost:* ${number(capCost(player))} coins`,
    ].join('\n'));
  },
});

moon({
  name: 'moonforfeit',
  aliases: ['moonleave'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'Forfeit your dungeon floor and lose a portion of current XP.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const player = await getPlayer(sender);
    const lostXp = forfeitPenalty(player);
    await player.save();
    return reply(`🏳️ You forfeited the floor. *-${number(lostXp)} current XP* and you returned to floor ${player.floor}.\n> HP: ${player.hp}/${player.maxHp} · Mana: ${player.mana}/${player.maxMana}`);
  },
});

moon({
  name: 'moonmarket',
  aliases: ['moonshop'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'Buy HP charms, mana charms, or extra-life totems.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const action = toKey(args[0]);
    const itemKey = toKey(args[1]);
    const player = await getPlayer(sender);
    if (action !== 'buy' || !MARKET[itemKey]) {
      return reply([
        '🛒 *MOONLIGHT MARKET*', '━━━━━━━━━━━━━━━━━━━━',
        `*HP Charm:* ${number(MARKET.hp.price)} coins — ${MARKET.hp.description}`,
        `*Mana Charm:* ${number(MARKET.mana.price)} coins — ${MARKET.mana.description}`,
        `*Extra Life Totem:* ${number(MARKET.totem.price)} coins — ${MARKET.totem.description}`,
        '', '> Use `.moonmarket buy hp`, `.moonmarket buy mana`, or `.moonmarket buy totem`.',
      ].join('\n'));
    }
    const item = MARKET[itemKey];
    if (player.coins < item.price) return reply(`❌ You need ${number(item.price - player.coins)} more coins for a ${item.label}.`);
    player.coins -= item.price;
    if (itemKey === 'hp') { player.hpCharms += 1; player.maxHp += 20; player.hp += 20; }
    if (itemKey === 'mana') { player.manaCharms += 1; player.maxMana += 12; player.mana += 12; }
    if (itemKey === 'totem') player.extraLifeTotems += 1;
    await player.save();
    return reply(`✅ Bought *${item.label}*.\n> Coins remaining: ${number(player.coins)}.`);
  },
});

moon({
  name: 'moonsell',
  aliases: ['moonloot'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'Sell dungeon loot or inspect your valuables.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const player = await getPlayer(sender);
    const requested = args.join(' ').trim().toLowerCase();
    if (!requested) {
      if (!player.loot.length) return reply('🎒 Your dungeon loot bag is empty. Defeat monsters to find valuables.');
      return reply(['🎒 *DUNGEON LOOT*', '━━━━━━━━━━━━━━━━━━━━', ...player.loot.map((item) => `• ${item.name} ×${item.quantity} — ${number(item.value)} coins each`), '', '> Use `.moonsell all` or `.moonsell <loot name>`.'].join('\n'));
    }
    const sold = requested === 'all' ? [...player.loot] : player.loot.filter((item) => item.name.toLowerCase() === requested || item.id === requested.replace(/\s+/g, '-'));
    if (!sold.length) return reply('❌ No matching dungeon loot was found. Use `.moonsell` to view your bag.');
    const value = sold.reduce((total, item) => total + (item.value * item.quantity), 0);
    player.loot = player.loot.filter((item) => !sold.includes(item));
    player.coins += value;
    await player.save();
    return reply(`💰 Sold ${sold.map((item) => `${item.name} ×${item.quantity}`).join(', ')} for *${number(value)} coins*.`);
  },
});

moon({
  name: 'moonupgrade',
  aliases: ['mooncap'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'Spend coins to raise your Moonlight level cap.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const player = await getPlayer(sender);
    if (toKey(args[0]) !== 'cap') return reply(`🌙 Your level cap is ${player.levelCap}. Raise it by five for *${number(capCost(player))} coins* with *.moonupgrade cap*.`);
    const cost = capCost(player);
    if (player.coins < cost) return reply(`❌ You need ${number(cost - player.coins)} more coins to raise your level cap.`);
    player.coins -= cost;
    player.levelCap += 5;
    await player.save();
    return reply(`⬆️ Your Moonlight level cap is now *${player.levelCap}*.\n> ${number(player.coins)} coins remain.`);
  },
});

moon({
  name: 'moonweekly',
  aliases: ['moonboss'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'Fight the weekly guild boss for personal and guild rewards.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const player = await getPlayer(sender);
    const now = Date.now();
    if (player.lastWeeklyBossAt && now - new Date(player.lastWeeklyBossAt).getTime() < 7 * 24 * 60 * 60 * 1000) {
      const remainingDays = Math.ceil((7 * 24 * 60 * 60 * 1000 - (now - new Date(player.lastWeeklyBossAt).getTime())) / (24 * 60 * 60 * 1000));
      return reply(`⏳ You have already challenged the weekly boss. Return in about ${remainingDays} day(s).`);
    }
    const guild = await Guild.findOne({ members: sender });
    if (!guild) return reply('❌ Join a guild before challenging the weekly guild boss.');
    const bossFloor = Math.max(5, Math.ceil(player.level / 5) * 5);
    const encounter = createEncounter(bossFloor);
    const result = resolveDungeonFight(player, encounter);
    player.lastWeeklyBossAt = new Date();
    if (!result.won) {
      player.hp = Math.max(1, Math.round(player.maxHp * .45));
      player.mana = Math.max(0, Math.round(player.maxMana * .40));
      await player.save();
      return reply(`👑 *${encounter.name.toUpperCase()}* repelled your guild challenge.\n> You may try again next week; HP and mana partially recovered.`);
    }
    player.weeklyBossWins += 1;
    player.kills += 1;
    player.bossesDefeated += 1;
    player.coins += encounter.coins * 2;
    const xp = applyExperience(player, encounter.xp * 2);
    const loot = awardLoot(player, true);
    const achievements = updateAchievements(player);
    guild.xp = (guild.xp || 0) + encounter.xp;
    await Promise.all([player.save(), guild.save()]);
    return reply([
      `🏆 *WEEKLY GUILD BOSS DEFEATED — ${encounter.name.toUpperCase()}*`,
      '━━━━━━━━━━━━━━━━━━━━',
      `*Guild:* ${guild.name} gained ${number(encounter.xp)} guild XP.`,
      `*Personal rewards:* +${number(encounter.xp * 2)} XP · +${number(encounter.coins * 2)} coins`,
      `*Boss loot:* ${loot.map((item) => item.name).join(', ')}`,
      xp.gainedLevels.length ? `⬆️ *Level up:* ${xp.gainedLevels.join(', ')}` : '',
      achievements.length ? `🏅 *Achievement:* ${achievements.join(', ')}` : '',
    ].filter(Boolean).join('\n'));
  },
});

moon({
  name: 'moontransfer',
  aliases: ['moonpay'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'Transfer coins or unspent dungeon XP to a mentioned player.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const kind = toKey(args[0]);
    const amount = Math.floor(Number(args[1]));
    const target = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    if (!['coins', 'xp'].includes(kind) || !Number.isInteger(amount) || amount <= 0 || !target) return reply('❌ Usage: `.moontransfer coins|xp <amount> @user`');
    if (target === sender) return reply('❌ You cannot transfer dungeon rewards to yourself.');
    const [from, to] = await Promise.all([getPlayer(sender), getPlayer(target)]);
    if (kind === 'coins') {
      if (from.coins < amount) return reply('❌ You do not have enough coins.');
      from.coins -= amount; to.coins += amount;
    } else {
      if (from.xp < amount) return reply('❌ You can only transfer unspent current-level XP.');
      from.xp -= amount;
      to.xp = Math.min(to.xpToNext - 1, to.xp + amount);
    }
    await Promise.all([from.save(), to.save()]);
    return reply(`✅ Transferred *${number(amount)} ${kind}* to @${target.split('@')[0]}.`, { mentions: [target] });
  },
});

moon({
  name: 'moonachievements',
  aliases: ['moonach'],
  category: 'moonlight',
  roles: STAFF_ROLES,
  description: 'View Moonlight dungeon achievements.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!(await requireDungeonGroup(jid, reply))) return;
    const player = await getPlayer(sender);
    const lines = ACHIEVEMENTS.map((achievement) => `${player.achievements.includes(achievement.id) ? '✅' : '⬜'} ${achievement.title}`);
    return reply(['🏅 *MOONLIGHT ACHIEVEMENTS*', '━━━━━━━━━━━━━━━━━━━━', ...lines, '', `Unlocked: ${player.achievements.length}/${ACHIEVEMENTS.length}`].join('\n'));
  },
});
