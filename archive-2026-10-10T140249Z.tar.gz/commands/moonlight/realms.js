const mongoose = require('mongoose');
const User = require('../../models/User');
const Group = require('../../models/athers/Group');
const SpawnControl = require('../../models/athers/SpawnControl');
const config = require('../../config');

const schema = new mongoose.Schema({
  whatsappNumber: { type: String, unique: true, index: true },
  level: { type: Number, default: 1 }, xp: { type: Number, default: 0 },
  region: { type: String, default: 'Moonlit Meadow' }, energy: { type: Number, default: 100 },
  discoveries: { type: Number, default: 0 }, relics: { type: Number, default: 0 },
  materials: { type: Number, default: 0 }, dungeons: { type: Number, default: 0 },
  bossKills: { type: Number, default: 0 }, pvpWins: { type: Number, default: 0 }, pvpLosses: { type: Number, default: 0 },
  achievements: { type: [String], default: [] },
  mission: { type: mongoose.Schema.Types.Mixed, default: null },
  lastActionAt: { type: Map, of: Date, default: {} }
}, { timestamps: true, strict: false });
const RealmState = mongoose.models.RealmState || mongoose.model('RealmState', schema);

const ADVENTURE = {
  adventure: 'Start a random story event with a meaningful choice and reward.',
  expedition: 'Begin a tracked expedition that completes after its objective is met.',
  explore: 'Survey your current region and reveal a location clue.',
  travel: 'Move to another discovered region and change your active region.',
  discover: 'Convert a clue into a permanent discovery and progression XP.',
  scavenge: 'Search for crafting materials; materials are tracked persistently.',
  dungeon: 'Run a dungeon encounter with a clear, persistent completion count.',
  treasure: 'Open a treasure cache using your discoveries for a weighted reward.',
  mystery: 'Resolve a random mystery with separate positive, neutral, and danger paths.',
  secret: 'Attempt a rare secret discovery with a deliberately low success rate.',
  craft: 'Spend tracked materials to craft a usable Realms item.',
  relic: 'Search specifically for relic fragments and rare relic progression.',
  fortune: 'Take a controlled luck roll with capped gains and losses.',
  fate: 'Receive a narrative fate result without destroying player progress.',
  lore: 'Read a region-specific piece of Moonlight Realms lore.'
};
const COMBAT = {
  encounter: 'Encounter a random enemy or Pokémon.', boss: 'Fight a powerful boss for special rewards.', raid: 'Join a cooperative raid encounter.',
  invasion: 'Defend the world against an invasion.', defend: 'Protect your region from attackers.', arena: 'Enter the PvP arena.',
  bounty: 'Accept a bounty and hunt its target.', survive: 'Attempt to survive a dangerous event.', hazard: 'Face a dangerous combat challenge.',
  worldevent: 'Participate in a group world event.', bountyboard: 'View active world bounties.', duel: 'Challenge another player to a Realms battle.'
};
const GUILD_REALMS = {
  grank: 'View the strongest Guilds in Moonlight Realms.',
  gstats: 'View your Guild\'s Realms statistics.',
  graid: 'Lead your Guild into a cooperative Realms raid.'
};
const cooldowns = new Map();
const regions = ['Moonlit Meadow', 'Silverpine Coast', 'Eclipse Ruins', 'Starlit Highlands', 'Abyssal Gate'];
const lore = {
  'Moonlit Meadow': 'The first light of the Realms gathers here. Travelers say the meadow remembers every promise made beneath its moon.',
  'Silverpine Coast': 'Silverpine tides carry fragments of ancient relics toward the shore after every eclipse.',
  'Eclipse Ruins': 'The ruins were built by a civilization that mapped the movement of Pokémon across the stars.',
  'Starlit Highlands': 'The highlands are watched by a silent order that rewards courage rather than wealth.',
  'Abyssal Gate': 'The gate is not a dungeon entrance alone; it is a boundary between forgotten histories.'
};
const pick = (list) => list[Math.floor(Math.random() * list.length)];
const xpFor = (level) => 100 + ((level - 1) * 50);
async function getState(sender) {
  return RealmState.findOneAndUpdate({ whatsappNumber: sender }, { $setOnInsert: { whatsappNumber: sender } }, { upsert: true, new: true });
}
async function takeCooldown(sender, key, ms) {
  const mapKey = `${sender}:${key}`; const previous = cooldowns.get(mapKey) || 0; const remaining = ms - (Date.now() - previous);
  if (remaining > 0) return Math.ceil(remaining / 1000);
  cooldowns.set(mapKey, Date.now());
  return 0;
}
async function grant(sender, coins, xp, state) {
  const user = await User.findOne({ whatsappNumber: sender });
  if (user) {
    user.balance = Math.max(0, Number(user.balance || 0) + coins);
    if (coins > 0) user.totalEarned = Number(user.totalEarned || 0) + coins;
    await user.save();
  }
  state.xp += xp;
  while (state.xp >= xpFor(state.level)) { state.xp -= xpFor(state.level); state.level += 1; }
  await state.save();
}
function menu(title, entries, prefix) {
  return `${title}\n\n${Object.entries(entries).map(([name, description]) => `│⊱ ${prefix}${name}\n│   ${description}`).join('\n')}`;
}
function combatBlocked() {
  const link = config.COMBAT || 'https://chat.whatsapp.com/DNyrXCpXv26AJ3sggoGEMq';
  return `${link}\nYou cant use this command as this group is not allowed\n> here join the mentioned group fore more fun and command's usage's`;
}
async function combatAllowed(jid) {
  if (!jid.endsWith('@g.us')) return false;
  const group = await Group.findOne({ groupId: jid }).lean();
  return group?.realmsCombatEnabled === true;
}
async function imageOrText(ctx, text) {
  if (ctx.replyWithImage && config.MOONLIGHT_IMAGE) return ctx.replyWithImage(config.MOONLIGHT_IMAGE, text);
  return ctx.reply(text);
}
async function runAdventure(name, sender, args, ctx) {
  const state = await getState(sender);
  const waits = { secret: 120000, relic: 90000, expedition: 90000, dungeon: 60000, travel: 45000, craft: 45000 };
  const wait = await takeCooldown(sender, name, waits[name] || 30000);
  if (wait) return ctx.reply(`⏳ This mission is still on cooldown. Try again in ${wait}s.`);

  if (name === 'adventure') {
    const event = pick(['a lost Pokémon asking for help', 'a moonlit merchant with a sealed map', 'a wounded scout from the Eclipse Ruins']);
    state.mission = { type: 'adventure', objective: event, progress: 1, target: 1, startedAt: new Date() }; await state.save();
    await grant(sender, 120, 30, state);
    return imageOrText(ctx, `🌙 *ADVENTURE STARTED*\n\nYou found ${event}.\nMission recorded: complete the next related command to continue your journey.\n\n💰 +120 coins  ✨ +30 XP`);
  }
  if (name === 'expedition') {
    const target = 3; state.mission = { type: 'expedition', objective: 'collect three expedition reports', progress: 0, target, startedAt: new Date() }; await state.save();
    return imageOrText(ctx, `🧭 *EXPEDITION REGISTERED*\n\nObjective: collect ${target} reports by using \`${ctx.prefix}explore\`.\nProgress is saved in the Realms database; it is not hidden in a message.`);
  }
  if (name === 'explore') {
    const clue = pick(['a marked shrine', 'a sleeping Pokémon trail', 'a collapsed observatory', 'a sealed dungeon door']);
    if (state.mission?.type === 'expedition') { state.mission.progress = Math.min(state.mission.target, Number(state.mission.progress || 0) + 1); }
    await grant(sender, 90, 25, state);
    return imageOrText(ctx, `🧭 *REGION SURVEY*\n\nIn *${state.region}* you discovered: *${clue}*.\n${state.mission?.type === 'expedition' ? `Expedition progress: ${state.mission.progress}/${state.mission.target}` : 'Use `.discover` to convert this clue into a permanent discovery.'}`);
  }
  if (name === 'travel') {
    const current = regions.indexOf(state.region); state.region = regions[(current + 1) % regions.length]; await grant(sender, 40, 10, state);
    return imageOrText(ctx, `🗺️ *TRAVEL COMPLETE*\n\nYou arrived at *${state.region}*.\nNew regional lore and encounters are now available.`);
  }
  if (name === 'discover') { state.discoveries += 1; await grant(sender, 180, 45, state); return imageOrText(ctx, `🔎 *DISCOVERY RECORDED*\n\nA hidden location in *${state.region}* is now permanently recorded.\nTotal discoveries: ${state.discoveries}`); }
  if (name === 'scavenge') { state.materials += 2 + Math.floor(Math.random() * 4); await grant(sender, 30, 15, state); return imageOrText(ctx, `🧺 *SCAVENGE COMPLETE*\n\nMaterials stored: *${state.materials}*.\nUse \`${ctx.prefix}craft\` when you have enough materials.`); }
  if (name === 'dungeon') { state.dungeons += 1; await grant(sender, 350, 80, state); return imageOrText(ctx, `🏚️ *DUNGEON CLEARED*\n\nThe dungeon yielded a guarded cache.\nCompleted dungeons: ${state.dungeons}\nRewards: 350 coins and 80 XP.`); }
  if (name === 'treasure') { const amount = 150 + Math.floor(Math.random() * 351); await grant(sender, amount, 35, state); return imageOrText(ctx, `💰 *TREASURE OPENED*\n\nA validated cache contained *${amount} coins*.\nNo negative result can destroy your balance.`); }
  if (name === 'mystery') { const outcome = pick(['A guide reveals a shortcut.', 'The mystery is harmless but teaches old lore.', 'A shadow follows you; your next dungeon is more dangerous.']); await grant(sender, 100, 30, state); return imageOrText(ctx, `❔ *MYSTERY RESOLVED*\n\n${outcome}\nReward: 100 coins and 30 XP.`); }
  if (name === 'secret') { const success = Math.random() < 0.12; if (success) { state.discoveries += 1; state.relics += 1; await grant(sender, 1000, 150, state); return imageOrText(ctx, '🌌 *SECRET FOUND*\n\nYou uncovered a rare Realms secret and a relic fragment.'); } return imageOrText(ctx, '🌌 *SECRET SEARCHED*\n\nThe secret remained hidden. The attempt was recorded; try again after the cooldown.'); }
  if (name === 'craft') { if (state.materials < 5) return ctx.reply(`🛠️ You need 5 materials. Current materials: ${state.materials}.`); state.materials -= 5; await grant(sender, 220, 55, state); return imageOrText(ctx, `🛠️ *CRAFT COMPLETE*\n\nA Moonsteel charm was added to your Realms inventory. Materials left: ${state.materials}.`); }
  if (name === 'relic') { state.relics += 1; await grant(sender, 500, 100, state); return imageOrText(ctx, `💎 *RELIC FRAGMENT FOUND*\n\nRelics collected: ${state.relics}.\nRelics grant progression and access, not unlimited power.`); }
  if (name === 'fortune') { const amount = Math.floor(Math.random() * 301) - 50; await grant(sender, amount, 20, state); return imageOrText(ctx, `🎲 *FORTUNE*\n\nThe wheel returned *${amount >= 0 ? '+' : ''}${amount} coins* and 20 XP.`); }
  if (name === 'fate') { await grant(sender, 75, 20, state); return imageOrText(ctx, `🌀 *FATE SPOKE*\n\nYour next journey begins in *${state.region}*. The Realms grants 75 coins and 20 XP.`); }
  if (name === 'lore') return imageOrText(ctx, `📜 *LORE — ${state.region.toUpperCase()}*\n\n${lore[state.region] || lore['Moonlit Meadow']}`);
}
async function runGuildRealm(name, sender, ctx) {
  const user = await User.findOne({ whatsappNumber: sender }).lean();
  const Guild = require('../../models/athers/Guild');
  const ids = [user?.moonId, user?.userId, sender.split('@')[0]].filter(Boolean);
  const guild = await Guild.findOne({ members: { $in: ids } }).lean();
  if (!guild) return ctx.reply('❌ You must be a public Guild member before using this Realms Guild command.');
  if (name === 'gstats') return ctx.reply(`🏰 *${guild.name} REALMS STATS*\n\nMembers: ${guild.members?.length || 0}\nXP: ${(guild.xp || 0).toLocaleString()}\nTerritory status: Uncontested\nRaid readiness: Available`);
  if (name === 'grank') { const rows = await Guild.find({}).sort({ xp: -1 }).limit(10).lean(); return ctx.reply(`🏆 *REALMS GUILD RANK*\n\n${rows.map((g, i) => `${i + 1}. *${g.name}* — ${(g.xp || 0).toLocaleString()} XP`).join('\n') || 'No public Guilds found.'}`); }
  return ctx.reply(`⚔️ *${guild.name.toUpperCase()} RAID*\n\nRaid registration is open for all public Guild members.\nUse the existing Guild system for membership and permissions; Realms only adds gameplay.`);
}
function register(name, category, description, aliases = []) { moon({ name, aliases, category, description, usage: `.${name}`, async execute(sock, jid, sender, args, m, ctx) { if (category === 'adventure') return runAdventure(name, sender, args, ctx); if (category === 'combat') { if (!(await combatAllowed(jid))) return ctx.reply(combatBlocked()); if (name === 'combat') return ctx.reply(menu('⚔️ MOONLIGHT REALMS — COMBAT', COMBAT, ctx.prefix)); return ctx.reply(`⚔️ *${name.toUpperCase()}*\n${description}\n\nCombat is enabled for this group. Existing battle safeguards remain active.`); } return runGuildRealm(name, sender, ctx); } }); }
register('adventure', 'adventure', ADVENTURE.adventure);
for (const [name, description] of Object.entries(ADVENTURE)) if (name !== 'adventure') register(name, 'adventure', description);
register('combat', 'combat', 'View all Moonlight Realms combat commands.');
for (const [name, description] of Object.entries(COMBAT)) register(name, 'combat', description);
for (const [name, description] of Object.entries(GUILD_REALMS)) register(name, 'guilds', description);
moon({ name: 'pms', aliases: ['havencombat'], category: 'general', description: 'Enable or disable Haven Combat for a group.', usage: '.pms combat on|off', async execute(sock, jid, sender, args, m, ctx) {
  if (!jid.endsWith('@g.us')) return ctx.reply(combatBlocked());
  const mode = String(args[0] || '').toLowerCase(); const value = String(args[1] || '').toLowerCase();
  if (mode === 'poke' || mode === 'pokemon' || mode === 'pokémon') {
    if (!['on', 'off'].includes(value)) return ctx.reply(`Usage: ${ctx.prefix}pms poke on|off\nDefault: OFF`);
    const user = await User.findOne({ $or: [{ whatsappNumber: sender }, { phoneNumber: sender.split('@')[0] }, { userId: sender.split('@')[0] }, { moonId: sender.split('@')[0] }] }).lean().catch(() => null);
    if (!(user?.isTrueOwner === true || ['Owner', 'Mod', 'Guardian', 'CDC'].includes(user?.role))) return ctx.reply('❌ Only staff can change Pokémon spawning.');
    await Group.findOneAndUpdate({ groupId: jid }, { $set: { pokemonSpawnEnabled: value === 'on', spawnEnabled: value === 'on' } }, { upsert: true });
    await SpawnControl.findOneAndUpdate({ groupId: jid }, { $set: { enabled: value === 'on' } }, { upsert: true, new: true });
    return ctx.reply(`🌿 Pokémon spawning is now *${value.toUpperCase()}* for this group.`);
  }
  if (!['com', 'bat', 'combat'].includes(mode) || !['on', 'off'].includes(value)) return ctx.reply(`Usage: ${ctx.prefix}pms poke on|off\n${ctx.prefix}pms combat on|off`);
  await Group.findOneAndUpdate({ groupId: jid }, { $set: { realmsCombatEnabled: value === 'on' } }, { upsert: true });
  return ctx.reply(`⚔️ Haven Combat is now *${value.toUpperCase()}* for this group.`);
}});
moon({ name: 'status', aliases: ['realms', 'realmstatus'], category: 'general', description: 'View Realms progression.', async execute(sock, jid, sender, args, m, ctx) { const r = await getState(sender); return imageOrText(ctx, `🌙 *MOONLIGHT REALMS STATUS*\n\nRegion: *${r.region}*\nLevel: *${r.level}* (${r.xp}/${xpFor(r.level)} XP)\nDiscoveries: *${r.discoveries}*\nRelics: *${r.relics}*\nMaterials: *${r.materials}*\nMission: *${r.mission?.type || 'none'}*`); }});
moon({ name: 'achievement', aliases: ['achievements'], category: 'general', description: 'View Realms achievements.', async execute(sock, jid, sender, args, m, ctx) { const r = await getState(sender); return imageOrText(ctx, `🏆 *REALMS ACHIEVEMENTS*\n\nLevel ${r.level}\nDiscoveries: ${r.discoveries}\nDungeons: ${r.dungeons}\nRelics: ${r.relics}\n\nKeep exploring to unlock more achievements.`); }});
