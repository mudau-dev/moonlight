const config = require('../../config');

moon({
  name: 'addbot',
  aliases: ['dbot'],
  category: 'general',
  description: 'Submit your group for bot review through Moonlight Haven.',
  usage: '.addbot',
  async execute(sock, jid, sender, args, m, { reply }) {
    const link = `${String(config.WEB).replace(/\/$/, '')}/add-bot`;
    const text = `🌙 *MOONLIGHT HAVEN · BOT REQUESTS*\n\nSubmit your group through the official Haven form.\n\n*Requirements*\n• 95+ members\n• Active community\n• At least one active admin\n• Bot can be made group admin after approval\n\n*Open submission form*\n${link}\n\n> Do not force-add a bot. Our team will review every request.`;
    try {
      return await sock.sendMessage(jid, { text, linkPreview: true }, { quoted: m });
    } catch {
      return reply(text);
    }
  },
});
