const COMMUNITY_LINK = process.env.COMMUNITY_LINK || '';
const COMMUNITY_LINK2 = process.env.COMMUNITY_LINK2 || '';
const DISCORD_LINK = process.env.DISCORD_LINK || '';
const WEB = process.env.WEB || '';
moon({
  name: 'support',
  aliases: ['supportc'],
  category: 'general',
  description: 'Open the official Moonlight Haven support communities.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!COMMUNITY_LINK && !COMMUNITY_LINK2) return reply('❌ The support communities are not configured yet.');
    const lines = ['🆘 *MOONLIGHT HAVEN COMMUNITIES*', ''];
    if (COMMUNITY_LINK) lines.push('*Moon Community - I*', COMMUNITY_LINK, '');
    if (COMMUNITY_LINK2) lines.push('*Moon Community - II*', COMMUNITY_LINK2, '');
    lines.push('> You can join the 2nd community if *Community - I* is full or something is wrong. The same applies to *Community - II*.');
    return reply(lines.join('\n'));
  },
});
moon({
  name: 'discord',
  aliases: ['ds'],
  category: 'general',
  description: 'Open the Moonlight Haven Discord server.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!DISCORD_LINK) return reply('❌ The Discord link is not configured yet.');
    return reply(`💬 *MOONLIGHT HAVEN DISCORD*\n\n${DISCORD_LINK}`);
  },
});
moon({
  name: 'website',
  aliases: ['web'],
  category: 'general',
  description: 'Open the Moonlight Haven website.',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!WEB) return reply('❌ The website link is not configured yet.');
    return reply(`🌙 *MOONLIGHT HAVEN WEBSITE*\n\n${WEB}\n> Create an account, then use \.webcp <password> in the bot to set your website password.`);
  },
});
moon({
  name: 'collab',
  aliases: ['clb'],
  category: 'general',
  description: 'Open the Moonlight Haven collaboration communities.',
  async execute(sock, jid, sender, args, m, { reply }) {
    return reply([
      '🤝 *MOONLIGHT HAVEN COLLABORATIONS*',
      '',
      '*Moonlight Haven*',
      'https://chat.whatsapp.com/JWgFzqYITn9J6RIPEFp9ZB',
      '',
      '*Avater*',
      'https://chat.whatsapp.com/F5WndukvH3BBRRuwE5G0cY',
    ].join('\n'));
  },
});
