const { downloadMediaMessage } = require('../../utils/baileys');
const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const pino = require('pino');
const sharp = require('sharp');
const User = require('../../models/User');

function unwrap(message) {
  if (!message) return null;
  if (message.ephemeralMessage) return unwrap(message.ephemeralMessage.message);
  if (message.viewOnceMessage) return unwrap(message.viewOnceMessage.message);
  if (message.viewOnceMessageV2) return unwrap(message.viewOnceMessageV2.message);
  return message;
}

function context(m) {
  return m.message?.extendedTextMessage?.contextInfo || m.message?.imageMessage?.contextInfo || m.message?.stickerMessage?.contextInfo || {};
}

function mediaType(message) {
  if (message?.stickerMessage) return 'stickerMessage';
  if (message?.imageMessage) return 'imageMessage';
  return null;
}

function targetFromContext(m) {
  const ctx = context(m);
  return ctx.participant || ctx.quotedParticipant || null;
}

moon({
  name: 'take',
  aliases: ['steal'],
  category: 'general',
  description: 'Brand a replied sticker as Moonlight or MoonLord',
  usage: '.take or .steal (reply to a sticker)',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const quoted = unwrap(context(m).quotedMessage);
      if (!quoted || mediaType(quoted) !== 'stickerMessage') return reply('❌ Reply to a sticker to use `.take`.');
      const target = targetFromContext(m);
      if (!target) return reply('❌ Reply to the sticker message so I know whose sticker this is.');
      const buffer = await downloadMediaMessage({ message: quoted, key: { remoteJid: jid, participant: target, id: context(m).stanzaId } }, 'buffer', {}, { logger: pino({ level: 'silent' }), reuploadRequest: sock.updateMediaMessage });
      if (!Buffer.isBuffer(buffer) || buffer.length < 50) return reply('❌ I could not download that sticker.');
      const square = await sharp(buffer).resize(512, 512, { fit: 'cover' }).png().toBuffer();
      const targetNumber = String(target).split('@')[0];
      const user = await User.findOne({ $or: [{ whatsappNumber: target }, { phoneNumber: targetNumber }, { userId: targetNumber }, { moonId: targetNumber }] }).lean().catch(() => null);
      const username = user?.username || `@${targetNumber}`;
      const moonlord = user?.isTrueOwner === true || ['True Owner', 'Mod'].includes(user?.role);
      const label = `${username} • ${moonlord ? 'MoonLord' : 'MOONLIGHT'}`;
      const sticker = new Sticker(square, { pack: label, author: 'MOONLIGHT', type: StickerTypes.FULL, categories: ['🌙', '✨'], id: 'moonlight-take', quality: 90 });
      return sock.sendMessage(jid, { sticker: await sticker.toBuffer() }, { quoted: m });
    } catch (error) {
      console.error('[TAKE ERROR]', error);
      return reply('❌ Failed to brand that sticker.');
    }
  },
});
