const fs = require('fs');
const { downloadMedia } = require('../../handlers/media');
const { uploadToCatbox, uploadWithFallback } = require('../../utils/uploader');

function getQuotedMediaMessage(message) {
  const quotedMessage = message?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  return quotedMessage ? { message: quotedMessage } : message;
}

moon({
  name: 'url',
  aliases: ['tourl', 'catbox'],
  category: 'general',
  description: 'Upload an image or video and return a short direct URL with multiple fallbacks.',
  usage: '.url (send with media or reply to media)',
  async execute(sock, jid, sender, args, m, { reply }) {
    let media = null;
    try {
      const sourceMessage = getQuotedMediaMessage(m);
      media = await downloadMedia(sock, sourceMessage);
      if (!media) return reply('❌ Send `.url` with an image or video, or reply to an image/video with `.url`.');
      if (media.buffer.length > 200 * 1024 * 1024) return reply('❌ This file is too large for an anonymous upload. Please use a smaller image or video.');
      const extension = String(media.mime || '').split('/')[1]?.split(';')[0] || 'bin';
      let result;
      try {
        result = { provider: 'Catbox (stable direct URL)', url: await uploadToCatbox(media.buffer, { filename: `moonlight-${Date.now()}.${extension}` }) };
      } catch {
        result = await uploadWithFallback(media.buffer, { filename: `moonlight-${Date.now()}.${extension}` });
      }
      return reply(`☆¤◇ *UPLOAD COMPLETE* ◇¤☆\n\n□ *Provider:* ${result.provider}\n◇ *Direct URL:*\n${result.url}\n\n> Save this direct URL in your config image setting. Catbox links are intended for long-term direct hosting.`);
    } catch (error) {
      console.error('[URL COMMAND]', error.message);
      return reply(`❌ Upload failed: ${error.message || 'please try again with a supported image or video.'}`);
    } finally {
      if (media?.path) fs.promises.unlink(media.path).catch(() => {});
    }
  },
});
