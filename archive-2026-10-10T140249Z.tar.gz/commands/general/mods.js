const User = require('../../models/User');
const config = require('../../config');

// Active support requests are intentionally short-lived and in-memory.
// They track only the support-message IDs needed for reaction feedback.
const supportRequests = new Map();
const REQUEST_TTL = 6 * 60 * 60 * 1000;

function normaliseJid(user) {
  const raw = String(user?.whatsappNumber || user?.phoneNumber || user?.userId || '').trim();
  if (!raw) return '';
  if (raw.includes('@')) return raw;
  return `${raw.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
}

function staffMention(user) {
  const jid = normaliseJid(user);
  return { jid, text: `么⁩ @${String(jid).split('@')[0]}` };
}

function getContext(msg) {
  return msg?.message?.extendedTextMessage?.contextInfo
    || msg?.message?.imageMessage?.contextInfo
    || msg?.message?.videoMessage?.contextInfo
    || msg?.message?.documentMessage?.contextInfo
    || msg?.message?.stickerMessage?.contextInfo
    || {};
}

function rememberRequest(originalKey, responseKey, requester, jid) {
  const request = {
    groupJid: jid,
    requester,
    reactionKey: originalKey || responseKey,
    responders: new Set(),
    createdAt: Date.now(),
  };
  for (const key of [originalKey?.id, responseKey?.id].filter(Boolean)) supportRequests.set(String(key), request);
  setTimeout(() => {
    for (const [key, value] of supportRequests) if (value === request) supportRequests.delete(key);
  }, REQUEST_TTL).unref?.();
}

async function trackSupportReply(sock, msg, sender) {
  try {
    const context = getContext(msg);
    const quotedId = context.stanzaId;
    if (!quotedId) return false;
    const request = supportRequests.get(String(quotedId));
    if (!request || Date.now() - request.createdAt > REQUEST_TTL) return false;

    const mod = await User.findOne({
      whatsappNumber: sender,
      role: 'Mod',
    }).select('whatsappNumber phoneNumber userId role').lean();
    if (!mod) return false;
    const modJid = normaliseJid(mod) || String(sender);
    if (request.responders.has(modJid)) return false;
    request.responders.add(modJid);

    const count = request.responders.size;
    const reaction = count === 1 ? '✅️' : count === 2 ? '🟡' : '🔴';
    await sock.sendMessage(request.groupJid, {
      react: { text: reaction, key: request.reactionKey },
    });
    return true;
  } catch (error) {
    console.error('[MODS REPLY TRACKER]', error.message);
    return false;
  }
}

moon({
  name: 'mods',
  category: 'general',
  description: 'Show the Moonlight Haven support team',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const staff = await User.find({ role: { $in: ['Owner', 'True Owner', 'Mod', 'Guardian'] } }).lean();
      const mods = staff.filter((user) => user.role === 'Mod');
      const guards = staff.filter((user) => user.role === 'Guardian');
      const owners = staff.filter((user) => user.role === 'Owner' || user.role === 'True Owner' || user.isTrueOwner === true);
      const mentions = [];
      const addMention = (user) => {
        const entry = staffMention(user);
        if (entry.jid && !mentions.includes(entry.jid)) mentions.push(entry.jid);
        return entry.text;
      };
      const render = (users, empty) => users.length ? users.map((user) => addMention(user)).join('\n') : empty;

      // Owners are included in `mentions` only: they are notified without being shown in the text.
      for (const owner of owners) addMention(owner);

      const caption = `       [ *SUPPORT TEAM* ]
❖─── 𝚳OO𝚴𝐋𝚰𝐆𝚮𝚻

 [么⁩]──[ *MODS* ]──┈ ⳹
${render(mods, '么⁩ None')}
[么⁩]──[ *GUARDS* ]─┈ ⳹
${render(guards, '么⁩ None')}
 [么⁩]─────────┈ ⳹
> *INFO:* our team will be with you in a short moment. Tell us your error while replying to this message if support does not come in *5 minutes*.
Try reading our \.rules`;

      const payload = { mentions };
      const sent = config.MENU_IMAGE
        ? await sock.sendMessage(jid, { image: { url: config.MENU_IMAGE }, caption, ...payload }, { quoted: m })
        : await sock.sendMessage(jid, { text: caption, ...payload }, { quoted: m });
      rememberRequest(m?.key, sent?.key, sender, jid);
      return sent;
    } catch (err) {
      console.error('mods error:', err);
      return reply('❌ Failed to load the support team list.');
    }
  },
});

module.exports = { staffMention, trackSupportReply };
