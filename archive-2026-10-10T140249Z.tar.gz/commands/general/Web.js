const config = require('../../config.js');
const User = require('../../models/User');
const bcrypt = require('bcryptjs');
const { getOTP } = require('../../utils/otpStore');
const { sendLinkPreview } = require('../../utils/linkPreview');

// .webcp — Create web password (only if user has NONE; otherwise redirect to web)
moon({
  name: 'webcp',
  aliases: ['setwebpass'],
  category: 'website',
  description: 'Create your website password. (Use the web to change it later.)',
  usage: '.webcp <password>',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const userNumber = sender.replace(/[^0-9]/g, '');
      const password = args.join(' ').trim();

      if (!password) {
        return reply(
          '❌ *Usage:* `.webcp <password>`\n\n' +
          '> Your password must be at least 6 characters.\n' +
          '> If you already have a password, visit the website to change it using *Forgot Password*.'
        );
      }

      if (password.length < 6) {
        return reply('❌ Password must be at least 6 characters long.');
      }

      let user = await User.findOne({
        $or: [
          { whatsappNumber: sender },
          { userId: userNumber },
          { moonId: userNumber },
          { phoneNumber: userNumber }
        ]
      });

      if (!user) {
        return reply(
          '❌ You are not registered yet.\n' +
          '> Use `.reg` to create your account first.'
        );
      }

      // If user already has a password, block and redirect to web
      if (user.webPassword) {
        return reply(
          '🔒 *You already have a web password set.*\n\n' +
          '> To change your password, use the *Forgot Password* option on the website.\n' +
          '> You can reset it via OTP — request it on the web, then use `.otp` here.'
        );
      }

      // Ensure moonId is set to phone number
      user.moonId = userNumber;
      user.webPassword = await bcrypt.hash(password, 10);
      user.webPasswordUpdatedAt = new Date();
      await user.save();

      // Delete the command message for security
      try {
        await sock.sendMessage(jid, { delete: m.key });
      } catch (_) {}

      const webUrl = `${config.WEB}/login`;
      return await sendLinkPreview(sock, jid, m, webUrl,
        '🌙 *MOONLIGHT HAVEN*\n' +
        '─────────────『❀』\n' +
        '✅ *Web password created successfully!*\n\n' +
        '🆔 *Moon ID:* `' + user.moonId + '`\n' +
        '─────────────『❀』\n' +
        '> Use your *Moon ID* and password to log in on the website.\n' +
        '> To change your password later, use *Forgot Password* on the web.\n' + webUrl,
        { mentions: [sender] });

    } catch (err) {
      console.error('[WEBCP ERROR]', err);
      return reply('❌ Failed to save your website password.');
    }
  }
});

// .webp / .moonid — Show your web account info
moon({
  name: 'webp',
  aliases: ['moonid'],
  category: 'website',
  description: 'Shows your Moonlight Haven website account.',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const userNumber = sender.replace(/[^0-9]/g, '');

      let user = await User.findOne({
        $or: [
          { whatsappNumber: sender },
          { userId: userNumber },
          { moonId: userNumber },
          { phoneNumber: userNumber }
        ]
      });

      if (!user) {
        return reply(
          '❌ You do not have an account.\n' +
          '> Use `.reg` to register, then `.webcp <password>` to set your web password.'
        );
      }

      if (!user.moonId || user.moonId.includes('@')) {
        user.moonId = userNumber;
        await user.save();
      }

      return reply(
        '🌙 *MOONLIGHT HAVEN WEB*\n' +
        '─────────────『❀』\n' +
        '🆔 *MOON ID:*\n' +
        '`' + user.moonId + '`\n' +
        '🔐 *Website Password:*\n' +
        (user.webPassword ? '✅ Created' : '❌ Not Created') + '\n' +
        '─────────────『❀』\n' +
        '> Use your Moon ID and password to log in on the website.\n' +
        '> *TIP:* Use `.webcp <password>` to create your password.\n' +
        '> To change password, use *Forgot Password* on the web.'
      );
    } catch (err) {
      console.error('[WEBP ERROR]', err);
      return reply('❌ Failed to load your website profile.');
    }
  }
});

// .otp — Get your OTP code for password reset (requested from the web)
moon({
  name: 'otp',
  category: 'website',
  description: 'Get your OTP code for password reset on the website.',
  usage: '.otp',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const userNumber = sender.replace(/[^0-9]/g, '');
      const user = await User.findOne({
        $or: [
          { whatsappNumber: sender },
          { userId: userNumber },
          { phoneNumber: userNumber },
          { moonId: userNumber },
        ],
      });
      if (!user?.moonId) {
        return reply('❌ Your WhatsApp account is not linked to a Moon ID yet. Use `.webp` to check your account.');
      }

      const otpCode = await getOTP(user.moonId);
      if (!otpCode) {
        return reply(
          '❌ *No active OTP request found.*\n\n' +
          '> Open *Forgot Password* on the website, enter your Moon ID, and request an OTP first.\n' +
          '> Then return here and use `.otp` to receive it through this linked account.'
        );
      }

      const timeLeft = user.otpExpires ? Math.max(0, Math.ceil((new Date(user.otpExpires).getTime() - Date.now()) / 1000)) : 0;

      try {
        await sock.sendMessage(jid, { delete: m.key });
      } catch (_) {}

      return await sock.sendMessage(jid, {
        text:
          '🔐 *MOONLIGHT HAVEN — OTP*\n' +
          '─────────────『❀』\n' +
          '🔑 *Your OTP Code:*\n' +
          '`' + otpCode + '`\n' +
          '⏳ *Expires in:* ' + timeLeft + 's\n' +
          '─────────────『❀』\n' +
          '> Enter this code on the website to reset your password.\n' +
          '> *Do NOT share this code with anyone.*',
      }, { quoted: m });

    } catch (err) {
      console.error('[OTP ERROR]', err);
      return reply('❌ Failed to retrieve your OTP.');
    }
  }
});
