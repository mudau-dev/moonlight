const config = require('../../config.js');
const crypto = require('crypto');
const User = require('../../models/User');
const { getRealUserIdentity } = require('../../utils/whatsappIdentity');

const REGISTRATION_CODE_TTL_MS = 10 * 60 * 1000;

function hash(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

async function findUserByPhone(phoneJid, phoneNumber) {
  return User.findOne({
    $or: [
      { whatsappNumber: phoneJid },
      { phoneNumber },
      { userId: phoneNumber },
      { moonId: phoneNumber },
    ],
  });
}

function registrationUrl() {
  const web = String(config.WEB || '').replace(/\/$/, '');
  return web ? `${web}/register` : '/register';
}

moon({
  name: 'register',
  aliases: ['reg'],
  category: 'general',
  description: 'Get the verification code for a pending Moonlight web registration.',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const identity = await getRealUserIdentity(sock, sender);
      if (!identity) return reply('❌ Your WhatsApp LID could not be resolved to a real phone number. No account was created. Please try again.');
      const { phoneJid, phoneNumber } = identity;
      const user = await findUserByPhone(phoneJid, phoneNumber);

      if (user?.moonId === phoneNumber) {
        return reply(`🔗 ${registrationUrl()}`);
      }

      if (!user || user.registrationStatus !== 'awaiting_bot') {
        return reply(`🔗 ${registrationUrl()}`);
      }

      const code = String(crypto.randomInt(100000, 1_000_000));
      user.whatsappNumber = phoneJid;
      user.phoneNumber = phoneNumber;
      user.userId = phoneNumber;
      if (!user.username || user.username === 'Unknown') user.username = pushName || 'Unknown';
      user.registrationStatus = 'awaiting_web_code';
      user.registrationCodeHash = hash(code);
      user.registrationCodeExpiresAt = new Date(Date.now() + REGISTRATION_CODE_TTL_MS);

      try {
        const profilePicture = await sock.profilePictureUrl(phoneJid, 'image');
        if (profilePicture) user.avatarUrl = profilePicture;
      } catch { /* A profile picture is optional. */ }

      await user.save();
      return reply(`*haven pass code:*\n${code}`);
    } catch (error) {
      console.error('[REG ERROR]', error);
      return reply('❌ Failed to create a registration verification code. Please try again.');
    }
  },
});
