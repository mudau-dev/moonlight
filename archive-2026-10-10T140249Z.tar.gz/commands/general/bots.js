const Bot = require('../../models/athers/Bot');

const FRESH_MS = 75_000;
const DISPLAY_ORDER = ['yumeko', 'cid', 'elaina', 'frieren', 'lain', 'oreki', 'rem', 'rimuru', 'saber'];

function isFresh(record) {
  if (!record?.lastSeen) return false;
  const age = Date.now() - new Date(record.lastSeen).getTime();
  return age >= 0 && age < FRESH_MS;
}

moon({
  name: 'bots',
  aliases: ['botstatus', 'botlist'],
  category: 'general',
  description: 'Show the live Moonlight bot network status from configured database records.',
  usage: '.bots',
  async execute(sock, jid, sender, args, m, { reply }) {
    const raw = await Bot.find({ disabled: { $ne: true } }).select('name lastSeen').lean();
    const byName = new Map();
    for (const record of raw) {
      const key = String(record.name || '').trim().toLowerCase();
      if (!key) continue;
      const previous = byName.get(key);
      if (!previous || new Date(record.lastSeen || 0) > new Date(previous.lastSeen || 0)) byName.set(key, record);
    }
    const records = [...byName.values()];
    records.sort((a, b) => {
      const ai = DISPLAY_ORDER.indexOf(String(a.name).toLowerCase());
      const bi = DISPLAY_ORDER.indexOf(String(b.name).toLowerCase());
      return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi) || String(a.name).localeCompare(String(b.name));
    });
    if (!records.length) return reply('📋 No bots are configured. A True Owner can use `.lbot add <name>`.');
    const lines = ['└┬─「 *MOONLIGHT BOTS* 」', '   │'];
    for (const record of records) lines.push(`   ├${isFresh(record) ? '🟢' : '🔴'} *${String(record.name).toUpperCase()}*${isFresh(record) ? '' : ' · offline'}`);
    lines.push('   └─────────❖');
    return reply(lines.join('\n'));
  },
});
