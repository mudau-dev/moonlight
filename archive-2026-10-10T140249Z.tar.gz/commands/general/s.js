const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { downloadMediaMessage } = require('../../utils/baileys');
const { getRealUserIdentity, normalizePhoneJid } = require('../../utils/whatsappIdentity');
const { createCanvas, loadImage } = require('canvas');
const User = require('../../models/User');

const MAX_IMAGE_BYTES = 12 * 1024 * 1024;
const MAX_VIDEO_BYTES = 18 * 1024 * 1024;
const MAX_VIDEO_SECONDS = 5;

function unwrapMessage(message) {
  if (!message) return null;
  if (message.ephemeralMessage?.message) return unwrapMessage(message.ephemeralMessage.message);
  if (message.viewOnceMessage?.message) return unwrapMessage(message.viewOnceMessage.message);
  if (message.viewOnceMessageV2?.message) return unwrapMessage(message.viewOnceMessageV2.message);
  if (message.documentWithCaptionMessage?.message) return unwrapMessage(message.documentWithCaptionMessage.message);
  return message;
}

function getContext(message) {
  const root = unwrapMessage(message?.message);
  return root?.extendedTextMessage?.contextInfo ||
    root?.imageMessage?.contextInfo ||
    root?.videoMessage?.contextInfo ||
    root?.stickerMessage?.contextInfo || {};
}

function getMediaType(message) {
  if (!message) return null;
  if (message.imageMessage) return 'imageMessage';
  if (message.videoMessage) return 'videoMessage';
  if (message.stickerMessage) return 'stickerMessage';
  return null;
}

function buildQuotedMessage(jid, sender, context, quoted) {
  if (!context?.stanzaId || !quoted) return null;
  return {
    message: quoted,
    key: {
      remoteJid: jid,
      id: context.stanzaId,
      fromMe: false,
      participant: context.participant || context.quotedParticipant || sender,
    },
  };
}

function runFfmpeg(args, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const child = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', ...args]);
    let stderr = '';
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new Error('sticker conversion timeout'));
    }, timeoutMs);
    child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
    child.on('error', (error) => { clearTimeout(timer); reject(error); });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) resolve();
      else reject(new Error(stderr.trim() || `ffmpeg exited with code ${code}`));
    });
  });
}

async function convertToWebp(buffer, type) {
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'moon-sticker-'));
  const input = path.join(tempDir, type === 'videoMessage' ? 'input.mp4' : 'input.bin');
  const output = path.join(tempDir, 'sticker.webp');
  try {
    await fs.writeFile(input, buffer);
    const filter = 'scale=512:512:flags=lanczos:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black@0,format=rgba';
    const args = type === 'videoMessage'
      ? ['-i', input, '-t', String(MAX_VIDEO_SECONDS), '-an', '-vf', filter, '-c:v', 'libwebp', '-q:v', '70', '-loop', '0', output]
      : ['-i', input, '-frames:v', '1', '-vf', filter, '-c:v', 'libwebp', '-lossless', '1', '-compression_level', '6', output];
    await runFfmpeg(args, type === 'videoMessage' ? 45000 : 30000);
    const result = await fs.readFile(output);
    if (!result.length) throw new Error('empty sticker output');
    return result;
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true }).catch(() => {});
  }
}


function textOf(message) { const root=unwrapMessage(message)||{}; return String(root.conversation||root.extendedTextMessage?.text||root.imageMessage?.caption||root.videoMessage?.caption||'').trim(); }
function digits(value) { return String(value||'').replace(/\D/g,''); }
async function findDbUser(sock, identity, alternate) {
  const raw=String(identity||'').trim(); if(!raw) return null;
  const resolved=await getRealUserIdentity(sock,raw,alternate).catch(()=>null);
  const values=[raw,alternate,resolved?.phoneJid,resolved?.phoneNumber,normalizePhoneJid(raw)].filter(Boolean);
  const phoneValues=[...new Set(values.flatMap(value=>{const d=digits(value);return d&&!String(value).endsWith('@lid')?[d]:[]}))];
  const clauses=[]; for(const value of values) clauses.push({whatsappNumber:value},{userId:value},{phoneNumber:value},{moonId:value},{lid:value});
  for(const number of phoneValues) clauses.push({whatsappNumber:`${number}@s.whatsapp.net`},{phoneNumber:number},{userId:number},{moonId:number});
  return clauses.length?User.findOne({$or:clauses}).lean().catch(()=>null):null;
}
function wrapText(text,max=34) { const words=String(text).split(/\s+/),lines=[];let line='';for(const word of words){if((line+' '+word).trim().length>max&&line){lines.push(line);line=word;}else line=(line+' '+word).trim();}if(line)lines.push(line);return lines.slice(0,7); }
async function renderMessageSticker(sock,sender,context,text) {
  const identity=context.participant||context.participantAlt||context.quotedParticipant||context.remoteJidAlt||(context.quotedMessage?.key?.fromMe?(sock.user?.id||sender):sender);
  const alternate=context.participantAlt||context.remoteJidAlt||context.quotedParticipant||null;
  const user=await findDbUser(sock,identity,alternate);
  const candidate=user?.name||user?.displayName||user?.username; const name=/^\d+$/.test(String(candidate||''))||['unknown','whatsapp user'].includes(String(candidate||'').trim().toLowerCase())?'WhatsApp User':String(candidate||'WhatsApp User').trim();
  let avatarUrl=user?.profileImage||user?.avatarUrl||user?.profilePicture||null;
  if(!avatarUrl){for(const id of [user?.whatsappNumber,identity,alternate].filter(Boolean)){try{avatarUrl=await sock.profilePictureUrl(id,'image');if(avatarUrl)break;}catch{}}}
  const canvas=createCanvas(1024,1024),c=canvas.getContext('2d');c.scale(2,2);const bg=c.createLinearGradient(0,0,512,512);bg.addColorStop(0,'#111827');bg.addColorStop(1,'#020617');c.fillStyle=bg;c.fillRect(0,0,512,512);c.fillStyle='rgba(255,255,255,.05)';for(let x=-60;x<580;x+=32)for(let y=-60;y<580;y+=32){c.beginPath();c.arc(x,y,1.5,0,Math.PI*2);c.fill();}
  c.fillStyle='#0b141a';c.roundRect(40,42,432,428,25);c.fill();c.fillStyle='#202c33';c.roundRect(60,64,392,342,18);c.fill();c.fillStyle='#075e54';c.roundRect(78,86,356,54,14);c.fill();let avatar=null;try{if(avatarUrl)avatar=await loadImage(avatarUrl);}catch{}c.save();c.beginPath();c.arc(108,113,19,0,Math.PI*2);c.clip();if(avatar)c.drawImage(avatar,89,94,38,38);else{c.fillStyle='#64748b';c.fill();}c.restore();c.fillStyle='#e9edef';c.font='bold 16px sans-serif';c.fillText(name.slice(0,25),140,115);c.fillStyle='#b7c8c8';c.font='11px sans-serif';c.fillText('WhatsApp message',140,132);
  const lines=wrapText(text,29),h=58+lines.length*25,y=168;c.fillStyle='#fff';c.roundRect(96,y,300,h,15);c.fill();c.fillStyle='#111827';c.font='18px sans-serif';lines.forEach((line,i)=>c.fillText(line,112,y+28+i*25));c.fillStyle='#8696a0';c.font='10px sans-serif';c.fillText('3:19 am',346,y+h-12);c.fillStyle='#34b7f1';c.font='13px sans-serif';c.fillText('✓✓',380,y+h-12);c.fillStyle='#a7f3d0';c.font='bold 13px sans-serif';c.fillText('MOONLIGHT HAVEN',190,446);return canvas.toBuffer('image/png');
}

moon({
  name: 's',
  aliases: ['sticker', 'stiker'],
  category: 'general',
  description: 'Convert an image, short video, or sticker to a sticker',
  usage: '.s (reply to an image/video/sticker, or caption media with .s)',
  cooldown: 5,
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const ctx = getContext(m);
      const quoted = unwrapMessage(ctx?.quotedMessage);
      const ownMessage = unwrapMessage(m?.message);
      const quotedType = getMediaType(quoted);
      const ownType = getMediaType(ownMessage);
      const type = quotedType || ownType;
      if (!type) { const text=textOf(quoted)||textOf(m); if(!text)return reply('❌ Reply to a message or media to make a sticker.'); const png=await renderMessageSticker(sock,sender,ctx,text); const sticker=await convertToWebp(png,'imageMessage'); return sock.sendMessage(jid,{sticker},{quoted:m}); }

      const targetMessage = quotedType ? quoted : ownMessage;
      const media = targetMessage?.[type];
      if (!media) return reply('❌ I could not read that media. Please send it again.');

      const messageToDownload = quotedType ? buildQuotedMessage(jid, sender, ctx, quoted) : m;
      if (!messageToDownload) return reply('❌ I could not locate the replied media. Please reply to it again.');
      const buffer = await Promise.race([
        downloadMediaMessage(messageToDownload, 'buffer', {}, { logger: { level: 'silent' }, reuploadRequest: sock.updateMediaMessage }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('media download timeout')), 30000)),
      ]);
      if (!Buffer.isBuffer(buffer) || buffer.length < 50) return reply('❌ Failed to download that media. Please resend it and try again.');
      const maxBytes = type === 'videoMessage' ? MAX_VIDEO_BYTES : MAX_IMAGE_BYTES;
      if (buffer.length > maxBytes) return reply('❌ That media is too large. Please use a smaller file.');

      const stickerBuffer = await convertToWebp(buffer, type);
      return sock.sendMessage(jid, { sticker: stickerBuffer }, { quoted: m });
    } catch (error) {
      console.error('[STICKER CMD ERROR]', error);
      return reply('❌ I could not create the sticker. Use a valid image or a video under 10 seconds and try again.');
    }
  },
});
