const config = require('../../config');
moon({
  name: 'casinos',
  category: 'general',
  description: 'View Moonlight Haven casino groups',

  async execute(sock, jid, sender, args, m, { reply }) {
    try {
        
        const casino1 = config.CASINO_LINK1;
        const casino2 = config.CASINO_LINK2;

      const intro = `┌─『❀』
│ 「 𝚳OO𝚴𝐋𝚰𝐆𝚮𝚻 」
└┬『❀』 「 CASINOS 」
  │────────────┈ ⳹
> These are the only official Moonlight Haven casino groups. Casino groups are not general-chat or RPG groups.`;

      return reply(`${intro}\n\n🎰 *MOONLIGHT CASINO I*\n${casino1}\n\n🎰 *MOONLIGHT CASINO II*\n${casino2}`);

    } catch (err) {
      console.error('casinos error:', err);
      return reply('❌ Failed to load casino groups.');
    }
  }
});