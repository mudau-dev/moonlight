/**
 * Moonlight Haven official rules.
 *
 * `.rules list`       — category index
 * `.rules <number>`   — one detailed category
 * `.rules`            — all rules
 */
const RULE_SECTIONS = [
  {
    title: '🛡️ COMMUNITY SAFETY & RESPECT',
    rules: [
      'Treat every player, staff member, and guest with respect. Harassment, bullying, hate speech, threats, sexual harassment, impersonation, doxxing, and targeted abuse are prohibited in every Moonlight Haven space.',
      'Keep shared chats and bot interactions safe for a broad community. Do not post NSFW material, graphic gore, malware, scam links, leaked private content, or content intended to frighten or humiliate another person.',
      'Do not use guild rivalry, casino losses, Legacy battles, Pokémon trades, or game results as reasons to harass another player. Competitive play ends with the match or event.',
      'If you see dangerous, exploitative, or abusive behaviour, report it to staff with context. Do not organise public retaliation, witch hunts, or callout campaigns.'
    ]
  },
  {
    title: '🤖 BOT USAGE, SPAM & ACCOUNT SECURITY',
    rules: [
      'Use commands at a reasonable pace. Command flooding, repeated mentions, message spam, and attempts to overload the bot can result in temporary mutes, cooldowns, or suspension.',
      'Never share pairing codes, login details, session files, recovery information, or personal information. Staff will not ask you for sensitive credentials in order to help with a bot command.',
      'Do not force-add the bot to groups. The bot may leave unauthorised groups and the account responsible can be suspended. Ask an authorised Owner or Mod to add the bot through the approved process.',
      'Do not attempt to bypass access restrictions, registration requirements, category locks, cooldowns, bans, or moderation actions with alternate accounts or automation.'
    ]
  },
  {
    title: '💰 ECONOMY, SHOP & REAL-MONEY TRADING',
    rules: [
      'Coins, Manas, licenses, cards, Pokémon, inventory items, and all other Moonlight Haven assets are virtual game property. They have no cash value and may not be exchanged for real money, gift cards, crypto, accounts, or external services.',
      'Do not use alternate accounts, scripts, macros, farms, duplicated transactions, chargeback tricks, or loopholes to obtain daily rewards, shop items, currency, XP, or event benefits.',
      'Report economy bugs immediately. Keeping, transferring, hiding, or spending assets created by an exploit may lead to balance correction, inventory removal, rollback, suspension, or a permanent ban.',
      'Shop purchases are final when confirmed by the system. Staff may correct clearly broken transactions but do not refund ordinary misclicks, gambling losses, or purchases made without checking the item description.'
    ]
  },
  {
    title: '🎰 CASINO & GAMBLING',
    rules: [
      'Casino games are entertainment only. Every bet, win, and loss is governed by the displayed bot logic and applicable usage limits. Do not use scripts, timing tools, packet manipulation, or bugs to influence outcomes.',
      'Do not pressure, threaten, or scam users over loans, gifts, wagers, or losses. There is no staff-backed debt collection and no player is required to transfer coins to another user.',
      'Daily casino-use limits and cooldowns exist to protect the economy and keep play fair. Do not evade them with alternate accounts, shared accounts, or command automation.',
      'Repeated attempts to exploit gambling systems, manipulate event outcomes, or launder unfair gains can result in loss reversal, economy restrictions, account suspension, and removal from community events.'
    ]
  },
  {
    title: '⚔️ LEGACY RPG — PLAY FAIR',
    rules: [
      'Legacy progress, battle mana, items, ranks, and character statistics must be earned through intended gameplay. Macros, bots, scripts, auto-clickers, account sharing, or any unattended farming are prohibited.',
      'Do not exploit battle bugs, duplicate items, bypass timers, force invalid combat states, or coordinate staged losses to farm wins, XP, gold, achievements, or rankings.',
      'Legacy trades and gifts must be truthful. Misrepresenting an item, using a fake trade promise, or attempting to obtain another player’s account or private information is treated as scamming.',
      'Report unintended Legacy behaviour before repeatedly using it. Staff may reset affected characters, remove items, reverse rewards, or suspend accounts to restore a fair game state.'
    ]
  },
  {
    title: '⚪ POKÉMON, CARDS & COLLECTION SYSTEMS',
    rules: [
      'Pokémon catches, card collections, Poké Balls, trading systems, and collection rankings must be obtained through normal commands and legitimate gameplay. Do not automate catching, searching, trading, or claiming rewards.',
      'Do not abuse encounter timing, duplicate catches, invalid names, move bugs, market loopholes, or transfer errors. If a Pokémon or card is obtained in an unintended way, stop using it and report the issue.',
      'All trades must be clear and voluntary. Do not swap items after an agreement, impersonate a trader, use misleading screenshots, or demand real-world payment for a virtual Pokémon or card.',
      'Staff may remove duplicated or exploited collectibles, correct inaccurate inventories, cancel abusive trades, and apply penalties where collection systems are manipulated.'
    ]
  },
  {
    title: '🏰 GUILDS, LEADERSHIP & COMPETITION',
    rules: [
      'Guild names, descriptions, icons, backgrounds, recruitment posts, and member conduct must follow all community rules. Inappropriate, hateful, explicit, stolen, or misleading guild content can be removed without notice.',
      'Guild Owners and Guards must use invitations, join requests, removals, and role changes responsibly. Do not recruit through harassment, run fake giveaways, threaten members, or misuse permissions to target users.',
      'Do not use alts to fill a guild, inflate member counts, farm Guild XP, evade a guild ban, manipulate rankings, or collude with another guild to stage results.',
      'Guild competition must remain respectful. Staff may remove abusive guild content, reverse exploit-based progress, dissolve a guild, or suspend leaders and members involved in serious misconduct.'
    ]
  },
  {
    title: '⚖️ REPORTS, APPEALS & ENFORCEMENT',
    rules: [
      'Consequences depend on severity, evidence, and previous behaviour. Possible actions include a warning, mute, cooldown, item or currency removal, progress rollback, guild action, temporary suspension, or permanent account suspension.',
      'Do not harass staff or repeatedly reopen the same appeal after a decision. You may submit a calm appeal through the official support route with relevant information, then allow staff time to review it.',
      'False reports, fabricated evidence, impersonating staff, or encouraging others to break rules are violations themselves. Be honest and preserve the safety of the reporting process.',
      'By using the bot, website, or any Moonlight Haven feature, you agree to these rules and to reasonable enforcement needed to protect players, the economy, and fair competition.'
    ]
  }
];

function renderSection(section, index) {
  return [
    `*${index + 1}. ${section.title}*`,
    ...section.rules.map((rule, ruleIndex) => `${ruleIndex + 1}. ${rule}`),
  ].join('\n');
}

moon({
  name: 'rules',
  aliases: ['rule'],
  category: 'general',
  description: 'Read the official Moonlight Haven rules.',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const sub = String(args[0] || '').toLowerCase();

      if (sub === 'list') {
        const list = RULE_SECTIONS.map((section, index) => `${index + 1}. ${section.title}`).join('\n');
        return reply(`📜 *MOONLIGHT HAVEN — RULES INDEX*\n━━━━━━━━━━━━━━━━━━━━\n${list}\n\n> Use \`.rules <number>\` to read one section, or \`.rules\` to read all rules.`);
      }

      const index = Number.parseInt(sub, 10);
      if (Number.isInteger(index) && RULE_SECTIONS[index - 1]) {
        return reply(`📜 *MOONLIGHT HAVEN — OFFICIAL RULES*\n━━━━━━━━━━━━━━━━━━━━\n\n${renderSection(RULE_SECTIONS[index - 1], index - 1)}\n\n⚠️ Violations may lead to warnings, reversals, cooldowns, suspension, or a permanent ban.`);
      }

      const allRules = RULE_SECTIONS.map(renderSection).join('\n\n━━━━━━━━━━━━━━━━━━━━\n\n');
      return reply(`📜 *MOONLIGHT HAVEN — OFFICIAL RULES*\n━━━━━━━━━━━━━━━━━━━━\n\n${allRules}\n\n━━━━━━━━━━━━━━━━━━━━\n⚠️ *Important:* Rules apply to the bot, website, casino, Legacy, Pokémon, guilds, cards, and every official Moonlight Haven community space. If you are unsure whether an action is allowed, ask staff before doing it.`);
    } catch (error) {
      console.error('[RULES CMD ERROR]', error);
      return reply('❌ Failed to load the official rules.');
    }
  },
});
