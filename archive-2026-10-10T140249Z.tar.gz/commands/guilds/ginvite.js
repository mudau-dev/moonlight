/**
 * commands/guilds/ginvite.js
 *
 * .ginvite @user
 *
 * Available to: guild owner + guards (+ regular members if guild.allowMemberInvite = true)
 * Sends the invite IN THE GROUP (not DM) to avoid bot bans.
 * Also shows the guild image in the invite message.
 */
const Guild       = require('../../models/athers/Guild');
const GuildInvite = require('../../models/athers/GuildInvite');
const User        = require('../../models/User');
const { findOrCreateWhatsApp } = require('../../database/users');
const { resolveMessageTarget, phoneNumberFromValue } = require('../../utils/adminIdentity');
const { generateGuildProfile } = require('../../utils/guildGen');
const WEB = process.env.WEB || '';

function userNumber(jid) {
  return (jid || '').split('@')[0];
}

async function resolveUsername(id) {
  if (!id) return 'Unknown';
  const clean = String(id).replace(/@s\.whatsapp\.net|@lid/g, '');
  try {
    const user = await User.findOne({
      $or: [
        { moonId: clean },
        { whatsappNumber: `${clean}@s.whatsapp.net` },
        { whatsappNumber: clean },
        { userId: clean },
        { phoneNumber: clean },
      ],
    });
    if (user) return user.username?.trim() || clean;
  } catch {}
  return clean;
}

moon({
  name: 'ginvite',
  aliases: ['guildinvite', 'gi'],
  category: 'guilds',
  description: 'Invite a user to your guild (owner/guards, or all members if allowed)',
  usage: '.ginvite @user',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const senderDoc = await findOrCreateWhatsApp(sender, pushName, true);
      if (!senderDoc) return reply('❌ Your phone identity could not be resolved.');
      const senderUser = senderDoc.toObject();
      const senderNumber = phoneNumberFromValue(sender);
      const senderId = senderNumber || senderUser.phoneNumber || senderUser.userId || senderUser.moonId;

      // Find sender's guild
      const ids = [...new Set([
        senderNumber,
        senderUser.phoneNumber,
        senderUser.userId,
        senderUser.moonId,
        senderUser.whatsappNumber?.split('@')[0],
      ].filter(Boolean))];
      const guild = await Guild.findOne({ members: { $in: ids } });

      if (!guild) {
        return reply('❌ You are not in a guild.');
      }

      // Permission check: owner, guard, or allowMemberInvite
      const isOwner = guild.ownerId === senderId || phoneNumberFromValue(guild.ownerId) === senderNumber;
      const isGuard = (guild.guards || []).some((value) => value === senderId || phoneNumberFromValue(value) === senderNumber);
      if (!isOwner && !isGuard && !guild.allowMemberInvite) {
        return reply('❌ Only guild owners and guards can invite members.');
      }

      // Get target
      const target = await resolveMessageTarget(sock, m, args);
      if (!target) {
        return reply('❌ Usage: `.ginvite @user`\nMention the user you want to invite.');
      }
      if (target === sender) return reply('❌ You cannot invite yourself.');

      const targetJid = target;
      const targetNumber = phoneNumberFromValue(targetJid);
      const targetDoc = await findOrCreateWhatsApp(targetJid, 'Unknown', true);
      if (!targetDoc) return reply('❌ The invited user could not be resolved by phone number.');
      const targetUser = targetDoc.toObject();
      const targetId = targetNumber || targetUser.phoneNumber || targetUser.userId || targetUser.moonId;

      // Already in a guild?
      const targetInGuild = await Guild.findOne({ members: { $in: [targetId, targetNumber] } });
      if (targetInGuild) {
        const tName = await resolveUsername(targetId);
        return reply(`❌ *${tName}* is already in a guild (*${targetInGuild.name}*).`);
      }

      // Banned?
      const isBanned = (guild.banned || []).some((value) => value === targetId || value === targetNumber || phoneNumberFromValue(value) === targetNumber);
      if (isBanned) {
        return reply('❌ This user is banned from your guild.');
      }

      // Check capacity: every guild is capped at 25 members.
      const maxMembers = Math.min(25, Math.max(2, Number(guild.maxMembers) || 25));
      if (guild.members.length >= maxMembers) {
        return reply(`❌ Your guild is full! (${guild.members.length}/${maxMembers} members)`);
      }

      // Create invite record
      await GuildInvite.create({
        guildId:   guild._id,
        guildName: guild.name,
        ownerId:   senderId,
        ownerName: senderUser.username || pushName || 'Unknown',
        targetId,
      });

      const joinLink  = WEB ? `${WEB}/guild/${guild._id}` : '(Visit the website to join)';
      const ownerName = await resolveUsername(senderId);
      const targetName = await resolveUsername(targetId);

      // Build invite text
      const inviteText =
        `🏰 *GUILD INVITATION*\n\n` +
        `@${targetNumber}, you have been invited to join *${guild.name}*!\n\n` +
        `👑 *Owner:* ${ownerName}\n` +
        `📜 *Description:* ${guild.description || 'No description set.'}\n` +
        `👥 *Members:* ${guild.members.length}${guild.maxMembers > 0 ? `/${guild.maxMembers}` : ''}\n\n` +
        `🔗 *Join here:* ${joinLink}`;

      // Try to generate guild image
      let guildImage = null;
      try {
        guildImage = await generateGuildProfile(guild, {
          name: ownerName,
          profilePic: null,
        });
      } catch {}

      // Send IN THE GROUP (not DM)
      if (guildImage?.buffer) {
        await sock.sendMessage(jid, {
          image: guildImage.buffer,
          caption: inviteText,
          mentions: [targetJid],
        }, { quoted: m });
      } else {
        await sock.sendMessage(jid, {
          text: inviteText,
          mentions: [targetJid],
        }, { quoted: m });
      }

      return; // done
    } catch (err) {
      console.error('[GINVITE ERROR]', err);
      return reply('❌ Failed to send guild invitation. Please try again.');
    }
  },
});
