/**
 * commands/guilds/greq.js
 *
 * .greq list                    — List pending join requests
 * .greq accept/yes/agree <index>— Accept a join request by index
 * .greq reject/no/deny <index>  — Reject a join request by index
 *
 * Available to: guild owner + guards
 */
const Guild = require('../../models/athers/Guild');
const User  = require('../../models/User');
const { findOrCreateWhatsApp } = require('../../database/users');
const WEB = process.env.WEB || '';

function userNumber(jid) {
  return (jid || '').split('@')[0];
}

async function resolveUsername(id) {
  if (!id) return 'Unknown';
  const clean = String(id).replace(/@s\.whatsapp\.net|@lid/g, '');
  try {
    const user = await User.findOne({
      $or: [
        { moonId: clean },
        { whatsappNumber: `${clean}@s.whatsapp.net` },
        { whatsappNumber: clean },
        { userId: clean },
        { phoneNumber: clean },
      ],
    });
    if (user) return user.username?.trim() || clean;
  } catch {}
  return clean;
}

moon({
  name: 'greq',
  aliases: ['guildreq', 'grequest'],
  category: 'guilds',
  description: 'Manage guild join requests (owner/guards only)',
  usage: '.greq list | .greq accept <index> | .greq reject <index>',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const senderDoc  = await findOrCreateWhatsApp(sender, pushName);
      const senderUser = senderDoc.toObject();
      const senderId   = senderUser.moonId || senderUser.userId || userNumber(sender);

      // Find sender's guild (must be owner or guard)
      const ids = [
        senderUser.moonId,
        senderUser.userId,
        senderUser.whatsappNumber?.split('@')[0],
        senderUser.phoneNumber,
      ].filter(Boolean);
      const guild = await Guild.findOne({ members: { $in: ids } });

      if (!guild) return reply('❌ You are not in a guild.');

      const isOwner = guild.ownerId === senderId;
      const isGuard = (guild.guards || []).includes(senderId);
      if (!isOwner && !isGuard) {
        return reply('❌ Only guild owners and guards can manage join requests.');
      }

      const sub = (args[0] || '').toLowerCase();

      // ── LIST ──────────────────────────────────────────────────────────────
      if (!sub || sub === 'list') {
        const requests = guild.joinRequests || [];
        if (requests.length === 0) {
          return reply(`📋 *${guild.name}* — No pending join requests.`);
        }
        let text = `📋 *${guild.name} — Join Requests* (${requests.length})\n\n`;
        for (let i = 0; i < requests.length; i++) {
          const req = requests[i];
          const name = req.username || await resolveUsername(req.userId);
          const date = new Date(req.requestedAt).toLocaleDateString('en-US', {
            month: 'short', day: 'numeric',
          });
          text += `${i + 1}. *${name}* — requested ${date}\n`;
        }
        text += `\n> Use \`.greq accept <number>\` or \`.greq reject <number>\``;
        return reply(text);
      }

      // ── ACCEPT ────────────────────────────────────────────────────────────
      const ACCEPT_WORDS = ['accept', 'yes', 'agree', 'except'];
      const REJECT_WORDS = ['reject', 'no', 'deny', 'des'];

      if (ACCEPT_WORDS.includes(sub)) {
        const index = parseInt(args[1]) - 1;
        const requests = guild.joinRequests || [];
        if (isNaN(index) || index < 0 || index >= requests.length) {
          return reply(`❌ Invalid index. Use \`.greq list\` to see pending requests.`);
        }
        const req = requests[index];
        const reqUserId = req.userId;
        const reqName   = req.username || await resolveUsername(reqUserId);

        // Check capacity: every guild is capped at 25 members.
        const maxMembers = Math.min(25, Math.max(2, Number(guild.maxMembers) || 25));
        if (guild.members.length >= maxMembers) {
          return reply(`❌ Guild is full! (${guild.members.length}/${maxMembers})`);
        }

        // Add member
        if (!guild.members.includes(reqUserId)) {
          guild.members.push(reqUserId);
        }
        // Remove request
        guild.joinRequests.splice(index, 1);
        await guild.save();

        // Update user's guildId
        await User.updateOne(
          {
            $or: [
              { moonId: reqUserId },
              { whatsappNumber: `${reqUserId}@s.whatsapp.net` },
              { whatsappNumber: reqUserId },
            ],
          },
          { $set: { guildId: guild._id } }
        );

        return reply(
          `✅ *${reqName}* has been accepted into *${guild.name}*!\n` +
          `👥 Members: ${guild.members.length}${guild.maxMembers > 0 ? `/${guild.maxMembers}` : ''}`
        );
      }

      // ── REJECT ────────────────────────────────────────────────────────────
      if (REJECT_WORDS.includes(sub)) {
        const index = parseInt(args[1]) - 1;
        const requests = guild.joinRequests || [];
        if (isNaN(index) || index < 0 || index >= requests.length) {
          return reply(`❌ Invalid index. Use \`.greq list\` to see pending requests.`);
        }
        const req     = requests[index];
        const reqName = req.username || await resolveUsername(req.userId);

        guild.joinRequests.splice(index, 1);
        await guild.save();

        return reply(`🚫 *${reqName}*'s join request has been rejected.`);
      }

      return reply(
        '❌ Unknown subcommand.\n\n' +
        '*Usage:*\n' +
        '• `.greq list` — List pending requests\n' +
        '• `.greq accept <number>` — Accept a request\n' +
        '• `.greq reject <number>` — Reject a request'
      );
    } catch (err) {
      console.error('[GREQ ERROR]', err);
      return reply('❌ An error occurred. Please try again.');
    }
  },
});
