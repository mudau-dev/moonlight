const Guild = require('../../models/athers/Guild');
const User = require('../../models/User');
const { findOrCreateWhatsApp } = require('../../database/users');

moon({
  name: 'gstats',
  aliases: ['guildstats'],
  category: 'guilds',
  description: 'Show your guild statistics.',
  usage: '.gstats',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    const user = await findOrCreateWhatsApp(sender, pushName);
    const ids = [user.moonId, user.userId, user.phoneNumber, user.whatsappNumber?.split('@')[0]].filter(Boolean);
    const guild = await Guild.findOne({ $or: [{ ownerId: { $in: ids } }, { members: { $in: ids } }] }).lean();
    if (!guild) return reply('❌ You are not in a guild. Use `.guilds` to open the Guilds guide.');
    const memberCount = Array.isArray(guild.members) ? guild.members.length : 0;
    const guards = Array.isArray(guild.guards) ? guild.guards.length : 0;
    return reply([
      `📊 *${String(guild.name).toUpperCase()} — GUILD STATS*`,
      '━━━━━━━━━━━━━━━━━━━━',
      `🏰 *Level:* ${Number(guild.level || 1)}`,
      `✨ *XP:* ${Number(guild.xp || 0).toLocaleString()}`,
      `👥 *Members:* ${memberCount}/${Number(guild.maxMembers || 25)}`,
      `🛡️ *Guards:* ${guards}`,
      `📅 *Created:* ${guild.createdAt ? new Date(guild.createdAt).toLocaleDateString() : 'Unknown'}`,
      '',
      '> Use `.grank` to compare guilds and `.graid` for the raid briefing.',
    ].join('\n'));
  },
});
