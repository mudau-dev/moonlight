const Guild = require('../../models/athers/Guild');

function guildLine(guild, index) {
  const members = Array.isArray(guild.members) ? guild.members.length : 0;
  const level = Number(guild.level || 1);
  const xp = Number(guild.xp || 0);
  return `${index}. *${guild.name}* — Lv. ${level} · ${xp.toLocaleString()} XP · ${members} members`;
}

moon({
  name: 'grank',
  aliases: ['guildrank', 'guildranking'],
  category: 'guilds',
  description: 'Show the guild XP ranking.',
  usage: '.grank',
  async execute(sock, jid, sender, args, m, { reply }) {
    const guilds = await Guild.find({}).sort({ level: -1, xp: -1, createdAt: 1 }).limit(15).lean();
    if (!guilds.length) return reply('🏰 No guilds have been created yet.');
    return reply(['🏆 *GUILD RANKING*', '━━━━━━━━━━━━━━━━━━━━', ...guilds.map(guildLine), '', '> Rankings are ordered by Guild level and XP.'].join('\n'));
  },
});

moon({
  name: 'graid',
  aliases: ['guildraid'],
  category: 'guilds',
  description: 'Show the guild raid briefing and rules.',
  usage: '.graid',
  async execute(sock, jid, sender, args, m, { reply }) {
    return reply([
      '⚔️ *GUILD RAID BRIEFING*',
      '━━━━━━━━━━━━━━━━━━━━',
      '> Guild raids are team events for earning Guild XP.',
      '> Gather your guild members before the raid window opens.',
      '> Battle fairly: win-trading, collusion, and exploit abuse are not allowed.',
      '> Raid rewards and results are recorded against your guild.',
      '',
      'Use `.guild` to view your guild and `.grank` to check the ranking.',
    ].join('\n'));
  },
});
