/**
 * `.guilds` — guild-directory guide and official guild rules.
 *
 * This command is intentionally standalone from `.guild`, so every user can
 * quickly find the website and understand the guild process before applying.
 */
const Guild = require('../../models/athers/Guild');
const { findOrCreateWhatsApp } = require('../../database/users');
const config = require('../../config');

const WEB = config.WEB || '';

async function findMembership(user) {
  const ids = [
    user?.moonId,
    user?.userId,
    user?.phoneNumber,
    user?.whatsappNumber?.split('@')[0],
  ].filter(Boolean);

  if (!ids.length) return null;
  return Guild.findOne({
    $or: [
      { members: { $in: ids } },
      { ownerId: { $in: ids } },
    ],
  }).select('name ownerId members maxMembers').lean();
}

moon({
  name: 'guilds',
  aliases: ['guildsite', 'guildhelp'],
  category: 'guilds',
  description: 'Open the guild directory and read guild information and rules.',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const user = await findOrCreateWhatsApp(sender, pushName);
      const membership = await findMembership(user);
      const directoryUrl = WEB ? `${WEB.replace(/\/$/, '')}/guild` : 'The guild directory is not configured yet.';
      const membershipInfo = membership
        ? `You are currently in *${membership.name}*. Use \`.guild\` to view it, \`.guild members\` to view the roster, or \`.guild leave\` if you are a member who wants to join a different guild.`
        : `You are not currently in a guild. Browse the directory, open a guild profile, and select *Apply to Join*. The owner or a Guard must approve the request.`;

      const text = [
        '🏰 *MOONLIGHT HAVEN — GUILD DIRECTORY*',
        '━━━━━━━━━━━━━━━━━━━━',
        `🔗 *Guilds site:* ${directoryUrl}`,
        '',
        '> *INFO:*',
        'Guilds are long-term alliances for players who want to build a community, collect Guild XP, organise members, and compete fairly in Moonlight Haven.',
        '',
        `• *Your status:* ${membershipInfo}`,
        '• *How to join:* Visit the directory, choose a guild that has room, and send an application. Do not spam owners or Guards for an instant approval.',
        '• *How to create:* Buy a *Guild License* from the web shop, then use `.guild create <name>`. Names must be unique, readable, and appropriate for the community.',
        '• *How to manage:* Owners can edit their guild at the website, review join requests, remove members, and promote trusted members with `.guild role @user guard`.',
        '• *Helpful commands:* `.guild` shows your guild, `.guild members` shows the roster, `.ginvite @user` sends an in-group invitation when allowed, and `.greq list` lets Owners/Guards review applications.',
        '',
        '📜 *OFFICIAL GUILD RULES*',
        '━━━━━━━━━━━━━━━━━━━━',
        '1. *Respect first.* Guild names, icons, descriptions, announcements, and member interactions must not contain harassment, hate speech, sexual content, threats, doxxing, or targeted abuse. A guild does not give anyone permission to ignore community rules.',
        '',
        '2. *No fake recruitment or scams.* Do not promise rewards, ranks, currency, accounts, or staff access that you cannot provide. Never ask for login codes, personal details, or payment in exchange for joining or receiving a guild role.',
        '',
        '3. *Leadership is accountable.* Guild Owners are responsible for the guild identity and for responding reasonably to serious reports involving their officers. Guards must use their permissions fairly and must not remove, threaten, or mislead members for personal reasons.',
        '',
        '4. *Join requests must be handled honestly.* Do not repeatedly apply to the same guild after rejection, bypass a ban with alternate accounts, or pressure an Owner/Guard to accept you. Leaders must not use requests to harass, insult, or publicly shame applicants.',
        '',
        '5. *No alt-account farming.* One person may not use multiple accounts to fill a guild, inflate membership, farm Guild XP, manipulate rewards, or evade a guild ban. Related accounts involved in abuse may all be removed and suspended.',
        '',
        '6. *Compete fairly.* Win-trading, planned losses, collusion, account sharing, exploitation of timers or rewards, and coordination intended to manipulate rankings are prohibited. Report loopholes instead of using them.',
        '',
        '7. *Keep guild media safe.* Only use artwork you have permission to share. Do not upload stolen private images, explicit material, shocking content, malware links, impersonation graphics, or copyrighted leaks as guild icons or backgrounds.',
        '',
        '8. *Respect the wider Haven.* Guild rivalry must remain friendly. Do not raid chats, mass-mention people, spam invitations, recruit through harassment, or start conflicts in casino, Legacy, Pokémon, or general community spaces.',
        '',
        '9. *Staff actions override guild roles.* Owners, Guards, and members remain subject to Moonlight Haven moderation. Staff may remove unsafe content, reject names, suspend accounts, disband abusive guilds, or reverse gains tied to exploits when necessary.',
        '',
        '10. *Leaving and removal.* Members may leave with `.guild leave` unless they own the guild. Owners must use `.guild delete` if they intend to close it. Removal from a guild does not remove a platform suspension, and guild bans must never be used to threaten users.',
        '',
        '⚠️ *Enforcement:* Violations can lead to warnings, content removal, Guild XP or reward reversal, role removal, guild deletion, temporary suspension, or permanent account suspension depending on severity and history.',
        '',
        '> Need more help? Open the guild directory or ask a moderator before taking action that you are unsure about.',
      ].join('\n');

      return reply(text);
    } catch (error) {
      console.error('[GUILDS CMD ERROR]', error);
      return reply('❌ Unable to load the guild directory guide right now.');
    }
  },
});
