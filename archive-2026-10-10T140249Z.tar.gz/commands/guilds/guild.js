/**
 * commands/guilds/guild.js
 *
 * .guild              — Show guild info (clean, no member listing)
 * .guild create <name>— Create a guild
 * .guild members      — List members
 * .guild remove @user — Remove a member
 * .guild leave        — Leave your guild
 * .guild delete       — Delete your guild
 * .guild role @user guard/gd     — Promote to Guard
 * .guild role @user normal/reset — Remove Guard role
 */
const Guild = require('../../models/athers/Guild');
const User  = require('../../models/User');
const { findOrCreateWhatsApp } = require('../../database/users');
const { resolveMessageTarget, phoneNumberFromValue } = require('../../utils/adminIdentity');
const { generateGuildProfile }  = require('../../utils/guildGen');
const WEB = process.env.MOON_WEB_URL || process.env.WEB || process.env.NEXT_PUBLIC_SITE_URL || 'https://haven-moon.zone.id';

function absoluteMedia(value) {
  if (!value) return value;
  try { return new URL(String(value), WEB).toString(); } catch { return value; }
}

function userNumber(jid) {
  return (jid || '').split('@')[0];
}

async function resolveUsername(id) {
  if (!id) return 'Unknown';
  const clean = String(id).replace(/@s\.whatsapp\.net|@lid/g, '');
  try {
    const user = await User.findOne({
      $or: [
        { moonId: clean },
        { whatsappNumber: `${clean}@s.whatsapp.net` },
        { whatsappNumber: clean },
        { userId: clean },
        { phoneNumber: clean },
      ],
    });
    if (user) return user.username?.trim() || clean;
  } catch {}
  return clean;
}

async function getUserGuild(user) {
  if (!user) return null;
  const ids = [
    user.moonId,
    user.userId,
    user.whatsappNumber?.split('@')[0],
    user.phoneNumber,
  ].filter(Boolean);
  return Guild.findOne({ members: { $in: ids } });
}

moon({
  name: 'guild',
  category: 'guilds',
  aliases: ['g'],
  description: 'Guild management',
  subcommands: ['create', 'members', 'remove', 'leave', 'delete', 'role'],
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    try {
      const userDoc  = await findOrCreateWhatsApp(sender, pushName);
      const user     = userDoc.toObject();
      const senderId = user.moonId || user.userId || userNumber(sender);
      const sub      = args[0]?.toLowerCase();

      // ── 1. GUILD PROFILE ─────────────────────────────────────────────────
      if (!sub) {
        const guild = await getUserGuild(user);

        if (!guild) {
          const allGuilds = await Guild.find().sort({ createdAt: -1 }).limit(20).lean();
          let listText = '';
          if (allGuilds.length > 0) {
            const lines = [];
            for (let i = 0; i < allGuilds.length; i++) {
              const g = allGuilds[i];
              const ownerName = await resolveUsername(g.ownerId);
              const cap = `/${Math.min(25, Math.max(2, Number(g.maxMembers) || 25))}`;
              lines.push(`${i + 1}. *${g.name}* — ${g.members.length}${cap} members | Leader: ${ownerName}`);
            }
            listText = `\n\n*Available Guilds:*\n${lines.join('\n')}`;
            if (WEB) listText += `\n\n> Join a guild at: ${WEB}/guild`;
          } else {
            listText = '\n\n> No guilds exist yet. Create one with `.guild create <name>`.';
          }
          return reply(
            `You are not in any guild. Get a guild member to invite you or create your own guild.` +
            listText
          );
        }

        const ownerName = await resolveUsername(guild.ownerId);
        const isOwner   = guild.ownerId === senderId;
        const isGuard   = (guild.guards || []).includes(senderId);
        const myRole    = isOwner ? '👑 Leader' : isGuard ? '🛡️ Guard' : '⚔️ Member';

        const guildCapacity = Math.min(25, Math.max(2, Number(guild.maxMembers) || 25));
        const capDisplay = `${guild.members.length}/${guildCapacity}`;

        // The renderer has a short artwork timeout and an in-memory cache.
        // Do not fetch an unrelated WhatsApp profile photo here: that network call
        // was the largest avoidable source of `.guild` response delay.
        let image = null;
        try {
          image = await generateGuildProfile({
            ...(guild.toObject ? guild.toObject() : guild),
            background: absoluteMedia(guild.background),
            icon: absoluteMedia(guild.icon),
          });
        } catch {}

        const text = [
          `╔══════════════════════╗`,
          `║  🏰 *${guild.name.toUpperCase()}*`,
          `╚══════════════════════╝`,
          ``,
          `🏷️  *Name:*      ${guild.name}`,
          `🎨  *Color:*     ${guild.color || '#7c3aed'}`,
          `👥  *Members:*   ${capDisplay}`,
          `✨  *XP:*        ${(guild.xp || 0).toLocaleString()}`,
          `👑  *Leader:*    ${ownerName}`,
          `🎖️  *Your Role:* ${myRole}`,
          ``,
          `📜 *Description:*`,
          guild.description?.trim() || 'A guild forged in the Moonlight Haven.',
          ``,
          `━━━━━━━━━━━━━━━━━━━━━━`,
          WEB ? `> Manage your guild at: ${WEB}/guild` : '',
        ].filter(l => l !== undefined).join('\n');

        if (image?.buffer) {
          return await sock.sendMessage(jid, { image: image.buffer, mimetype: 'image/png', caption: text }, { quoted: m });
        }
        return reply(text);
      }

      // ── 2. CREATE ─────────────────────────────────────────────────────────
      if (sub === 'create') {
        const existingGuild = await getUserGuild(user);
        if (existingGuild) return reply(`❌ You are already in a guild (*${existingGuild.name}*).`);
        const ownedGuild = await Guild.findOne({
          $or: [{ ownerId: senderId }, { ownerId: user.moonId }],
        });
        if (ownedGuild) return reply(`❌ You already own a guild (*${ownedGuild.name}*).`);
        const name = args.slice(1).join(' ').trim();
        if (!name) return reply('❌ Usage: `.guild create <name>`');
        if (name.length < 2 || name.length > 30)
          return reply('❌ Guild name must be 2–30 characters.');
        const taken = await Guild.findOne({ name: { $regex: new RegExp(`^${name}$`, 'i') } });
        if (taken) return reply(`❌ A guild named *${name}* already exists.`);
        if (!user.guildLicense) {
          return reply(
            '❌ You need a *Guild License* to create a guild.\n' +
            (WEB ? `Purchase one from the shop: ${WEB}/shop` : 'Purchase one from the shop.')
          );
        }
        const newGuild = new Guild({
          name,
          ownerId: senderId,
          members: [senderId],
          description: 'A new legendary guild.',
          descriptions: [],
          maxMembers: 25,
          allowMemberInvite: false,
        });
        await newGuild.save();
        await User.updateOne(
          { _id: user._id },
          {
            $set: { guildLicense: false, guildId: newGuild._id },
            $pull: { inventory: { id: 'item:guild-license' } },
          }
        );
        return reply(`✅ Guild *${name}* created successfully!\n\n> Use \`.guild\` to view your guild.`);
      }

      // ── 3. MEMBERS ────────────────────────────────────────────────────────
      if (sub === 'members') {
        const guild = await getUserGuild(user);
        if (!guild) return reply('❌ You are not in a guild.');
        let text = `👥 *${guild.name.toUpperCase()} — MEMBERS*\n\n`;
        const mentions = [];
        for (let i = 0; i < guild.members.length; i++) {
          const mid   = guild.members[i];
          const mName = await resolveUsername(mid);
          const isO   = mid === guild.ownerId;
          const isG   = (guild.guards || []).includes(mid);
          const role  = isO ? '👑 Leader' : isG ? '🛡️ Guard' : '⚔️ Member';
          text += `${i + 1}. *${mName}* — ${role}\n`;
          mentions.push(`${mid}@s.whatsapp.net`);
        }
        return await sock.sendMessage(jid, { text, mentions }, { quoted: m });
      }

      // ── 4. REMOVE ─────────────────────────────────────────────────────────
      if (sub === 'remove') {
        const guild = await Guild.findOne({
          $or: [{ ownerId: senderId }, { ownerId: user.moonId }],
        });
        if (!guild) return reply('❌ Only the guild owner can remove members.');
        const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        const targetRaw = mentioned ? userNumber(mentioned) : args[1];
        if (!targetRaw) return reply('❌ Mention a user to remove.');
        if (targetRaw === senderId) return reply('❌ You cannot remove yourself.');
        const prevLen = guild.members.length;
        guild.members = guild.members.filter(id => id !== targetRaw);
        guild.guards  = (guild.guards || []).filter(id => id !== targetRaw);
        if (guild.members.length === prevLen) return reply('❌ That user is not in your guild.');
        if (!guild.banned.includes(targetRaw)) guild.banned.push(targetRaw);
        await guild.save();
        const tName = await resolveUsername(targetRaw);
        return reply(`🚫 *${tName}* has been removed and banned from the guild.`);
      }

      // ── 5. LEAVE ──────────────────────────────────────────────────────────
      if (sub === 'leave') {
        const guild = await getUserGuild(user);
        if (!guild) return reply('❌ You are not in a guild.');
        if (guild.ownerId === senderId) return reply('❌ Owners cannot leave. Use `.guild delete` instead.');
        guild.members = guild.members.filter(id => id !== senderId);
        guild.guards  = (guild.guards || []).filter(id => id !== senderId);
        await guild.save();
        await User.updateOne({ _id: user._id }, { $set: { guildId: null } });
        return reply(`✅ You left *${guild.name}*.`);
      }

      // ── 6. DELETE ─────────────────────────────────────────────────────────
      if (sub === 'delete') {
        const guild = await Guild.findOne({
          $or: [{ ownerId: senderId }, { ownerId: user.moonId }],
        });
        if (!guild) return reply('❌ Only the guild owner can delete the guild.');
        await Guild.deleteOne({ _id: guild._id });
        await User.updateMany({ guildId: guild._id }, { $set: { guildId: null } });
        return reply(`🗑️ Guild *${guild.name}* has been deleted.`);
      }

      // ── 7. ROLE ───────────────────────────────────────────────────────────
      if (sub === 'role') {
        const guild = await Guild.findOne({
          $or: [{ ownerId: senderId }, { ownerId: user.moonId }],
        });
        if (!guild) return reply('❌ Only the guild owner can manage roles.');

        const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        const targetJid = await resolveMessageTarget(sock, m, args.slice(1));
        const targetRaw = phoneNumberFromValue(targetJid || (mentioned ? mentioned : args[1]));
        const roleArg = (mentioned ? args[1] : args[2] || '').toLowerCase();

        if (!targetRaw || !roleArg) {
          return reply(
            '❌ Usage:\n' +
            '• `.guild role @user guard` — Make user a Guard\n' +
            '• `.guild role @user normal` — Remove Guard role'
          );
        }
        const memberMatches = (guild.members || []).some((value) => value === targetRaw || phoneNumberFromValue(value) === targetRaw);
        if (!memberMatches) return reply('❌ That user is not in your guild.');
        if (targetRaw === senderId || targetRaw === phoneNumberFromValue(sender))
          return reply('❌ You cannot change your own role.');

        const isPromote = ['guard', 'gd'].includes(roleArg);
        const isDemote  = ['normal', 'reset'].includes(roleArg);
        if (!isPromote && !isDemote) {
          return reply('❌ Use `guard`/`gd` to promote or `normal`/`reset` to demote.');
        }

        guild.guards = guild.guards || [];
        const tName  = await resolveUsername(targetRaw);

        if (isPromote) {
          guild.guards = guild.guards.filter((value) => phoneNumberFromValue(value) !== targetRaw);
          guild.guards.push(targetRaw);
          await guild.save();
          return reply(`🛡️ *${tName}* is now a *Guard* in *${guild.name}*!`);
        } else {
          guild.guards = guild.guards.filter((id) => phoneNumberFromValue(id) !== targetRaw);
          await guild.save();
          return reply(`✅ *${tName}*'s role reset to *Member* in *${guild.name}*.`);
        }
      }

      return reply(
        '❌ Unknown guild command.\n\n' +
        '*Available commands:*\n' +
        '• `.guild` — View your guild info\n' +
        '• `.guild create <name>` — Create a guild\n' +
        '• `.guild members` — List all members\n' +
        '• `.guild remove @user` — Remove a member\n' +
        '• `.guild leave` — Leave your guild\n' +
        '• `.guild delete` — Delete your guild\n' +
        '• `.guild role @user guard` — Promote to Guard\n' +
        '• `.guild role @user normal` — Remove Guard role'
      );
    } catch (err) {
      console.error('GUILD ERROR:', err);
      return reply('❌ An error occurred in the guild system.');
    }
  },
});
