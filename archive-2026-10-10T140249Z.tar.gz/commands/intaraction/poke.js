const { interactionTarget, sendInteraction } = require('../../utils/interactionMedia');

moon({
  name: 'pokeuser',
  aliases: ['pokeaction'],
  category: 'interaction',
  description: 'Send a visible animated poke interaction to another user.',
  usage: '.pokeuser @user',
  async execute(sock, jid, sender, args, m, { reply }) {
    const target = interactionTarget(m);
    if (!target) return reply('❌ Tag someone or reply to their message to use .pokeuser.');
    try {
      return await sendInteraction(sock, jid, sender, target, 'poke', m);
    } catch (error) {
      console.error('[pokeuser interaction]', error.message);
      return reply('❌ The poke media could not be loaded right now. Please try again.');
    }
  },
});
