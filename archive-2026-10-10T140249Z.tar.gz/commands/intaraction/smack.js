const { interactionTarget, sendInteraction } = require('../../utils/interactionMedia');
moon({
  name: 'smack',
  category: 'interaction',
  description: 'Send a visible animated interaction to another user.',
  usage: '.smack @user',
  async execute(sock, jid, sender, args, m, { reply }) {
    const target = interactionTarget(m);
    if (!target) return reply('❌ Tag someone or reply to their message to use .smack.');
    try {
      const result = await sendInteraction(sock, jid, sender, target, 'smack', m);
      if (result) return result;
    } catch (error) {
      console.error('[smack interaction]', error.message);
      return reply('❌ The interaction media could not be loaded right now. Please try again.');
    }
  },
});
