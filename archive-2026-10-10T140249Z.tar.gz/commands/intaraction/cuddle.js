const { interactionTarget, sendInteraction } = require('../../utils/interactionMedia');
moon({
  name: 'cuddle',
  category: 'interaction',
  description: 'Send a visible animated interaction to another user.',
  usage: '.cuddle @user',
  async execute(sock, jid, sender, args, m, { reply }) {
    const target = interactionTarget(m);
    if (!target) return reply('❌ Tag someone or reply to their message to use .cuddle.');
    try {
      const result = await sendInteraction(sock, jid, sender, target, 'cuddle', m);
      if (result) return result;
    } catch (error) {
      console.error('[cuddle interaction]', error.message);
      return reply('❌ The interaction media could not be loaded right now. Please try again.');
    }
  },
});
