const { interactionTarget, sendInteraction } = require('../../utils/interactionMedia');
moon({
  name: 'feed',
  category: 'interaction',
  description: 'Send a visible animated interaction to another user.',
  usage: '.feed @user',
  async execute(sock, jid, sender, args, m, { reply }) {
    const target = interactionTarget(m);
    if (!target) return reply('❌ Tag someone or reply to their message to use .feed.');
    try {
      const result = await sendInteraction(sock, jid, sender, target, 'feed', m);
      if (result) return result;
    } catch (error) {
      console.error('[feed interaction]', error.message);
      return reply('❌ The interaction media could not be loaded right now. Please try again.');
    }
  },
});
