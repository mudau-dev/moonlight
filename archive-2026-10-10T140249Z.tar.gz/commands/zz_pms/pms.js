const Group = require('../../models/athers/Group');
const User = require('../../models/User');
const config = require('../../config');

function enabled(value) { return value === true || value === 'true' || value === 'on' || value === 1; }
function status(value) { return enabled(value) ? 'ON' : 'OFF'; }
function usage(prefix, group) {
  return ['⚙️ *GROUP SYSTEM STATUS*', '', `.gambling / .casino: ${status(group?.gamblingEnabled)}`, `.cards: ${status(group?.cardsEnabled || group?.cardSpawnEnabled)}`, `.poke: ${status(group?.spawnEnabled || group?.pokemonSpawnEnabled)}`, '', `Use ${prefix}pms from the owner settings command to change these values.`].join('\n');
}

async function isTrueOwner(sender) {
  const value = String(sender || '');
  const digits = value.replace(/[^0-9]/g, '');
  const candidates = [{ whatsappNumber: value }, ...(digits ? [{ phoneNumber: digits }, { userId: digits }, { moonId: digits }, { whatsappNumber: digits }] : [])];
  const user = await User.findOne({ $or: candidates }).lean().catch(() => null);
  return user?.isTrueOwner === true;
}

moon({
  name: 'groupsettings',
  aliases: ['groupsetting', 'gsettings'],
  category: 'group',
  description: 'View group system status. Changes are owner-only through .pms.',
  usage: '.groupsettings',
  async execute(sock, jid, sender, args, m, { reply, prefix }) {
    if (!jid.endsWith('@g.us')) return reply('❌ This command only works in groups.');
    const group = await Group.findOne({ groupId: jid }).lean();
    return reply(usage(prefix, group));
  },
});

