const User = require('../../models/User');
const Group = require('../../models/athers/Group');
const config = require('../../config');
const { Battle, battles } = require('../../utils/battleEngine');
const { generateBattleImage } = require('../../utils/battleGenerator');
const { generateOutcomeImage } = require('../../utils/outcomeGenerator');
const { fetchPokemonData, calculateStat, normalizeMoveList, readableMoveName } = require('../../utils/pokemonUtils');
const { listPokemon, getCurrentHp } = require('../../utils/pokemonStorage');

const cooldowns = new Map();
const timers = new Map();
const species = ['pikachu', 'charizard', 'gengar', 'lucario', 'gyarados', 'dragonite', 'tyranitar', 'eevee', 'blastoise', 'sceptile'];
const modes = {
  encounter: { title: 'WILD ENCOUNTER', scale: 0.72, level: 1, reward: 160 },
  boss: { title: 'BOSS BATTLE', scale: 0.9, level: 8, reward: 650 },
  raid: { title: 'REALMS RAID', scale: 0.82, level: 5, reward: 420 },
  invasion: { title: 'INVASION DEFENSE', scale: 0.78, level: 4, reward: 300 },
  defend: { title: 'REGION DEFENSE', scale: 0.76, level: 3, reward: 260 },
  bounty: { title: 'BOUNTY HUNT', scale: 0.85, level: 6, reward: 500 },
  survive: { title: 'SURVIVAL EVENT', scale: 0.8, level: 5, reward: 350 },
  hazard: { title: 'COMBAT HAZARD', scale: 0.86, level: 6, reward: 380 },
  worldevent: { title: 'WORLD EVENT', scale: 0.88, level: 7, reward: 700 },
};

function blocked() {
  const link = config.COMBAT || 'https://chat.whatsapp.com/DNyrXCpXv26AJ3sggoGEMq';
  return `${link}\nYou cant use this command as this group is not allowed\n> here join the mentioned group fore more fun and command's usage's`;
}
async function allowed(jid) {
  if (!jid.endsWith('@g.us')) return false;
  const group = await Group.findOne({ groupId: jid }).lean().catch(() => null);
  return group?.realmsCombatEnabled === true;
}
async function ready(sender, key, ms = 15000) {
  const id = `${sender}:${key}`; const last = cooldowns.get(id) || 0;
  if (Date.now() - last < ms) return Math.ceil((ms - (Date.now() - last)) / 1000);
  cooldowns.set(id, Date.now()); return 0;
}
function activeBattle(sender) {
  const direct = battles.get(sender);
  if (direct?.status === 'active') return direct;
  for (const battle of battles.values()) if (battle?.status === 'active' && battle.players?.includes(sender)) return battle;
  return null;
}
function removeBattle(battle) {
  for (const player of battle.players || []) if (player && player !== 'wild') battles.delete(player);
  if (battle.groupId) timers.delete(battle.groupId);
  battle.status = 'finished';
}
async function sendBattleImage(sock, jid, m, battle, caption) {
  try {
    for (const pokemon of battle.activePokemon) if (pokemon && !pokemon.sprite) pokemon.sprite = (await fetchPokemonData(pokemon.name)).sprite;
    battle.activePokemon[0].hp = battle.hp[0]; battle.activePokemon[1].hp = battle.hp[1];
    const image = await generateBattleImage({ player: battle.activePokemon[0], opponent: battle.activePokemon[1], lastAction: caption, weather: battle.weather, logImage: true });
    return sock.sendMessage(jid, { image, caption }, { quoted: m });
  } catch (error) {
    console.warn('[REALMS COMBAT IMAGE]', error.message);
    return sock.sendMessage(jid, { text: caption }, { quoted: m });
  }
}
async function getPlayer(sender) {
  const { pokemons } = await listPokemon(sender, 'party', 6);
  const active = pokemons.find((pokemon) => getCurrentHp(pokemon) > 0);
  if (!active) return null;
  const data = await fetchPokemonData(active.name);
  const iv = active.iv || {}; const ev = active.ev || {}; const level = Number(active.level || 1);
  const maxHp = calculateStat(data.stats.hp, iv.hp || 0, ev.hp || 0, level, true);
  return { document: active, data, battle: { ...active.toObject(), ...data, name: active.nickname || active.name, level, sprite: data.sprite, maxHp, hp: Math.min(maxHp, Math.max(1, Number(active.hp || maxHp))), moves: normalizeMoveList(active.moves).length ? normalizeMoveList(active.moves) : normalizeMoveList(data.moves), attack: calculateStat(data.stats.attack, iv.attack || 0, ev.attack || 0, level), defense: calculateStat(data.stats.defense, iv.defense || 0, ev.defense || 0, level), spAtk: calculateStat(data.stats.spAtk, iv.spAtk || 0, ev.spAtk || 0, level), spDef: calculateStat(data.stats.spDef, iv.spDef || 0, ev.spDef || 0, level), speed: calculateStat(data.stats.speed, iv.speed || 0, ev.speed || 0, level) } };
}
function timeoutBattle(sock, jid, m, sender, battle) {
  const timer = setTimeout(() => { if (battle.status === 'active') { removeBattle(battle); sock.sendMessage(jid, { text: '⏳ No move was made for five minutes. The Combat battle has ended.' }, { quoted: m }).catch(() => {}); } }, 5 * 60 * 1000);
  timers.set(jid, timer); battle.players = [sender, 'wild'];
}
async function reward(sender, amount, mode) {
  await User.updateOne({ whatsappNumber: sender }, { $inc: { balance: amount, totalEarned: amount, 'realmsCombat.wins': 1, [`realmsCombat.${mode}`]: 1 } });
}
async function startCombat(sock, jid, sender, m, mode, ctx) {
  const settings = modes[mode]; const wait = await ready(sender, mode, mode === 'encounter' ? 15000 : 45000);
  if (wait) return ctx.reply(`⏳ ${settings.title} cooldown: ${wait}s remaining.`);
  if (activeBattle(sender)) return ctx.reply('❌ You already have an active Combat battle. Use `.cb <move>`, `.cb switch <slot>`, or `.cb run`.');
  const player = await getPlayer(sender);
  if (!player) return ctx.reply('❌ You need a healthy Pokémon in your party. Use `.party` or `.t2party <pc_index>` first.');
  const name = species[Math.floor(Math.random() * species.length)]; const data = await fetchPokemonData(name);
  const enemyLevel = Math.max(2, Number(player.battle.level || 1) + settings.level);
  const enemyMaxHp = Math.floor(calculateStat(data.stats.hp, 20, 0, enemyLevel, true) * (mode === 'boss' ? 1.6 : mode === 'raid' ? 1.35 : 1.15));
  const enemy = { ...data, name: data.name, level: enemyLevel, sprite: data.sprite, maxHp: enemyMaxHp, hp: enemyMaxHp, energy: 100, moves: normalizeMoveList(data.moves).length ? normalizeMoveList(data.moves) : ['tackle'], attack: calculateStat(data.stats.attack, 20, 0, enemyLevel), defense: calculateStat(data.stats.defense, 20, 0, enemyLevel), spAtk: calculateStat(data.stats.spAtk, 20, 0, enemyLevel), spDef: calculateStat(data.stats.spDef, 20, 0, enemyLevel), speed: calculateStat(data.stats.speed, 20, 0, enemyLevel) };
  const battle = new Battle(player.battle, enemy); battle.activePokemon = [player.battle, enemy]; battle.players = [sender, 'wild']; battle.type = 'wild'; battle.groupId = jid; battle.mode = mode; battle.reward = settings.reward; battle.damageScale = settings.scale; battle.minimumTurns = 0; await battle.start(); battles.set(sender, battle); timeoutBattle(sock, jid, m, sender, battle);
  const caption = [`⚔️ *${settings.title}*`, '', `Your *${player.battle.name}* encountered *${enemy.name}* Lv.${enemy.level}.`, `🌦️ Weather: *${battle.weather}*`, '', `Use ".cb <move>" to attack.`, `Use ".cb moves" to view moves.`, `Use ".cb switch <slot>" to switch Pokémon.`, `Use ".cb run" to leave.`].join('\n');
  return sendBattleImage(sock, jid, m, battle, caption);
}
async function move(sock, jid, sender, args, m, ctx) {
  const battle = activeBattle(sender); if (!battle) return ctx.reply('❌ You are not in a Combat battle. Use `.encounter` to begin.');
  const index = 0; const input = String(args[0] || '').toLowerCase();
  if (input === 'run' || input === 'leave') { removeBattle(battle); return ctx.reply('🏃 You left the Combat battle.'); }
  if (input === 'moves') return ctx.reply((battle.activePokemon[0].moves || []).map((value, i) => `${i + 1}. ${readableMoveName(value)}`).join('\n') || 'No moves found.');
  if (input === 'switch') return ctx.reply('🔁 Use the existing `.pb switch <party_slot>` command during Pokémon battles.');
  const moves = normalizeMoveList(battle.activePokemon[index].moves); const moveName = /^\d+$/.test(input) ? moves[Number(input) - 1] : moves.find((value) => value.toLowerCase() === input || readableMoveName(value).toLowerCase() === input);
  if (!moveName) return ctx.reply('❌ Move not found. Use `.cb moves` first.');
  battle.moves[0] = moveName; battle.moves[1] = normalizeMoveList(battle.activePokemon[1].moves)[Math.floor(Math.random() * normalizeMoveList(battle.activePokemon[1].moves).length)] || 'tackle';
  const result = await battle.resolveTurn();
  const lines = [`⚔️ *Turn ${battle.turn - (battle.status === 'finished' ? 0 : 1)}*`, ...result, `❤️ Your HP: ${Math.max(0, Math.round(battle.hp[0]))}/${battle.activePokemon[0].maxHp}`, `💀 Enemy HP: ${Math.max(0, Math.round(battle.hp[1]))}/${battle.activePokemon[1].maxHp}`];
  if (battle.status !== 'finished') return sendBattleImage(sock, jid, m, battle, lines.join('\n'));
  const won = battle.winnerIndex === 0;
  if (won) { await reward(sender, battle.reward || 150, battle.mode || 'encounter'); try { const image = await generateOutcomeImage({ pokemon: battle.activePokemon[0], opponent: battle.activePokemon[1], won: true, winnerIndex: 0, reason: 'Knockout' }); removeBattle(battle); return sock.sendMessage(jid, { image, caption: `🏆 *VICTORY*\n\n${battle.activePokemon[0].name} defeated ${battle.activePokemon[1].name}.\n💰 Reward: ${battle.reward || 150} coins` }, { quoted: m }); } catch {} }
  removeBattle(battle); return ctx.reply(`💀 Defeat. *${battle.activePokemon[0].name}* fainted. Heal your party before starting another Combat battle.`);
}
function register(name, description, aliases = []) { moon({ name, aliases, category: 'combat', description, usage: `.${name}`, async execute(sock, jid, sender, args, m, ctx) { if (!(await allowed(jid))) return ctx.reply(blocked()); if (name === 'combat') return ctx.reply(`⚔️ *COMBAT COMMANDS*\n\n${Object.entries(modes).map(([key, value]) => `${ctx.prefix}${key} — ${value.title}`).join('\n')}\n${ctx.prefix}cb — attack, switch, run, or view moves`); if (name === 'cb') return move(sock, jid, sender, args, m, ctx); if (name === 'arena' || name === 'duel') { const pduel = ctx.commands.get('pduel'); return pduel ? pduel.execute(sock, jid, sender, args, m, ctx) : ctx.reply('❌ The Pokémon duel engine is unavailable.'); } if (modes[name]) return startCombat(sock, jid, sender, m, name, ctx); if (name === 'bountyboard') return ctx.reply(`🎯 *BOUNTY BOARD*\n\n${Object.keys(modes).filter((key) => key !== 'encounter').map((key) => `• ${ctx.prefix}${key} — ${modes[key].title} · ${modes[key].reward} coins`).join('\n')}`); return ctx.reply('❌ Combat target unavailable.'); } }); }
register('combat', 'View real Moonlight Realms Combat commands.');
for (const name of Object.keys(modes)) register(name, `Start a real ${modes[name].title.toLowerCase()} using the existing Pokémon Battle engine.`);
register('bountyboard', 'View live Combat targets and rewards.');
register('cb', 'Use a move, view moves, or leave an active Realms battle.', ['combatmove']);
register('arena', 'Challenge another trainer through the existing Pokémon duel engine.');
register('duel', 'Challenge another trainer through the existing Pokémon duel engine.');
