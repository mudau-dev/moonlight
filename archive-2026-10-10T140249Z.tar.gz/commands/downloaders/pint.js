const { cleanQuery, searchPinterest, fetchBuffer } = require('./searchHelpers');

const activeChats = new Set();
const lastUse = new Map();
let activeSearches = 0;
const COOLDOWN_MS = 12000;
const MAX_IMAGES = 4;
const MAX_ACTIVE_SEARCHES = 2;

moon({
  name: 'pint',
  aliases: ['pin', 'images', 'image'],
  category: 'downloaders',
  description: 'Search the Internet for a small safe image pack.',
  usage: '.pint <search terms>',
  async execute(sock, jid, sender, args, message, { reply }) {
    const query = cleanQuery(args);
    if (!query) return reply('❌ Usage: .pint <what you want to see>\nExample: .pint Tensura Rimuru');
    const now = Date.now();
    const previous = lastUse.get(jid) || 0;
    if (activeChats.has(jid)) return reply('⏳ An image search is already being delivered here. Please wait for it to finish.');
    if (activeSearches >= MAX_ACTIVE_SEARCHES) return reply('⏳ Image searches are busy right now. Please try again in a few seconds.');
    if (now - previous < COOLDOWN_MS) return reply(`⏳ Please wait ${Math.ceil((COOLDOWN_MS - (now - previous)) / 1000)}s before using .pint again.`);

    activeChats.add(jid);
    activeSearches += 1;
    lastUse.set(jid, now);
    try {
      const results = (await searchPinterest(query, MAX_IMAGES)).slice(0, MAX_IMAGES);
      if (!results.length) return reply(`❌ I could not find public images for *${query}*.`);

      const images = [];
      for (const result of results) {
        try {
          const buffer = await fetchBuffer(result.url);
          if (buffer && buffer.length <= 8 * 1024 * 1024) images.push(buffer);
        } catch (error) {
          console.warn('[PINT] Skipping image:', error.message);
        }
      }
      if (!images.length) return reply('❌ Pinterest returned results, but none could be downloaded safely.');

      for (let index = 0; index < images.length; index += 1) {
        await sock.sendMessage(jid, {
          image: images[index],
          caption: index === 0 ? `🖼️ *Pinterest pack: ${query}*\n${images.length} safe images.` : undefined,
        }, { quoted: message });
      }
    } catch (error) {
      console.error('[PINT ERROR]', error.response?.data || error.message);
      return reply('❌ Image search is temporarily unavailable. Please try again in a moment.');
    } finally {
      activeChats.delete(jid);
      activeSearches = Math.max(0, activeSearches - 1);
    }
    return null;
  },
});
