const axios = require('axios');
const config = require('../../config');

const REQUEST_TIMEOUT = 20_000;
const USER_AGENT = 'MoonlightHavenBot/1.0 (image and sticker search)';

function cleanQuery(args) {
  return String(Array.isArray(args) ? args.join(' ') : args || '').trim().replace(/\s+/g, ' ');
}

async function searchCommons(query, limit = 7) {
  const { data } = await axios.get('https://commons.wikimedia.org/w/api.php', {
    timeout: REQUEST_TIMEOUT,
    headers: { 'User-Agent': USER_AGENT },
    params: {
      action: 'query',
      generator: 'search',
      gsrsearch: query,
      gsrnamespace: 6,
      gsrlimit: Math.min(Math.max(limit, 1), 15),
      prop: 'imageinfo',
      iiprop: 'url|mime|size',
      iiurlwidth: 1280,
      format: 'json',
      origin: '*',
    },
  });
  const pages = Object.values(data?.query?.pages || {});
  return pages.map((page) => {
    const info = page.imageinfo?.[0] || {};
    return {
      title: String(page.title || '').replace(/^File:/i, ''),
      url: info.thumburl || info.url,
      mime: info.mime,
      source: `https://commons.wikimedia.org/wiki/${encodeURIComponent(page.title || '')}`,
    };
  }).filter((item) => /^https?:\/\//i.test(item.url || '') && /^image\//i.test(item.mime || ''));
}

async function searchPinterest(query, limit = 7) {
  const sourceUrl = `/search/pins/?q=${encodeURIComponent(query)}`;
  const options = {
    query,
    scope: 'pins',
    rs: 'typed',
    page_size: Math.min(Math.max(limit * 3, 7), 25),
    prepend: false,
  };
  const { data } = await axios.get('https://za.pinterest.com/resource/BaseSearchResource/get/', {
    timeout: REQUEST_TIMEOUT,
    headers: {
      'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/125 Safari/537.36',
      Accept: 'application/json, text/javascript, */*, q=0.01',
      'X-Requested-With': 'XMLHttpRequest',
      'X-Pinterest-AppState': 'active',
      'X-Pinterest-PWS-Handler': 'www/search/[scope].js',
      Referer: `https://za.pinterest.com${sourceUrl}`,
    },
    params: {
      source_url: sourceUrl,
      data: JSON.stringify({ options, context: {} }),
      _: Date.now(),
    },
  });
  const pins = data?.resource_response?.data?.results || [];
  const seen = new Set();
  return pins.map((pin) => {
    const images = pin.images || {};
    const image = images.orig || images['736x'] || images['474x'] || images['236x'];
    return {
      id: pin.id,
      title: pin.title || pin.grid_title || pin.seo_alt_text || pin.description || query,
      url: image?.url,
      source: `https://za.pinterest.com/pin/${pin.id}/`,
    };
  }).filter((item) => {
    if (!/^https?:\/\//i.test(item.url || '') || seen.has(item.url)) return false;
    seen.add(item.url);
    return true;
  }).slice(0, 15);
}

async function searchTenorStickers(query, limit = 8) {
  const wanted = Math.min(Math.max(Number(limit) || 10, 7), 15);
  const seen = new Set();
  const results = [];
  const add = (items) => { for (const item of (items || [])) { if (!item?.url || seen.has(item.url)) continue; seen.add(item.url); results.push({ ...item, title: item.title || query }); if (results.length >= wanted) break; } };
  try { add(await searchPinterest(`${query} sticker` , wanted * 2)); } catch (error) { console.warn('[STICKER SEARCH PINTEREST]', error.message); }
  if (results.length < wanted) {
    try { add(await searchCommons(`${query} sticker`, wanted * 2)); } catch (error) { console.warn('[STICKER SEARCH COMMONS]', error.message); }
  }
  return results.slice(0, wanted);
}
async function fetchBuffer(url) {
  const response = await axios.get(url, {
    timeout: REQUEST_TIMEOUT,
    responseType: 'arraybuffer',
    maxContentLength: 15 * 1024 * 1024,
    maxBodyLength: 15 * 1024 * 1024,
    headers: { 'User-Agent': USER_AGENT },
  });
  return Buffer.from(response.data);
}

module.exports = { cleanQuery, searchCommons, searchPinterest, searchTenorStickers, fetchBuffer };
