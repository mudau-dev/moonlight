const fs = require('node:fs');
const os = require('node:os');
const { promisify } = require('node:util');
const execFile = promisify(require('node:child_process').execFile);
const path = require('node:path');
const crypto = require('node:crypto');
const yts = require('yt-search');
const youtubedl = require('youtube-dl-exec');
const axios = require('axios');
function cleanText(value, fallback = 'Not available.') { const text = String(value || '').replace(/\s+/g, ' ').trim(); return text ? text.slice(0, 520) : fallback; }
function safeFileName(title) { return cleanText(title, 'Moonlight Audio').replace(/[\\/:*?"<>|]/g, '').slice(0, 96) || 'Moonlight Audio'; }
async function directAudio(url) {
  const output = path.join(os.tmpdir(), `moonlight-play-${crypto.randomBytes(6).toString('hex')}.%(ext)s`);
  await youtubedl(url, { noPlaylist: true, extractAudio: true, audioFormat: 'mp3', audioQuality: '5', output, ffmpegLocation: process.env.FFMPEG_PATH || undefined, noWarnings: true, quiet: true, restrictFilenames: true, socketTimeout: 30, extractorArgs: 'youtube:player_client=android,web_safari' });
  const dir = path.dirname(output), stem = path.basename(output).replace('.%(ext)s','');
  const files = fs.readdirSync(dir).filter((file) => file.startsWith(stem + '.') && /\.(mp3|m4a|webm|opus)$/i.test(file));
  if (!files.length) throw new Error('youtube-dl-exec produced no audio file');
  return path.join(dir, files[0]);
}

function findAudioUrl(payload) { const c=[payload?.download_url,payload?.audioUrl,payload?.url,payload?.link,payload?.result?.download_url,payload?.result?.audioUrl,payload?.result?.url,payload?.data?.download_url,payload?.data?.audioUrl,payload?.BK9?.[0]?.mediaLink,payload?.BK9?.download_url,payload?.BK9?.audio_url]; return c.find(v=>typeof v==='string'&&/^https?:\/\//i.test(v))||null; }
async function providerAudio(url) {
  const endpoints=[
    ['xemoz',`https://api-xemoz-official.my.id/api/donwloader/ytplay.php?q=${encodeURIComponent(url)}`],
    ['bk9',`https://bk9.fun/download/youtube2?url=${encodeURIComponent(url)}`],
    ['delirius',`https://api.delirius.store/download/ytmp3?url=${encodeURIComponent(url)}`],
    ['vreden',`https://api.vreden.my.id/api/ytmp3?url=${encodeURIComponent(url)}`],
    ['agatz',`https://api.agatz.xyz/api/ytmp3?url=${encodeURIComponent(url)}`],
  ];
  for(const [name,endpoint] of endpoints) { try { const {data}=await axios.get(endpoint,{timeout:20_000}); const audio=findAudioUrl(data); if(audio) return {audio,provider:name}; } catch(e) { console.warn(`[PLAY API ${name}]`,e.message); } }
  return null;
}
moon({ name: 'play', aliases: ['song', 'music', 'hall'], category: 'downloaders', description: 'Find and download YouTube audio.', async execute(sock, jid, sender, args, m, { reply }) {
  let file;
  try {
    const query = args.join(' ').trim();
    if (!query) return reply('❌ Provide a song name.\nExample: `.play faded alan walker`');
    await sock.sendMessage(jid, { react: { text: '🎵', key: m.key } }).catch(() => {});
    const search = await yts(query);
    const video = search.videos?.[0];
    if (!video?.url) return reply('❌ No matching music was found.');
    const caption = `🎵 *MUSIC FOUND*\n━━━━━━━━━━━━━━━━━━━━\n*Name:* ${cleanText(video.title)}\n*Duration:* ${video.timestamp || 'Unknown'}\n\n> Downloading audio…`;
    await sock.sendMessage(jid, video.thumbnail ? { image: { url: video.thumbnail }, caption } : { text: caption }, { quoted: m });
    try { file = await directAudio(video.url); } catch (directError) { console.warn('[PLAY DIRECT FALLBACK]', directError.message); }
    if (file) await sock.sendMessage(jid, { audio: { url: file }, mimetype: 'audio/mpeg', ptt: false, fileName: `${safeFileName(video.title)}.mp3` }, { quoted: m });
    else { const fallback = await providerAudio(video.url); if (!fallback?.audio) throw new Error('YouTube blocked direct download and all fallback providers were unavailable'); const tmp = path.join(os.tmpdir(), `moonlight-api-${crypto.randomBytes(5).toString('hex')}.mp3`); try { const response = await axios.get(fallback.audio, { responseType: 'arraybuffer', timeout: 45_000, maxContentLength: 40 * 1024 * 1024 }); fs.writeFileSync(tmp, response.data); await sock.sendMessage(jid, { audio: fs.readFileSync(tmp), mimetype: 'audio/mpeg', ptt: false, fileName: `${safeFileName(video.title)}.mp3` }, { quoted: m }); } finally { try { fs.unlinkSync(tmp); } catch {} } }
    await sock.sendMessage(jid, { react: { text: '✅', key: m.key } }).catch(() => {});
  } catch (error) { console.error('[PLAY DIRECT ERROR]', error); await sock.sendMessage(jid, { react: { text: '❌', key: m.key } }).catch(() => {}); return reply(`❌ Play failed: ${String(error.message || 'audio download error').slice(0, 180)}`); }
  finally { if (file) try { fs.unlinkSync(file); } catch {} }
}});
