const { findParticipantByIdentity, isParticipantAdmin, getBotIdentity, sameIdentity } = require('../../utils/adminIdentity');
const config = require('../../config');

moon({
  name: "promote",
  category: "group",
  description: "Promote a user to admin",

  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const contextInfo = m.message?.extendedTextMessage?.contextInfo;
      const target = contextInfo?.mentionedJid?.[0] || contextInfo?.participant;

      if (!target) return reply("❌ Mention or reply to a user.");

      const metadata = await sock.groupMetadata(jid);

      const user = findParticipantByIdentity(metadata.participants, sender);
      const bot = findParticipantByIdentity(metadata.participants, getBotIdentity(sock, config));

      if (!user || (user.admin !== "admin" && user.admin !== "superadmin")) {
        return reply("❌ You must be admin.");
      }

      if (!bot || (bot.admin !== "admin" && bot.admin !== "superadmin")) {
        return reply("❌ Bot must be admin.");
      }

      await sock.groupParticipantsUpdate(jid, [target], "promote");

      return reply(`✅ Promoted @${target.split('@')[0]}`, { mentions: [target] });

    } catch (err) {
      console.error(err);
      return reply("❌ Failed to promote user.");
    }
  }
});