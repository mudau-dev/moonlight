const { findParticipantByIdentity, resolveMessageTarget, phoneNumberFromValue } = require('../../utils/adminIdentity');
const { muteUser } = require('../../utils/muteStore');
const { mentionTag } = require('../../handlers/_shared');

async function isAdmin(sock, jid, userJid) {
  try {
    const meta = await sock.groupMetadata(jid);
    const member = findParticipantByIdentity(meta.participants, userJid);
    return member?.admin === 'admin' || member?.admin === 'superadmin';
  } catch {
    return false;
  }
}

moon({
  name: 'mute',
  category: 'group',
  description: 'Mute a group member; all future messages, including commands, are deleted',

  async execute(sock, jid, sender, args, m, context) {
    const { reply } = context;
    try {
      if (!jid.endsWith('@g.us')) return reply('❌ This command only works in groups.');
      if (!(await isAdmin(sock, jid, sender))) return reply('❌ Only group admins can use this command.');

      const targetJid = await resolveMessageTarget(sock, m, args);
      if (!targetJid) return reply('❌ Tag, reply to, or provide the phone number of the user to mute.');
      if (phoneNumberFromValue(targetJid) === phoneNumberFromValue(sender)) return reply("❌ You can't mute yourself.");
      if (await isAdmin(sock, jid, targetJid)) return reply('❌ You cannot mute another group admin.');

      await muteUser(jid, targetJid);
      return sock.sendMessage(jid, {
        text: `🔇 ${mentionTag(targetJid)} has been muted. Their messages, including commands, will be automatically deleted.`,
        mentions: [targetJid],
      }, { quoted: m });
    } catch (err) {
      console.error('[MUTE ERROR]', err);
      return reply('❌ Failed to mute user.');
    }
  },
});
