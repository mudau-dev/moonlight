const { findParticipantByIdentity, isParticipantAdmin, getBotIdentity, sameIdentity } = require('../../utils/adminIdentity');
const config = require('../../config');

moon({
  name: "admincheck",
  category: "group",
  description: "Check if user and bot are admins",

  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      if (!jid || !jid.endsWith("@g.us")) {
        return reply("❌ This command only works in groups.");
      }

      const metadata = await sock.groupMetadata(jid);

      // ---------------- USER CHECK ----------------
      const userParticipant = findParticipantByIdentity(metadata.participants, sender);

      const isUserAdmin =
        userParticipant?.admin === "admin" ||
        userParticipant?.admin === "superadmin";

      // ---------------- BOT CHECK ----------------
      const botJid = getBotIdentity(sock, config);

      const botParticipant = findParticipantByIdentity(metadata.participants, botJid);

      const isBotAdmin =
        botParticipant?.admin === "admin" ||
        botParticipant?.admin === "superadmin";

      // ---------------- RESPONSE ----------------
      let text = `🔍 *Admin Check*\n\n`;

      text += `👤 *User:* ${isUserAdmin ? "✅ Admin" : "❌ Not Admin"}\n`;
      text += `🤖 *Bot:* ${isBotAdmin ? "✅ Admin" : "❌ Not Admin"}\n`;

      return reply(text);

    } catch (err) {
      console.error("admincheck error:", err);
      return reply("❌ Failed to check admin status.");
    }
  }
});