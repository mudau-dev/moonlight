const { findParticipantByIdentity, isParticipantAdmin, getBotIdentity } = require('../../utils/adminIdentity');
const { getGroup, updateGroup } = require('../../models/athers/GroupSettings');
const config = require('../../config');

moon({
  name: 'antigpro',
  category: 'group',
  description: 'Protect the group from WhatsApp status/profile promotions.',
  usage: '.antigpro on | warn <max> | kick | delete | off',
  async execute(sock, jid, sender, args, m, { reply, isStaff }) {
    if (!jid.endsWith('@g.us')) return reply('❌ This command only works in groups.');
    const metadata = await sock.groupMetadata(jid);
    const user = findParticipantByIdentity(metadata.participants || [], sender);
    const bot = findParticipantByIdentity(metadata.participants || [], getBotIdentity(sock, config));
    if (!isStaff && !isParticipantAdmin(user)) return reply('❌ You must be a group admin or approved staff member.');
    if (!isParticipantAdmin(bot)) return reply('❌ I need to be a group admin to enforce anti-group-profile protection.');
    const group = getGroup(jid);
    const sub = String(args[0] || '').toLowerCase();
    if (!sub) return reply(`🛡️ *Anti Group-Profile Protection*\nStatus: ${group.antigpro.enabled ? '✅ Enabled' : '❌ Disabled'}\nAction: ${group.antigpro.action}\nWarn limit: ${group.antigpro.warnLimit}\n\n.antigpro on\n.antigpro off\n.antigpro warn <max>\n.antigpro kick\n.antigpro delete`);
    if (sub === 'off') {
      updateGroup(jid, { antigpro: { ...group.antigpro, enabled: false } });
      return reply('❌ Anti group-profile protection disabled.');
    }
    if (sub === 'on') {
      updateGroup(jid, { antigpro: { ...group.antigpro, enabled: true } });
      return reply(`✅ Anti group-profile protection enabled with *${group.antigpro.action}* mode.`);
    }
    if (!['warn', 'kick', 'delete'].includes(sub)) return reply('❌ Use: on | off | warn <max> | kick | delete');
    const limit = sub === 'warn' ? Number.parseInt(args[1], 10) : Number(group.antigpro.warnLimit || 3);
    if (sub === 'warn' && (!Number.isInteger(limit) || limit < 1 || limit > 20)) return reply('❌ The warning limit must be a whole number from 1 to 20.');
    updateGroup(jid, { antigpro: { ...group.antigpro, enabled: true, action: sub, warnLimit: limit } });
    return reply(`✅ Anti group-profile protection set to *${sub}*${sub === 'warn' ? ` after ${limit} warning(s)` : ''}.`);
  },
});
