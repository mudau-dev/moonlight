const { findParticipantByIdentity, getBotIdentity } = require('../../utils/adminIdentity');
const GroupSettings = require('../../models/athers/GroupSettings');
const config = require('../../config');
function isAdmin(participant) { return participant?.admin === 'admin' || participant?.admin === 'superadmin'; }
moon({
  name: 'tleave', category: 'group', description: 'Manage group leave messages.',
  async execute(sock, jid, sender, args, m, { reply, isStaff }) {
    if (!jid.endsWith('@g.us')) return reply('❌ This command only works in groups.');
    const metadata = await sock.groupMetadata(jid);
    if (!isStaff && !isAdmin(findParticipantByIdentity(metadata.participants, sender))) return reply('❌ You must be a group admin to use this command.');
    if (!isAdmin(findParticipantByIdentity(metadata.participants, getBotIdentity(sock, config)))) return reply('❌ I need to be a group admin to manage leave messages.');
    const sub = String(args[0] || '').toLowerCase();
    const group = GroupSettings.getGroup(jid);
    if (sub === 'on' || sub === 'off') {
      const value = sub === 'on';
      GroupSettings.updateGroup(jid, { leaveEnabled: value, leave: { ...(group.leave || {}), enabled: value } });
      return reply(`${value ? '✅ Leave messages enabled.' : '❌ Leave messages disabled.'}`);
    }
    if (sub === 'set') {
      const message = args.slice(1).join(' ');
      if (!message) return reply('Usage: .tleave set <message>\nPlaceholders: @user @gname @count');
      GroupSettings.updateGroup(jid, { leaveMessage: message, leave: { ...(group.leave || {}), enabled: group.leave?.enabled ?? true, message } });
      return reply('✅ Leave message updated.');
    }
    return reply(`🌙 *Leave Settings*\n\nStatus: ${group.leaveEnabled ? '✅ Enabled' : '❌ Disabled'}\n\nMessage:\n${group.leaveMessage}\n\nCommands:\n• .tleave on\n• .tleave off\n• .tleave set <message>\n\nPlaceholders: @user @gname @count`);
  },
});
