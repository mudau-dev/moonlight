const { findParticipantByIdentity, resolveMessageTarget } = require('../../utils/adminIdentity');
const { unmuteUser } = require('../../utils/muteStore');
const { mentionTag } = require('../../handlers/_shared');

async function isAdmin(sock, jid, userJid) {
  try {
    const meta = await sock.groupMetadata(jid);
    const member = findParticipantByIdentity(meta.participants, userJid);
    return member?.admin === 'admin' || member?.admin === 'superadmin';
  } catch {
    return false;
  }
}

moon({
  name: 'unmute',
  category: 'group',
  description: 'Unmute a group member',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      if (!jid.endsWith('@g.us')) return reply('❌ This command only works in groups.');
      if (!(await isAdmin(sock, jid, sender))) return reply('❌ Only group admins can use this command.');

      const targetJid = await resolveMessageTarget(sock, m, args);
      if (!targetJid) return reply('❌ Tag, reply to, or provide the phone number of the user to unmute.');

      await unmuteUser(jid, targetJid);
      return sock.sendMessage(jid, {
        text: `🔊 ${mentionTag(targetJid)} has been unmuted.`,
        mentions: [targetJid],
      }, { quoted: m });
    } catch (error) {
      console.error('UNMUTE ERROR:', error);
      return reply('❌ Failed to unmute user.');
    }
  },
});
