const { findParticipantByIdentity, getBotIdentity, sameIdentity } = require('../../utils/adminIdentity');
const GroupSettings = require('../../models/athers/GroupSettings');
const config = require('../../config');

function isAdmin(participant) { return participant?.admin === 'admin' || participant?.admin === 'superadmin'; }
moon({
  name: 'welcome', category: 'group', description: 'Manage group welcome messages.',
  async execute(sock, jid, sender, args, m, { reply, isStaff }) {
    if (!jid.endsWith('@g.us')) return reply('❌ This command can only be used in groups.');
    const metadata = await sock.groupMetadata(jid);
    if (!isStaff && !isAdmin(findParticipantByIdentity(metadata.participants, sender))) return reply('❌ You must be a group admin to use this command.');
    if (!isAdmin(findParticipantByIdentity(metadata.participants, getBotIdentity(sock, config)))) return reply('❌ I need to be a group admin first.');
    const sub = String(args[0] || '').toLowerCase();
    const group = GroupSettings.getGroup(jid);
    if (sub === 'on' || sub === 'off') {
      const value = sub === 'on';
      GroupSettings.updateGroup(jid, { welcomeEnabled: value, welcome: { ...(group.welcome || {}), enabled: value } });
      return reply(`${value ? '✅ Welcome messages enabled.' : '❌ Welcome messages disabled.'}`);
    }
    if (sub === 'set') {
      const message = args.slice(1).join(' ');
      if (!message) return reply('Usage: .welcome set <message>\nPlaceholders: @user @gname @count @p');
      GroupSettings.updateGroup(jid, { welcomeMessage: message, welcome: { ...(group.welcome || {}), enabled: group.welcome?.enabled ?? true, message } });
      return reply('✅ Welcome message updated.');
    }
    return reply(`🌙 *Welcome Settings*\n\nStatus: ${group.welcomeEnabled ? '✅ Enabled' : '❌ Disabled'}\n\nMessage:\n${group.welcomeMessage}\n\nCommands:\n• .welcome on\n• .welcome off\n• .welcome set <message>\n\nPlaceholders: @user @gname @count @p`);
  },
});
