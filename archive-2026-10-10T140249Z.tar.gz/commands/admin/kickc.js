const System = require('../../models/System');
const User = require('../../models/User');
const { getConfiguredCommunities, scanKey } = require('../../handlers/Community');
const { getBotIdentity, isParticipantAdminByIdentity, phoneNumberFromValue } = require('../../utils/adminIdentity');
const STAFF = ['Guardian', 'Mod', 'Owner', 'True Owner', 'CDC'];
function memberKey(value) { return phoneNumberFromValue(value) || String(value || '').split(':')[0].toLowerCase(); }
function requestKey(jid, sender) { return `${scanKey(`${jid}:${memberKey(sender)}`)}`; }
function participantId(participant) { return participant?.id || participant?.jid || participant?.lid || null; }
async function botIsAdmin(sock, metadata, config) {
  const candidates = [sock.user?.id, sock.user?.jid, sock.user?.lid, getBotIdentity(sock, config), config.BOT_JID].filter(Boolean);
  return candidates.some((candidate) => isParticipantAdminByIdentity(metadata?.participants || [], candidate));
}
async function protectedMember(value) {
  const number = phoneNumberFromValue(value);
  if (!number) return false;
  const user = await User.findOne({ $or: [{ phoneNumber: number }, { userId: number }, { moonId: number }, { whatsappNumber: value }] }).select('role isTrueOwner isCDC').lean().catch(() => null);
  return Boolean(user?.isTrueOwner || user?.isCDC || STAFF.includes(user?.role));
}
function scanMessage(data) {
  const checked = (data.checkedBots || []).map((name) => name[0].toUpperCase() + name.slice(1)).join(', ') || 'none';
  return `🔎 *COMMUNITY LIVE SCAN COMPLETE*\n\nChecked bots: *${checked}*\nMembers found in the community but in none of the linked groups: *${(data.candidates || []).length}*\n\nNo one was removed. Review the result, then send *.kickc confirm*.\n\n> The scan used each responding bot's live WhatsApp group list.`;
}
moon({ name: 'kickc', category: 'group', roles: ['Guardian', 'Mod', 'Owner', 'True Owner'], description: 'Live-scan community members across the bot fleet, then confirm cleanup.', usage: '.kickc <count>|all | .kickc confirm', async execute(sock, jid, sender, args, m, { reply, config }) {
  if (!jid.endsWith('@g.us')) return reply('❌ Use `.kickc` inside a group.');
  const communities = await getConfiguredCommunities();
  if (!communities.length) return reply('❌ No community is configured. Set one with `.ckick set <community-id>` first.');
  const communityJid = communities[0];
  const key = requestKey(jid, sender);
  const sub = String(args?.[0] || '').toLowerCase();
  if (sub === 'confirm') {
    const row = await System.findOne({ key }).lean();
    const data = row?.value || {};
    if (data.status !== 'ready') return reply('❌ The live scan is not ready yet. Run `.kickc all` and wait for the scan-complete message.');
    if (new Date(data.expiresAt || 0).getTime() < Date.now()) return reply('❌ This scan expired. Run `.kickc all` again.');
    const metadata = await sock.groupMetadata(data.communityJid).catch(() => null);
    if (!metadata) return reply('❌ I cannot read the configured community right now; nobody was removed.');
    if (!(await botIsAdmin(sock, metadata, config))) return reply('❌ I am not an admin in the configured community; nobody was removed.');
    const current = new Set((metadata.participants || []).map(participantId).filter(Boolean).map(memberKey));
    const groupMembers = new Set((data.results || []).flatMap((result) => result.groupMembers || []));
    const safe = [];
    const skipped = [];
    for (const candidate of data.candidates || []) {
      if (!current.has(memberKey(candidate)) || groupMembers.has(memberKey(candidate)) || await protectedMember(candidate)) skipped.push(candidate);
      else safe.push(candidate);
    }
    const removed = [];
    for (let i = 0; i < safe.length; i += 20) {
      try { await sock.groupParticipantsUpdate(data.communityJid, safe.slice(i, i + 20), 'remove'); removed.push(...safe.slice(i, i + 20)); }
      catch (error) { console.error('[KICKC LIVE REMOVE]', error.message); }
    }
    await System.updateOne({ _id: row._id }, { $set: { 'value.status': 'completed', 'value.completedAt': new Date(), 'value.removed': removed, 'value.skipped': skipped } });
    const list = removed.map((id) => `• ${id.split('@')[0]}`).join('\n') || '• None';
    return reply(`✅ *COMMUNITY CLEANUP COMPLETE*\n\n*Removed:* ${removed.length}\n${list}\n\n*Skipped safely:* ${skipped.length}\n> Skipped includes members now found in a group, no longer present, or protected staff.`);
  }
  const amount = sub === 'all' ? 1000 : Number(sub);
  if (!Number.isInteger(amount) || amount < 1 || amount > 1000) return reply('Usage: `.kickc 1`, `.kickc 10`, `.kickc all`, then `.kickc confirm`.');
  const existing = await System.findOne({ key }).lean();
  if (existing?.value?.status === 'scanning' && Date.now() - new Date(existing.value.createdAt || 0).getTime() < 60_000) return reply('⏳ The six-bot live scan is still running. Please wait for the scan-complete message.');
  if (existing?.value?.status === 'ready') return reply(scanMessage(existing.value));
  await System.findOneAndUpdate({ key }, { $set: { value: { status: 'scanning', communityJid, responseJid: jid, requesterJid: sender, amount, createdAt: new Date(), expiresAt: new Date(Date.now() + 10 * 60 * 1000), results: [] }, updatedAt: new Date() } }, { upsert: true });
  return reply(`🔎 Starting a *live community scan* across Rem, Frieren, Rimuru, Saber, Cid, and Kurumi.\n\nNo one will be removed during the scan. I will compare the community against every linked group and report the exact count.\n\n> Wait for the scan-complete message, then use *.kickc confirm* if the result is correct.`);
}});
