const { getGroup, updateGroup } = require('../../models/athers/GroupSettings');

moon({
  name: 'spm',
  category: 'admin',
  roles: ['Owner', 'Guardian', 'Mod'],
  description: 'Configure rapid-link protection or send a small authorized announcement batch.',
  usage: '.spm lock | .spm unlock | .spm <1-250> <message>',
  async execute(sock, jid, sender, args, m, { reply }) {
    if (!jid.endsWith('@g.us')) return reply('❌ `.spm` can only be used in a group.');
    const sub = String(args[0] || '').toLowerCase();
    const group = getGroup(jid);
    if (sub === 'lock' || sub === 'unlock') {
      const locked = sub === 'lock';
      updateGroup(jid, { spm: { ...(group.spm || {}), locked, windowMs: 2000, linkLimit: 2 } });
      return reply(locked
        ? '🔒 *SPM LINK PROTECTION ENABLED*\n> Two links from the same member within 2 seconds will be deleted and the member removed.\n> The bot will not flood the group.'
        : '🔓 *SPM LINK PROTECTION DISABLED*');
    }
    const count = Number.parseInt(sub, 10);
    const message = args.slice(1).join(' ').trim();
    if (!Number.isInteger(count) || count < 1 || count > 250 || !message) return reply('❌ Usage: `.spm lock`, `.spm unlock`, or `.spm <1-250> <message>`.');
    // Hard cap: requested testing limit. Keep a tiny yield between sends so the
    // socket event loop remains responsive for moderation and battle commands.
    for (let i = 0; i < count; i += 1) {
      await sock.sendMessage(jid, { text: `📢 ${message}` }, { quoted: m });
      if (i < count - 1) await new Promise((resolve) => setTimeout(resolve, 20));
    }
    return undefined;
  },
});
