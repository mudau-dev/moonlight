const { findParticipantByIdentity, isParticipantAdmin, getBotIdentity, sameIdentity } = require('../../utils/adminIdentity');
const config = require('../../config');

moon({
  name: "tag",
  category: "group",

  async execute(sock, jid, sender, args, m, { reply, isStaff }) {
    try {

      if (!jid.endsWith("@g.us")) return;

      const metadata = await sock.groupMetadata(jid);

      const user = findParticipantByIdentity(metadata.participants, sender);
      if (!isStaff && (!user || !user.admin)) return;

      const bot = findParticipantByIdentity(metadata.participants, getBotIdentity(sock, config));
      if (!bot || !bot.admin) return;

      const members = metadata.participants.map(p => p.id);

      const quotedCtx = m.message?.extendedTextMessage?.contextInfo || m.message?.imageMessage?.contextInfo || m.message?.videoMessage?.contextInfo || m.message?.stickerMessage?.contextInfo;
      const hasQuoted = !!quotedCtx?.stanzaId;

      // -------- CASE 1: reply to ANY message (text/media/sticker) --------
      if (hasQuoted) {
        try {
          await sock.sendMessage(jid, {
            forward: m.quoted?.message ? { key: { remoteJid: jid, id: quotedCtx.stanzaId, participant: quotedCtx.participant }, message: m.quoted.message } : undefined,
            text: m.quoted?.message ? undefined : (m.quoted?.text || m.quoted?.conversation || m.quoted?.caption || 'ㅤ'),
            mentions: members
          });
        } catch {
          // fallback if forward fails
          await sock.sendMessage(jid, {
            text: "ㅤㅤㅤㅤ",
            mentions: members
          });
        }

      } else {
        // -------- CASE 2: text or fallback --------
        let message = args.join(" ").trim();

        if (!message) {
          message = "‎‎‎‎‎‎ㅤ"; // your required blank
        }

        await sock.sendMessage(jid, {
          text: message,
          mentions: members
        }, { quoted: m });
      }

      // -------- DELETE .tag COMMAND --------
      try {
        await sock.sendMessage(jid, {
          delete: {
            remoteJid: jid,
            fromMe: true,
            id: m.key.id,
            participant: m.key.participant || sender
          }
        });
      } catch {}

    } catch (err) {
      console.error("tag error:", err);
      // silent
    }
  }
});
