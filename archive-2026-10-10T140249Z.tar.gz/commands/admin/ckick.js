const User = require('../../models/User');
const KickRequest = require('../../models/athers/KickRequest');
const config = require('../../config');
const { resolveMessageTarget, phoneNumberFromValue } = require('../../utils/adminIdentity');
const {
  MAX_COMMUNITIES,
  normalizeCommunityJid,
  getConfiguredCommunities,
  setConfiguredCommunities,
  createKickRequest,
} = require('../../handlers/Community');

const ALLOWED_ROLES = new Set(['Guardian', 'Mod', 'Owner', 'True Owner']);
const PROTECTED_ROLES = new Set(['Guardian', 'Mod', 'Owner', 'True Owner', 'CDC']);

async function lookupUser(jid) {
  const number = phoneNumberFromValue(jid);
  return User.findOne({
    $or: [
      { whatsappNumber: jid },
      ...(number ? [{ phoneNumber: number }, { userId: number }, { moonId: number }] : []),
    ],
  }).lean();
}

async function hasCommunityKickRole(sender) {
  const user = await lookupUser(sender);
  return Boolean(user?.isTrueOwner === true || ALLOWED_ROLES.has(user?.role));
}

moon({
  name: 'ckick',
  category: 'group',
  description: 'Create a persistent community-wide kick action or manage configured communities.',
  usage: '.ckick @user | .ckick set <community-jid> | .ckick add <community-jid> | .ckick del <community-jid> | .ckick list',
  roles: ['Guardian', 'Mod', 'Owner', 'True Owner'],
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      if (!jid.endsWith('@g.us')) return reply('❌ This command can only be used in groups.');
      if (!(await hasCommunityKickRole(sender))) return reply('❌ Only True Owners, Owners, Mods, and Guardians can use `.ckick`.');

      const subcommand = String(args[0] || '').toLowerCase();
      if (subcommand === 'list') {
        const communities = await getConfiguredCommunities();
        if (!communities.length) return reply('No communities are configured for community kicks.');
        return reply(`🌙 *COMMUNITY KICK LIST*\n\n${communities.map((community, index) => `${index + 1}. ${community}`).join('\n')}`);
      }

      if (subcommand === 'set') {
        const communityJid = normalizeCommunityJid(args[1]);
        if (!communityJid) return reply('❌ Usage: .ckick set <community-id/jid>');
        await setConfiguredCommunities([communityJid]);
        return reply(`✅ Community replaced for fleet-wide kicks: ${communityJid}`);
      }
      if (subcommand === 'add' || subcommand === 'del') {
        const communityJid = normalizeCommunityJid(args[1]);
        if (!communityJid) return reply(`❌ Usage: \.ckick ${subcommand} <community-id/jid>`);
        const current = await getConfiguredCommunities();
        if (subcommand === 'add') {
          if (current.includes(communityJid)) return reply('That community is already configured.');
          if (current.length >= MAX_COMMUNITIES) return reply(`❌ A maximum of ${MAX_COMMUNITIES} communities can be configured.`);
          await setConfiguredCommunities([...current, communityJid]);
          return reply(`✅ Community added for fleet-wide kicks: ${communityJid}`);
        }
        if (!current.includes(communityJid)) return reply('That community is not configured.');
        await setConfiguredCommunities(current.filter((community) => community !== communityJid));
        return reply(`✅ Community removed from fleet-wide kicks: ${communityJid}`);
      }

      const targetJid = await resolveMessageTarget(sock, m, args);
      if (!targetJid) return reply('❌ Mention, reply to, or provide the user you want to community-kick.');
      if (phoneNumberFromValue(targetJid) === phoneNumberFromValue(sender)) return reply("😅 You can't kick yourself!");

      const targetUser = await lookupUser(targetJid);
      if (targetUser && PROTECTED_ROLES.has(targetUser.isTrueOwner ? 'True Owner' : targetUser.role)) {
        return reply('❌ Staff members cannot be community-kicked.');
      }

      const created = await createKickRequest({ targetJid, requesterJid: sender, responseJid: jid });
      if (created.reason === 'no_communities') return reply('❌ No communities are configured. Use `.ckick add <community-id/jid>` first.');
      if (!created.created) return reply('⏳ A community-kick action for this user is already processing.');
      const progress = await sock.sendMessage(jid, {
        text: `> kicking user from all community's groups\n\n⏳ Starting fleet-wide kick for @${targetJid.split('@')[0]}...`,
        mentions: [targetJid],
      }, { quoted: m });
      if (progress?.key) await KickRequest.updateOne(
        { _id: created.request._id },
        { $set: { progressKey: progress.key, progressBotName: config.BOT_NAME } },
      );
      return undefined;
    } catch (error) {
      console.error('[CKICK ERROR]', error);
      return reply('❌ Failed to create the community-kick action.');
    }
  },
});
