const { findParticipantByIdentity, isParticipantAdmin, getBotIdentity, sameIdentity } = require('../../utils/adminIdentity');
const config = require('../../config');

moon({
  name: "tagall",
  category: "group",

  async execute(sock, jid, sender, args, m, { reply, isStaff }) {
    try {

      if (!jid.endsWith("@g.us")) {
        return reply("❌ Group only.");
      }

      const metadata = await sock.groupMetadata(jid);

      const user = findParticipantByIdentity(metadata.participants, sender);
      if (!isStaff && (!user || !user.admin)) {
        return reply("❌ Admin only.");
      }

      const bot = findParticipantByIdentity(metadata.participants, getBotIdentity(sock, config));
      if (!bot || !bot.admin) {
        return reply("❌ Bot must be admin.");
      }

      const members = metadata.participants.map(p => p.id);

      // message source
      let message = args.join(" ");
      if (!message && m.quoted) {
        message =
          m.quoted.text ||
          m.quoted.conversation ||
          m.quoted.caption ||
          "";
      }

      if (!message) message = "No message provided.";

      const text = `
❀ TAGGED BY: @${sender.split("@")[0]}
❀ MESSAGE:
${message}
${members.map(u => `❀ @${u.split("@")[0]}`).join("\n")}
`.trim();

      await sock.sendMessage(jid, {
        text,
        mentions: members
      }, { quoted: m });

    } catch (err) {
      console.error("tagall error:", err);
      return reply("❌ Failed to execute tagall.");
    }
  }
});
