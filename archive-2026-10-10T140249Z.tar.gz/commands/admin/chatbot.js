const axios = require('axios');
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const Group = require('../../models/athers/Group');
const STAFF = ['Guardian', 'Mod', 'Owner', 'True Owner'];
const QUERIES = {
  rem: 'Rem anime cute reaction sticker',
  frieren: 'Frieren anime reaction sticker',
  rimuru: 'Rimuru Tempest anime reaction sticker',
  saber: 'Saber Artoria anime reaction sticker',
  cid: 'Cid Kagenou Eminence in Shadow reaction sticker',
  kurumi: 'Kurumi Tokisaki anime reaction sticker',
};
function slug(name) { return String(name || 'moonlight').toLowerCase().replace(/[^a-z0-9]+/g, '_'); }
function queryFor(name) { return QUERIES[String(name || '').toLowerCase()] || `${name} anime reaction sticker`; }
async function fetchStickers(botName) {
  const moods = {
    rem: ['smile', 'happy', 'wave', 'blush', 'hug'],
    frieren: ['think', 'sleep', 'smug', 'wave', 'happy'],
    rimuru: ['happy', 'smug', 'wave', 'think', 'hug'],
    saber: ['angry', 'serious', 'wave', 'happy', 'smug'],
    cid: ['smug', 'cool', 'think', 'stare', 'happy'],
    kurumi: ['smile', 'wink', 'blush', 'kiss', 'love'],
  };
  const list = moods[String(botName || '').toLowerCase()] || ['happy', 'wave', 'smile', 'think', 'blush'];
  const root = path.join(process.cwd(), 'assets', 'stickers');
  fs.mkdirSync(root, { recursive: true });
  const prefix = `sticker_${slug(botName)}_`;
  for (const file of fs.readdirSync(root)) if (file.startsWith(prefix) && file.endsWith('.webp')) fs.rmSync(path.join(root, file), { force: true });
  let saved = 0;
  for (const mood of list) {
    try {
      const response = await axios.get(`https://nekos.best/api/v2/${encodeURIComponent(mood)}`, { timeout: 25_000 });
      const source = response.data?.results?.[0]?.url;
      if (!source) continue;
      const image = await axios.get(source, { timeout: 25_000, responseType: 'arraybuffer' });
      const input = path.join(root, `.sticker_${slug(botName)}_${saved + 1}.input`);
      const output = path.join(root, `${prefix}anime_${saved + 1}.webp`);
      fs.writeFileSync(input, Buffer.from(image.data));
      execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', input, '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white@0', '-vcodec', 'libwebp', '-lossless', '0', '-q:v', '70', output], { timeout: 45_000 });
      fs.rmSync(input, { force: true });
      if (fs.statSync(output).size > 100) saved++;
      if (saved >= 5) break;
    } catch (error) { console.error('[CHATBOT STICKER SOURCE]', mood, error.message); }
  }
  return saved;
}
moon({ name: 'chatbot', aliases: ['aichat'], category: 'group', roles: STAFF, description: 'Enable/disable the chatbot for this group or fetch five personality stickers.', usage: '.chatbot on | .chatbot off | .chatbot set', async execute(sock, jid, sender, args, m, { reply, config }) {
  if (!jid.endsWith('@g.us')) return reply('❌ Use this command inside a group.');
  const sub = String(args?.[0] || '').toLowerCase();
  if (sub === 'on' || sub === 'off') {
    await Group.findOneAndUpdate({ groupId: jid }, { $set: { chatbotEnabled: sub === 'on' } }, { upsert: true, new: true, setDefaultsOnInsert: true });
    return reply(`✅ Chatbot is now *${sub}* in this group.`);
  }
  if (sub === 'set') {
    try {
      const count = await fetchStickers(config.BOT_NAME);
      if (!count) return reply(`❌ No ${config.BOT_NAME} stickers were returned by Tenor.`);
      return reply(`✅ Saved *${count}* ${config.BOT_NAME} personality stickers. They will be used in this bot's chats.`);
    } catch (error) {
      console.error('[CHATBOT STICKERS]', error.response?.data || error.message);
      return reply('❌ The free sticker source could not be reached right now. Please try `.chatbot set` again.');
    }
  }
  return reply('Usage: `.chatbot on`, `.chatbot off`, or `.chatbot set`');
}});
