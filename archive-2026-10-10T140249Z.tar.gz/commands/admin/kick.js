const { findParticipantByIdentity, isParticipantAdmin, getBotIdentity, sameIdentity } = require('../../utils/adminIdentity');
const config = require('../../config');
const User = require('../../models/User');
const { getRealUserIdentity } = require('../../utils/whatsappIdentity');

moon({
  name: "kick",
  category: "group",
  description: "Kick a user from group",

  async execute(sock, jid, sender, args, m, { reply, isStaff }) {
    try {
      const contextInfo = m.message?.extendedTextMessage?.contextInfo;
      const target = contextInfo?.mentionedJid?.[0] || contextInfo?.participant;

      if (!target) return reply("❌ Mention or reply to a user.");

      const targetIdentity = await getRealUserIdentity(sock, target).catch(() => null);
      const targetJid = targetIdentity?.phoneJid || target;
      const protectedUser = await User.findOne({ $or: [{ whatsappNumber: targetJid }, { phoneNumber: targetJid }, { userId: targetJid }] }).lean().catch(() => null);
      const protectedRoles = new Set(['Owner', 'True Owner', 'Mod', 'Guardian']);
      const targetRole = String(protectedUser?.role || '').trim();
      if (protectedUser && (protectedRoles.has(targetRole) || protectedUser.isTrueOwner === true)) {
        return reply(`🔒🌙 *anti lord protect*\noi.oi.oi how dare you use this command on a *moonLord* have some shame @${targetJid.split('@')[0]}`, { mentions: [targetJid] });
      }

      const metadata = await sock.groupMetadata(jid);

      const user = findParticipantByIdentity(metadata.participants, sender);
      const bot = findParticipantByIdentity(metadata.participants, getBotIdentity(sock, config));

      if (!isStaff && (!user || (user.admin !== "admin" && user.admin !== "superadmin"))) {
        return reply("❌ You must be admin.");
      }

      if (!bot || (bot.admin !== "admin" && bot.admin !== "superadmin")) {
        return reply("❌ Bot must be admin.");
      }

      await sock.groupParticipantsUpdate(jid, [target], "remove");

      return reply(`🚫 Kicked @${target.split('@')[0]}`, { mentions: [target] });

    } catch (err) {
      console.error(err);
      return reply("❌ Failed to kick user.");
    }
  }
});
