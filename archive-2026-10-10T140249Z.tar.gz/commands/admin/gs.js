const { getGroup } = require('../../models/athers/GroupSettings');
const Group = require('../../models/athers/Group');

function status(value) { return value ? 'on' : 'off'; }
function indicator(value) { return value ? '🟢' : '🔴'; }
function preview(value) {
  const text = String(value || 'N/A').trim() || 'N/A';
  return text.length > 15 ? `${text.slice(0, 15)}...` : text;
}

moon({
  name: 'gs',
  aliases: ['gstats', 'gcstats'],
  category: 'group',
  description: 'Show the Moonlight Haven group control panel and feature status.',
  async execute(sock, jid, sender, args, m, context) {
    if (!jid.endsWith('@g.us')) return context.reply('❌ This command only works in groups.');
    try {
      const [metadata, settings, dbGroup] = await Promise.all([
        sock.groupMetadata(jid),
        Promise.resolve(getGroup(jid) || {}),
        Group.findOne({ groupId: jid }).lean().catch(() => null),
      ]);
      const groupImage = await sock.profilePictureUrl(jid, 'image').catch(() => null);
      const warnLimit = settings.antilink?.warnLimit || 3;
      const gamblingEnabled = Boolean(dbGroup?.gamblingEnabled);
      const pokemonEnabled = dbGroup?.pokemonSpawnEnabled === true;
      const cardsEnabled = Boolean(dbGroup?.cardsEnabled || dbGroup?.cardSpawnEnabled);
      const caption = [
        '★ *GROUP • STATUS*',
        '┏━━━━━━━━━━━',
        `│ *Name:* ${metadata.subject || 'Moonlight'}`,
        `│ *ANTI-LINK:* ${status(settings.antilink?.enabled)}`,
        `│ *ANTI-MENTION:* ${status(settings.antimention?.enabled)}`,
        `│ *ANTI-BOT:* ${status(settings.antibot?.enabled)}`,
        `│ *MAX WARN'S:* ${warnLimit}/delete/kick`,
        '┣━━━━━━━━━━━━',
        `│ *WELCOME:* ${status(settings.welcomeEnabled)}`,
        '│ *MESSAGE*',
        `> ${preview(settings.welcomeMessage)}`,
        '',
        `│ *LEAVE:* ${status(settings.leaveEnabled)}`,
        '│ *MESSAGE:*',
        `> ${preview(settings.leaveMessage)}`,
        '│',
        '┣[𝐒𝐓𝐀𝐅𝐅 𝐂𝐌𝐃𝐒]━━━',
        `┣│ *Pokémon:* ${indicator(pokemonEnabled)}`,
        `┣│ *gambling:* ${indicator(gamblingEnabled)}`,
        `┣│ *cards spawn:* ${indicator(cardsEnabled)}`,
        '┗━━━━━━━━━━━━',
      ].join('\n');
      if (groupImage) return sock.sendMessage(jid, { image: { url: groupImage }, caption }, { quoted: m });
      return sock.sendMessage(jid, { text: caption }, { quoted: m });
    } catch (error) {
      console.error('[GS] status error:', error);
      return context.reply('❌ I could not load the group control panel right now.');
    }
  },
});
