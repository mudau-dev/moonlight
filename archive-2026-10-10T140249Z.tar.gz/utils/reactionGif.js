const axios = require('axios');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { promisify } = require('util');
const { execFile } = require('child_process');
const ffmpegPath = require('ffmpeg-static') || 'ffmpeg';

const execFileAsync = promisify(execFile);
const GIFUKAI_BASE = 'https://api.gifukai.com/v1';

async function gifToFiveLoopMp4(url) {
  const directory = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'moon-reaction-'));
  try {
    const source = path.join(directory, 'reaction.gif');
    const output = path.join(directory, 'reaction.mp4');
    const response = await axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 12000,
      maxRedirects: 5,
      maxContentLength: 12 * 1024 * 1024,
      maxBodyLength: 12 * 1024 * 1024,
      headers: { 'User-Agent': 'Moonlight-Haven-Reactions/1.0' },
    });
    await fs.promises.writeFile(source, Buffer.from(response.data));
    await execFileAsync(ffmpegPath, [
      '-y', '-stream_loop', '4', '-i', source,
      '-vf', 'fps=12,scale=480:-2:flags=lanczos,format=yuv420p',
      '-an', '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '27',
      '-movflags', 'faststart', output,
    ], { timeout: 25000, maxBuffer: 1024 * 1024 * 4 });
    return fs.promises.readFile(output);
  } finally {
    await fs.promises.rm(directory, { recursive: true, force: true });
  }
}

async function sendReactionGif(sock, jid, quoted, { action, text, sender, target }) {
  const endpoint = `${GIFUKAI_BASE}/${encodeURIComponent(action)}`;
  const { data } = await axios.get(endpoint, { timeout: 8000, headers: { Accept: 'application/json' } });
  if (!data?.url) throw new Error('Reaction API returned no GIF URL.');
  const video = await gifToFiveLoopMp4(data.url);
  return sock.sendMessage(jid, {
    video,
    mimetype: 'video/mp4',
    gifPlayback: true,
    ptv: false,
    caption: text,
    mentions: [sender, target].filter(Boolean),
  }, { quoted });
}

module.exports = { sendReactionGif };
