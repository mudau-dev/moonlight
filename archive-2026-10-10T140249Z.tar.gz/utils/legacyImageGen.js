/**
 * utils/legacyImageGen.js
 *
 * REDESIGNED: Cinematic dark fantasy profile card.
 * Avatar on left, glowing stats panel on right.
 * Fully robust — never throws, always returns a valid buffer.
 */

let createCanvas = null;
let loadImage = null;
try {
  ({ createCanvas, loadImage } = require('canvas'));
} catch (error) {
  console.warn('[LEGACY IMAGE] Native canvas unavailable; using Sharp fallback cards.');
}
const axios = require('axios');
const sharp = require('sharp');

async function fallbackPng(title, lines = [], accent = '#8b7cff') {
  const safe = (value) => String(value ?? '').replace(/[&<>\"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&apos;' }[char]));
  const text = [title, ...lines].map(safe);
  const rows = text.map((line, index) => `<text x=\"50%\" y=\"${72 + index * 34}\" text-anchor=\"middle\" fill=\"${index === 0 ? accent : '#f4f1ff'}\" font-family=\"Arial, sans-serif\" font-size=\"${index === 0 ? 28 : 19}\" font-weight=\"${index === 0 ? 700 : 400}\">${line}</text>`).join('');
  const svg = `<svg width=\"1000\" height=\"500\" xmlns=\"http://www.w3.org/2000/svg\"><defs><linearGradient id=\"bg\" x1=\"0\" x2=\"1\" y1=\"0\" y2=\"1\"><stop stop-color=\"#07051a\"/><stop offset=\".55\" stop-color=\"#171044\"/><stop offset=\"1\" stop-color=\"#050816\"/></linearGradient></defs><rect width=\"100%\" height=\"100%\" fill=\"url(#bg)\"/><circle cx=\"120\" cy=\"90\" r=\"72\" fill=\"none\" stroke=\"${accent}\" stroke-opacity=\".35\" stroke-width=\"3\"/><circle cx=\"880\" cy=\"410\" r=\"110\" fill=\"none\" stroke=\"#38d9ff\" stroke-opacity=\".25\" stroke-width=\"3\"/><rect x=\"18\" y=\"18\" width=\"964\" height=\"464\" rx=\"24\" fill=\"none\" stroke=\"${accent}\" stroke-opacity=\".6\" stroke-width=\"2\"/>${rows}</svg>`;
  return sharp(Buffer.from(svg)).png().toBuffer();
}

// ─────────────────────────────────────────────────────────────────────────────
// ASSETS & CONFIG
// ─────────────────────────────────────────────────────────────────────────────

const BG_URLS = {
  profile: 'https://files.catbox.moe/k3b4t0.jpg',
  battle:  'https://files.catbox.moe/qxd31v.jpg',
  victory: 'https://files.catbox.moe/k3b4t0.jpg',
  defeat:  'https://files.catbox.moe/qxd31v.jpg',
};

const CLASS_COLORS = {
  Mage: '#9b59b6', Warrior: '#e74c3c', Assassin: '#2ecc71',
  Archer: '#27ae60', Paladin: '#f39c12', Guardian: '#95a5a6',
};
const CLASS_ICONS = {
  Mage: '🔮', Warrior: '⚔️', Assassin: '🗡️',
  Archer: '🏹', Paladin: '🛡️', Guardian: '🤖',
};
const RANK_COLORS = {
  Commoner: '#aaa', Knight: '#c0c0c0', Baron: '#cd7f32',
  Viscount: '#4fc3f7', Count: '#ab47bc', Duke: '#ffd700',
  Archduke: '#ff7043', King: '#ef5350', Emperor: '#e040fb',
  'Celestial Emperor': '#ffeb3b', 'Celestial Empress': '#f48fb1',
};

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

async function loadImageSafe(url) {
  if (!url || !loadImage) return null;
  try {
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 8000 });
    return await loadImage(Buffer.from(res.data));
  } catch { return null; }
}

function roundRect(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawBar(ctx, x, y, w, h, current, max, colorA, colorB, label) {
  const pct = max > 0 ? Math.min(1, Math.max(0, current / max)) : 0;
  // Background track
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  roundRect(ctx, x, y, w, h, h / 2);
  ctx.fill();
  // Fill
  if (pct > 0) {
    const grad = ctx.createLinearGradient(x, y, x + w * pct, y);
    grad.addColorStop(0, colorA);
    grad.addColorStop(1, colorB);
    ctx.fillStyle = grad;
    roundRect(ctx, x, y, w * pct, h, h / 2);
    ctx.fill();
  }
  // Border
  ctx.strokeStyle = 'rgba(255,255,255,0.15)';
  ctx.lineWidth = 1;
  roundRect(ctx, x, y, w, h, h / 2);
  ctx.stroke();
  // Label
  if (label) {
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.font = `bold ${Math.max(10, h - 6)}px Sans`;
    ctx.textAlign = 'center';
    ctx.fillText(label, x + w / 2, y + h - 4);
  }
}

function drawStars(ctx, W, H) {
  ctx.save();
  for (let i = 0; i < 120; i++) {
    const x = (i * 83 + 37) % W;
    const y = (i * 137 + 19) % H;
    const r = i % 11 === 0 ? 1.5 : 0.7;
    ctx.globalAlpha = i % 7 === 0 ? 0.5 : 0.15;
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawGlowLine(ctx, x1, y1, x2, y2, color) {
  ctx.save();
  ctx.shadowColor = color;
  ctx.shadowBlur = 12;
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
  ctx.restore();
}

function drawStatBox(ctx, x, y, w, h, label, value, accent) {
  // Glass panel
  ctx.fillStyle = 'rgba(255,255,255,0.06)';
  roundRect(ctx, x, y, w, h, 10);
  ctx.fill();
  ctx.strokeStyle = `${accent}55`;
  ctx.lineWidth = 1;
  roundRect(ctx, x, y, w, h, 10);
  ctx.stroke();

  // Label
  ctx.fillStyle = 'rgba(255,255,255,0.5)';
  ctx.font = '13px Sans';
  ctx.textAlign = 'left';
  ctx.fillText(label, x + 10, y + 18);

  // Value
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 18px Sans';
  ctx.textAlign = 'right';
  ctx.fillText(String(value), x + w - 10, y + 36);
}

// ─────────────────────────────────────────────────────────────────────────────
// PROFILE CARD (.me) — CINEMATIC REDESIGN
// ─────────────────────────────────────────────────────────────────────────────
async function generateLegacyProfileCard(p, avatarUrl) {
  if (!createCanvas) return fallbackPng('MOONLIGHT LEGACY', [`${p.name || 'Unknown'} · Level ${p.level || 1}`, `${p.class || 'No Class'} · ${p.rank || 'Commoner'}`, `Gold ${p.gold || 0} · Wins ${p.wins || 0}`], '#ffd34d');
  try {
    const W = 1000, H = 580;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    // ── Background ──────────────────────────────────────────────────────────
    const bg = await loadImageSafe(BG_URLS.profile);
    if (bg) {
      const scale = Math.max(W / bg.width, H / bg.height);
      ctx.drawImage(bg, (W - bg.width * scale) / 2, (H - bg.height * scale) / 2, bg.width * scale, bg.height * scale);
    } else {
      // Fallback gradient background
      const bgGrad = ctx.createLinearGradient(0, 0, W, H);
      bgGrad.addColorStop(0, '#0a0015');
      bgGrad.addColorStop(0.5, '#0d001f');
      bgGrad.addColorStop(1, '#050010');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, W, H);
    }
    // Dark overlay for readability
    ctx.fillStyle = 'rgba(0,0,12,0.82)';
    ctx.fillRect(0, 0, W, H);

    // Stars
    drawStars(ctx, W, H);

    // ── Outer border with glow ───────────────────────────────────────────────
    const cls = p.class || 'None';
    const clsColor = CLASS_COLORS[cls] || '#ffd700';
    ctx.save();
    ctx.shadowColor = clsColor;
    ctx.shadowBlur = 20;
    ctx.strokeStyle = clsColor;
    ctx.lineWidth = 3;
    roundRect(ctx, 12, 12, W - 24, H - 24, 18);
    ctx.stroke();
    ctx.restore();

    // ── LEFT PANEL: Avatar ───────────────────────────────────────────────────
    const avX = 40, avY = 40, avSize = 280;

    // Avatar glow ring
    ctx.save();
    ctx.shadowColor = clsColor;
    ctx.shadowBlur = 30;
    ctx.strokeStyle = clsColor;
    ctx.lineWidth = 4;
    ctx.strokeRect(avX - 4, avY - 4, avSize + 8, avSize + 8);
    ctx.restore();

    // Avatar image
    const avatar = await loadImageSafe(avatarUrl);
    if (avatar) {
      ctx.save();
      roundRect(ctx, avX, avY, avSize, avSize, 12);
      ctx.clip();
      ctx.drawImage(avatar, avX, avY, avSize, avSize);
      ctx.restore();
    } else {
      // Placeholder
      const avGrad = ctx.createLinearGradient(avX, avY, avX + avSize, avY + avSize);
      avGrad.addColorStop(0, '#1a0030');
      avGrad.addColorStop(1, '#0a0020');
      ctx.fillStyle = avGrad;
      roundRect(ctx, avX, avY, avSize, avSize, 12);
      ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      ctx.font = '90px Sans';
      ctx.textAlign = 'center';
      ctx.fillText('⚔️', avX + avSize / 2, avY + avSize / 2 + 30);
    }

    // Avatar corner accent
    ctx.strokeStyle = clsColor;
    ctx.lineWidth = 2;
    ctx.strokeRect(avX, avY, avSize, avSize);

    // ── Name & Class below avatar ────────────────────────────────────────────
    const nameY = avY + avSize + 38;
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 34px Sans';
    ctx.textAlign = 'left';
    ctx.fillText(p.name || 'Unknown', avX, nameY);

    // Class badge
    const classLabel = `${CLASS_ICONS[cls] || ''} ${cls}`;
    ctx.fillStyle = clsColor;
    ctx.font = 'bold 20px Sans';
    ctx.fillText(classLabel, avX, nameY + 32);

    // Rank
    const rankColor = RANK_COLORS[p.rank] || '#ffd700';
    ctx.fillStyle = rankColor;
    ctx.font = 'italic 17px Sans';
    ctx.fillText(`✦ ${p.rank || 'Commoner'} ✦`, avX, nameY + 58);

    // ── Divider ──────────────────────────────────────────────────────────────
    drawGlowLine(ctx, 360, 20, 360, H - 20, clsColor);

    // ── RIGHT PANEL: Stats ───────────────────────────────────────────────────
    const rx = 390, barW = 580;

    // Section header
    ctx.fillStyle = clsColor;
    ctx.font = 'bold 22px Sans';
    ctx.textAlign = 'left';
    ctx.fillText('COMBAT STATS', rx, 55);
    drawGlowLine(ctx, rx, 62, rx + barW, 62, clsColor);

    // HP Bar
    ctx.fillStyle = '#ff6b6b';
    ctx.font = 'bold 15px Sans';
    ctx.fillText('❤️  HP', rx, 88);
    drawBar(ctx, rx, 95, barW, 26, p.hp, p.maxHp, '#7b241c', '#e74c3c', `${p.hp} / ${p.maxHp}`);

    // Mana Bar
    ctx.fillStyle = '#74b9ff';
    ctx.font = 'bold 15px Sans';
    ctx.fillText('💧  MANA', rx, 145);
    drawBar(ctx, rx, 152, barW, 26, p.mana, p.maxMana, '#1a5276', '#2980b9', `${p.mana} / ${p.maxMana}`);

    // XP Bar
    ctx.fillStyle = '#ffd700';
    ctx.font = 'bold 15px Sans';
    ctx.fillText('✨  XP', rx, 202);
    drawBar(ctx, rx, 209, barW, 26, p.xp, p.xpToNext, '#7d6608', '#d4ac0d', `${p.xp} / ${p.xpToNext}`);

    // ── Stat Grid ────────────────────────────────────────────────────────────
    const statBoxW = 185, statBoxH = 52, statGapX = 10, statGapY = 10;
    const stats = [
      { l: 'Level',    v: p.level || 1,                    c: '#ffd700' },
      { l: 'Gold',     v: (p.gold || 0).toLocaleString(),  c: '#f39c12' },
      { l: 'Wins',     v: p.wins || 0,                     c: '#2ecc71' },
      { l: 'Losses',   v: p.losses || 0,                   c: '#e74c3c' },
      { l: 'ATK',      v: p.attack || 0,                   c: '#e74c3c' },
      { l: 'DEF',      v: p.defense || 0,                  c: '#3498db' },
      { l: 'Stage',    v: `${p.stage || 1} / 30`,          c: '#9b59b6' },
      { l: 'Progress', v: `${p.stageProgress || 0}%`,      c: '#1abc9c' },
      { l: 'Magic',    v: p.magic || 0,                    c: '#9b59b6' },
      { l: 'Speed',    v: p.speed || 0,                    c: '#1abc9c' },
      { l: 'Crit',     v: `${p.critRate || 0}%`,           c: '#e67e22' },
      { l: 'Battles',  v: (p.wins || 0) + (p.losses || 0), c: '#95a5a6' },
    ];

    const colCount = 3;
    stats.forEach((s, i) => {
      const col = i % colCount;
      const row = Math.floor(i / colCount);
      const x = rx + col * (statBoxW + statGapX);
      const y = 255 + row * (statBoxH + statGapY);
      drawStatBox(ctx, x, y, statBoxW, statBoxH, s.l, s.v, s.c);
    });

    return canvas.toBuffer('image/png');
  } catch (err) {
    console.error('[PROFILE CARD ERROR]', err);
    // Return a minimal fallback card so the command never crashes
    const W = 600, H = 200;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#0a0015';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#ffd700';
    ctx.font = 'bold 28px Sans';
    ctx.textAlign = 'center';
    ctx.fillText('⚔️ MOONLIGHT LEGACY', W / 2, 80);
    ctx.fillStyle = '#fff';
    ctx.font = '20px Sans';
    ctx.fillText(p.name || 'Unknown', W / 2, 120);
    ctx.fillStyle = '#aaa';
    ctx.font = '16px Sans';
    ctx.fillText(`Level ${p.level || 1} | ${p.class || 'No Class'} | ${p.rank || 'Commoner'}`, W / 2, 155);
    return canvas.toBuffer('image/png');
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// BATTLE CARD
// ─────────────────────────────────────────────────────────────────────────────
async function generateBattleCard(p1, p2, round, currentTurnName) {
  if (!createCanvas) return fallbackPng('MOONLIGHT LEGACY BATTLE', [`${p1.name || 'Player'} VS ${p2.name || 'Opponent'}`, `Round ${round || 1}`, `Turn: ${currentTurnName || 'Player'}`], '#38d9ff');
  try {
    const W = 1000, H = 500;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    const bg = await loadImageSafe(BG_URLS.battle);
    if (bg) {
      const scale = Math.max(W / bg.width, H / bg.height);
      ctx.drawImage(bg, (W - bg.width * scale) / 2, (H - bg.height * scale) / 2, bg.width * scale, bg.height * scale);
    } else {
      ctx.fillStyle = '#0a0010';
      ctx.fillRect(0, 0, W, H);
    }
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    ctx.fillRect(0, 0, W, H);
    drawStars(ctx, W, H);

    // VS Line
    drawGlowLine(ctx, W / 2, 40, W / 2, H - 40, '#ffd700');

    // P1 (Left)
    const av1 = await loadImageSafe(p1.avatarUrl);
    if (av1) {
      ctx.save();
      roundRect(ctx, 100, 80, 150, 150, 10);
      ctx.clip();
      ctx.drawImage(av1, 100, 80, 150, 150);
      ctx.restore();
    }
    ctx.save();
    ctx.shadowColor = CLASS_COLORS[p1.class] || '#ffd700';
    ctx.shadowBlur = 15;
    ctx.strokeStyle = CLASS_COLORS[p1.class] || '#ffd700';
    ctx.lineWidth = 3;
    ctx.strokeRect(100, 80, 150, 150);
    ctx.restore();

    ctx.fillStyle = '#fff';
    ctx.font = 'bold 22px Sans';
    ctx.textAlign = 'center';
    ctx.fillText(p1.name, 175, 260);
    drawBar(ctx, 50, 278, 250, 22, p1.hp, p1.maxHp, '#7b241c', '#e74c3c', `HP: ${p1.hp}`);
    drawBar(ctx, 50, 308, 250, 22, p1.mana, p1.maxMana, '#1a5276', '#2980b9', `MP: ${p1.mana}`);

    // P2 (Right)
    const av2 = await loadImageSafe(p2.avatarUrl);
    if (av2) {
      ctx.save();
      roundRect(ctx, W - 250, 80, 150, 150, 10);
      ctx.clip();
      ctx.drawImage(av2, W - 250, 80, 150, 150);
      ctx.restore();
    }
    ctx.save();
    ctx.shadowColor = CLASS_COLORS[p2.class] || '#e74c3c';
    ctx.shadowBlur = 15;
    ctx.strokeStyle = CLASS_COLORS[p2.class] || '#e74c3c';
    ctx.lineWidth = 3;
    ctx.strokeRect(W - 250, 80, 150, 150);
    ctx.restore();

    ctx.fillStyle = '#fff';
    ctx.fillText(p2.name, W - 175, 260);
    drawBar(ctx, W - 300, 278, 250, 22, p2.hp, p2.maxHp, '#7b241c', '#e74c3c', `HP: ${p2.hp}`);
    drawBar(ctx, W - 300, 308, 250, 22, p2.mana, p2.maxMana, '#1a5276', '#2980b9', `MP: ${p2.mana}`);

    // Center Info
    ctx.save();
    ctx.shadowColor = '#ffd700';
    ctx.shadowBlur = 20;
    ctx.fillStyle = '#ffd700';
    ctx.font = 'bold 64px Sans';
    ctx.fillText('VS', W / 2, 185);
    ctx.restore();

    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.font = '20px Sans';
    ctx.fillText(`Round ${round}`, W / 2, 225);

    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    roundRect(ctx, W / 2 - 160, 350, 320, 60, 12);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,215,0,0.3)';
    ctx.lineWidth = 1;
    roundRect(ctx, W / 2 - 160, 350, 320, 60, 12);
    ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 20px Sans';
    ctx.fillText(`TURN: ${currentTurnName}`, W / 2, 390);

    return canvas.toBuffer('image/png');
  } catch (err) {
    console.error('[BATTLE CARD ERROR]', err);
    const canvas = createCanvas(600, 200);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#0a0010';
    ctx.fillRect(0, 0, 600, 200);
    ctx.fillStyle = '#ffd700';
    ctx.font = 'bold 28px Sans';
    ctx.textAlign = 'center';
    ctx.fillText(`${p1.name} VS ${p2.name}`, 300, 110);
    return canvas.toBuffer('image/png');
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// RESULT CARD
// ─────────────────────────────────────────────────────────────────────────────
async function generateResultCard(type, p) {
  if (!createCanvas) return fallbackPng(type === 'victory' ? 'VICTORY' : 'DEFEAT', [`${p.name || 'Player'}`, `+${p.xpEarned || 0} XP  ·  +${p.goldEarned || 0} Gold`, p.newLevel ? `Level Up: ${p.newLevel}` : 'Battle complete'], type === 'victory' ? '#ffd34d' : '#ff6688');
  try {
    const W = 800, H = 500;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');
    const isWin = type === 'victory';

    const bg = await loadImageSafe(isWin ? BG_URLS.victory : BG_URLS.defeat);
    if (bg) {
      const scale = Math.max(W / bg.width, H / bg.height);
      ctx.drawImage(bg, (W - bg.width * scale) / 2, (H - bg.height * scale) / 2, bg.width * scale, bg.height * scale);
    } else {
      ctx.fillStyle = isWin ? '#001500' : '#150000';
      ctx.fillRect(0, 0, W, H);
    }
    ctx.fillStyle = isWin ? 'rgba(0,20,0,0.82)' : 'rgba(20,0,0,0.82)';
    ctx.fillRect(0, 0, W, H);
    drawStars(ctx, W, H);

    const accentColor = isWin ? '#ffd700' : '#ff4444';
    ctx.save();
    ctx.shadowColor = accentColor;
    ctx.shadowBlur = 30;
    ctx.fillStyle = accentColor;
    ctx.font = 'bold 80px Sans';
    ctx.textAlign = 'center';
    ctx.fillText(isWin ? '✦ VICTORY ✦' : '✦ DEFEAT ✦', W / 2, 120);
    ctx.restore();

    const av = await loadImageSafe(p.avatarUrl);
    if (av) {
      ctx.save();
      roundRect(ctx, W / 2 - 75, 150, 150, 150, 10);
      ctx.clip();
      ctx.drawImage(av, W / 2 - 75, 150, 150, 150);
      ctx.restore();
    }
    ctx.save();
    ctx.shadowColor = accentColor;
    ctx.shadowBlur = 15;
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 3;
    ctx.strokeRect(W / 2 - 75, 150, 150, 150);
    ctx.restore();

    ctx.fillStyle = '#fff';
    ctx.font = 'bold 30px Sans';
    ctx.fillText(p.name, W / 2, 340);

    ctx.fillStyle = 'rgba(255,255,255,0.8)';
    ctx.font = '22px Sans';
    ctx.fillText(`+${p.xpEarned} XP  |  +${p.goldEarned} Gold`, W / 2, 378);

    if (p.newLevel) {
      ctx.save();
      ctx.shadowColor = '#00ff88';
      ctx.shadowBlur = 20;
      ctx.fillStyle = '#00ff88';
      ctx.font = 'bold 32px Sans';
      ctx.fillText(`⬆️ LEVEL UP! → ${p.newLevel}`, W / 2, 430);
      ctx.restore();
    }

    return canvas.toBuffer('image/png');
  } catch (err) {
    console.error('[RESULT CARD ERROR]', err);
    const canvas = createCanvas(400, 150);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#0a0010';
    ctx.fillRect(0, 0, 400, 150);
    ctx.fillStyle = '#ffd700';
    ctx.font = 'bold 24px Sans';
    ctx.textAlign = 'center';
    ctx.fillText(type === 'victory' ? 'VICTORY' : 'DEFEAT', 200, 80);
    return canvas.toBuffer('image/png');
  }
}

async function generateLegacyInfoBanner() {
  if (!createCanvas) return fallbackPng('MOONLIGHT LEGACY', ['A persistent fantasy adventure', 'Create your character and begin your journey'], '#ffd34d');
  try {
    const W = 900, H = 500;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    const bgGrad = ctx.createLinearGradient(0, 0, W, H);
    bgGrad.addColorStop(0, '#050010');
    bgGrad.addColorStop(0.5, '#0d001f');
    bgGrad.addColorStop(1, '#050010');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);
    drawStars(ctx, W, H);

    ctx.save();
    ctx.shadowColor = '#ffd700';
    ctx.shadowBlur = 30;
    ctx.fillStyle = '#ffd700';
    ctx.font = 'bold 56px Sans';
    ctx.textAlign = 'center';
    ctx.fillText('⚔️  MOONLIGHT LEGACY  ⚔️', W / 2, 200);
    ctx.restore();

    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.font = '24px Sans';
    ctx.fillText('A Persistent Fantasy MMORPG', W / 2, 260);

    ctx.strokeStyle = 'rgba(255,215,0,0.4)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(W / 2 - 200, 280);
    ctx.lineTo(W / 2 + 200, 280);
    ctx.stroke();

    return canvas.toBuffer('image/png');
  } catch (err) {
    console.error('[INFO BANNER ERROR]', err);
    const canvas = createCanvas(400, 150);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#050010';
    ctx.fillRect(0, 0, 400, 150);
    ctx.fillStyle = '#ffd700';
    ctx.font = 'bold 24px Sans';
    ctx.textAlign = 'center';
    ctx.fillText('MOONLIGHT LEGACY', 200, 80);
    return canvas.toBuffer('image/png');
  }
}

module.exports = {
  generateLegacyProfileCard,
  generateBattleCard,
  generateResultCard,
  generateLegacyInfoBanner,
};
