const { getLinkPreview } = require('link-preview-js');
const DEFAULT_PREVIEW_IMAGE = 'https://files.catbox.moe/gim8wi.jpeg';

function normalizeHttpUrl(value) {
  try {
    const url = new URL(String(value || '').trim());
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    return url.toString();
  } catch {
    return null;
  }
}

async function createLinkPreview(value) {
  const url = normalizeHttpUrl(value);
  if (!url) return null;

  try {
    const metadata = await getLinkPreview(url, {
      timeout: 6_000,
      followRedirects: 'follow',
      headers: { 'user-agent': 'Mozilla/5.0 (compatible; MoonlightHavenBot/1.0)' },
    });
    const imageUrl = (Array.isArray(metadata.images) ? metadata.images[0] : undefined) || metadata.image || metadata.favicons?.[0] || DEFAULT_PREVIEW_IMAGE;
    return {
      url,
      title: metadata.title || 'Moonlight Haven',
      description: metadata.description || 'Open this Moonlight Haven page.',
      imageUrl,
    };
  } catch (error) {
    console.warn('[LINK PREVIEW]', error.message);
    return { url, title: 'Moonlight Haven', description: 'Open this Moonlight Haven page.', imageUrl: DEFAULT_PREVIEW_IMAGE };
  }
}

function extractHttpUrls(text) {
  return [...String(text || '').matchAll(/https?:\/\/[^\s<>]+/gi)]
    .map((match) => normalizeHttpUrl(match[0].replace(/[),.!?;:]+$/, '')))
    .filter(Boolean)
    .filter((url, index, all) => all.indexOf(url) === index);
}

function extractGroupInviteCode(value) {
  const url = normalizeHttpUrl(value);
  if (!url) return null;
  try {
    const parsed = new URL(url);
    if (parsed.hostname.toLowerCase() !== 'chat.whatsapp.com') return null;
    const code = parsed.pathname.split('/').filter(Boolean)[0];
    return /^[A-Za-z0-9_-]{10,80}$/.test(code || '') ? code : null;
  } catch {
    return null;
  }
}

async function loadThumbnail(imageUrl) {
  if (!imageUrl) return undefined;
  try {
    const response = await fetch(imageUrl, {
      headers: { 'user-agent': 'Mozilla/5.0 (compatible; MoonlightHavenBot/1.0)' },
      signal: AbortSignal.timeout(6_000),
    });
    if (!response.ok) return undefined;
    const length = Number(response.headers.get('content-length') || 0);
    if (length > 1_500_000) return undefined;
    const buffer = Buffer.from(await response.arrayBuffer());
    return buffer.length <= 1_500_000 ? buffer : undefined;
  } catch {
    return undefined;
  }
}

async function previewContext(preview) {
  if (!preview) return undefined;
  const jpegThumbnail = await loadThumbnail(preview.imageUrl);
  return {
    externalAdReply: {
      title: String(preview.title || 'Moonlight Haven').slice(0, 120),
      body: String(preview.description || 'Open this Moonlight Haven page.').slice(0, 180),
      sourceUrl: preview.url,
      jpegThumbnail,
      mediaType: 1,
      renderLargerThumbnail: Boolean(jpegThumbnail),
      showAdAttribution: false,
    },
  };
}

async function sendLinkPreview(sock, jid, message, url, text, options = {}) {
  const preview = await createLinkPreview(url);
  return sock.sendMessage(jid, {
    text,
    contextInfo: await previewContext(preview),
    ...options,
  }, { quoted: message });
}

async function sendFullLinkPreview(sock, jid, message, url, text, options = {}) {
  const inviteCode = extractGroupInviteCode(url);
  if (inviteCode && typeof sock.groupGetInviteInfo === 'function') {
    try {
      const group = await sock.groupGetInviteInfo(inviteCode);
      return await sock.sendMessage(jid, {
        groupInvite: {
          jid: group.id,
          inviteCode: group.inviteCode || inviteCode,
          inviteExpiration: 0,
          subject: group.subject || 'WhatsApp group',
          text: text || `Join ${group.subject || 'this WhatsApp group'}`,
        },
        ...options,
      }, { quoted: message });
    } catch (error) {
      console.warn('[GROUP INVITE PREVIEW]', error.message);
    }
  }

  return sendLinkPreview(sock, jid, message, url, text, options);
}

module.exports = {
  createLinkPreview,
  extractHttpUrls,
  extractGroupInviteCode,
  previewContext,
  sendLinkPreview,
  sendFullLinkPreview,
};
