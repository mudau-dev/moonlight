const axios = require('axios');

const TYPE_CHART = {
  normal: { rock: 0.5, ghost: 0, steel: 0.5 },
  fire: { fire: 0.5, water: 0.5, grass: 2, ice: 2, bug: 2, rock: 0.5, dragon: 0.5, steel: 2 },
  water: { fire: 2, water: 0.5, grass: 0.5, ground: 2, rock: 2, dragon: 0.5 },
  electric: { water: 2, electric: 0.5, grass: 0.5, ground: 0, flying: 2, dragon: 0.5 },
  grass: { fire: 0.5, water: 2, grass: 0.5, poison: 0.5, ground: 2, flying: 0.5, bug: 0.5, rock: 2, dragon: 0.5, steel: 0.5 },
  ice: { fire: 0.5, water: 0.5, grass: 2, ice: 0.5, ground: 2, flying: 2, dragon: 2, steel: 0.5 },
  fighting: { normal: 2, ice: 2, poison: 0.5, flying: 0.5, psychic: 0.5, bug: 0.5, rock: 2, ghost: 0, dark: 2, steel: 2, fairy: 0.5 },
  poison: { grass: 2, poison: 0.5, ground: 0.5, rock: 0.5, ghost: 0.5, steel: 0, fairy: 2 },
  ground: { fire: 2, electric: 2, grass: 0.5, poison: 2, flying: 0, bug: 0.5, rock: 2, steel: 2 },
  flying: { electric: 0.5, grass: 2, fighting: 2, bug: 2, rock: 0.5, steel: 0.5 },
  psychic: { fighting: 2, poison: 2, psychic: 0.5, dark: 0, steel: 0.5 },
  bug: { fire: 0.5, grass: 2, fighting: 0.5, poison: 0.5, flying: 0.5, psychic: 2, ghost: 0.5, dark: 2, steel: 0.5, fairy: 0.5 },
  rock: { fire: 2, ice: 2, fighting: 0.5, ground: 0.5, flying: 2, bug: 2, steel: 0.5 },
  ghost: { normal: 0, psychic: 2, ghost: 2, dark: 0.5 },
  dragon: { dragon: 2, steel: 0.5, fairy: 0 },
  dark: { fighting: 0.5, psychic: 2, ghost: 2, dark: 0.5, fairy: 0.5 },
  steel: { fire: 0.5, water: 0.5, electric: 0.5, ice: 2, rock: 2, steel: 0.5, fairy: 2 },
  fairy: { fire: 0.5, fighting: 2, poison: 0.5, dragon: 2, dark: 2, steel: 0.5 },
};

const MOVE_CACHE = new Map();
const EVOLUTION_CACHE = new Map();
const POKEMON_CACHE = new Map();
const SPECIES_CACHE = new Map();
const API_CACHE_TTL_MS = 30 * 60 * 1000;

function cachedApi(cache, key, loader) {
  const existing = cache.get(key);
  if (existing && existing.expiresAt > Date.now()) return existing.promise;
  const promise = Promise.resolve().then(loader).catch((error) => {
    cache.delete(key);
    throw error;
  });
  cache.set(key, { promise, expiresAt: Date.now() + API_CACHE_TTL_MS });
  return promise;
}

function normalizeMoveName(moveName) {
  return String(moveName || '').trim().toLowerCase().replace(/[\s_]+/g, '-');
}

function moveNameValue(move) {
  if (typeof move === 'string') return move;
  if (!move || typeof move !== 'object') return '';
  return move.name || move.moveName || move.move?.name || move.move || move.id || '';
}

function normalizeMoveList(moves) {
  return [...new Set((Array.isArray(moves) ? moves : []).map(moveNameValue).map(normalizeMoveName).filter(Boolean))];
}

function readableMoveName(moveName) {
  return String(moveNameValue(moveName) || '').replace(/-/g, ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function moveDataFromApi(data) {
  const effect = data.effect_entries?.find((entry) => entry.language?.name === 'en')?.effect
    || data.flavor_text_entries?.find((entry) => entry.language?.name === 'en')?.flavor_text
    || 'No additional effect information is available.';

  return {
    name: data.name,
    displayName: readableMoveName(data.name),
    power: Number(data.power) || 0,
    accuracy: Number(data.accuracy) || 100,
    type: data.type?.name || 'normal',
    damageClass: data.damage_class?.name || 'status',
    pp: Number(data.pp) || 0,
    priority: Number(data.priority) || 0,
    effect: effect.replace(/\$effect_chance/g, String(data.effect_chance ?? 0)).replace(/\n|\f/g, ' '),
    effectChance: data.effect_chance,
    energy: Math.max(5, Math.min(50, Math.floor((Number(data.power) || 20) / 2.5) + 10)),
  };
}

function fallbackMoveData(moveName) {
  const name = normalizeMoveName(moveName) || 'tackle';
  return {
    name,
    displayName: readableMoveName(name),
    power: 40,
    accuracy: 100,
    type: 'normal',
    damageClass: 'physical',
    pp: 35,
    priority: 0,
    effect: 'The move could not be refreshed from the move service, so a safe basic battle profile was used.',
    effectChance: 0,
    energy: 16,
    fallback: true,
  };
}

async function getMoveData(moveName) {
  const normalized = normalizeMoveName(moveName);
  if (!normalized) return null;
  if (MOVE_CACHE.has(normalized)) return MOVE_CACHE.get(normalized);

  try {
    const response = await cachedApi(MOVE_CACHE, normalized, () => axios.get(`https://pokeapi.co/api/v2/move/${normalized}`, { timeout: 10_000 }));
    const move = moveDataFromApi(response.data);
    MOVE_CACHE.set(normalized, move);
    return move;
  } catch (error) {
    console.warn('[POKEMON MOVE]', `Could not load ${normalized}: ${error.message}`);
    // A temporary PokeAPI failure must not turn a valid learned move into a
    // generic "Battle error" after a faint. Keep the turn playable.
    const fallback = fallbackMoveData(normalized);
    MOVE_CACHE.set(normalized, fallback);
    return fallback;
  }
}

async function getMoveInfo(moveName) {
  return getMoveData(moveName);
}

function getEffectiveness(moveType, targetTypes) {
  let multiplier = 1;
  for (const type of targetTypes) {
    if (type && TYPE_CHART[moveType] && TYPE_CHART[moveType][type] !== undefined) {
      multiplier *= TYPE_CHART[moveType][type];
    }
  }
  return multiplier;
}

function calculateDamage(attacker, defender, move) {
  if (!move) return { total: 0, effectiveness: 1, stab: 1, random: 1, reason: 'unknown_move' };

  const level = Math.max(1, Number(attacker?.level) || 1);
  const attack = Math.max(1, Number(move.damageClass === 'special' ? attacker?.spAtk : attacker?.attack) || 1);
  const defense = Math.max(1, Number(move.damageClass === 'special' ? defender?.spDef : defender?.defense) || 1);
  const moveType = String(move.type || 'normal').toLowerCase();
  const attackerTypes = [attacker?.type1, attacker?.type2].filter(Boolean).map((type) => String(type).toLowerCase());
  const defenderTypes = [defender?.type1, defender?.type2].filter(Boolean).map((type) => String(type).toLowerCase());
  const effectiveness = getEffectiveness(moveType, defenderTypes);
  const stab = attackerTypes.includes(moveType) ? 1.5 : 1;
  const random = (Math.floor(Math.random() * 16) + 85) / 100;

  if (effectiveness === 0) return { total: 0, effectiveness, stab, random, reason: 'immune' };

  // Some valid API moves (notably OHKO/status-class moves) have power 0 or a
  // missing damage class. They must not become fake zero-damage turns in this
  // battle system, so use a conservative fallback power and resolve them as a
  // light physical hit unless the matchup is genuinely immune.
  const power = Math.max(20, Number(move.power) || 0);
  const baseDamage = Math.floor((Math.floor((2 * level) / 5 + 2) * power * attack) / defense / 50) + 2;
  return {
    total: Math.max(1, Math.floor(baseDamage * stab * effectiveness * random)),
    effectiveness,
    stab,
    random,
    reason: 'hit',
  };
}

async function fetchPokemonData(name) {
  const query = String(name).toLowerCase().replace(/\s+/g, '-');
  return cachedApi(POKEMON_CACHE, query, async () => {
    const { data } = await axios.get(`https://pokeapi.co/api/v2/pokemon/${query}`, { timeout: 10_000 });
    const stat = (statName) => data.stats.find((entry) => entry.stat.name === statName)?.base_stat || 0;
    return {
      pokedexNumber: data.id,
      name: data.name,
      sprite: data.sprites.other['official-artwork'].front_default || data.sprites.front_default,
      type1: data.types[0]?.type?.name || null,
      type2: data.types[1]?.type?.name || null,
      stats: { hp: stat('hp'), attack: stat('attack'), defense: stat('defense'), spAtk: stat('special-attack'), spDef: stat('special-defense'), speed: stat('speed') },
      moves: data.moves.slice(0, 4).map((entry) => entry.move.name.replace(/-/g, ' ')),
    };
  });
}

async function fetchPokemonSpecies(name) {
  const query = String(name).toLowerCase().replace(/\s+/g, '-');
  return cachedApi(SPECIES_CACHE, query, async () => {
    const { data } = await axios.get(`https://pokeapi.co/api/v2/pokemon-species/${query}`, { timeout: 10_000 });
    return { captureRate: Number.isFinite(data.capture_rate) ? data.capture_rate : null, genderRate: Number.isFinite(data.gender_rate) ? data.gender_rate : -1 };
  });
}

async function getEvolutionTarget(name) {
  const query = String(name || '').toLowerCase().replace(/\s+/g, '-');
  if (!query) return null;
  if (EVOLUTION_CACHE.has(query)) return EVOLUTION_CACHE.get(query);
  try {
    const speciesResponse = await axios.get(`https://pokeapi.co/api/v2/pokemon-species/${encodeURIComponent(query)}`, { timeout: 10_000 });
    const chainUrl = speciesResponse.data.evolution_chain?.url;
    if (!chainUrl) return null;
    const chainResponse = await axios.get(chainUrl, { timeout: 10_000 });
    const target = query;
    const walk = (node) => {
      const current = node.species?.name;
      const next = (node.evolves_to || []).find((entry) => current === target);
      if (next) {
        const detail = next.evolution_details?.[0] || {};
        return { name: next.species.name, requiredLevel: Number(detail.min_level || 1) };
      }
      for (const child of node.evolves_to || []) {
        const result = walk(child);
        if (result) return result;
      }
      return null;
    };
    const result = walk(chainResponse.data.chain);
    EVOLUTION_CACHE.set(query, result);
    return result;
  } catch (error) {
    console.warn('[POKEMON EVOLUTION]', `Could not load ${query}: ${error.message}`);
    return null;
  }
}

function rollGender(genderRate) {
  if (genderRate === -1) return 'Genderless';
  if (genderRate === 0) return 'Male';
  if (genderRate === 8) return 'Female';
  return Math.random() < genderRate / 8 ? 'Female' : 'Male';
}

function generateIVs() {
  const randomIv = () => Math.floor(Math.random() * 32);
  return { hp: randomIv(), attack: randomIv(), defense: randomIv(), spAtk: randomIv(), spDef: randomIv(), speed: randomIv() };
}

function calculateStat(base, iv, ev = 0, level = 50, hp = false) {
  if (hp) return Math.floor((((2 * base + iv + Math.floor(ev / 4)) * level) / 100) + level + 10);
  return Math.floor((((2 * base + iv + Math.floor(ev / 4)) * level) / 100) + 5);
}

module.exports = {
  fetchPokemonData,
  fetchPokemonSpecies,
  getEvolutionTarget,
  rollGender,
  generateIVs,
  calculateStat,
  getMoveData,
  fallbackMoveData,
  getMoveInfo,
  normalizeMoveName,
  normalizeMoveList,
  readableMoveName,
  getEffectiveness,
  calculateDamage,
};
