const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

const CATBOX_TIMEOUT_MS = Number(process.env.CATBOX_UPLOAD_TIMEOUT_MS) || 60_000;
const FALLBACK_TIMEOUT_MS = Number(process.env.UPLOAD_FALLBACK_TIMEOUT_MS) || 30_000;
function filenameOf(input, options = {}) { return options.filename || (typeof input === 'string' ? path.basename(input) : 'moonlight-upload.bin'); }
function contentOf(input) { return typeof input === 'string' ? fs.createReadStream(input) : input; }
function validUrl(value) { return /^https?:\/\/[^\s]+$/i.test(String(value || '').trim()); }
function uploadConfig(form, timeout, extraHeaders = {}) { return { headers: { ...form.getHeaders(), 'User-Agent': 'MoonlightHavenBot/1.0', ...extraHeaders }, maxBodyLength: Infinity, maxContentLength: Infinity, timeout, validateStatus: () => true }; }

async function uploadToCatbox(input, options = {}) {
  const form = new FormData();
  form.append('reqtype', 'fileupload');
  form.append('fileToUpload', contentOf(input), { filename: filenameOf(input, options) });
  let length;
  try { length = await new Promise((resolve, reject) => form.getLength((error, value) => error ? reject(error) : resolve(value))); } catch {}
  const headers = { Accept: 'text/plain, */*' };
  if (Number.isFinite(length)) headers['Content-Length'] = length;
  const response = await axios.post('https://catbox.moe/user/api.php', form, uploadConfig(form, CATBOX_TIMEOUT_MS, headers));
  const url = String(response.data || '').trim();
  if (response.status >= 400 || !/^https?:\/\/files\.catbox\.moe\/[A-Za-z0-9._/?=&-]+$/i.test(url)) throw new Error(`Catbox HTTP ${response.status}: ${url.slice(0, 160)}`);
  return url;
}
async function uploadToTelegraph(input, options = {}) {
  const form = new FormData(); form.append('file', contentOf(input), { filename: filenameOf(input, options) });
  const response = await axios.post('https://telegra.ph/upload', form, uploadConfig(form, FALLBACK_TIMEOUT_MS));
  const src = response.data?.[0]?.src;
  if (response.status >= 400 || !src || !/^\/file\/[A-Za-z0-9._/-]+$/.test(String(src))) throw new Error(`Telegraph HTTP ${response.status}`);
  return `https://telegra.ph${src}`;
}
async function uploadToZeroX(input, options = {}) {
  const form = new FormData(); form.append('file', contentOf(input), { filename: filenameOf(input, options) });
  const response = await axios.post('https://0x0.st', form, uploadConfig(form, FALLBACK_TIMEOUT_MS));
  const url = String(response.data || '').trim();
  if (response.status >= 400 || !validUrl(url)) throw new Error(`0x0 HTTP ${response.status}`);
  return url;
}
async function uploadToTmpFiles(input, options = {}) {
  const form = new FormData(); form.append('file', contentOf(input), { filename: filenameOf(input, options) });
  const response = await axios.post('https://tmpfiles.org/api/v1/upload', form, uploadConfig(form, FALLBACK_TIMEOUT_MS));
  const url = response.data?.data?.url;
  if (response.status >= 400 || !validUrl(url)) throw new Error(`tmpfiles HTTP ${response.status}`);
  return String(url).replace('://tmpfiles.org/', '://tmpfiles.org/dl/');
}
async function uploadToUguu(input, options = {}) {
  const form = new FormData(); form.append('files[]', contentOf(input), { filename: filenameOf(input, options) });
  const response = await axios.post('https://uguu.se/upload.php', form, uploadConfig(form, FALLBACK_TIMEOUT_MS));
  const url = response.data?.files?.[0]?.url;
  if (response.status >= 400 || !validUrl(url)) throw new Error(`Uguu HTTP ${response.status}`);
  return url;
}
async function uploadToFileIo(input, options = {}) {
  const form = new FormData(); form.append('file', contentOf(input), { filename: filenameOf(input, options) });
  const response = await axios.post('https://file.io', form, uploadConfig(form, FALLBACK_TIMEOUT_MS));
  const url = response.data?.link;
  if (response.status >= 400 || response.data?.success === false || !validUrl(url)) throw new Error(`file.io HTTP ${response.status}`);
  return url;
}
async function uploadWithFallback(input, options = {}) {
  const providers = [['Catbox', uploadToCatbox], ['Telegraph', uploadToTelegraph], ['0x0.st', uploadToZeroX], ['tmpfiles.org', uploadToTmpFiles], ['Uguu', uploadToUguu], ['file.io', uploadToFileIo]];
  const failures = [];
  for (const [provider, uploader] of providers) {
    try { return { url: await uploader(input, options), provider }; }
    catch (error) { failures.push(`${provider}: ${error.message}`); console.warn(`[UPLOAD] ${provider} failed: ${error.message}`); }
  }
  throw new Error(`All upload providers failed. ${failures.join(' | ')}`);
}
module.exports = { CATBOX_TIMEOUT_MS, uploadToTelegraph, uploadToCatbox, uploadToZeroX, uploadToTmpFiles, uploadToUguu, uploadToFileIo, uploadWithFallback };
