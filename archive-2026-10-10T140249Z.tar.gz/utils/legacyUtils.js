const LegacyPlayer = require('../models/LegacyPlayer');

function normalizeLegacyIdentifiers(sender) {
  const raw = String(sender || '').trim();
  const number = raw.split('@')[0].replace(/[^0-9]/g, '');
  const ids = new Set([raw]);
  if (number) {
    ids.add(number);
    ids.add(`${number}@s.whatsapp.net`);
    ids.add(`${number}@lid`);
  }
  return [...ids].filter(Boolean);
}

async function findLegacyPlayer(sender) {
  const ids = normalizeLegacyIdentifiers(sender);
  if (!ids.length) return null;
  return LegacyPlayer.findOne({ whatsappId: { $in: ids } });
}

async function findLegacyPlayerLean(sender) {
  const ids = normalizeLegacyIdentifiers(sender);
  if (!ids.length) return null;
  return LegacyPlayer.findOne({ whatsappId: { $in: ids } }).lean();
}

module.exports = { findLegacyPlayer, findLegacyPlayerLean, normalizeLegacyIdentifiers };
