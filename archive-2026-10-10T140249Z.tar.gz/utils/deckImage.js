const axios = require('axios');
const sharp = require('sharp');
const fs = require('fs/promises');
const os = require('os');
const path = require('path');
const { promisify } = require('util');
const { execFile } = require('child_process');
const execFileAsync = promisify(execFile);

function cardUrl(card) {
  if (typeof card?.media === 'string') return card.media;
  if (card?.media && typeof card.media === 'object') return card.media.url || card.media.src || card.media.imageUrl || card.media.image || null;
  return card?.imageUrl || null;
}

function escapeSvg(value) {
  return String(value || '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[char]));
}

async function fetchCardImage(card) {
  const url = cardUrl(card);
  if (!url) return null;
  try {
    const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 8000, maxContentLength: 8 * 1024 * 1024 });
    return sharp(Buffer.from(response.data)).resize(270, 360, { fit: 'cover' }).png().toBuffer();
  } catch (error) {
    console.warn('[DECK IMAGE] unable to load card image:', error.message);
    return null;
  }
}

async function createDeckImage(cards, page = 1, totalPages = 1) {
  const width = 1200;
  const cardWidth = 270;
  const cardHeight = 360;
  const gap = 24;
  const top = 150;
  const columns = 4;
  const rows = Math.max(1, Math.ceil(cards.length / columns));
  const height = 150 + rows * cardHeight + Math.max(0, rows - 1) * gap + 30;
  const background = Buffer.from(`<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#080b27"/><stop offset=".5" stop-color="#16114a"/><stop offset="1" stop-color="#351044"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/><circle cx="1080" cy="-20" r="240" fill="#67e8f9" opacity=".12"/><circle cx="60" cy="600" r="220" fill="#e879f9" opacity=".1"/><text x="60" y="66" fill="#a5f3fc" font-family="sans-serif" font-size="24" font-weight="700" letter-spacing="7">MOONLIGHT HAVEN · CARD SANCTUM</text><text x="60" y="112" fill="white" font-family="sans-serif" font-size="42" font-weight="900">YOUR ACTIVE DECK</text><text x="1110" y="98" fill="#f0abfc" font-family="sans-serif" font-size="22" text-anchor="end">${escapeSvg(page)}/${escapeSvg(totalPages)}</text></svg>`);
  const composites = [{ input: background, left: 0, top: 0 }];
  const gridWidth = columns * cardWidth + (columns - 1) * gap;
  const startX = Math.round((width - gridWidth) / 2);
  for (let index = 0; index < cards.length; index += 1) {
    const column = index % columns;
    const row = Math.floor(index / columns);
    const left = startX + column * (cardWidth + gap);
    const cardTop = top + row * (cardHeight + gap);
    const image = await fetchCardImage(cards[index]);
    const fallback = Buffer.from(`<svg width="${cardWidth}" height="${cardHeight}" xmlns="http://www.w3.org/2000/svg"><rect width="100%" height="100%" rx="18" fill="#1e293b"/><text x="135" y="170" fill="#94a3b8" text-anchor="middle" font-family="sans-serif" font-size="22">No image</text></svg>`);
    composites.push({ input: image || fallback, left, top: cardTop });
    const label = Buffer.from(`<svg width="${cardWidth}" height="70" xmlns="http://www.w3.org/2000/svg"><rect y="${cardHeight - 70}" width="100%" height="70" fill="#020617" opacity=".88"/><text x="16" y="${cardHeight - 40}" fill="white" font-family="sans-serif" font-size="18" font-weight="700">${escapeSvg(`${index + 1}. ${cards[index]?.name || 'Unknown Card'}`.slice(0, 24))}</text><text x="16" y="${cardHeight - 16}" fill="#a5f3fc" font-family="sans-serif" font-size="14">${escapeSvg(cards[index]?.tier || 'Common')}</text></svg>`);
    composites.push({ input: label, left, top: cardTop });
  }
  return sharp({ create: { width, height, channels: 4, background: { r: 7, g: 9, b: 26, alpha: 1 } } }).composite(composites).png().toBuffer();
}

async function createDeckVideo(cards, page = 1, totalPages = 1) {
  const image = await createDeckImage(cards, page, totalPages);
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'moonlight-deck-'));
  const source = path.join(dir, 'deck.png');
  const output = path.join(dir, 'deck.mp4');
  await fs.writeFile(source, image);
  try {
    await execFileAsync('ffmpeg', ['-y', '-loop', '1', '-i', source, '-t', '5', '-vf', 'scale=1280:-2,format=yuv420p', '-r', '12', '-movflags', '+faststart', '-an', output], { timeout: 30000 });
    return await fs.readFile(output);
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}

module.exports = { createDeckImage, createDeckVideo, cardUrl };
