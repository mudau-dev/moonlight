const { generateBattleImage } = require('./battleGenerator');
const { fetchPokemonData } = require('./pokemonUtils');

function frameBattleText(text) {
  return `□------------------------------□\n${String(text || '').trim()}\n□------------------------------□`;
}

async function renderGymBattle(sock, jid, quoted, battle, active, lastAction, options = {}) {
  try {
    const [playerData, opponentData] = await Promise.all([
      active.sprite ? active : fetchPokemonData(active.name),
      battle.opponent.sprite ? battle.opponent : fetchPokemonData(battle.opponent.name),
    ]);
    const image = await generateBattleImage({
      player: { ...active.toObject?.() || active, ...playerData, hp: battle.playerHp, maxHp: battle.playerMaxHp, energy: 100 },
      opponent: { ...battle.opponent, ...opponentData, sprite: opponentData.sprite },
      weather: battle.weather || 'Clear',
      lastAction,
      thrownBall: battle.thrownBall || null,
    });
    return sock.sendMessage(jid, { image, caption: frameBattleText(lastAction), mentions: options.mentions || [] }, { quoted });
  } catch (error) {
    return sock.sendMessage(jid, { text: frameBattleText(lastAction), mentions: options.mentions || [] }, { quoted });
  }
}

module.exports = { renderGymBattle, frameBattleText };
