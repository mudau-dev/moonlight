/**
 * Moonlight guild profile card renderer.
 * Square cinematic layout shared with the Discord renderer.
 */
const { createCanvas, loadImage } = require('canvas');

const ART_CACHE_TTL = 5 * 60 * 1000;
const ART_TIMEOUT_MS = 2500;
const artworkCache = new Map();
const CYAN = '#27f4ff';
const INK = '#10161c';

function withTimeout(promise, timeout = ART_TIMEOUT_MS) {
  return Promise.race([promise, new Promise((resolve) => setTimeout(() => resolve(null), timeout))]);
}

function cachedImage(url) {
  if (!url) return Promise.resolve(null);
  const cached = artworkCache.get(url);
  const now = Date.now();
  if (cached && cached.expiresAt > now) return cached.promise;
  const promise = loadImage(url).catch((error) => {
    console.warn('[GUILD GEN] Artwork unavailable:', error.message);
    return null;
  });
  artworkCache.set(url, { promise, expiresAt: now + ART_CACHE_TTL });
  if (artworkCache.size > 100) {
    for (const [key, item] of artworkCache) {
      if (item.expiresAt <= now || artworkCache.size > 80) artworkCache.delete(key);
      if (artworkCache.size <= 80) break;
    }
  }
  return promise;
}

function drawCover(ctx, image, x, y, width, height) {
  const scale = Math.max(width / image.width, height / image.height);
  const drawWidth = image.width * scale;
  const drawHeight = image.height * scale;
  ctx.drawImage(image, x + (width - drawWidth) / 2, y + (height - drawHeight) / 2, drawWidth, drawHeight);
}

function roundedRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + width, y, x + width, y + height, radius);
  ctx.arcTo(x + width, y + height, x, y + height, radius);
  ctx.arcTo(x, y + height, x, y, radius);
  ctx.arcTo(x, y, x + width, y, radius);
  ctx.closePath();
}

function fitText(ctx, value, maxWidth, startSize, family = 'Sans') {
  let size = startSize;
  while (size > 12) {
    ctx.font = `800 ${size}px ${family}`;
    if (ctx.measureText(value).width <= maxWidth) return size;
    size -= 1;
  }
  return size;
}

function fallback(ctx, width, height, accent) {
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, accent || '#182631');
  gradient.addColorStop(0.45, '#172027');
  gradient.addColorStop(1, INK);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
}

async function generateGuildProfile(guild) {
  const width = 512;
  const height = 512;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const accent = guild.color || CYAN;
  const name = String(guild.name || 'UNKNOWN GUILD').toUpperCase();
  const subtitle = String(guild.subtitle || guild.description || guild.tagline || 'DISSECTION & AUSTERITY').toUpperCase();
  const level = Math.max(1, Number(guild.level) || 1);
  const memberCount = Number(guild.memberCount ?? guild.members?.length ?? 0) || 0;

  try {
    const backgroundUrl = guild.background || guild.icon || null;
    const iconUrl = guild.icon || null;
    const [background, icon] = await Promise.all([
      withTimeout(cachedImage(backgroundUrl)),
      backgroundUrl === iconUrl ? Promise.resolve(null) : withTimeout(cachedImage(iconUrl)),
    ]);

    if (background) drawCover(ctx, background, 0, 0, width, height);
    else fallback(ctx, width, height, accent);

    // Cinematic photo treatment: muted upper image, near-black lower panel.
    ctx.fillStyle = 'rgba(4, 8, 12, 0.42)';
    ctx.fillRect(0, 0, width, height);
    const shade = ctx.createLinearGradient(0, 120, 0, height);
    shade.addColorStop(0, 'rgba(5, 10, 14, 0.06)');
    shade.addColorStop(0.56, 'rgba(5, 10, 14, 0.54)');
    shade.addColorStop(0.72, 'rgba(12, 18, 23, 0.96)');
    shade.addColorStop(1, 'rgba(12, 18, 23, 1)');
    ctx.fillStyle = shade;
    ctx.fillRect(0, 0, width, height);

    // Fine cyan edge accents give the card a premium sci-fi frame.
    ctx.strokeStyle = `${accent}55`;
    ctx.lineWidth = 1;
    ctx.strokeRect(14, 14, width - 28, height - 28);
    ctx.fillStyle = `${accent}22`;
    ctx.fillRect(0, 0, 5, height);

    // Centered rounded emblem.
    const iconSize = 132;
    const iconX = (width - iconSize) / 2;
    const iconY = 138;
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur = 18;
    ctx.fillStyle = '#0c151b';
    roundedRect(ctx, iconX - 4, iconY - 4, iconSize + 8, iconSize + 8, 20);
    ctx.fill();
    ctx.restore();
    ctx.save();
    roundedRect(ctx, iconX, iconY, iconSize, iconSize, 16);
    ctx.clip();
    if (icon || background) drawCover(ctx, icon || background, iconX, iconY, iconSize, iconSize);
    else {
      const iconGradient = ctx.createLinearGradient(iconX, iconY, iconX + iconSize, iconY + iconSize);
      iconGradient.addColorStop(0, accent);
      iconGradient.addColorStop(1, '#15222c');
      ctx.fillStyle = iconGradient;
      ctx.fillRect(iconX, iconY, iconSize, iconSize);
      ctx.fillStyle = '#071015';
      ctx.font = '900 64px Sans';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(name[0] || 'G', width / 2, iconY + iconSize / 2);
    }
    ctx.restore();
    ctx.strokeStyle = `${accent}bb`;
    ctx.lineWidth = 2;
    roundedRect(ctx, iconX, iconY, iconSize, iconSize, 16);
    ctx.stroke();

    // Title and cyan typographic signature.
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    const titleSize = fitText(ctx, name, 440, 38);
    ctx.font = `900 ${titleSize}px Sans`;
    ctx.fillStyle = '#f8fafb';
    ctx.shadowColor = 'rgba(0,0,0,0.7)';
    ctx.shadowBlur = 10;
    ctx.fillText(name, width / 2, 347);
    ctx.shadowBlur = 0;

    const subtitleSize = fitText(ctx, subtitle, 430, 15, 'Monospace');
    ctx.font = `700 ${subtitleSize}px Monospace`;
    ctx.fillStyle = accent;
    ctx.fillText(`⌣  ${subtitle}  ⚚`, width / 2, 389);

    // Outlined stat pills.
    const pillY = 430;
    const pillH = 34;
    const pills = [`Lv. ${level}`, String(memberCount)];
    const pillWidths = [114, 114];
    let x = 136;
    ctx.font = '700 16px Sans';
    for (let i = 0; i < pills.length; i += 1) {
      const pillW = pillWidths[i];
      ctx.strokeStyle = accent;
      ctx.lineWidth = 1.5;
      roundedRect(ctx, x, pillY, pillW, pillH, 18);
      ctx.stroke();
      ctx.fillStyle = '#f4fbfc';
      ctx.fillText(pills[i], x + pillW / 2, pillY + 23);
      x += pillW + 12;
    }

    return { buffer: canvas.toBuffer('image/png') };
  } catch (error) {
    console.error('[GUILD GEN ERROR]', error);
    fallback(ctx, width, height, accent);
    return { buffer: canvas.toBuffer('image/png') };
  }
}

module.exports = { generateGuildProfile };
