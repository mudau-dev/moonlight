const Guild = require('../models/athers/Guild');

function identityKeys(value = '') {
  const raw = String(value || '').trim().toLowerCase();
  const number = raw.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
  return [...new Set([raw, number, number ? `${number}@s.whatsapp.net` : ''].filter(Boolean))];
}

async function isGuildMember(value) {
  const keys = identityKeys(value);
  if (!keys.length) return false;
  const guilds = await Guild.find({ $or: keys.flatMap((key) => [{ ownerId: key }, { members: key }]) }).select('ownerId members').lean();
  return guilds.some((guild) => identityKeys(guild.ownerId).some((key) => keys.includes(key)) || (guild.members || []).some((member) => identityKeys(member).some((key) => keys.includes(key))));
}

module.exports = { identityKeys, isGuildMember };
