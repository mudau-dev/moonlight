const MONSTERS = [
  { name: 'Abyssal Slime', type: 'slime', hp: 40, attack: 8, defense: 2, xp: 28, coins: 24 },
  { name: 'Grave Goblin', type: 'goblin', hp: 54, attack: 11, defense: 3, xp: 36, coins: 32 },
  { name: 'Moonfang Wolf', type: 'wolf', hp: 62, attack: 13, defense: 4, xp: 44, coins: 41 },
  { name: 'Cinder Bat Swarm', type: 'bat', hp: 48, attack: 15, defense: 2, xp: 42, coins: 37 },
  { name: 'Crypt Skeleton', type: 'skeleton', hp: 78, attack: 16, defense: 6, xp: 58, coins: 55 },
  { name: 'Abyssal Ogre', type: 'ogre', hp: 108, attack: 21, defense: 8, xp: 76, coins: 75 },
];

const BOSS_NAMES = [
  'The Drowned Warden', 'Moon-Eater Varg', 'The Bone Bellringer', 'Embermaw Tyrant',
  'Lady Nocturne', 'The Hollow King', 'Abyssal Leviathan', 'The Final Lantern',
];

const LOOT_TABLE = [
  { id: 'abyssal-ichor', name: 'Abyssal Ichor', rarity: 'Common', value: 90 },
  { id: 'goblin-tooth', name: 'Goblin King Tooth', rarity: 'Uncommon', value: 180 },
  { id: 'moonshard', name: 'Moonshard', rarity: 'Rare', value: 420 },
  { id: 'nightsteel', name: 'Nightsteel Ingot', rarity: 'Epic', value: 900 },
  { id: 'void-pearl', name: 'Void Pearl', rarity: 'Legendary', value: 2400 },
];

const ACHIEVEMENTS = [
  { id: 'first-blood', title: 'First Blood', test: (player) => player.kills >= 1 },
  { id: 'flawless', title: 'Flawless', test: (player) => player.kills >= 20 },
  { id: 'unstoppable', title: 'UNSTOPPABLE', test: (player) => player.kills >= 50 },
  { id: 'massacre', title: 'Massacre', test: (player) => player.kills >= 100 },
  { id: 'reaper', title: 'Reaper', test: (player) => player.kills >= 500 },
  { id: 'one-of-us', title: 'One of Us', test: (player) => player.level >= 5 },
  { id: 'growing', title: 'Growing', test: (player) => player.level >= 15 },
  { id: 'veteran-slayer', title: 'Veteran Slayer', test: (player) => player.level >= 30 },
  { id: 'aura-farmer', title: 'Aura Farmer', test: (player) => player.level >= 35 },
];

function clamp(value, minimum, maximum) { return Math.max(minimum, Math.min(maximum, value)); }
function capCost(player) { return 25_000 + ((player.levelCap - 10) * 12_500); }
function isBossFloor(floor) { return floor > 0 && floor % 5 === 0; }
function xpForLevel(level) { return 100 + ((level - 1) * 70); }
function randomPick(values) { return values[Math.floor(Math.random() * values.length)]; }

function createEncounter(floor) {
  const boss = isBossFloor(floor);
  const multiplier = 1 + ((floor - 1) * 0.17);
  if (boss) {
    const tier = Math.floor(floor / 5) - 1;
    const name = BOSS_NAMES[tier % BOSS_NAMES.length];
    return {
      boss: true, floor, name,
      hp: Math.round((260 + floor * 42) * multiplier),
      attack: Math.round((28 + floor * 5) * multiplier),
      defense: Math.round((10 + floor * 2) * multiplier),
      xp: Math.round((180 + floor * 30) * multiplier),
      coins: Math.round((240 + floor * 42) * multiplier),
    };
  }
  const template = randomPick(MONSTERS);
  return {
    ...template, boss: false, floor,
    hp: Math.round(template.hp * multiplier),
    attack: Math.round(template.attack * multiplier),
    defense: Math.round(template.defense * multiplier),
    xp: Math.round(template.xp * multiplier),
    coins: Math.round(template.coins * multiplier),
  };
}

function awardLoot(player, boss = false) {
  const rolls = boss ? 2 : 1;
  const drops = [];
  for (let index = 0; index < rolls; index += 1) {
    const roll = Math.random();
    const item = LOOT_TABLE[roll > .985 ? 4 : roll > .90 ? 3 : roll > .66 ? 2 : roll > .33 ? 1 : 0];
    const existing = player.loot.find((loot) => loot.id === item.id && loot.rarity === item.rarity);
    if (existing) existing.quantity += 1;
    else player.loot.push({ ...item, quantity: 1 });
    drops.push(item);
  }
  if (boss && Math.random() < .50) {
    const chest = { id: 'boss-treasure-chest', name: 'Abyssal Treasure Chest', rarity: 'Boss', value: 1600 };
    const existingChest = player.loot.find((loot) => loot.id === chest.id);
    if (existingChest) existingChest.quantity += 1;
    else player.loot.push({ ...chest, quantity: 1 });
    drops.push(chest);
  }
  return drops;
}

function applyExperience(player, amount) {
  let remaining = Math.max(0, Math.floor(amount));
  const gainedLevels = [];
  let capped = false;
  while (remaining > 0 && player.level < player.levelCap) {
    const required = player.xpToNext || xpForLevel(player.level);
    const needed = Math.max(0, required - player.xp);
    if (remaining < needed) { player.xp += remaining; remaining = 0; break; }
    remaining -= needed;
    player.level += 1;
    player.xp = 0;
    player.xpToNext = xpForLevel(player.level);
    player.maxHp += 16 + (player.hpCharms * 2);
    player.maxMana += 8 + (player.manaCharms * 2);
    player.attack += 3;
    player.defense += 1;
    player.hp = player.maxHp;
    player.mana = player.maxMana;
    gainedLevels.push(player.level);
  }
  if (player.level >= player.levelCap && remaining > 0) capped = true;
  return { gainedLevels, capped, appliedXp: amount - remaining };
}

function updateAchievements(player) {
  const unlocked = [];
  for (const achievement of ACHIEVEMENTS) {
    if (achievement.test(player) && !player.achievements.includes(achievement.id)) {
      player.achievements.push(achievement.id);
      unlocked.push(achievement.title);
    }
  }
  return unlocked;
}

function calculateAttack(player, enemy) {
  const manaBurst = player.mana >= 10 && Math.random() < .35;
  const critical = Math.random() < .12;
  const raw = player.attack + Math.floor(Math.random() * 12) + (manaBurst ? Math.round(player.level * 1.5) : 0);
  const damage = Math.max(1, Math.round((raw - enemy.defense * .58) * (critical ? 1.65 : 1)));
  if (manaBurst) player.mana -= 10;
  return { damage, manaBurst, critical };
}

function calculateEnemyAttack(player, enemy) {
  const raw = enemy.attack + Math.floor(Math.random() * 10);
  return Math.max(1, Math.round(raw - (player.defense * .52)));
}

function resolveDungeonFight(player, encounter) {
  let enemyHp = encounter.hp;
  let rounds = 0;
  let playerHp = player.hp;
  const events = [];
  while (enemyHp > 0 && playerHp > 0 && rounds < 18) {
    rounds += 1;
    const strike = calculateAttack(player, encounter);
    enemyHp -= strike.damage;
    events.push(`You dealt ${strike.damage}${strike.critical ? ' critical' : ''}${strike.manaBurst ? ' mana-burst' : ''} damage`);
    if (enemyHp <= 0) break;
    const damage = calculateEnemyAttack(player, encounter);
    playerHp -= damage;
    events.push(`${encounter.name} dealt ${damage} damage`);
  }
  player.hp = clamp(playerHp, 0, player.maxHp);
  return { won: enemyHp <= 0, rounds, enemyHp: Math.max(0, enemyHp), events };
}

function forfeitPenalty(player) {
  const lostXp = Math.min(player.xp, Math.max(10, Math.floor(player.xpToNext * .15)));
  player.xp -= lostXp;
  player.floor = Math.max(1, player.floor - 1);
  player.hp = Math.max(1, Math.round(player.maxHp * .40));
  player.mana = Math.max(0, Math.round(player.maxMana * .35));
  return lostXp;
}

module.exports = {
  ACHIEVEMENTS, applyExperience, awardLoot, capCost, createEncounter,
  forfeitPenalty, isBossFloor, resolveDungeonFight, updateAchievements,
};
