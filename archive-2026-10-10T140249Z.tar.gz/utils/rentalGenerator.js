const { createCanvas, loadImage } = require('canvas');

const TYPE_COLORS = {
  psychic: '#c026d3', dragon: '#4f46e5', normal: '#64748b', fighting: '#dc2626',
  flying: '#0284c7', fire: '#ea580c', water: '#2563eb', grass: '#16a34a',
  electric: '#ca8a04', dark: '#334155', steel: '#475569', ice: '#0891b2',
};

function roundedRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + width, y, x + width, y + height, radius);
  ctx.arcTo(x + width, y + height, x, y + height, radius);
  ctx.arcTo(x, y + height, x, y, radius);
  ctx.arcTo(x, y, x + width, y, radius);
  ctx.closePath();
}

async function loadSprite(pokedexNumber) {
  try {
    return await loadImage(`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokedexNumber}.png`);
  } catch {
    return null;
  }
}

async function generateRentalImage({ pokemon = [] }) {
  const width = 1080;
  const height = 760;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  const background = ctx.createLinearGradient(0, 0, width, height);
  background.addColorStop(0, '#120b2e');
  background.addColorStop(0.48, '#0e1b3d');
  background.addColorStop(1, '#071423');
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, width, height);

  ctx.globalAlpha = 0.13;
  for (let index = 0; index < 70; index += 1) {
    const x = (index * 157) % width;
    const y = (index * 83) % height;
    const radius = 1 + (index % 3);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  ctx.fillStyle = '#a78bfa';
  ctx.fillRect(38, 38, 8, 84);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 38px Sans';
  ctx.fillText('POKÉMON RENTAL CENTER', 64, 78);
  ctx.fillStyle = '#c4b5fd';
  ctx.font = '16px Sans';
  ctx.fillText('Choose one legendary partner · Rental period: 30 minutes', 66, 108);

  const cardWidth = 238;
  const cardHeight = 270;
  const gap = 18;
  const startX = 39;
  const startY = 155;

  for (let index = 0; index < pokemon.length; index += 1) {
    const entry = pokemon[index];
    const column = index % 4;
    const row = Math.floor(index / 4);
    const x = startX + column * (cardWidth + gap);
    const y = startY + row * (cardHeight + gap);
    const accent = TYPE_COLORS[String(entry.type1 || 'normal').toLowerCase()] || '#7c3aed';

    const cardBackground = ctx.createLinearGradient(x, y, x + cardWidth, y + cardHeight);
    cardBackground.addColorStop(0, 'rgba(42, 31, 76, 0.95)');
    cardBackground.addColorStop(1, 'rgba(11, 30, 56, 0.95)');
    ctx.fillStyle = cardBackground;
    roundedRect(ctx, x, y, cardWidth, cardHeight, 20);
    ctx.fill();
    ctx.strokeStyle = `${accent}99`;
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = accent;
    roundedRect(ctx, x + 14, y + 14, 38, 28, 10);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 14px Sans';
    ctx.textAlign = 'center';
    ctx.fillText(String(index + 1), x + 33, y + 34);

    const sprite = await loadSprite(entry.pokedexNumber);
    if (sprite) ctx.drawImage(sprite, x + 50, y + 22, 142, 142);
    else {
      ctx.fillStyle = 'rgba(255,255,255,0.08)';
      ctx.beginPath();
      ctx.arc(x + cardWidth / 2, y + 93, 60, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px Sans';
    ctx.fillText(String(entry.name).toUpperCase(), x + cardWidth / 2, y + 190);
    ctx.fillStyle = '#dbeafe';
    ctx.font = 'bold 14px Sans';
    ctx.fillText('LEVEL 100', x + cardWidth / 2, y + 215);

    const types = [entry.type1, entry.type2].filter(Boolean).map((type) => String(type).toUpperCase()).join(' / ');
    ctx.fillStyle = `${accent}55`;
    roundedRect(ctx, x + 25, y + 230, cardWidth - 50, 24, 12);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 11px Sans';
    ctx.fillText(types || 'NORMAL', x + cardWidth / 2, y + 247);
  }

  ctx.textAlign = 'center';
  ctx.fillStyle = '#94a3b8';
  ctx.font = '13px Sans';
  ctx.fillText('Use .prent <number> to rent · Only one active rental is allowed at a time', width / 2, height - 28);
  return canvas.toBuffer('image/png');
}

module.exports = { generateRentalImage };
