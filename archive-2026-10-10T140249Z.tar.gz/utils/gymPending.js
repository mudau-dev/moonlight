const pending = new Map();

function key(value = '') {
  const digits = String(value || '').split('@')[0].replace(/[^0-9]/g, '');
  return digits || String(value || '').trim().toLowerCase();
}

function setPending(value, stage) {
  pending.set(key(value), { stage: Number(stage), createdAt: Date.now() });
}

function getPending(value) {
  const item = pending.get(key(value));
  if (!item) return null;
  if (Date.now() - item.createdAt > 10 * 60 * 1000) {
    pending.delete(key(value));
    return null;
  }
  return item;
}

function clearPending(value) {
  pending.delete(key(value));
}

module.exports = { setPending, getPending, clearPending };
