const crypto = require('crypto');
const mongoose = require('mongoose');
const WebBattle = require('../models/WebBattle');
const { fetchPokemonData } = require('./pokemonUtils');

let connected = false;
async function ensureDb() {
  if (connected || mongoose.connection.readyState === 1) { connected = true; return; }
  if (!process.env.MONGO_URI) throw new Error('MONGO_URI is not configured');
  await mongoose.connect(process.env.MONGO_URI);
  connected = true;
}
function makeCode() { return crypto.randomBytes(4).toString('hex').toUpperCase(); }
async function uniqueCode() { let code = makeCode(); while (await WebBattle.exists({ code })) code = makeCode(); return code; }
async function toCombatant(document, userId, wild = false) {
  const data = await fetchPokemonData(document.name);
  const maxHp = Math.max(1, Number(document.hp || data.stats?.hp || 1));
  return { userId: wild ? null : userId, pokemonId: document.pokemonId || null, name: document.name, nickname: document.nickname || null, level: Number(document.level || 1), sprite: document.sprite || data.sprite, type1: document.type1 || data.type1, type2: document.type2 || data.type2 || null, hp: maxHp, maxHp, attack: Number(document.attack || data.stats?.attack || 1), defense: Number(document.defense || data.stats?.defense || 1), moves: Array.isArray(document.moves) && document.moves.length ? document.moves.slice(0, 4) : (data.moves || ['tackle']), isWild: wild };
}
async function createWildBattle({ creatorId, groupJid, guildId, playerPokemon, wildPokemon }) {
  await ensureDb();
  const code = await uniqueCode();
  const player = await toCombatant(playerPokemon, creatorId);
  const wild = await toCombatant(wildPokemon, '', true);
  return WebBattle.create({ code, type: 'wild', status: 'active', creatorId, groupJid: groupJid || null, guildId: guildId ? String(guildId) : null, turnUserId: creatorId, players: [player], wild, lastAction: 'Battle ready.' });
}
async function createPvpBattle({ creatorId, opponentId, groupJid, playerPokemon, opponentPokemon }) {
  await ensureDb();
  const code = await uniqueCode();
  const first = await toCombatant(playerPokemon, creatorId);
  const second = await toCombatant(opponentPokemon, opponentId);
  return WebBattle.create({ code, type: 'pvp', status: 'active', creatorId, opponentId, groupJid: groupJid || null, turnUserId: creatorId, players: [first, second], lastAction: 'Both trainers are ready.' });
}
function battleUrl(type, code) {
  const base = String(process.env.WEB || 'https://haven.nett.to').replace(/\/$/, '');
  const path = type === 'pvp' ? '/battle/pvp/code' : '/battle/code';
  return `${base}${path}?code=${encodeURIComponent(code)}`;
}
module.exports = { ensureDb, createWildBattle, createPvpBattle, battleUrl };
