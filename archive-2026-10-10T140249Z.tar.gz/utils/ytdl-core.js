const axios = require('axios');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const ffmpeg = require('ffmpeg-static');

async function getAudioFromUrl(url) {
  const response = await axios.get('https://bk9.fun/download/youtube2', { params: { url } });
  const media = response.data?.BK9?.[0]?.mediaLink;
  if (!response.data?.status || !media) throw new Error(response.data?.message || 'download failed');
  const input = path.join('/tmp', `${crypto.randomInt(1e9)}.mp4`);
  const output = path.join('/tmp', `${crypto.randomInt(1e9)}.mp3`);
  const stream = await axios.get(media, { responseType: 'stream' });
  await new Promise((resolve, reject) => stream.data.pipe(fs.createWriteStream(input)).on('finish', resolve).on('error', reject));
  await new Promise((resolve, reject) => { const p = spawn(ffmpeg, ['-y', '-i', input, '-vn', '-codec:a', 'libmp3lame', output]); p.on('close', (code) => code === 0 ? resolve() : reject(new Error(`ffmpeg ${code}`))); p.on('error', reject); });
  fs.unlinkSync(input);
  return output;
}

module.exports = { getAudioFromUrl };
