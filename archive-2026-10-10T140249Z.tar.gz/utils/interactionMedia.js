const axios = require('axios');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
const run = promisify(execFile);

async function fetchInteractionMedia(action) {
  const api = await axios.get(`https://nekos.best/api/v2/${encodeURIComponent(action)}`, { timeout: 12000 });
  const url = api.data?.results?.[0]?.url;
  if (!url) throw new Error(`No media returned for ${action}`);
  const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 20000, maxContentLength: 15 * 1024 * 1024 });
  const contentType = String(response.headers?.['content-type'] || '').toLowerCase();
  const input = Buffer.from(response.data);
  if (contentType.includes('video/mp4') || /\.mp4($|\?)/i.test(url)) return { buffer: input, mimetype: 'video/mp4' };
  const base = path.join(os.tmpdir(), `interaction-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}`);
  const inputPath = `${base}.input`;
  const outputPath = `${base}.mp4`;
  fs.writeFileSync(inputPath, input);
  try {
    await run('ffmpeg', ['-y', '-i', inputPath, '-movflags', 'faststart', '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', outputPath], { timeout: 30000 });
    return { buffer: fs.readFileSync(outputPath), mimetype: 'video/mp4' };
  } finally {
    for (const file of [inputPath, outputPath]) { try { fs.unlinkSync(file); } catch {} }
  }
}
function interactionTarget(message) {
  const context = message?.message?.extendedTextMessage?.contextInfo || {};
  return context.mentionedJid?.[0] || context.participant || null;
}
async function sendInteraction(sock, jid, sender, target, action, message) {
  const media = await fetchInteractionMedia(action);
  const caption = `☆¤◇ @${String(sender).split('@')[0]} ${action}ed @${String(target).split('@')[0]}! ◇¤☆`;
  let lastError;
  for (let play = 0; play < 4; play += 1) {
    try {
      await sock.sendMessage(jid, { video: media.buffer, gifPlayback: true, mimetype: media.mimetype, caption: play === 0 ? caption : undefined, mentions: play === 0 ? [sender, target] : [] }, { quoted: play === 0 ? message : undefined });
    } catch (error) { lastError = error; }
  }
  if (lastError) throw lastError;
  return true;
}
module.exports = { fetchInteractionMedia, interactionTarget, sendInteraction };
