const { createCanvas, loadImage } = require('canvas');
const cache = new Map();
const BATTLE_BACKGROUND_URLS = Object.freeze({
  clear: 'https://files.catbox.moe/ct4nci.jpg',
  sunny: 'https://files.catbox.moe/ct4nci.jpg',
  night: 'https://files.catbox.moe/39fqob.jpg',
  rain: 'https://files.catbox.moe/dyzu37.jpg',
  snow: 'https://files.catbox.moe/igmfjo.jpg',
  sandstorm: 'https://files.catbox.moe/bsh3ff.jpg',
  fog: 'https://files.catbox.moe/39fqob.jpg',
  storm: 'https://files.catbox.moe/dyzu37.jpg',
});
function image(src){if(!src)return Promise.resolve(null);if(!cache.has(src))cache.set(src,loadImage(src).catch(()=>null));return cache.get(src)}
function rounded(ctx,x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath()}
function clamp(v){return Math.max(0,Math.min(1,Number(v)||0))}
function bar(ctx,x,y,w,ratio,color,h=12){ctx.fillStyle='rgba(0,0,0,.48)';rounded(ctx,x,y,w,h,h/2);ctx.fill();ctx.fillStyle=color;rounded(ctx,x,y,Math.max(4,w*clamp(ratio)),h,h/2);ctx.fill()}
async function sprite(ctx,url,x,y,w,h,flip=false){const img=await image(url);if(!img)return;ctx.save();if(flip){ctx.translate(x+w,y);ctx.scale(-1,1);ctx.drawImage(img,0,0,w,h)}else ctx.drawImage(img,x,y,w,h);ctx.restore()}
function typeColor(p){const colors={grass:'#55d99a',fire:'#ff765f',water:'#5fb5ff',electric:'#ffd35c',ice:'#8cecff',fighting:'#ff907b',poison:'#c88cff',ground:'#e8bc79',flying:'#b6c5ff',psychic:'#ff91bd',bug:'#badf69',rock:'#cbb18d',ghost:'#ad91ff',dragon:'#91a4ff',dark:'#c0b0ad',steel:'#c9dce7',fairy:'#ffacd0',normal:'#e3e8ed'};return colors[String(p?.type1||p?.type||'normal').toLowerCase()]||colors.normal}
async function drawStatusCard(ctx,p,x,y,w,h,color,align='left'){
  ctx.save();ctx.fillStyle='rgba(8,12,17,.91)';ctx.shadowColor='rgba(0,0,0,.3)';ctx.shadowBlur=20;rounded(ctx,x,y,w,h,15);ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle=`${color}cc`;ctx.lineWidth=2;ctx.stroke();
  const left=x+24,right=x+w-24;ctx.textAlign=align;const tx=align==='left'?left:right;
  const name=String(p?.nickname||p?.name||'Pokémon').toUpperCase().slice(0,20);ctx.fillStyle='#f7fafc';ctx.font='900 27px Sans';ctx.fillText(name,tx,y+39);
  ctx.fillStyle='#d9e1e8';ctx.font='800 16px Sans';ctx.fillText(`Lv ${Number(p?.level||1)}`,tx,y+67);
  const maxHp=Math.max(1,Number(p?.maxHp||p?.hp||1));const hp=Math.max(0,Math.min(maxHp,Number(p?.hp??maxHp)));const xp=Math.max(0,Number(p?.xp||p?.experience||0));const xpNext=Math.max(100,Number(p?.xpToNext||p?.nextXp||100));
  const bx=align==='left'?left:right-340;bar(ctx,bx,y+82,340,hp/maxHp,'#22e58b',12);bar(ctx,bx,y+106,340,xp/xpNext,'#5ab4ff',7);
  ctx.fillStyle='#d9e1e8';ctx.font='700 12px Monospace';ctx.textAlign='right';ctx.fillText(`${Math.round(hp)} / ${Math.round(maxHp)} HP`,x+w-24,y+94);ctx.fillStyle='#a9cfff';ctx.fillText(`XP ${Math.round(xp)} / ${Math.round(xpNext)}`,x+w-24,y+119);
  if(p?.type1){ctx.textAlign='left';ctx.fillStyle=color;ctx.font='800 11px Monospace';ctx.fillText(String(p.type1).toUpperCase(),left,y+125)}ctx.restore()
}
async function drawArenaBackground(ctx,w,h,weather){const key=String(weather||'Clear').toLowerCase();const src=BATTLE_BACKGROUND_URLS[key]||BATTLE_BACKGROUND_URLS.clear;const bg=await image(src);if(bg){const scale=Math.max(w/bg.width,h/bg.height),dw=bg.width*scale,dh=bg.height*scale;ctx.drawImage(bg,(w-dw)/2,(h-dh)/2,dw,dh)}else{const g=ctx.createLinearGradient(0,0,w,h);g.addColorStop(0,'#6d8e73');g.addColorStop(1,'#1a2730');ctx.fillStyle=g;ctx.fillRect(0,0,w,h)}ctx.fillStyle='rgba(4,8,12,.12)';ctx.fillRect(0,0,w,h);const shade=ctx.createLinearGradient(0,0,0,h);shade.addColorStop(0,'rgba(0,0,0,.02)');shade.addColorStop(.6,'rgba(0,0,0,.04)');shade.addColorStop(1,'rgba(0,0,0,.22)');ctx.fillStyle=shade;ctx.fillRect(0,0,w,h)}
async function generateBattleImage(data={}){const w=1200,h=800,c=createCanvas(w,h),ctx=c.getContext('2d');await drawArenaBackground(ctx,w,h,data.weather);
  // Preserve the old diagonal composition: opponent high-right, player low-left.
  await sprite(ctx,data.opponent?.sprite,735,145,360,360,true);
  await sprite(ctx,data.player?.sprite,75,365,390,390,false);
  const opponentColor=typeColor(data.opponent),playerColor=typeColor(data.player);
  await drawStatusCard(ctx,data.opponent,45,45,500,160,opponentColor,'left');
  await drawStatusCard(ctx,data.player,655,585,500,160,playerColor,'left');
  ctx.strokeStyle='rgba(255,255,255,.32)';ctx.lineWidth=2;ctx.strokeRect(14,14,w-28,h-28);
  return c.toBuffer('image/png')}
function getBattleBackgroundUrl(weather='Clear'){return BATTLE_BACKGROUND_URLS[String(weather||'Clear').toLowerCase()]||BATTLE_BACKGROUND_URLS.clear}
module.exports={generateBattleImage,getBattleBackgroundUrl};
