const lidCache = new Map();
const CACHE_TTL_MS = 5 * 60 * 1000;

function normalizePhoneJid(jid) {
  const value = typeof jid === 'string' ? jid.trim() : '';
  // Baileys may return a device JID such as 27673661818:0@s.whatsapp.net.
  // Only canonicalize a numeric device suffix; never derive a phone from LID digits.
  const match = /^(\d+)(?::\d+)?@s\.whatsapp\.net$/i.exec(value);
  return match ? `${match[1]}@s.whatsapp.net` : null;
}

function validPhoneJid(jid) {
  return Boolean(normalizePhoneJid(jid));
}

function fromPhoneJid(originalJid, phoneJid) {
  const canonicalPhoneJid = normalizePhoneJid(phoneJid);
  if (!canonicalPhoneJid) return null;
  const phoneNumber = canonicalPhoneJid.split('@')[0];
  return { originalJid, phoneJid: canonicalPhoneJid, phoneNumber };
}

async function getRealUserIdentity(sock, sender, alternatePhoneJid = null) {
  const originalJid = String(sender || '').trim();
  if (!originalJid) return null;

  const directPhoneJid = normalizePhoneJid(originalJid);
  if (directPhoneJid) return fromPhoneJid(originalJid, directPhoneJid);

  if (!originalJid.endsWith('@lid')) {
    console.warn(`[IDENTITY] Unsupported sender JID; no user identity will be created. Original: ${originalJid}`);
    return null;
  }

  // Baileys 7 attaches the corresponding phone JID to an incoming LID message
  // as participantAlt/remoteJid. Prefer that verified message-key value.
  const alternateJid = normalizePhoneJid(alternatePhoneJid);
  if (alternateJid) {
    lidCache.set(originalJid, { phoneJid: alternateJid, expiresAt: Date.now() + CACHE_TTL_MS });
    return fromPhoneJid(originalJid, alternateJid);
  }

  const cached = lidCache.get(originalJid);
  if (cached && cached.expiresAt > Date.now()) return fromPhoneJid(originalJid, cached.phoneJid);

  try {
    const resolver = sock?.signalRepository?.lidMapping?.getPNForLID;
    if (typeof resolver !== 'function') throw new Error('Baileys LID mapping is unavailable');
    const mappedJid = normalizePhoneJid(await resolver.call(sock.signalRepository.lidMapping, originalJid));
    if (!mappedJid) throw new Error('LID mapping returned an invalid phone JID');
    lidCache.set(originalJid, { phoneJid: mappedJid, expiresAt: Date.now() + CACHE_TTL_MS });
    return fromPhoneJid(originalJid, mappedJid);
  } catch (error) {
    console.warn(`[IDENTITY] Unable to resolve LID. Original: ${originalJid}. ${error.message}`);
    // Deliberately return null: LID digits are never a phone-number fallback.
    return null;
  }
}

async function getRealUserNumber(sock, sender, alternatePhoneJid = null) {
  return (await getRealUserIdentity(sock, sender, alternatePhoneJid))?.phoneNumber || null;
}

module.exports = { getRealUserIdentity, getRealUserNumber, normalizePhoneJid, validPhoneJid };
