const crypto = require('crypto');
const User = require('../models/User');
const Pokemon = require('../models/pokemon');
const config = require('../config');

const TOTAL_LEVELS = 250;
const PAGE_SIZE = 16;
const GYM_GROUP_ID = (process.env.POKEMON_GROUP_ID || '').trim();
const STAGE_NAMES = ['Verdant Gate', 'Tideglass Route', 'Thunder Summit', 'Moonlit Ruins', 'Ember Crown', 'Frostveil Pass', 'Skyforge Rise', 'Shadow Circuit', 'Abyssal Trial', 'Celestial League'];

function normalizeJid(value = '') {
  const raw = String(value || '').split(':')[0].trim().toLowerCase();
  return raw.includes('@') ? raw : `${raw}@s.whatsapp.net`;
}

function identityKeys(value = '') {
  const raw = String(value || '').split(':')[0].trim().toLowerCase();
  const number = raw.split('@')[0].replace(/[^0-9]/g, '');
  return [...new Set([raw, number, number ? `${number}@s.whatsapp.net` : ''].filter(Boolean))];
}

function groupAllowed(jid) {
  if (!GYM_GROUP_ID) return true;
  return jid === GYM_GROUP_ID;
}

function levelData(index) {
  const i = Number(index);
  const tier = Math.floor((i - 1) / 5) + 1;
  const opponentLevel = i > 245 ? 100 : Math.min(100, Math.max(3, Math.floor(4 + i * 0.55)));
  const requiredLevel = i > 245 ? 90 : Math.max(1, Math.min(opponentLevel, Math.floor((i - 1) * 0.4) + 1));
  return {
    index: i,
    name: `${STAGE_NAMES[tier % STAGE_NAMES.length]} · Stage ${String(i).padStart(3, '0')}`,
    master: i > 245
      ? ['Kaizel', 'Luc', 'Senpai', 'Riku', 'Ricko'][i - 246]
      : ['Brock', 'Misty', 'Lt. Surge', 'Erika', 'Koga', 'Sabrina', 'Blaine', 'Giovanni', 'Kaizel', 'Luc'][tier % 10],
    requiredLevel,
    opponent: i > 245
      ? ['rayquaza', 'mewtwo', 'groudon', 'kyogre', 'garchomp'][i - 246]
      : ['bulbasaur', 'charmander', 'squirtle', 'pikachu', 'eevee', 'gastly', 'dratini', 'riolu'][tier % 8],
    opponentLevel,
    points: i * 100 * (i > 245 ? 5 : 1),
    prize: i % 5 === 0 ? `a special Pokémon and ${i * 500} coins` : `${i * 250} coins and ${i * 10} XP`,
  };
}

async function getProgress(userId) {
  const user = await User.findOne({ $or: identityKeys(userId).flatMap((key) => [{ whatsappNumber: key }, { phoneNumber: key }, { userId: key }]) });
  if (!user) return { user: null, progress: { current: 1, points: 0, completed: 0 } };
  if (!user.gymProgress) user.gymProgress = { current: 1, points: 0, completed: 0 };
  return { user, progress: user.gymProgress };
}

async function partyFor(userId) {
  return Pokemon.find({ userId: { $in: identityKeys(userId).map(normalizeJid) }, location: 'party' }).sort({ partyPosition: 1, level: -1 }).limit(6);
}

function gymPage(progress, page = 1) {
  const safePage = Math.max(1, Math.min(Math.ceil(TOTAL_LEVELS / PAGE_SIZE), Number(page) || 1));
  const start = (safePage - 1) * PAGE_SIZE + 1;
  return { page: safePage, totalPages: Math.ceil(TOTAL_LEVELS / PAGE_SIZE), levels: Array.from({ length: Math.min(PAGE_SIZE, TOTAL_LEVELS - start + 1) }, (_, n) => {
    const level = levelData(start + n);
    const completed = level.index < progress.current;
    const current = level.index === progress.current;
    return { ...level, completed, current, open: completed || current };
  }) };
}

function battleFor(user, stage) {
  return {
    id: crypto.randomBytes(4).toString('hex').toUpperCase(),
    stage,
    userId: normalizeJid(user.whatsappNumber || user.phoneNumber || user.userId),
    turn: 1,
    playerPokemonId: null,
    opponent: {
      name: stage.opponent,
      level: stage.opponentLevel,
      hp: Math.min(15000, 250 + stage.index * 35),
      maxHp: Math.min(15000, 250 + stage.index * 35),
    },
    createdAt: new Date(),
  };
}

module.exports = { TOTAL_LEVELS, PAGE_SIZE, GYM_GROUP_ID, config, normalizeJid, identityKeys, groupAllowed, levelData, getProgress, partyFor, gymPage, battleFor };
