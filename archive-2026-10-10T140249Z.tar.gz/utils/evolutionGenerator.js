const { createCanvas, loadImage } = require('canvas');

async function loadArtwork(url) {
  if (!url) return null;
  try { return await loadImage(url); } catch { return null; }
}

async function generateEvolutionImage({ before, after, level }) {
  const width = 1100;
  const height = 700;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const background = ctx.createLinearGradient(0, 0, width, height);
  background.addColorStop(0, '#210d31');
  background.addColorStop(0.5, '#3a123f');
  background.addColorStop(1, '#101a36');
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = '#facc15';
  ctx.font = 'bold 44px Sans';
  ctx.textAlign = 'center';
  ctx.fillText('EVOLUTION COMPLETE', width / 2, 76);
  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 20px Sans';
  ctx.fillText(`Level ${level} · A new form has awakened`, width / 2, 112);

  const oldImage = await loadArtwork(before.sprite);
  const newImage = await loadArtwork(after.sprite);
  const draw = (image, x) => {
    if (!image) return;
    ctx.globalAlpha = 0.98;
    ctx.drawImage(image, x, 165, 330, 330);
    ctx.globalAlpha = 1;
  };
  draw(oldImage, 95);
  draw(newImage, 675);

  ctx.fillStyle = 'rgba(255,255,255,0.1)';
  ctx.fillRect(55, 535, 990, 2);
  ctx.fillStyle = '#cbd5e1';
  ctx.font = 'bold 25px Sans';
  ctx.fillText(String(before.name || '').toUpperCase(), 260, 600);
  ctx.fillStyle = '#facc15';
  ctx.font = 'bold 52px Sans';
  ctx.fillText('→', width / 2, 600);
  ctx.fillStyle = '#f8fafc';
  ctx.font = 'bold 25px Sans';
  ctx.fillText(String(after.name || '').toUpperCase(), 840, 600);
  return canvas.toBuffer('image/png');
}

module.exports = { generateEvolutionImage };
