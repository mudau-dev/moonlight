const Pokemon = require('../models/pokemon');
const { findOrCreateWhatsApp } = require('../database/users');
const rentalCleanupCache = new Map();
const RENTAL_CLEANUP_TTL_MS = 60 * 1000;

function unique(values) {
  return [...new Set(values.filter(Boolean).map((value) => String(value)))];
}

function digits(value) {
  return String(value || '').replace(/[^0-9]/g, '');
}

async function resolvePokemonOwner(sender) {
  const user = await findOrCreateWhatsApp(sender);
  const identifiers = unique([
    sender,
    digits(sender),
    user?.moonId,
    user?.whatsappNumber,
    user?.userId,
    user?.phoneNumber,
  ]);

  return { user, identifiers, primaryId: user?.moonId || sender };
}

async function ownedPokemonFilter(sender, location) {
  const owner = await resolvePokemonOwner(sender);
  const filter = { userId: { $in: owner.identifiers } };
  if (location) filter.location = location;
  return { owner, filter };
}

async function cleanupExpiredRentals(sender) {
  const owner = await resolvePokemonOwner(sender);
  const cacheKey = owner.primaryId || sender;
  const previous = rentalCleanupCache.get(cacheKey);
  if (previous && previous > Date.now()) return { owner, removedCount: 0 };
  rentalCleanupCache.set(cacheKey, Date.now() + RENTAL_CLEANUP_TTL_MS);
  const result = await Pokemon.deleteMany({
    userId: { $in: owner.identifiers },
    isRental: true,
    rentalExpiresAt: { $lte: new Date() },
  });
  return { owner, removedCount: result.deletedCount || 0 };
}

async function ensurePartyPositions(owner) {
  const party = await Pokemon.find({ userId: { $in: owner.identifiers }, location: 'party' }).sort({ caughtAt: 1, _id: 1 });
  const positions = party.map((pokemon) => Number(pokemon.partyPosition));
  const hasValidStoredOrder = positions.length === new Set(positions).size
    && positions.every((position) => Number.isInteger(position) && position >= 1 && position <= party.length);

  // New installs and older catches have no position. Preserve their original caught order once,
  // then all future reads follow the persisted partyPosition set by `.pchange`.
  if (!hasValidStoredOrder) {
    await Promise.all(party.map((pokemon, index) => Pokemon.updateOne(
      { _id: pokemon._id },
      { $set: { partyPosition: index + 1 } }
    )));
    party.forEach((pokemon, index) => { pokemon.partyPosition = index + 1; });
  }

  return party.sort((left, right) => Number(left.partyPosition) - Number(right.partyPosition));
}

async function listPokemon(sender, location, limit) {
  const { owner } = await cleanupExpiredRentals(sender);
  let pokemons;
  if (location === 'party') {
    pokemons = await ensurePartyPositions(owner);
  } else {
    const filter = { userId: { $in: owner.identifiers } };
    if (location) filter.location = location;
    pokemons = await Pokemon.find(filter).sort({ caughtAt: 1, _id: 1 });
  }

  if (Number.isInteger(limit)) pokemons = pokemons.slice(0, limit);
  return { owner, pokemons };
}

async function getPokemonByIndex(sender, location, oneBasedIndex) {
  const index = Number.parseInt(oneBasedIndex, 10);
  if (!Number.isInteger(index) || index < 1) return null;

  const { owner, pokemons } = await listPokemon(sender, location);
  const pokemon = pokemons[index - 1] || null;
  return pokemon ? { owner, pokemon, index, total: pokemons.length } : null;
}

function getMaxHp(pokemon) {
  const stored = Number(pokemon?.maxHp);
  const current = Number(pokemon?.hp);
  if (Number.isFinite(stored) && stored > 0) return Math.round(stored);
  if (Number.isFinite(current) && current > 0) return Math.round(current);
  return 1;
}

function getCurrentHp(pokemon) {
  const maxHp = getMaxHp(pokemon);
  const current = Number(pokemon?.hp);
  if (!Number.isFinite(current)) return maxHp;
  return Math.max(0, Math.min(Math.round(current), maxHp));
}

function displayName(pokemon) {
  return String(pokemon?.nickname || pokemon?.name || 'Unknown Pokémon').toUpperCase();
}

function formatPokemonDetails(pokemon, options = {}) {
  const maxHp = getMaxHp(pokemon);
  const currentHp = getCurrentHp(pokemon);
  const types = [pokemon?.type1, pokemon?.type2].filter(Boolean).map((type) => String(type).toUpperCase()).join(' / ') || 'UNKNOWN';
  const moves = Array.isArray(pokemon?.moves) && pokemon.moves.length
    ? pokemon.moves.map((move) => String(move).replace(/-/g, ' ').toUpperCase()).join(', ')
    : 'None';
  const title = options.title || `POKÉMON DETAILS: ${displayName(pokemon)}`;

  return [
    `📜 *${title}*`,
    '',
    `*Name:* ${pokemon?.nickname || pokemon?.name || 'Unknown'}`,
    `*ID:* ${pokemon?.pokemonId || 'Unknown'}`,
    `*Capture Rate:* ${pokemon?.captureRate ?? 'Unknown'}`,
    `*Gender:* ${pokemon?.gender || 'Unknown'}`,
    `*Nature:* ${pokemon?.nature || 'Hardy'}`,
    `*Types:* ${types}`,
    `*Level:* ${pokemon?.level ?? 1}`,
    `*XP:* ${pokemon?.xp ?? 0}`,
    `*State:* ${pokemon?.status || 'Healthy'}${(pokemon?.status === 'Fainted' || currentHp <= 0) ? '\n\n❌ *Pokémon Unavailable*\n_This Pokémon cannot be used until it recovers._' : ''}`,
    `*HP:* ${currentHp}/${maxHp}`,
    `*Attack:* ${pokemon?.attack ?? 0}`,
    `*Defense:* ${pokemon?.defense ?? 0}`,
    `*Sp. Atk:* ${pokemon?.spAtk ?? 0}`,
    `*Sp. Def:* ${pokemon?.spDef ?? 0}`,
    `*Speed:* ${pokemon?.speed ?? 0}`,
    `> *Moves:* ${moves}`,
  ].join('\n');
}

module.exports = {
  resolvePokemonOwner,
  ownedPokemonFilter,
  cleanupExpiredRentals,
  ensurePartyPositions,
  listPokemon,
  getPokemonByIndex,
  getMaxHp,
  getCurrentHp,
  displayName,
  formatPokemonDetails,
};
