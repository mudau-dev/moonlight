const { createCanvas, loadImage } = require('canvas');
const { getBattleBackgroundUrl } = require('./battleGenerator');

const spriteCache = new Map();
function loadSprite(url) {
  if (!url) return Promise.resolve(null);
  if (!spriteCache.has(url)) spriteCache.set(url, loadImage(url).catch(() => null));
  return spriteCache.get(url);
}

function rounded(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, radius);
}

function label(ctx, value, x, y, size, color = '#f8fafc', align = 'left') {
  ctx.fillStyle = color;
  ctx.font = `700 ${size}px Sans`;
  ctx.textAlign = align;
  ctx.fillText(String(value), x, y);
}

async function resultImage({ pokemon, opponent, won, capture = false, reason = 'Knockout', weather = 'Clear' }) {
  const width = 900;
  const height = 600;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const backgroundUrl = getBattleBackgroundUrl(weather);
  let background = null;
  try { background = await loadImage(backgroundUrl); } catch {}
  if (background) {
    const scale = Math.max(width / background.width, height / background.height);
    const dw = background.width * scale;
    const dh = background.height * scale;
    ctx.drawImage(background, (width - dw) / 2, (height - dh) / 2, dw, dh);
  } else {
    ctx.fillStyle = won ? '#102d31' : '#2d1821';
    ctx.fillRect(0, 0, width, height);
  }

  const accent = capture ? '#facc15' : (won ? '#22e889' : '#fb7185');
  ctx.fillStyle = capture ? 'rgba(48,34,5,.62)' : (won ? 'rgba(4,35,31,.56)' : 'rgba(45,8,22,.64)');
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = `${accent}22`;
  ctx.fillRect(0, 0, width, 178);
  label(ctx, capture ? 'POKÉMON CAUGHT' : (won ? 'VICTORY' : 'DEFEATED'), width / 2, 78, capture ? 48 : 58, accent, 'center');
  label(ctx, capture ? 'The wild Pokémon was added to your PC' : (won ? 'Your Pokémon won the battle' : 'Your Pokémon was defeated'), width / 2, 116, 23, '#ffffff', 'center');

  const primary = await loadSprite(pokemon?.sprite);
  const secondary = await loadSprite(opponent?.sprite);
  if (secondary) {
    ctx.globalAlpha = 0.38;
    ctx.drawImage(secondary, won ? 555 : 45, 170, 260, 260);
    ctx.globalAlpha = 1;
  }
  if (primary) {
    ctx.shadowColor = `${accent}aa`;
    ctx.shadowBlur = 34;
    ctx.drawImage(primary, won ? 130 : 520, 155, 320, 320);
    ctx.shadowBlur = 0;
  }

  const panelX = 115;
  const panelY = 442;
  const panelW = 670;
  const panelH = 112;
  ctx.fillStyle = 'rgba(13,16,23,.93)';
  rounded(ctx, panelX, panelY, panelW, panelH, 18);
  ctx.fill();
  ctx.strokeStyle = `${accent}aa`;
  ctx.lineWidth = 2;
  ctx.stroke();
  label(ctx, `${pokemon?.nickname || pokemon?.name || 'Pokémon'} ${won ? 'wins' : 'needs rest'}`, panelX + 26, panelY + 38, 25, '#ffffff');
  label(ctx, `Reason: ${reason}`, panelX + 26, panelY + 74, 17, '#d7d7df');
  label(ctx, won ? 'Battle complete' : 'Heal your party before battling again', panelX + panelW - 26, panelY + 74, 17, accent, 'right');
  return canvas.toBuffer('image/png');
}

async function captureImage({ pokemon, pcIndex = null, xpGained = 0 }) {
  return resultImage({ pokemon, won: true, capture: true, reason: `Caught and stored in PC${pcIndex ? ` · slot ${pcIndex}` : ''}`, weather: 'Clear', opponent: null, xpGained });
}

async function defeatImage(options) {
  return resultImage({ ...options, won: false });
}

async function victoryImage(options) {
  return resultImage({ ...options, won: true });
}

async function generateOutcomeImage(options = {}) {
  if (options.capture) return captureImage(options);
  return options.won === false ? defeatImage(options) : victoryImage(options);
}

module.exports = { generateOutcomeImage };
