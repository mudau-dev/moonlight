module.exports = new Proxy({}, {
  get(_target, property) {
    if (!global.baileys) {
      throw new Error(`Baileys is not initialized before requesting export: ${String(property)}`);
    }
    return global.baileys[property];
  },
});
