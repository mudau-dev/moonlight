const { getRealUserIdentity, normalizePhoneJid } = require('./whatsappIdentity');

function phoneNumberFromValue(value) {
  if (value && typeof value === 'object') {
    const candidates = [value.phoneNumber, value.jid, value.id, value.lid, value.phone];
    for (const candidate of candidates) {
      const number = phoneNumberFromValue(candidate);
      if (number) return number;
    }
    return null;
  }

  const raw = String(value || '').trim();
  if (!raw || raw.endsWith('@lid')) return null;

  const canonical = normalizePhoneJid(raw);
  if (canonical) return canonical.split('@')[0];

  const digits = raw.replace(/\D/g, '');
  return digits.length >= 7 ? digits : null;
}

function canonicalPhoneJid(value) {
  const number = phoneNumberFromValue(value);
  return number ? `${number}@s.whatsapp.net` : null;
}

function sameIdentity(left, right) {
  if (!left || !right) return false;
  if (left === right) return true;

  const leftNumber = phoneNumberFromValue(left);
  const rightNumber = phoneNumberFromValue(right);
  return Boolean(leftNumber && rightNumber && leftNumber === rightNumber);
}

function findParticipantByIdentity(participants, identity) {
  return (participants || []).find((participant) => sameIdentity(participant, identity));
}

function isParticipantAdmin(participant) {
  return participant?.admin === 'admin' || participant?.admin === 'superadmin';
}

function isParticipantAdminByIdentity(participants, identity) {
  return isParticipantAdmin(findParticipantByIdentity(participants, identity));
}

function getBotIdentity(sock, config = {}) {
  return sock?.user?.id || sock?.user?.jid || config?.BOT_JID || null;
}

async function resolvePhoneJid(sock, value) {
  const direct = canonicalPhoneJid(value);
  if (direct) return direct;

  const raw = String(value || '').trim();
  if (!raw.endsWith('@lid')) return null;

  const identity = await getRealUserIdentity(sock, raw);
  return identity?.phoneJid || null;
}

async function resolveMessageTarget(sock, message, args = []) {
  const contextInfo = message?.message?.extendedTextMessage?.contextInfo
    || message?.message?.imageMessage?.contextInfo
    || message?.message?.videoMessage?.contextInfo
    || message?.message?.conversation?.contextInfo
    || {};
  const candidates = [
    ...(contextInfo.mentionedJid || []),
    contextInfo.participant,
    contextInfo.participantAlt,
    ...(contextInfo.quotedMessage?.key ? [contextInfo.quotedMessage.key.participant, contextInfo.quotedMessage.key.remoteJidAlt] : []),
    args[0],
  ].filter(Boolean);

  const seen = new Set();
  for (const candidate of candidates) {
    const key = typeof candidate === 'string' ? candidate.trim() : JSON.stringify(candidate);
    if (seen.has(key)) continue;
    seen.add(key);
    const resolved = await resolvePhoneJid(sock, candidate);
    if (resolved) return resolved;
  }
  return null;
}

module.exports = {
  phoneNumberFromValue,
  canonicalPhoneJid,
  sameIdentity,
  findParticipantByIdentity,
  isParticipantAdmin,
  isParticipantAdminByIdentity,
  getBotIdentity,
  resolvePhoneJid,
  resolveMessageTarget,
};
