const System = require('../models/System');

const CACHE_TTL_MS = 1000;
const muteCache = new Map();

function muteKey(groupJid) {
  return `mutedUsers:${groupJid}`;
}

function normalizeUser(userJid) {
  if (!userJid) return null;
  if (String(userJid).includes('@')) return String(userJid);
  const digits = String(userJid).replace(/[^0-9]/g, '');
  return digits ? `${digits}@s.whatsapp.net` : null;
}

function cacheUsers(groupJid, users) {
  muteCache.set(groupJid, { users: [...new Set(users.map(normalizeUser).filter(Boolean))], expiresAt: Date.now() + CACHE_TTL_MS });
}

async function getMutedUsers(groupJid) {
  const cached = muteCache.get(groupJid);
  if (cached && cached.expiresAt > Date.now()) return cached.users;
  const doc = await System.findOne({ key: muteKey(groupJid) }).lean();
  const users = Array.isArray(doc?.value) ? doc.value.map(normalizeUser).filter(Boolean) : [];
  cacheUsers(groupJid, users);
  return users;
}

async function isMuted(groupJid, userJid) {
  const normalized = normalizeUser(userJid);
  return Boolean(normalized && (await getMutedUsers(groupJid)).includes(normalized));
}

async function muteUser(groupJid, userJid) {
  const normalized = normalizeUser(userJid);
  if (!normalized) return [];
  const doc = await System.findOneAndUpdate(
    { key: muteKey(groupJid) },
    { $addToSet: { value: normalized }, $set: { updatedAt: new Date() } },
    { upsert: true, new: true }
  );
  const next = Array.isArray(doc?.value) ? doc.value.map(normalizeUser).filter(Boolean) : [];
  cacheUsers(groupJid, next);
  return next;
}

async function unmuteUser(groupJid, userJid) {
  const normalized = normalizeUser(userJid);
  if (!normalized) return [];
  const doc = await System.findOneAndUpdate(
    { key: muteKey(groupJid) },
    { $pull: { value: normalized }, $set: { updatedAt: new Date() } },
    { upsert: true, new: true }
  );
  const next = Array.isArray(doc?.value) ? doc.value.map(normalizeUser).filter(Boolean) : [];
  cacheUsers(groupJid, next);
  return next;
}

module.exports = { normalizeUser, getMutedUsers, isMuted, muteUser, unmuteUser };
