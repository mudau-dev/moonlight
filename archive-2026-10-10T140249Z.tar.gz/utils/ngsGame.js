const User = require('../models/User');
const { updateUser } = require('../database/users');

const games = new Map();
const MAX_DURATION_MS = 5 * 24 * 60 * 60 * 1000;
const PAYOUTS = [500000, 400000, 300000, 250000, 200000, 150000, 100000, 75000, 50000, 25000];
const dbKey = (jid) => `ngs:${jid}`;

function parseDuration(value) {
  const match = String(value || '').trim().toLowerCase().match(/^(\d+)(m|h|d)$/);
  if (!match) return null;
  const duration = Number(match[1]) * { m: 60000, h: 3600000, d: 86400000 }[match[2]];
  return Number.isFinite(duration) && duration >= 60000 && duration <= MAX_DURATION_MS ? duration : null;
}
function formatDuration(ms) {
  const minutes = Math.ceil(ms / 60000);
  if (minutes % 1440 === 0) return `${minutes / 1440}d`;
  if (minutes % 60 === 0) return `${minutes / 60}h`;
  return `${minutes}m`;
}
async function persistGame(jid, game) {
  await User.findOneAndUpdate({ userId: dbKey(jid) }, { $set: { userId: dbKey(jid), ngsGame: { target: game.target, startedAt: game.startedAt, endsAt: game.endsAt, mentions: game.mentions || [], guesses: [...game.guesses.values()] } } }, { upsert: true, setDefaultsOnInsert: true }).exec();
}
async function clearPersisted(jid) {
  await User.updateOne({ userId: dbKey(jid) }, { $unset: { ngsGame: 1 } }).exec().catch(() => {});
}
function clearGame(jid, options = {}) {
  const game = games.get(jid);
  if (game?.timer) clearTimeout(game.timer);
  games.delete(jid);
  if (options.persist !== false) clearPersisted(jid);
}
function schedule(sock, jid, game) {
  const remaining = Math.max(1, game.endsAt - Date.now());
  game.timer = setTimeout(() => finishGame(sock, jid, game).catch((error) => console.error('[NGS FINISH]', error.message)), remaining);
}
async function restoreGame(sock, jid) {
  if (games.has(jid)) return games.get(jid);
  const record = await User.findOne({ userId: dbKey(jid) }).select('ngsGame').lean().exec().catch(() => null);
  const saved = record?.ngsGame;
  if (!saved || Number(saved.endsAt) <= Date.now()) {
    if (saved) await clearPersisted(jid);
    return null;
  }
  const game = { target: Number(saved.target), startedAt: Number(saved.startedAt), endsAt: Number(saved.endsAt), mentions: saved.mentions || [], guesses: new Map((saved.guesses || []).map((entry) => [entry.sender, entry])), timer: null };
  games.set(jid, game);
  schedule(sock, jid, game);
  return game;
}
async function finishGame(sock, jid, game, reason = 'time') {
  if (games.get(jid) !== game) return;
  if (game.timer) clearTimeout(game.timer);
  games.delete(jid);
  await clearPersisted(jid);
  const ranked = [...game.guesses.values()].map((entry) => ({ ...entry, distance: Math.abs(entry.number - game.target) })).sort((a, b) => a.distance - b.distance || a.at - b.at).slice(0, 10);
  if (!ranked.length) return sock.sendMessage(jid, { text: `⏱️ *NGS ENDED*\n\nNo valid guesses were recorded.\n🎯 The secret number was *${game.target}*.` });
  const endLabel = reason === 'time' ? 'Time is up!' : reason === 'draw' ? 'Game drawn early by the owner.' : 'Game closed.';
  const lines = ['🏁 *NGS CHAMPIONS BOARD*', `🎯 Secret number: *${game.target}*`, `📌 ${endLabel}`, '', '✨ *Top players*'];
  const mentions = [];
  for (let i = 0; i < ranked.length; i += 1) {
    const entry = ranked[i];
    const payout = entry.distance === 0 ? 2000000 : PAYOUTS[i];
    if (payout > 0) await updateUser(entry.sender, { $inc: { balance: payout, totalEarned: payout } });
    mentions.push(entry.sender);
    lines.push(`${i + 1}. @${entry.sender.split('@')[0]} · ${entry.distance === 0 ? '🎯 EXACT' : `distance ${entry.distance}`} · \`${entry.number}\` · ${payout.toLocaleString()} coins`);
  }
  lines.push('', '🌙 Thank you for playing — the next challenge can start anytime!');
  return sock.sendMessage(jid, { text: lines.join('\n'), mentions });
}
function startGame(sock, jid, ownerMessage, target, duration, mentions) {
  clearGame(jid, { persist: false });
  const game = { target, startedAt: Date.now(), endsAt: Date.now() + duration, guesses: new Map(), mentions: mentions || [], timer: null };
  games.set(jid, game);
  persistGame(jid, game).catch((error) => console.error('[NGS SAVE]', error.message));
  schedule(sock, jid, game);
  sock.sendMessage(jid, { text: `🎉 *MOONLIGHT NUMBER GUESSING PARTY* 🎉\n\n🌟 Everyone is invited to play! Guess the secret number from *1 to 150*.\n⏳ You have *${formatDuration(duration)}* to join the challenge.\n\n💫 Send *one number only* — your first valid guess is locked in.\n🏆 The closest players win coins, and an exact guess wins the grand prize!\n\n🍀 Good luck, MoonLords! Let the guessing begin!`, mentions: game.mentions }).catch(() => {});
  return game;
}
async function handleGuess(sock, jid, sender, body, message) {
  let game = games.get(jid);
  if (!game) game = await restoreGame(sock, jid);
  if (!game || Date.now() >= game.endsAt) { if (game) await finishGame(sock, jid, game); return false; }
  const match = String(body || '').trim().match(/^(\d{1,3})$/);
  if (!match) return false;
  const number = Number(match[1]);
  if (number < 1 || number > 150 || game.guesses.has(sender)) return false;
  const entry = { sender, number, at: Date.now() };
  game.guesses.set(sender, entry);
  await persistGame(jid, game).catch(() => {});
  try { await sock.sendMessage(jid, { react: { text: '✅', key: message?.key } }); } catch {}
  return true;
}
module.exports = { games, parseDuration, formatDuration, startGame, finishGame, handleGuess, clearGame, restoreGame };
