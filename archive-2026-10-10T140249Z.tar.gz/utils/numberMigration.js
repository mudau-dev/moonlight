const mongoose = require('mongoose');
const User = require('../models/User');

function digits(value) { return String(value || '').replace(/\D/g, ''); }
function aliasesFor(user) { return [...new Set([user.moonId, user.phoneNumber, user.userId, user.whatsappNumber, digits(user.moonId), digits(user.phoneNumber), digits(user.userId), digits(user.whatsappNumber)].map((v) => String(v || '').trim()).filter(Boolean))]; }
function replace(value, aliases, next) { return aliases.includes(String(value || '').trim()) ? next : value; }
function replaceArray(values, aliases, next) { return Array.isArray(values) ? values.map((v) => replace(v, aliases, next)) : values; }

async function migrateNumber(user, newNumber) {
  const oldAliases = aliasesFor(user); const newWhatsApp = `${newNumber}@s.whatsapp.net`; const db = mongoose.connection;
  const scalar = [['pokemons','userId',newWhatsApp],['pokemon_journeys','userId',newNumber],['news_posts','authorId',newNumber],['cardmarkets','sellerId',newNumber],['staff_applications','userId',newNumber],['staff_applications','moonId',newNumber],['chat_invites','createdByMoonId',newNumber],['group_requests','moonId',newNumber],['legacyplayers','whatsappId',newNumber],['notifications','targetMoonId',newNumber],['notifications','sentBy',newNumber]];
  for (const [collection, field, value] of scalar) await db.collection(collection).updateMany({ [field]: { $in: oldAliases } }, { $set: { [field]: value } });
  await db.collection('discord_links').updateMany({ $or: [{ phoneNumber: { $in: oldAliases } }, { whatsappNumber: { $in: oldAliases } }, { moonId: { $in: oldAliases } }] }, { $set: { phoneNumber: newNumber, whatsappNumber: newWhatsApp, moonId: newNumber } });
  const guilds = await db.collection('guilds').find({ $or: [{ ownerId: { $in: oldAliases } }, { members: { $in: oldAliases } }, { guards: { $in: oldAliases } }, { banned: { $in: oldAliases } }, { 'joinRequests.userId': { $in: oldAliases } }] }).toArray();
  for (const guild of guilds) await db.collection('guilds').updateOne({ _id: guild._id }, { $set: { ownerId: replace(guild.ownerId, oldAliases, newNumber), members: replaceArray(guild.members, oldAliases, newNumber), guards: replaceArray(guild.guards, oldAliases, newNumber), banned: replaceArray(guild.banned, oldAliases, newNumber), joinRequests: (guild.joinRequests || []).map((r) => ({ ...r, userId: replace(r.userId, oldAliases, newNumber) })) } });
  const chats = await db.collection('chat_conversations').find({ $or: [{ creatorMoonId: { $in: oldAliases } }, { 'members.moonId': { $in: oldAliases } }] }).toArray();
  for (const chat of chats) await db.collection('chat_conversations').updateOne({ _id: chat._id }, { $set: { creatorMoonId: replace(chat.creatorMoonId, oldAliases, newNumber), members: (chat.members || []).map((m) => ({ ...m, moonId: replace(m.moonId, oldAliases, newNumber) })) } });
  const notifications = await db.collection('notifications').find({ readBy: { $in: oldAliases } }).toArray();
  for (const notification of notifications) await db.collection('notifications').updateOne({ _id: notification._id }, { $set: { readBy: replaceArray(notification.readBy, oldAliases, newNumber) } });
  const battles = await db.collection('webbattles').find({ $or: [{ creatorId: { $in: oldAliases } }, { opponentId: { $in: oldAliases } }, { turnUserId: { $in: oldAliases } }, { forcedSwitchUserId: { $in: oldAliases } }, { winnerId: { $in: oldAliases } }, { 'players.userId': { $in: oldAliases } }, { 'spectators.userId': { $in: oldAliases } }, { 'usage.userId': { $in: oldAliases } }, { 'rematchRequest.fromUserId': { $in: oldAliases } }] }).toArray();
  for (const battle of battles) await db.collection('webbattles').updateOne({ _id: battle._id }, { $set: { creatorId: replace(battle.creatorId, oldAliases, newNumber), opponentId: replace(battle.opponentId, oldAliases, newNumber), turnUserId: replace(battle.turnUserId, oldAliases, newNumber), forcedSwitchUserId: replace(battle.forcedSwitchUserId, oldAliases, newNumber), winnerId: replace(battle.winnerId, oldAliases, newNumber), players: (battle.players || []).map((p) => ({ ...p, userId: replace(p.userId, oldAliases, newNumber) })), spectators: (battle.spectators || []).map((p) => ({ ...p, userId: replace(p.userId, oldAliases, newNumber) })), usage: (battle.usage || []).map((p) => ({ ...p, userId: replace(p.userId, oldAliases, newNumber) })), rematchRequest: battle.rematchRequest ? { ...battle.rematchRequest, fromUserId: replace(battle.rematchRequest.fromUserId, oldAliases, newNumber) } : battle.rematchRequest } });
  user.moonId = newNumber; user.phoneNumber = newNumber; user.userId = newNumber; user.whatsappNumber = newWhatsApp; await user.save();
  return { oldNumber: oldAliases[0], newNumber };
}

async function deleteNumberAccount(user) {
  const aliases = aliasesFor(user);
  const db = mongoose.connection;
  const direct = [
    ['pokemons', 'userId'], ['pokemon_journeys', 'userId'], ['news_posts', 'authorId'],
    ['cardmarkets', 'sellerId'], ['staff_applications', 'userId'], ['group_requests', 'moonId'],
    ['legacyplayers', 'whatsappId'], ['notifications', 'targetMoonId'], ['notifications', 'sentBy'],
    ['eventprogresses', 'userId'], ['realmplayers', 'userId'], ['realmplayers', 'whatsappNumber'],
    ['realmcharacters', 'userId'], ['realmbattles', 'player1'], ['realmbattles', 'player2'],
    ['webbattles', 'creatorId'], ['webbattles', 'opponentId'], ['webbattles', 'turnUserId'],
    ['webbattles', 'winnerId'], ['discord_links', 'phoneNumber'], ['discord_links', 'whatsappNumber'],
    ['discord_links', 'moonId'], ['afks', 'userId'], ['cooldowns', 'userId'],
  ];
  const deleted = {};
  for (const [collection, field] of direct) {
    const result = await db.collection(collection).deleteMany({ [field]: { $in: aliases } });
    if (result.deletedCount) deleted[collection] = (deleted[collection] || 0) + result.deletedCount;
  }

  // Remove the account from shared documents without deleting other users' data.
  await db.collection('guilds').updateMany(
    { $or: [{ ownerId: { $in: aliases } }, { members: { $in: aliases } }, { guards: { $in: aliases } }, { banned: { $in: aliases } }, { 'joinRequests.userId': { $in: aliases } }] },
    [{ $set: {
      members: { $setDifference: ['$members', aliases] },
      guards: { $setDifference: ['$guards', aliases] },
      banned: { $setDifference: ['$banned', aliases] },
      joinRequests: { $filter: { input: { $ifNull: ['$joinRequests', []] }, as: 'request', cond: { $not: [{ $in: ['$$request.userId', aliases] }] } } },
    } }, { $set: { ownerId: { $cond: [{ $in: ['$ownerId', aliases] }, null, '$ownerId'] } } }],
  );
  const userResult = await User.deleteOne({ _id: user._id });
  return { aliases, deleted, userDeleted: userResult.deletedCount === 1 };
}

module.exports = { migrateNumber, deleteNumberAccount, aliasesFor, digits };
