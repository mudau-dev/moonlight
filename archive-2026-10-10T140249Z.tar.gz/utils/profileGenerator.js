/**
 * Lightweight WhatsApp profile-card renderer.
 *
 * All frames are procedural Canvas artwork. No remote frame file is downloaded
 * when a profile command runs. Animated cards are encoded as an eight-state,
 * 720px MP4 that WhatsApp displays through its GIF playback mode.
 */
const { createCanvas, loadImage } = require('canvas');
const axios = require('axios');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { promisify } = require('util');
const { execFile } = require('child_process');
const ffmpegPath = require('ffmpeg-static') || 'ffmpeg';

const execFileAsync = promisify(execFile);
const DEFAULT_ICON = 'https://files.catbox.moe/4oz1zk.jpeg';
const DEFAULT_BACKGROUND = 'https://files.catbox.moe/gim8wi.jpeg';
const CANVAS_SIZE = 720;
const ANIMATION_FRAME_COUNT = 8;
const ANIMATION_FPS = 4;
const ANIMATION_DURATION_SECONDS = 10; // Five complete 2-second animation loops.

const PALETTES = {
  classic: ['#a78bfa', '#e2e8f0'],
  'celestial-crown': ['#8b5cf6', '#fef3c7'], 'rose-thorns': ['#be123c', '#fb7185'],
  'ocean-leviathan': ['#0891b2', '#a5f3fc'], 'crystal-geode': ['#7e22ce', '#93c5fd'],
  'cyber-mecha': ['#0f766e', '#67e8f9'], 'iron-blades': ['#94a3b8', '#f8fafc'],
  'verdant-bloom': ['#22c55e', '#bbf7d0'], 'bound-silver': ['#94a3b8', '#60a5fa'],
  'seraph-wings': ['#e2e8f0', '#fef3c7'], emberborn: ['#f97316', '#fde68a'],
  'paper-spells': ['#f8f0cf', '#f59e0b'], clockwork: ['#64748b', '#38bdf8'],
  frostbound: ['#67e8f9', '#dbeafe'], 'thorn-garden': ['#15803d', '#bef264'],
  'moon-lilies': ['#e9d5ff', '#f0abfc'], 'sun-forged': ['#fbbf24', '#fef08a'],
  'ink-noir': ['#334155', '#c084fc'], 'tempest-mark': ['#2563eb', '#67e8f9'],
  'sky-feather': ['#7dd3fc', '#e0f2fe'],
  'animated-orbit': ['#ec4899', '#c084fc'], 'animated-starfall': ['#22d3ee', '#a5f3fc'],
  'animated-crownlight': ['#fbbf24', '#fde68a'], 'animated-prism': ['#a855f7', '#60a5fa'],
  'animated-inferno': ['#ef4444', '#f59e0b'], 'animated-lunar': ['#93c5fd', '#e0e7ff'],
  'animated-rosefall': ['#f43f5e', '#f0abfc'], 'animated-runic': ['#8b5cf6', '#c4b5fd'],
  'animated-thunder': ['#2563eb', '#a5f3fc'], 'animated-chains': ['#64748b', '#f8fafc'],
  'animated-seraph': ['#fef3c7', '#f8fafc'], 'animated-comet': ['#38bdf8', '#fef08a'],
  'animated-grid': ['#06b6d4', '#84cc16'], 'animated-halo': ['#10b981', '#67e8f9'],
  'animated-void': ['#7c3aed', '#312e81'],
};

const LEGACY_FRAME_IDS = {
  moonviolet: 'celestial-crown', cyan: 'ocean-leviathan', gold: 'sun-forged', emerald: 'verdant-bloom',
  rose: 'rose-thorns', sky: 'sky-feather', sunset: 'emberborn', forest: 'thorn-garden', ocean: 'ocean-leviathan',
  twilight: 'crystal-geode', mint: 'verdant-bloom', lavender: 'celestial-crown', coral: 'rose-thorns',
  silver: 'bound-silver', copper: 'clockwork', sapphire: 'tempest-mark', plasma: 'crystal-geode',
  obsidian: 'ink-noir', aurora: 'celestial-crown', animated_orbit: 'animated-orbit', animated_spark: 'animated-starfall',
  animated_crown: 'animated-crownlight', animated_rune: 'animated-runic', animated_halo: 'animated-halo',
  animated_flame: 'animated-inferno', animated_aurora: 'animated-halo', animated_void: 'animated-void',
  animated_rose: 'animated-rosefall', animated_ice: 'animated-lunar', animated_neon: 'animated-grid',
  animated_solar: 'animated-crownlight', animated_mystic: 'animated-prism', animated_tide: 'animated-thunder', animated_prism: 'animated-prism',
};

const FRAMES = Object.fromEntries(Object.entries(PALETTES).map(([id, [color, secondary]]) => [id, {
  color, secondary, glow: `${color}cc`, animated: id.startsWith('animated-'), ownerOnly: id.startsWith('animated-'),
}]));

function normalizeFrameId(id) { return PALETTES[id] ? id : (LEGACY_FRAME_IDS[id] || 'classic'); }
function compactNumber(value) {
  const amount = Number(value) || 0;
  const abs = Math.abs(amount);
  const trim = (number) => number.toFixed(1).replace(/\.0$/, '');
  if (abs >= 1e12) return `${trim(amount / 1e12)}T`;
  if (abs >= 1e9) return `${trim(amount / 1e9)}B`;
  if (abs >= 1e6) return `${trim(amount / 1e6)}M`;
  if (abs >= 1e3) return `${trim(amount / 1e3)}K`;
  return Math.round(amount).toLocaleString();
}
async function loadImageSafe(url) { try { return url ? await loadImage(url) : null; } catch { return null; } }

function drawCover(ctx, image, size) {
  const ratio = image.width / image.height;
  const drawWidth = ratio > 1 ? size * ratio : size;
  const drawHeight = ratio > 1 ? size : size / ratio;
  ctx.drawImage(image, (size - drawWidth) / 2, (size - drawHeight) / 2, drawWidth, drawHeight);
}
function drawCircularImage(ctx, image, x, y, size) {
  ctx.save(); ctx.beginPath(); ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2); ctx.clip();
  drawCoverInBox(ctx, image, x, y, size); ctx.restore();
}
function drawCoverInBox(ctx, image, x, y, size) {
  const ratio = image.width / image.height;
  const width = ratio > 1 ? size * ratio : size;
  const height = ratio > 1 ? size : size / ratio;
  ctx.drawImage(image, x + (size - width) / 2, y + (size - height) / 2, width, height);
}
function polar(cx, cy, distance, angle) { return [cx + Math.cos(angle) * distance, cy + Math.sin(angle) * distance]; }
function polygon(ctx, cx, cy, radius, sides, rotation = 0) {
  ctx.beginPath();
  for (let i = 0; i < sides; i += 1) {
    const [x, y] = polar(cx, cy, radius, rotation + (Math.PI * 2 * i) / sides);
    if (!i) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.closePath();
}
function drawGem(ctx, x, y, size, primary, secondary) {
  const grad = ctx.createLinearGradient(x - size, y - size, x + size, y + size);
  grad.addColorStop(0, '#fff'); grad.addColorStop(.25, secondary); grad.addColorStop(1, primary);
  ctx.fillStyle = grad; polygon(ctx, x, y, size, 4, Math.PI / 4); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 2; ctx.stroke();
}
function drawLeaf(ctx, x, y, size, angle, primary, secondary) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(angle); ctx.beginPath(); ctx.moveTo(0, -size); ctx.bezierCurveTo(size, -size / 2, size, size / 2, 0, size); ctx.bezierCurveTo(-size, size / 2, -size, -size / 2, 0, -size); ctx.closePath();
  const grad = ctx.createLinearGradient(-size, -size, size, size); grad.addColorStop(0, primary); grad.addColorStop(1, secondary); ctx.fillStyle = grad; ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.restore();
}
function drawGear(ctx, x, y, radius, primary, secondary, rotation = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rotation); ctx.fillStyle = primary; ctx.strokeStyle = secondary; ctx.lineWidth = 3;
  for (let i = 0; i < 10; i += 1) { ctx.save(); ctx.rotate((Math.PI * 2 * i) / 10); ctx.fillRect(radius * .75, -radius * .16, radius * .5, radius * .32); ctx.restore(); }
  ctx.beginPath(); ctx.arc(0, 0, radius, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#0b1020'; ctx.beginPath(); ctx.arc(0, 0, radius * .38, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = secondary; ctx.stroke(); ctx.restore();
}

function drawFrame(ctx, frameId, info, cx, cy, radius, phase = 0) {
  const { color, secondary, glow, animated } = info;
  const outer = radius + 18;
  ctx.save(); ctx.shadowBlur = animated ? 34 : 22; ctx.shadowColor = glow;
  const ring = ctx.createLinearGradient(cx - outer, cy - outer, cx + outer, cy + outer); ring.addColorStop(0, color); ring.addColorStop(.52, '#111827'); ring.addColorStop(1, secondary);
  ctx.beginPath(); ctx.arc(cx, cy, outer, 0, Math.PI * 2); ctx.strokeStyle = ring; ctx.lineWidth = animated ? 12 : 15; ctx.stroke();
  ctx.shadowBlur = 0; ctx.beginPath(); ctx.arc(cx, cy, outer - 12, 0, Math.PI * 2); ctx.strokeStyle = `${secondary}aa`; ctx.lineWidth = 2; ctx.setLineDash([4, 9]); ctx.stroke(); ctx.setLineDash([]);

  const enhanced = ['celestial-crown', 'crystal-geode', 'animated-prism', 'animated-orbit'].includes(frameId);
  const floral = ['rose-thorns', 'thorn-garden', 'moon-lilies', 'animated-rosefall'].includes(frameId);
  const mechanical = ['cyber-mecha', 'clockwork', 'ocean-leviathan', 'animated-grid', 'animated-chains'].includes(frameId);
  const winged = ['seraph-wings', 'sky-feather', 'animated-seraph'].includes(frameId);
  const elemental = ['emberborn', 'frostbound', 'sun-forged', 'tempest-mark', 'animated-inferno', 'animated-thunder', 'animated-comet'].includes(frameId);

  if (enhanced) {
    for (let i = 0; i < 4; i += 1) { const a = phase + i * Math.PI / 2; const [x, y] = polar(cx, cy, outer + 8, a); drawGem(ctx, x, y, i % 2 ? 18 : 28, color, secondary); }
    ctx.strokeStyle = `${secondary}aa`; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cx, cy, outer + 28, phase, phase + Math.PI * 1.3); ctx.stroke();
  } else if (floral) {
    for (let i = 0; i < 8; i += 1) { const a = i * Math.PI / 4 + phase * .15; const [x, y] = polar(cx, cy, outer + 5, a); drawLeaf(ctx, x, y, i % 2 ? 22 : 28, a + Math.PI / 2, color, secondary); }
    ctx.strokeStyle = `${color}cc`; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(cx, cy, outer + 28, .35, Math.PI * 1.1); ctx.stroke();
  } else if (mechanical) {
    for (let i = 0; i < 4; i += 1) { const a = i * Math.PI / 2 + phase * .2; const [x, y] = polar(cx, cy, outer + 18, a); drawGear(ctx, x, y, i % 2 ? 21 : 27, color, secondary, phase * (i % 2 ? -1 : 1)); }
  } else if (winged) {
    for (let side = -1; side <= 1; side += 2) { ctx.save(); ctx.translate(cx, cy); ctx.scale(side, 1); ctx.rotate(phase * .08 * side); ctx.fillStyle = `${color}dd`; ctx.strokeStyle = secondary; ctx.lineWidth = 3; for (let i = 0; i < 4; i += 1) { ctx.beginPath(); ctx.ellipse(outer * .65, -outer * .55 + i * 26, 48, 18, -.6 + i * .12, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); } ctx.restore(); }
  } else if (elemental) {
    for (let i = 0; i < 8; i += 1) { const a = phase * 1.3 + i * Math.PI / 4; const [x, y] = polar(cx, cy, outer + 16, a); ctx.fillStyle = i % 2 ? secondary : color; ctx.beginPath(); ctx.moveTo(x, y - 19); ctx.lineTo(x + 11, y + 12); ctx.lineTo(x - 11, y + 12); ctx.closePath(); ctx.fill(); }
  } else {
    for (let i = 0; i < 6; i += 1) { const a = phase + i * Math.PI / 3; const [x, y] = polar(cx, cy, outer + 13, a); drawGem(ctx, x, y, 11, color, secondary); }
  }

  if (animated) {
    for (let i = 0; i < 10; i += 1) { const a = phase * 1.7 + (i * Math.PI * 2) / 10; const [x, y] = polar(cx, cy, outer + 37, a); ctx.fillStyle = i % 2 ? secondary : color; ctx.globalAlpha = .9; ctx.beginPath(); ctx.arc(x, y, i % 3 ? 4 : 7, 0, Math.PI * 2); ctx.fill(); }
    ctx.globalAlpha = 1;
  }
  ctx.restore();
}

async function resolveMedia(data) {
  const [avatar, background] = await Promise.all([
    loadImageSafe(data.profileImage || data.avatarUrl || DEFAULT_ICON),
    data.videoBackground ? Promise.resolve(null) : loadImageSafe(data.bannerUrl || data.backgroundImage || DEFAULT_BACKGROUND),
  ]);
  return { avatar, background };
}

function drawTextBlock(ctx, data, info, scale) {
  const W = CANVAS_SIZE;
  ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic'; ctx.fillStyle = '#fff'; ctx.font = `bold ${30 * scale}px Sans`;
  ctx.shadowBlur = 8 * scale; ctx.shadowColor = info.glow; ctx.fillText(data.username || 'Unknown', W / 2, 386 * scale); ctx.shadowBlur = 0;
  ctx.fillStyle = '#d8b4fe'; ctx.font = `italic ${16 * scale}px Sans`; ctx.fillText(`${data.role || 'Moon Citizen'}  •  ${data.guildName || 'No Guild'}`, W / 2, 418 * scale);
  ctx.fillStyle = '#e2e8f0'; ctx.font = `${18 * scale}px Sans`; ctx.fillText(`Rank #${data.rank || 0}  •  Level ${data.level || 1}`, W / 2, 454 * scale);
  const barW = 420 * scale; const barH = 20 * scale; const barX = (W - barW) / 2; const barY = 482 * scale; const progress = Math.min((data.xp || 0) / Math.max(data.xpTarget || 100, 1), 1);
  ctx.fillStyle = 'rgba(255,255,255,.15)'; ctx.beginPath(); ctx.roundRect(barX, barY, barW, barH, 10 * scale); ctx.fill();
  if (progress > 0) { const g = ctx.createLinearGradient(barX, barY, barX + barW, barY); g.addColorStop(0, info.color); g.addColorStop(1, info.secondary); ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(barX, barY, barW * progress, barH, 10 * scale); ctx.fill(); }
  ctx.fillStyle = '#fff'; ctx.font = `${12 * scale}px Sans`; ctx.fillText(`${data.xp || 0} / ${data.xpTarget || 100} XP`, W / 2, barY + 14 * scale);
  ctx.textAlign = 'left'; ctx.font = `${14 * scale}px Sans`; ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.fillText(`Bank: $${compactNumber(data.bank)}`, 24 * scale, 32 * scale); ctx.fillText(`Wallet: $${compactNumber(data.wallet ?? data.balance)}`, 24 * scale, 57 * scale);
  ctx.textAlign = 'right'; ctx.fillText(`${data.cardCount || 0} cards`, W - 24 * scale, 32 * scale);
  ctx.strokeStyle = `${info.color}66`; ctx.lineWidth = scale; ctx.beginPath(); ctx.moveTo(54 * scale, 544 * scale); ctx.lineTo(W - 54 * scale, 544 * scale); ctx.stroke();
  ctx.textAlign = 'center'; ctx.font = `${13 * scale}px Sans`; ctx.fillStyle = 'rgba(255,255,255,.7)'; ctx.fillText('MESSAGES', W / 4, 575 * scale); ctx.fillText('BALANCE', W / 2, 575 * scale); ctx.fillText('CARDS', (W * 3) / 4, 575 * scale);
  ctx.fillStyle = info.color; ctx.font = `bold ${17 * scale}px Sans`; ctx.fillText(compactNumber(data.messageCount), W / 4, 603 * scale); ctx.fillText(`$${compactNumber(data.balance)}`, W / 2, 603 * scale); ctx.fillText(String(data.cardCount || 0), (W * 3) / 4, 603 * scale);
  ctx.fillStyle = 'rgba(255,255,255,.48)'; ctx.font = `bold ${14 * scale}px Sans`; ctx.fillText('MOONLIGHT • PROFILE', W / 2, 686 * scale);
}

async function renderFrame(data, phase = 0, media = null, transparent = false) {
  const canvas = createCanvas(CANVAS_SIZE, CANVAS_SIZE); const ctx = canvas.getContext('2d'); const scale = CANVAS_SIZE / 720;
  const assets = media || await resolveMedia(data); const frameId = normalizeFrameId(data.profileFrame); const info = FRAMES[frameId] || FRAMES.classic;
  if (!transparent) {
    if (assets.background) drawCover(ctx, assets.background, CANVAS_SIZE);
    else { const fallback = ctx.createLinearGradient(0, 0, CANVAS_SIZE, CANVAS_SIZE); fallback.addColorStop(0, '#18233e'); fallback.addColorStop(1, '#080a10'); ctx.fillStyle = fallback; ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE); }
    ctx.fillStyle = 'rgba(0,0,0,.54)'; ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
  } else {
    // This translucent layer is preserved in the PNG alpha channel, keeping
    // the imported video clearly visible while maintaining readable text.
    ctx.fillStyle = 'rgba(4, 8, 20, .34)'; ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
  }
  const avatarSize = 230 * scale; const avatarX = (CANVAS_SIZE - avatarSize) / 2; const avatarY = 84 * scale; const cx = avatarX + avatarSize / 2; const cy = avatarY + avatarSize / 2;
  if (assets.avatar) drawCircularImage(ctx, assets.avatar, avatarX, avatarY, avatarSize);
  else { ctx.beginPath(); ctx.arc(cx, cy, avatarSize / 2, 0, Math.PI * 2); ctx.fillStyle = '#1e1b4b'; ctx.fill(); ctx.fillStyle = '#fff'; ctx.font = `bold ${66 * scale}px Sans`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText((data.username || '?')[0].toUpperCase(), cx, cy); }
  drawFrame(ctx, frameId, info, cx, cy, avatarSize / 2, phase); drawTextBlock(ctx, data, info, scale);
  return canvas.toBuffer('image/png');
}

async function generateProfileImage(data) { return renderFrame(data); }
async function generateAnimatedProfileFrames(data, frameCount = ANIMATION_FRAME_COUNT) {
  const media = await resolveMedia(data); const frames = [];
  for (let i = 0; i < frameCount; i += 1) frames.push(await renderFrame(data, (i / frameCount) * Math.PI * 2, media, Boolean(data.videoBackground)));
  return frames;
}

async function cacheVideoBackground(source, directory) {
  if (typeof source !== 'string' || !/^https?:\/\//i.test(source)) throw new Error('Video background must use an http(s) URL.');
  const extension = (new URL(source).pathname.match(/\.(mp4|webm|mov|mkv|gif)$/i) || [])[1] || 'mp4';
  const output = path.join(directory, `video-background.${extension}`);
  const response = await axios.get(source, {
    responseType: 'arraybuffer', timeout: 12000, maxRedirects: 5,
    maxContentLength: 30 * 1024 * 1024, maxBodyLength: 30 * 1024 * 1024,
    headers: { 'User-Agent': 'Moonlight-Haven-Profile-Renderer/1.0' },
  });
  const data = Buffer.from(response.data);
  if (data.length < 1024) throw new Error('Video background download was empty.');
  await fs.promises.writeFile(output, data);
  return output;
}

async function encodeProfileAnimation({ directory, framePattern, output, backgroundInput = null }) {
  const frameInput = ['-stream_loop', '-1', '-framerate', String(ANIMATION_FPS), '-i', framePattern];
  const args = backgroundInput
    ? ['-y', '-stream_loop', '-1', '-i', backgroundInput, ...frameInput, '-t', String(ANIMATION_DURATION_SECONDS), '-filter_complex', `[0:v]fps=${ANIMATION_FPS},scale=${CANVAS_SIZE}:${CANVAS_SIZE}:force_original_aspect_ratio=increase,crop=${CANVAS_SIZE}:${CANVAS_SIZE},setsar=1[bg];[1:v]fps=${ANIMATION_FPS},format=rgba[fg];[bg][fg]overlay=0:0:shortest=1,format=yuv420p[v]`, '-map', '[v]']
    : ['-y', ...frameInput, '-t', String(ANIMATION_DURATION_SECONDS), '-vf', `fps=${ANIMATION_FPS},format=yuv420p`];
  args.push('-an', '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '25', '-profile:v', 'baseline', '-movflags', 'faststart', output);
  await execFileAsync(ffmpegPath, args, { maxBuffer: 1024 * 1024 * 6, timeout: 25000 });
}

async function generateAnimatedProfileVideo(data) {
  const directory = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'moon-profile-'));
  const useVideoBackground = Boolean(data.videoBackground);
  try {
    const frames = await generateAnimatedProfileFrames(data, ANIMATION_FRAME_COUNT);
    for (let i = 0; i < frames.length; i += 1) await fs.promises.writeFile(path.join(directory, `frame-${String(i).padStart(2, '0')}.png`), frames[i]);
    const output = path.join(directory, 'profile-gif-playback.mp4'); const pattern = path.join(directory, 'frame-%02d.png');
    const backgroundInput = useVideoBackground ? await cacheVideoBackground(data.videoBackground, directory) : null;
    await encodeProfileAnimation({ directory, framePattern: pattern, output, backgroundInput });
    return await fs.promises.readFile(output);
  } catch (error) {
    console.error('PROFILE ANIMATION ENCODE ERROR:', error?.message || error);
    if (useVideoBackground) {
      // Keep the profile animated if a remote background fails, but never hide
      // that failure behind an all-static pseudo-animation.
      const staticData = { ...data, videoBackground: null };
      const frames = await generateAnimatedProfileFrames(staticData, ANIMATION_FRAME_COUNT);
      for (let i = 0; i < frames.length; i += 1) await fs.promises.writeFile(path.join(directory, `fallback-${String(i).padStart(2, '0')}.png`), frames[i]);
      const output = path.join(directory, 'profile-fallback.mp4');
      await encodeProfileAnimation({ directory, framePattern: path.join(directory, 'fallback-%02d.png'), output });
      return fs.promises.readFile(output);
    }
    throw error;
  } finally { await fs.promises.rm(directory, { recursive: true, force: true }); }
}

module.exports = { generateProfileImage, generateAnimatedProfileFrames, generateAnimatedProfileVideo, FRAMES, normalizeFrameId, DEFAULT_ICON, DEFAULT_BACKGROUND, compactNumber };
