const User = require('../../models/User');
const config = require('../../config');

function staffMention(user) {
  const jid = user.whatsappNumber || `${user.userId}@s.whatsapp.net`;
  return { jid, text: `么⁩ @${user.userId}` };
}

moon({
  name: 'mods',
  category: 'general',
  description: 'Show the Moonlight Haven support team',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const staff = await User.find({ role: { $in: ['Owner', 'True Owner', 'Mod', 'Guardian'] } });
      const mods = staff.filter((user) => user.role === 'Mod');
      const guards = staff.filter((user) => user.role === 'Guardian');
      const mentions = [];
      const render = (users, empty) => users.length ? users.map((user) => {
        const entry = staffMention(user);
        mentions.push(entry.jid);
        return entry.text;
      }).join('\n') : empty;

      const caption = `       [ *SUPPORT TEAM* ]
❖─── 𝚳OO𝚴𝐋𝚰𝐆𝚮𝚻

 [么⁩]──[ *MODS* ]──┈ ⳹
${render(mods, '么⁩ None')}
[么⁩]──[ *GUARDS* ]─┈ ⳹
${render(guards, '么⁩ None')}
 [么⁩]─────────┈ ⳹
> *INFO:* our team will be with you in a short moment. Tell us your error while replying to this message if support does not come in *5 minutes*.
Try reading our \.rules`;

      if (config.MENU_IMAGE) {
        return sock.sendMessage(jid, { image: { url: config.MENU_IMAGE }, caption, mentions }, { quoted: m });
      }
      return sock.sendMessage(jid, { text: caption, mentions }, { quoted: m });
    } catch (err) {
      console.error('mods error:', err);
      return reply('❌ Failed to load the support team list.');
    }
  },
});

module.exports = { staffMention };
