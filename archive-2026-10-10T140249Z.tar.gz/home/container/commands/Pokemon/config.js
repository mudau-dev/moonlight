const SpawnControl = require("../../models/athers/SpawnControl");
const axios = require('axios');
const { fetchPokemonData } = require("../../utils/pokemonUtils");
const { resolveMessageTarget } = require('../../utils/adminIdentity');
const WILD_POOL = ['pikachu', 'charmander', 'bulbasaur', 'squirtle', 'eevee', 'gengar', 'snorlax', 'lucario', 'gible', 'riolu', 'mudkip', 'torchic', 'treecko'];

moon({
    name: "pspawn",
    category: "Pokémon",
    roles: ["Owner", "True Owner"],
    description: "Manage wild Pokémon spawns",
    async execute(sock, jid, sender, args, m, { reply }) {
        const sub = (args[0] || "").toLowerCase();
        let spawn = await SpawnControl.findOne({ groupId: jid });
        if (!spawn) spawn = new SpawnControl({ groupId: jid });

        if (sub === "on") {
            spawn.enabled = true;
            await spawn.save();
            return reply("✅ Wild Pokémon spawns enabled in this group!");
        }

        if (sub === "off") {
            spawn.enabled = false;
            spawn.active = false;
            await spawn.save();
            return reply("✅ Wild Pokémon spawns disabled in this group!");
        }

        if (sub === "force" || sub === "drop") {
            const name = args.slice(1).join(" ").trim() || WILD_POOL[Math.floor(Math.random() * WILD_POOL.length)];
            
            try {
                const data = await fetchPokemonData(name);
                const level = Math.floor(Math.random() * 30) + 5;
                
                spawn.active = true;
                spawn.pokemon = data.name;
                spawn.level = level;
                spawn.spawnedAt = new Date();
                spawn.lastSpawn = new Date();
                await spawn.save();

                const sent = await sock.sendMessage(jid, {
                    image: { url: data.sprite }, 
                    caption: `🌿 *A WILD POKÉMON APPEARED!* 🌿\n━━━━━━━━━━━━━━━━━━━━\n🐾 *${data.name.toUpperCase()}*\n📊 *Level:* ${level}\n🔥 *Type:* ${[data.type1, data.type2].filter(Boolean).join(' / ').toUpperCase()}\n━━━━━━━━━━━━━━━━━━━━\nCatch it fast before it flees to the woods.\n> \.catch — to try and fight it\n> \.catch web/wb — to enter a web battle\n\nIt will *flee in 5 minutes* if not caught.`
                }, { quoted: m });
                setTimeout(async () => {
                    const current = await SpawnControl.findOne({ groupId: jid });
                    if (!current?.active || current.pokemon !== data.name) return;
                    current.active = false;
                    current.pokemon = null;
                    await current.save();
                    await sock.sendMessage(jid, { text: `${data.name.toUpperCase()} was not claimed and fled away to the woods.` }, sent?.key ? { quoted: sent } : undefined);
                }, 5 * 60 * 1000);
                return sent;
            } catch (e) {
                return reply(`❌ Error spawning Pokémon: ${e.message}`);
            }
        }

        return reply("📌 Usage:\n.pspawn on/off\n.pspawn force [pokemon]\n.pspawn drop [pokemon]");
    }
});

moon({
    name: "gpoke",
    category: "Pokémon",
    roles: ["Owner", "True Owner"],
    description: "Give a Pokémon to a user",
    async execute(sock, jid, sender, args, m, { reply }) {
        const target = await resolveMessageTarget(sock, m, args);
        const context = m.message?.extendedTextMessage?.contextInfo || {};
        const mentioned = context.mentionedJid?.[0] || null;
        const quotedParticipant = context.participant || context.participantAlt || null;
        const targetTokens = new Set([mentioned, quotedParticipant, target].filter(Boolean).map(String));
        const pokemonArgs = (args || []).filter((value) => {
            const token = String(value || '').trim();
            if (!token || token.startsWith('@') || targetTokens.has(token)) return false;
            return !/^\d{7,}(?:@s\.whatsapp\.net)?$/i.test(token);
        });
        const pokemonName = pokemonArgs.join(' ').trim();

        if (!target || !pokemonName) return reply('❌ Usage: .gpoke <@user> <pokemon> (or reply to a user)');

        const Pokemon = require('../../models/pokemon');
        const { fetchPokemonData, generateIVs, calculateStat } = require('../../utils/pokemonUtils');

        try {
            const data = await fetchPokemonData(pokemonName);
            if (!data?.name || !data?.type1 || !data?.stats) throw new Error('Incomplete Pokémon data');
            const api = await axios.get(`https://pokeapi.co/api/v2/pokemon/${encodeURIComponent(data.name)}`, { timeout: 15000 });
            const movePool = [...new Set((api.data?.moves || []).map((entry) => entry?.move?.name).filter(Boolean))];
            const fallbackMoves = Array.isArray(data.moves) ? data.moves.map((move) => String(move).trim()).filter(Boolean) : [];
            const availableMoves = [...new Set([...movePool, ...fallbackMoves])];
            if (!availableMoves.length) throw new Error('No moves available for this Pokémon');
            const moves = availableMoves.sort(() => Math.random() - 0.5).slice(0, Math.min(5, availableMoves.length)).map((move) => move.replace(/-/g, ' '));
            const ivs = generateIVs();
            const level = 50;
            const hp = calculateStat(data.stats.hp, ivs.hp, 0, level, true);
            const uniqueId = `GIVE-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;

            await Pokemon.create({
                pokemonId: uniqueId,
                userId: target,
                pokedexNumber: Number(data.pokedexNumber),
                name: String(data.name).toLowerCase(),
                level,
                xp: 0,
                type1: data.type1,
                type2: data.type2 || null,
                hp,
                attack: calculateStat(data.stats.attack, ivs.attack, 0, level),
                defense: calculateStat(data.stats.defense, ivs.defense, 0, level),
                spAtk: calculateStat(data.stats.spAtk, ivs.spAtk, 0, level),
                spDef: calculateStat(data.stats.spDef, ivs.spDef, 0, level),
                speed: calculateStat(data.stats.speed, ivs.speed, 0, level),
                iv: ivs,
                moves,
                partyPosition: null,
                location: 'pc',
                status: 'Healthy',
                caughtLocation: 'Owner grant',
            });

            return reply(`✅ Gave *${String(data.name).toLowerCase()}* with *${moves.length} random skills* to @${target.split('@')[0]}!`, { mentions: [target] });
        } catch (error) {
            console.error('[GPOKE ERROR]', { message: error.message, target, pokemonName });
            return reply(`❌ Could not give *${pokemonName}*. Check the Pokémon name and try again.`);
        }
    }
});
