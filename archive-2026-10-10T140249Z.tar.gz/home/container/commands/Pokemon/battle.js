const Pokemon = require('../../models/pokemon');
const SpawnControl = require('../../models/athers/SpawnControl');
const User = require('../../models/User');
const { Battle, battles } = require('../../utils/battleEngine');

// ── Battle lock: one active Pokémon battle per group ────────────────────────────
// groupJid → { sender, timer }
const pokeBattleLocks = new Map();
const POKE_TIMEOUT_MS = 5 * 60 * 1000;

function clearPokeTimer(groupJid) {
  const entry = pokeBattleLocks.get(groupJid);
  if (entry?.timer) clearTimeout(entry.timer);
}

function setPokeTimer(sock, jid, originalMsg, groupJid, sender) {
  clearPokeTimer(groupJid);
  const t = setTimeout(async () => {
    const battle = battles.get(sender);
    if (battle) {
      battle.status = 'finished';
      removeBattle(battle);
    }
    pokeBattleLocks.delete(groupJid);
    try {
      await sock.sendMessage(jid, {
        text: 'No move was made in the last 5 minutes. This battle has ended.',
      }, { quoted: originalMsg });
    } catch {}
  }, POKE_TIMEOUT_MS);
  pokeBattleLocks.set(groupJid, { sender, timer: t });
}

function releasePokelock(groupJid) {
  clearPokeTimer(groupJid);
  pokeBattleLocks.delete(groupJid);
}
const { generateBattleImage } = require('../../utils/battleGenerator');
const { fetchPokemonData, fetchPokemonSpecies, generateIVs, rollGender, calculateStat, getMoveData, calculateDamage, normalizeMoveName, normalizeMoveList, readableMoveName } = require('../../utils/pokemonUtils');
const { listPokemon, getCurrentHp } = require('../../utils/pokemonStorage');
const { getPokeBall, getCatchMultiplier, inventoryId } = require('../../utils/pokeBalls');
const { generateOutcomeImage } = require('../../utils/outcomeGenerator');
const { createWildBattle, battleUrl } = require('../../utils/webBattle');

async function cancelWebBattles(identity) {
  const base = String(process.env.WEB || 'https://haven.nett.to').replace(/\/$/, '');
  const token = String(process.env.WEB_BATTLE_BOT_TOKEN || '').trim();
  if (!token) return 0;
  try {
    const response = await fetch(`${base}/api/battles/cancel`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-moon-bot-token': token }, body: JSON.stringify({ userId: String(identity).split('@')[0] }) });
    if (!response.ok) return 0;
    return Number((await response.json()).cancelled || 0);
  } catch { return 0; }
}

function getBattleForUser(sender) {
  const direct = battles.get(sender);
  if (direct?.status === 'active') return direct;
  for (const battle of battles.values()) {
    if (battle.status === 'active' && battle.players.includes(sender)) return battle;
  }
  return null;
}

function getPlayerIndex(battle, sender) {
  return battle.players[0] === sender ? 0 : battle.players[1] === sender ? 1 : -1;
}

function toBattlePokemon(document, data) {
  const iv = document.iv || {};
  const ev = document.ev || {};
  const level = document.level || 1;

  // Use proper calculated stats — this is the fix for trainer dealing only 1 damage.
  // calculateStat returns the full base stat when IVs/EVs are provided.
  const maxHp = calculateStat(data.stats.hp, iv.hp || 0, ev.hp || 0, level, true);
  // Recalculate all battle stats from the Pokémon's base stats, level, IVs, and EVs.
  // Stored values can be absent or stale on Pokémon created before the stat fields existed.
  const attack = calculateStat(data.stats.attack, iv.attack || 0, ev.attack || 0, level);
  const defense = calculateStat(data.stats.defense, iv.defense || 0, ev.defense || 0, level);
  const spAtk = calculateStat(data.stats.spAtk, iv.spAtk || 0, ev.spAtk || 0, level);
  const spDef = calculateStat(data.stats.spDef, iv.spDef || 0, ev.spDef || 0, level);
  const speed = calculateStat(data.stats.speed, iv.speed || 0, ev.speed || 0, level);

  // Use stored moves if available, otherwise fall back to API moves.
  // This fixes the 'no moves found' bug where battle couldn't find moves
  // because document.moves was empty but data.moves had them.
  const storedMoves = normalizeMoveList(document.moves).length
    ? normalizeMoveList(document.moves)
    : (normalizeMoveList(data.moves).length ? normalizeMoveList(data.moves) : ['tackle']);

  return {
    ...document.toObject(),
    sprite: data.sprite,
    // Ensure all combat stats are populated from the Pokémon's actual values
    attack,
    defense,
    spAtk,
    spDef,
    speed,
    maxHp,
    hp: Number.isFinite(Number(document.hp))
      ? Math.min(maxHp, Math.max(0, Number(document.hp)))
      : maxHp,
    energy: 100,
    // Always ensure moves is populated
    moves: storedMoves,
  };
}

function battleBox(lines) {
  return ['■━━━━━□━━━━━■', ...lines, '■━━━━━□━━━━━■'].join('\n');
}

function trainerLabel(jid, fallback) {
  return jid === 'wild' ? 'Wild Pokémon' : `@${String(jid || fallback || '').split('@')[0]}`;
}

function formatPendingBattleMove(battle, playerIndex, move, damage) {
  const pokemon = battle.activePokemon[playerIndex];
  const opponent = battle.players[1 - playerIndex];
  return battleBox([
    `*${pokemon.name}* used *${readableMoveName(move)}* and dealt *${damage} damage*`,
    `> waiting for ${opponent === 'wild' ? 'the wild Pokémon' : `@${String(opponent).split('@')[0]}`} to make a move`,
  ]);
}

function formatBattleTurn(battle) {
  const details = [...(battle.lastTurn || [])].sort((a, b) => a.index - b.index);
  const lines = ['□─────────[ BATTLE ]─────────□', ''];
  for (const detail of details) {
    lines.push(`*${detail.attacker}* used *${detail.move}* and damaged *${detail.defender}* by *${detail.damage}*.`, '━━━━━');
  }
  if (!details.length) lines.push('No direct damage was dealt this turn.', '━━━━━');
  lines.push('');
  const playerIndexes = battle.type === 'pvp' ? [0, 1] : [0];
  for (const index of playerIndexes) {
    const pokemon = battle.activePokemon[index];
    if (!pokemon) continue;
    lines.push(`*Trainer:* ${trainerLabel(battle.players[index], 'Trainer')}`, `*Pokémon:* *${pokemon.name}*`, `*Health:* ${Math.max(0, Math.round(battle.hp[index]))}/${Math.max(1, Math.round(pokemon.maxHp || battle.hp[index] || 1))} HP`, '');
  }
  lines.push('■━━━━━□━━━━━■');
  if (battle.status === 'active') lines.push('> waiting for users next moves...');
  return lines.join('\n');
}

async function renderBattle(sock, jid, message, battle, lastAction, logImage = false) {
  for (const pokemon of battle.activePokemon) {
    if (!pokemon.sprite) {
      try {
        pokemon.sprite = (await fetchPokemonData(pokemon.name)).sprite;
      } catch (error) {
        console.warn('[BATTLE SPRITE]', error.message);
      }
    }
  }

  battle.activePokemon[0].hp = battle.hp[0];
  battle.activePokemon[1].hp = battle.hp[1];
  battle.activePokemon[0].energy = battle.energy[0];
  battle.activePokemon[1].energy = battle.energy[1];

  try {
    const image = await generateBattleImage({
      player: battle.activePokemon[0],
      opponent: battle.activePokemon[1],
      lastAction,
      weather: battle.weather,
      logImage,
      droppedItem: battle.droppedItem,
      thrownBall: battle.thrownBall,
    });
    return sock.sendMessage(jid, { image, caption: lastAction }, { quoted: message });
  } catch (error) {
    console.error('[BATTLE IMAGE]', error.message);
    return sock.sendMessage(jid, { text: lastAction }, { quoted: message });
  }
}

async function persistBattleLog(battle, text) {
  if (battle.type !== 'pvp' || !text) return;
  const entry = { turn: Number(battle.turn || 1), text: String(text), createdAt: new Date() };
  const ids = [...new Set((battle.players || []).filter((player) => player && player !== 'wild'))];
  await User.updateMany(
    { $or: ids.flatMap((id) => [{ whatsappNumber: id }, { phoneNumber: id }, { userId: id }]) },
    { $push: { lastPokemonBattleLogs: { $each: [entry], $slice: -20 } } },
  );
}

async function persistBattleHp(battle) {
  const updates = battle.activePokemon
    .filter((pokemon, index) => battle.players[index] && battle.players[index] !== 'wild' && pokemon?.pokemonId)
    .map((pokemon, index) => {
      const newHp = Math.max(0, Math.round(battle.hp[index]));
      // Keep HP and status consistent in every persisted battle result.
      // This prevents a recovered Pokémon from retaining a stale Fainted flag.
      const update = { $set: { hp: newHp, status: newHp <= 0 ? 'Fainted' : 'Healthy' } };
      return Pokemon.updateOne({ pokemonId: pokemon.pokemonId }, update);
    });
  await Promise.all(updates);
}

function removeBattle(battle) {
  battle.players.filter(Boolean).forEach((player) => battles.delete(player));
  // Release group battle lock
  if (battle.groupId) releasePokelock(battle.groupId);
}

async function captureWildPokemon(sender, battle, ball) {
  const spawn = await SpawnControl.findOne({ groupId: battle.groupId });
  if (!spawn?.active || !spawn.pokemon) return { success: false, message: '❌ The wild Pokémon is no longer available.' };

  const data = await fetchPokemonData(spawn.pokemon);
  let species = { captureRate: null, genderRate: -1 };
  try {
    species = await fetchPokemonSpecies(spawn.pokemon);
  } catch (error) {
    console.warn('[CATCH SPECIES]', error.message);
  }

  const ivs = generateIVs();
  const maxHp = calculateStat(data.stats.hp, ivs.hp, 0, spawn.level, true);
  const caughtPokemon = await Pokemon.create({
    pokemonId: `PKMN-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    userId: sender,
    pokedexNumber: data.pokedexNumber,
    name: data.name,
    level: spawn.level,
    type1: data.type1,
    type2: data.type2 || null,
    hp: ball.healOnCatch ? maxHp : Math.max(1, Math.round(maxHp * 0.65)),
    attack: calculateStat(data.stats.attack, ivs.attack, 0, spawn.level),
    defense: calculateStat(data.stats.defense, ivs.defense, 0, spawn.level),
    spAtk: calculateStat(data.stats.spAtk, ivs.spAtk, 0, spawn.level),
    spDef: calculateStat(data.stats.spDef, ivs.spDef, 0, spawn.level),
    speed: calculateStat(data.stats.speed, ivs.speed, 0, spawn.level),
    iv: ivs,
    moves: data.moves,
    captureRate: species.captureRate,
    gender: rollGender(species.genderRate),
    happiness: ball.happinessOnCatch || 0,
    location: 'pc',
  });

  spawn.active = false;
  await spawn.save();
  battle.status = 'finished';
  battle.winnerIndex = 0;
  battle.finishedReason = 'captured';
  removeBattle(battle);

  return {
    success: true,
    pokemon: caughtPokemon,
    message: `🎉 *CAUGHT!*\n\n${ball.emoji} ${ball.name} caught *${data.name.toUpperCase()}*!\nIt was sent to your PC. Use \`.pc\` to view it and \`.t2party <index>\` to move it into your party.`,
  };
}

async function throwPokeBall(sender, battle, ballName) {
  if (battle.type !== 'wild') return '❌ Poké Balls can only be used in wild battles.';
  const ball = getPokeBall(ballName);
  if (!ball) return '❌ Unknown Poké Ball. Usage: `.pb pokeball <ball>`';

  const { owner } = await listPokemon(sender);
  const inventoryIndex = owner.user.inventory.findIndex((item) => item.id === inventoryId(ball));
  if (inventoryIndex < 0) return `❌ You do not own a ${ball.name}. Visit the shop to buy one.`;

  owner.user.inventory.splice(inventoryIndex, 1);
  await owner.user.save();

  const wildPokemon = battle.activePokemon[1];
  const hpRatio = Math.max(0, Math.min(1, battle.hp[1] / Math.max(1, wildPokemon.maxHp)));
  const multiplier = getCatchMultiplier(ball, wildPokemon, battle.turn);
  const baseChance = 0.18 + (1 - hpRatio) * 0.58;
  const caught = Number.isFinite(multiplier) ? Math.random() < Math.min(0.95, baseChance * multiplier) : true;

  if (!caught) {
    return `${ball.emoji} *${ball.name}* shook and broke free!\n> Lower the wild Pokémon's HP before trying again.`;
  }

  const captured = await captureWildPokemon(sender, battle, ball);
  return captured.message;
}

moon({
  name: 'catch',
  category: 'Pokémon',
  description: 'Start a battle with the wild Pokémon in this group.',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const spawn = await SpawnControl.findOne({ groupId: jid });
      if (!spawn?.active || !spawn.pokemon) return reply('❌ No wild Pokémon has spawned here.');
      if (getBattleForUser(sender)) return reply('❌ You are already in an active Pokémon battle.');
      // Battle lock: one active Pokémon battle per group
      if (pokeBattleLocks.has(jid)) {
        return reply(`Hold on @${sender.split('@')[0]}, there is already an active battle in this group.`, { mentions: [sender] });
      }

      const { pokemons } = await listPokemon(sender, 'party', 6);
      const active = pokemons.find((pokemon) => getCurrentHp(pokemon) > 0);
      if (!active) return reply('❌ You need a healthy Pokémon in your party to battle. Use `.party` or `.t2party <pc_index>`.');

      const [playerData, wildData] = await Promise.all([
        fetchPokemonData(active.name),
        fetchPokemonData(spawn.pokemon),
      ]);
      const webRequested = ['web', 'wb'].includes(String(args[0] || '').toLowerCase());
      if (webRequested) {
        const wildLevel = Math.max(Number(spawn.level || 1), Number(active.level || 1) + 2);
        const wildMaxHp = Math.floor(calculateStat(wildData.stats.hp, 20, 0, wildLevel, true) * 1.35);
        const webBattle = await createWildBattle({
          creatorId: sender.split('@')[0],
          groupJid: jid,
          playerPokemon: active,
          wildPokemon: { ...wildData, level: wildLevel, hp: wildMaxHp, maxHp: wildMaxHp, moves: wildData.moves || ['tackle'] },
        });
        spawn.active = false;
        await spawn.save();
        return reply(`🌐 *WEB WILD BATTLE READY*\n\n@${sender.split('@')[0]} entered a web battle against *${spawn.pokemon.toUpperCase()}* (Lv.${wildLevel}).\n\n🔗 ${battleUrl('wild', webBattle.code)}\n\nOpen the link to battle live.`, { mentions: [sender] });
      }
      const player = toBattlePokemon(active, playerData);
      const wildMaxHp = Math.floor(calculateStat(wildData.stats.hp, 20, 0, Math.max(spawn.level, (player.level || 1) + 2), true) * 1.35);
      const wild = {
        ...wildData,
        level: Math.max(spawn.level, (player.level || 1) + 2),
        maxHp: wildMaxHp,
        hp: wildMaxHp,
        energy: 100,
      };

      const battle = new Battle(player, wild);
      battle.damageScale = 0.72;
      battle.minimumTurns = 0;
      battle.activePokemon = [player, wild];
      battle.players = [sender, 'wild'];
      battle.type = 'wild';
      battle.groupId = jid;
      await battle.start();
      battles.set(sender, battle);
      setPokeTimer(sock, jid, m, jid, sender);

      const caption = [
        '⚔️ *WILD BATTLE*',
        '',
        `A wild *${spawn.pokemon.toUpperCase()}* appeared at Lv.${spawn.level}!`,
        'Use `.pb <move>` to attack.',
        'Use `.pb pokeball <ball>` to throw a Poké Ball.',
        'Use `.pb switch <party_index>` to swap your active Pokémon.',
        'Use `.pb run` to leave the encounter.',
      ].join('\n');
      return renderBattle(sock, jid, m, battle, caption);
    } catch (error) {
      console.error('[CATCH]', error);
      return reply('❌ Failed to start the battle. Please try again.');
    }
  },
});

moon({
  name: 'pb',
  aliases: ['battle'],
  category: 'Pokémon',
  description: 'Use a move, throw a Poké Ball, switch Pokémon, or leave an active battle.',
  usage: '.pb <move> | .pb pokeball <ball> | .pb switch <index> | .pb run',
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      const battle = getBattleForUser(sender);
      if (!battle) return reply('❌ You are not in a battle. Use `.catch` to start a wild encounter.');
      const playerIndex = getPlayerIndex(battle, sender);
      if (playerIndex < 0) return reply('❌ You are not a player in this battle.');

      const rentalExpiry = battle.activePokemon[playerIndex]?.rentalExpiresAt;
      if (rentalExpiry && new Date(rentalExpiry).getTime() <= Date.now()) {
        battle.status = 'finished';
        battle.finishedReason = 'rental_expired';
        removeBattle(battle);
        return reply('⌛ Your rental Pokémon has been returned because its 30-minute rental period ended.');
      }

      const subcommand = String(args[0] || '').toLowerCase();

      // ── Run / flee ──────────────────────────────────────────────────────
      if (['run', 'leave', 'flee'].includes(subcommand)) {
        battle.status = 'finished';
        battle.finishedReason = 'left';
        removeBattle(battle);
        const webCancelled = await cancelWebBattles(sender.split('@')[0]);
        return reply(`🏃 You safely left the battle${webCancelled ? ` and cleared ${webCancelled} stale web battle${webCancelled === 1 ? '' : 's'}` : ''}. The wild Pokémon is still available for another trainer.`);
      }

      // ── Throw a Poké Ball ───────────────────────────────────────────────
      if (['pokeball', 'ball'].includes(subcommand)) {
        const result = await throwPokeBall(sender, battle, args.slice(1).join(' '));
        await sock.sendMessage(jid, { react: { text: '✅', key: m.key } }).catch(() => {});
        if (battle.status === 'finished') {
          battle.thrownBall = { caught: true, color: '#ef4444', side: 'right' };
          await renderBattle(sock, jid, m, battle, `🔃 Battle log made.\n${result}`);
          return undefined;
        }
        battle.thrownBall = { caught: false, color: '#ef4444', side: 'right' };
        await renderBattle(sock, jid, m, battle, `🔃 Battle log made.\n${result}`);
        battle.thrownBall = null;
        return undefined;
      }

      // ── Switch active Pokémon ───────────────────────────────────────────
      if (subcommand === 'switch') {
        const switchIndex = Number.parseInt(args[1], 10);
        if (!Number.isInteger(switchIndex) || switchIndex < 1 || switchIndex > 6) {
          return reply('❌ Usage: `.pb switch <party_index>` (1–6)');
        }

        const { pokemons } = await listPokemon(sender, 'party', 6);
        const target = pokemons[switchIndex - 1];
        if (!target) return reply(`❌ No Pokémon in party slot ${switchIndex}.`);
        if (getCurrentHp(target) <= 0) return reply(`❌ *${(target.nickname || target.name).toUpperCase()}* has fainted and cannot battle.`);

        const currentActive = battle.activePokemon[playerIndex];
        if (target.pokemonId === currentActive?.pokemonId) {
          return reply(`❌ *${(target.nickname || target.name).toUpperCase()}* is already your active Pokémon.`);
        }

        // Persist current HP back to the outgoing Pokémon
        if (currentActive?.pokemonId) {
          await Pokemon.updateOne(
            { pokemonId: currentActive.pokemonId },
            { $set: { hp: Math.max(0, Math.round(battle.hp[playerIndex])) } }
          );
        }

        // Load fresh data for the incoming Pokémon
        const incomingData = await fetchPokemonData(target.name);
        const incoming = toBattlePokemon(target, incomingData);
        // Restore the Pokémon's current HP (not max)
        incoming.hp = Math.max(0, Number(target.hp) || incoming.maxHp);

        battle.activePokemon[playerIndex] = incoming;
        battle.hp[playerIndex] = incoming.hp;
        battle.energy[playerIndex] = 100;

        const switchMsg = `🔄 *${(currentActive?.name || '???').toUpperCase()}*, come back!\nGo, *${incoming.name.toUpperCase()}*!`;
        return renderBattle(sock, jid, m, battle, switchMsg);
      }

      // ── Use a move ──────────────────────────────────────────────────────
      const moveInput = args.join(' ').trim();
      if (!moveInput) {
        return reply('❌ Usage: `.pb <move or index>`\n> You can also use `.pb pokeball <ball>`, `.pb switch <index>`, or `.pb run`.');
      }

      const activePokemon = battle.activePokemon[playerIndex];
      const learnedMoves = normalizeMoveList(activePokemon?.moves);
      const requestedIndex = /^\d+$/.test(moveInput) ? Number.parseInt(moveInput, 10) : null;
      let selectedMove = requestedIndex ? learnedMoves[requestedIndex - 1] : learnedMoves.find((move) => normalizeMoveName(move) === normalizeMoveName(moveInput));
      if (!selectedMove) {
        const fallback = learnedMoves[0] || 'tackle';
        return reply(`□------------------------------□\nYou try using the skill of number ${requestedIndex || moveInput}\n> But that move was not found. Your Pokémon still knows *${readableMoveName(fallback).toLowerCase()}*.\n□------------------------------□`);
      }

      const selectedMoveData = await getMoveData(selectedMove);
      if (!selectedMoveData) {
        return reply(`❌ I could not verify \`${readableMoveName(selectedMove)}\` right now. Please try again shortly.`);
      }

      if (battle.type === 'wild') {
        const wildMoves = normalizeMoveList(battle.activePokemon[1]?.moves).length
          ? normalizeMoveList(battle.activePokemon[1].moves)
          : ['tackle'];
        battle.moves[0] = selectedMove;
        battle.moves[1] = wildMoves[Math.floor(Math.random() * wildMoves.length)] || 'tackle';
      } else {
        battle.moves[playerIndex] = selectedMove;
        if (battle.moves[0] === null || battle.moves[1] === null) {
          const scale = Number(battle.damageScale) > 0 ? Number(battle.damageScale) : 1;
          const preview = calculateDamage(activePokemon, battle.activePokemon[1 - playerIndex], selectedMoveData);
          const estimatedDamage = Math.max(0, Math.floor((Number(preview.total) || 0) * scale));
          const waitingText = formatPendingBattleMove(battle, playerIndex, selectedMove, estimatedDamage);
          const opponent = battle.players[1 - playerIndex];
          return opponent !== 'wild' ? reply(waitingText, { mentions: [opponent] }) : reply(waitingText);
        }
      }

      const results = await battle.resolveTurn();
      await persistBattleHp(battle);
      await sock.sendMessage(jid, { react: { text: '✅', key: m.key } }).catch(() => {});
      battle.thrownBall = null;
      const turnText = battle.type === 'pvp'
        ? formatBattleTurn(battle)
        : battleBox([`*${activePokemon.name}* used *${readableMoveName(selectedMove)}* and dealt *${battle.lastTurn?.find((detail) => detail.index === playerIndex)?.damage || 0}* damage.`, `> loading your battle logs`]);
      if (battle.type === 'pvp') {
        await persistBattleLog(battle, turnText);
        await renderBattle(sock, jid, m, battle, turnText, true);
      } else {
        await sock.sendMessage(jid, { text: turnText }, { quoted: m });
      }

      if (battle.status !== 'finished') return undefined;

      const winnerId = battle.players[battle.winnerIndex];
      if (battle.type === 'wild' && winnerId === sender) {
        try {
          const image = await generateOutcomeImage({ pokemon: battle.activePokemon[playerIndex], opponent: battle.activePokemon[1 - playerIndex], won: true });
          await sock.sendMessage(jid, { image, caption: `🏆 *${battle.activePokemon[playerIndex].name} WON THE BATTLE!*` }, { quoted: m });
        } catch (error) { console.warn('[PB VICTORY IMAGE]', error.message); }
        const captured = await captureWildPokemon(sender, battle, {
          name: 'Battle Capture',
          emoji: '⚪',
          healOnCatch: false,
        });
        return reply(captured.message);
      }

      if (battle.type === 'pvp') {
        const loserId = battle.players[1 - battle.winnerIndex];
        try {
          const winnerImage = await generateOutcomeImage({ pokemon: battle.activePokemon[battle.winnerIndex], opponent: battle.activePokemon[1 - battle.winnerIndex], won: true });
          const loserImage = await generateOutcomeImage({ pokemon: battle.activePokemon[1 - battle.winnerIndex], opponent: battle.activePokemon[battle.winnerIndex], won: false });
          await sock.sendMessage(jid, { image: winnerImage, caption: `🏆 *${battle.activePokemon[battle.winnerIndex].name} WON THE BATTLE!*` }, { quoted: m });
          await sock.sendMessage(jid, { image: loserImage, caption: `💀 *${battle.activePokemon[1 - battle.winnerIndex].name} WAS DEFEATED!*` }, { quoted: m });
        } catch (error) { console.warn('[PB OUTCOME IMAGES]', error.message); }
        removeBattle(battle);
        return sock.sendMessage(jid, {
          text: `🏆 *DUEL OVER!*\n\n🥇 Winner: @${winnerId.split('@')[0]}\n💀 Loser: @${loserId.split('@')[0]}`,
          mentions: [winnerId, loserId],
        }, { quoted: m });
      }

      try {
        const image = await generateOutcomeImage({ pokemon: battle.activePokemon[playerIndex], opponent: battle.activePokemon[1 - playerIndex], won: false });
        await sock.sendMessage(jid, { image, caption: `💀 *${battle.activePokemon[playerIndex].name} WAS DEFEATED!*` }, { quoted: m });
      } catch (error) { console.warn('[PB DEFEAT IMAGE]', error.message); }
      removeBattle(battle);
      return reply('💤 Your Pokémon fainted. Heal your party before battling again.');
    } catch (error) {
      console.error('[PB]', error);
      return reply('❌ Battle error. Please try again.');
    }
  },
});

moon({
  name: 'm',
  category: 'Pokémon',
  description: 'Pick up or use a dropped battle item.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const battle = getBattleForUser(sender);
    if (!battle) return reply('❌ You are not in a battle.');
    const playerIndex = getPlayerIndex(battle, sender);
    const subcommand = String(args[0] || '').toLowerCase();

    if (['c', 'catch'].includes(subcommand)) return reply(battle.catchItem(playerIndex));
    if (subcommand === 'use') {
      const result = battle.useItem(playerIndex);
      await persistBattleHp(battle);
      return reply(result);
    }
    return reply('❌ Usage: `.m catch` to pick up an item or `.m use` to use one.');
  },
});
