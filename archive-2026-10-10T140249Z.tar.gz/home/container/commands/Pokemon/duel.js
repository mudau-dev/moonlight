const { Battle, battles } = require('../../utils/battleEngine');
const { generateBattleImage } = require('../../utils/battleGenerator');
const { fetchPokemonData, calculateStat, normalizeMoveList } = require('../../utils/pokemonUtils');
const { listPokemon, getCurrentHp } = require('../../utils/pokemonStorage');
const { createPvpBattle, battleUrl } = require('../../utils/webBattle');
const { sameIdentity, resolvePhoneJid, resolveMessageTarget } = require('../../utils/adminIdentity');
const webPduelCooldowns = new Map();
const WEB_PDUEL_COOLDOWN_MS = 60 * 60 * 1000;

const pendingDuels = new Map();

async function cancelWebBattles(identity) {
  const base = String(process.env.WEB || 'https://haven.nett.to').replace(/\/$/, '');
  const token = String(process.env.WEB_BATTLE_BOT_TOKEN || '').trim();
  if (!token) return 0;
  try {
    const response = await fetch(`${base}/api/battles/cancel`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-moon-bot-token': token },
      body: JSON.stringify({ userId: String(identity).split('@')[0] }),
    });
    if (!response.ok) return 0;
    const payload = await response.json().catch(() => ({}));
    return Number(payload.cancelled || 0);
  } catch (error) {
    console.warn('[PDUEL WEB CANCEL]', error.message);
    return 0;
  }
}

function cancelLocalBattles(identity) {
  const cancelled = new Set();
  for (const [key, battle] of battles.entries()) {
    if (battle?.status === 'active' && (battle.players || []).some((player) => sameIdentity(player, identity))) {
      battle.status = 'finished';
      battle.finishedReason = 'user_cancelled';
      (battle.players || []).filter(Boolean).forEach((player) => { battles.delete(player); cancelled.add(player); });
    }
  }
  return cancelled.size;
}

function toBattlePokemon(document, data) {
  const iv = document.iv || {};
  const ev = document.ev || {};
  const maxHp = calculateStat(data.stats.hp, iv.hp || 0, ev.hp || 0, document.level, true);
  return {
    ...document.toObject(),
    sprite: data.sprite,
    maxHp,
    hp: Math.min(maxHp, Math.max(0, Number(document.hp) || maxHp)),
    energy: 100,
    moves: normalizeMoveList(document.moves).length ? normalizeMoveList(document.moves) : normalizeMoveList(data.moves),
  };
}

async function getActivePartyPokemon(sender) {
  const { pokemons } = await listPokemon(sender, 'party', 6);
  return pokemons.find((pokemon) => getCurrentHp(pokemon) > 0) || null;
}

async function renderDuel(sock, jid, message, battle, caption, mentions) {
  try {
    const image = await generateBattleImage({
      player: battle.activePokemon[0],
      opponent: battle.activePokemon[1],
      lastAction: caption,
      weather: battle.weather,
    });
    return sock.sendMessage(jid, { image, caption, mentions }, { quoted: message });
  } catch (error) {
    console.error('[DUEL IMAGE]', error.message);
    return sock.sendMessage(jid, { text: caption, mentions }, { quoted: message });
  }
}

moon({
  name: 'pduel',
  aliases: ['pd', 'bd'],
  category: 'Pokémon',
  description: 'Challenge another trainer to a Pokémon duel.',
  usage: '.pduel/.pd/.bd @user | .bd web @user | .pduel accept | .pduel decline | .pduel run',
  async execute(sock, jid, sender, args, m, { reply }) {
    const subcommand = String(args[0] || '').toLowerCase();
    const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const repliedTarget = !['yes', 'accept', 'no', 'decline', 'run', 'leave', 'cancel'].includes(subcommand)
      ? await resolveMessageTarget(sock, m, args).catch(() => null)
      : null;
    const normalizedSender = await resolvePhoneJid(sock, sender) || sender;
    const challengeTarget = mentioned || repliedTarget;
    const normalizedMentioned = challengeTarget ? (await resolvePhoneJid(sock, challengeTarget) || challengeTarget) : null;
    const webRequested = ['web', 'wb'].includes(subcommand) || String(args[args.length - 1] || '').toLowerCase() === 'web';
    if (webRequested && !['yes', 'accept', 'no', 'decline'].includes(subcommand)) {
      const target = normalizedMentioned;
      if (!target) return reply('❌ Tag a user to create a web Pokémon duel. Use `.pduel wb @user` or `.pduel @user web`.');
      if (sameIdentity(target, normalizedSender)) return reply('❌ You cannot challenge yourself.');
      const last = webPduelCooldowns.get(sender) || 0;
      if (Date.now() - last < WEB_PDUEL_COOLDOWN_MS) return reply('⏳ Your web PvP duel is on cooldown for one hour.');
      const [challengerPokemon, opponentPokemon] = await Promise.all([getActivePartyPokemon(sender), getActivePartyPokemon(target)]);
      if (!challengerPokemon) return reply('❌ You need a healthy Pokémon in your party to duel.');
      if (!opponentPokemon) return reply('❌ That trainer has no healthy Pokémon ready for a web duel.');
      const webBattle = await createPvpBattle({         creatorId: normalizedSender.split('@')[0], opponentId: target.split('@')[0], groupJid: jid, playerPokemon: challengerPokemon, opponentPokemon });
      webPduelCooldowns.set(sender, Date.now());
      return reply(`🌐 *WEB PVP DUEL READY*\n\n@${sender.split('@')[0]} challenged @${target.split('@')[0]} to an animated Pokémon duel.\n\n🔗 ${battleUrl('pvp', webBattle.code)}\n\nOpen the link to use moves, switch Pokémon, and battle live.`, { mentions: [sender, target] });
    }

    if (['run', 'leave', 'cancel'].includes(subcommand)) {
      const localCancelled = cancelLocalBattles(sender);
      const webCancelled = await cancelWebBattles(sender.split('@')[0]);
      pendingDuels.delete(jid);
      if (!localCancelled && !webCancelled) return reply('❌ You do not have an active bot or web battle.');
      return reply(`🏃 Battle ended. Cleared ${localCancelled + webCancelled} active battle${localCancelled + webCancelled === 1 ? '' : 's'}. You can duel again.`);
    }

    if (['yes', 'accept'].includes(subcommand)) {
      const duel = pendingDuels.get(jid);
      if (!duel) return reply('❌ No pending duel request exists in this chat.');
      const acceptingSender = await resolvePhoneJid(sock, m.key?.participant || m.key?.remoteJidAlt || sender) || normalizedSender;
      if (!sameIdentity(duel.opponent, acceptingSender)) return reply('❌ This duel request is not for you.');
      if (Date.now() > duel.expiresAt) {
        pendingDuels.delete(jid);
        return reply('❌ The duel request expired.');
      }

      const [challengerPokemon, opponentPokemon] = await Promise.all([
        getActivePartyPokemon(duel.challenger),
        getActivePartyPokemon(duel.opponent),
      ]);
      if (!challengerPokemon) {
        pendingDuels.delete(jid);
        return reply('❌ The challenger has no healthy Pokémon in their party.');
      }
      if (!opponentPokemon) return reply('❌ You have no healthy Pokémon in your party. Use `.party` or `.t2party <pc_index>`.');

      const [challengerData, opponentData] = await Promise.all([
        fetchPokemonData(challengerPokemon.name),
        fetchPokemonData(opponentPokemon.name),
      ]);
      const first = toBattlePokemon(challengerPokemon, challengerData);
      const second = toBattlePokemon(opponentPokemon, opponentData);

      const battle = new Battle(first, second);
      battle.activePokemon = [first, second];
      battle.players = [duel.challenger, duel.opponent];
      battle.type = 'pvp';
      await battle.start();
      battles.set(duel.challenger, battle);
      battles.set(duel.opponent, battle);
      pendingDuels.delete(jid);

      const caption = [
        '⚔️ *POKÉMON DUEL*',
        '',
        `@${duel.challenger.split('@')[0]} vs @${duel.opponent.split('@')[0]}`,
        `🌙 Weather: ${battle.weather}`,
        '',
        'Both trainers must use `.pb <move>` each turn.',
        'Use `.pmoves` to view your active Pokémon moves.',
      ].join('\n');
      return renderDuel(sock, jid, m, battle, caption, [duel.challenger, duel.opponent]);
    }

    if (['no', 'decline'].includes(subcommand)) {
      const duel = pendingDuels.get(jid);
      const decliningSender = await resolvePhoneJid(sock, m.key?.participant || m.key?.remoteJidAlt || sender) || normalizedSender;
      if (!duel || !sameIdentity(duel.opponent, decliningSender)) return reply('❌ You have no pending duel request to decline.');
      pendingDuels.delete(jid);
      return reply(`❌ @${sender.split('@')[0]} declined the duel.`, { mentions: [sender] });
    }

    const target = normalizedMentioned;
    if (!target) return reply('❌ Tag a user or reply to their message to challenge them. Usage: `.pduel @user` or reply with `.pduel`.');
    if (sameIdentity(target, normalizedSender)) return reply('❌ You cannot challenge yourself.');
    if (battles.get(normalizedSender) || battles.get(target)) return reply('❌ One of those trainers is already in an active battle.');

    const challengerPokemon = await getActivePartyPokemon(sender);
    if (!challengerPokemon) return reply('❌ You need a healthy Pokémon in your party to duel. Use `.party` or `.t2party <pc_index>`.');

    pendingDuels.set(jid, {
      challenger: normalizedSender,
      opponent: target,
      expiresAt: Date.now() + 2 * 60 * 1000,
    });

    return sock.sendMessage(jid, {
      text: `⚔️ *DUEL REQUEST*\n\n@${sender.split('@')[0]} challenged @${target.split('@')[0]} to a Pokémon duel.\n\nType \`.pduel accept\` to accept or \`.pduel decline\` to decline.\n> This request expires in two minutes.`,
      mentions: [sender, target],
    }, { quoted: m });
  },
});

moon({
  name: 'pmoves',
  category: 'Pokémon',
  description: 'List moves for your active party Pokémon.',
  async execute(sock, jid, sender, args, m, { reply }) {
    const pokemon = await getActivePartyPokemon(sender);
    if (!pokemon) return reply('❌ You have no healthy Pokémon in your party.');
    const moves = Array.isArray(pokemon.moves) ? pokemon.moves : [];
    if (!moves.length) return reply('❌ This Pokémon has no moves.');

    const lines = [
      `📜 *${String(pokemon.nickname || pokemon.name).toLowerCase()} — moves*`,
      '',
      ...moves.map((move, index) => `${index + 1}. *${String(move).replace(/-/g, ' ').toLowerCase()}*`),
      '',
      '> Use `.pb <index>` to attack during a battle.',
    ];
    return reply(lines.join('\n'));
  },
});
