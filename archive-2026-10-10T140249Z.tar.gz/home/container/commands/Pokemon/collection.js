const { listPokemon, getPokemonByIndex, getCurrentHp, getMaxHp, formatPokemonDetails } = require('../../utils/pokemonStorage');
const { fetchPokemonData, fetchPokemonSpecies, rollGender } = require('../../utils/pokemonUtils');
const { generatePartyImage } = require('../../utils/partyGenerator');

async function enrichDetailMetadata(pokemon) {
  if (pokemon.captureRate != null && pokemon.gender && pokemon.gender !== 'Unknown') return pokemon;

  try {
    const species = await fetchPokemonSpecies(pokemon.name);
    let changed = false;
    if (pokemon.captureRate == null && species.captureRate != null) {
      pokemon.captureRate = species.captureRate;
      changed = true;
    }
    if (!pokemon.gender || pokemon.gender === 'Unknown') {
      pokemon.gender = rollGender(species.genderRate);
      changed = true;
    }
    if (changed) await pokemon.save();
  } catch (error) {
    console.warn('[POKEMON METADATA]', error.message);
  }

  return pokemon;
}

function partyOverviewText(party, trainerName) {
  const lines = [
    `🌙 *@${trainerName} — CURRENT ACTIVE PARTY*`,
    '━━━━━━━━━━━━━━━━━━━━',
  ];

  for (let index = 0; index < 6; index += 1) {
    const pokemon = party[index];
    if (!pokemon) {
      lines.push(`*${index + 1}.* — Empty slot`);
      continue;
    }

    const isFainted = pokemon.status === 'Fainted' || getCurrentHp(pokemon) <= 0;
    if (isFainted) {
      lines.push(
        `*${index + 1}.* *${String(pokemon.nickname || pokemon.name).toLowerCase()}*`,
        `   ❌ *Pokémon Unavailable*`,
        `   _This Pokémon cannot be used until it recovers._`,
        ''
      );
    } else {
      lines.push(
        `*${index + 1}.* *${String(pokemon.nickname || pokemon.name).toLowerCase()}*`,
        `   *HP:* ${getCurrentHp(pokemon)}/${getMaxHp(pokemon)}`,
        `   *GENDER:* ${pokemon.gender || 'Unknown'}`,
        `   *LEVEL:* ${pokemon.level ?? 1}`,
        ''
      );
    }
  }

  lines.push('> Use `.party <index>` to view one Pokémon in full detail.');
  return lines.join('\n');
}

function pcOverview(pokemons, trainerName) {
  const lines = [
    `💻 *@${trainerName} — CURRENT PC*`,
    '━━━━━━━━━━━━━━━━━━━━',
  ];

  if (!pokemons.length) {
    lines.push('Your PC is empty.');
  } else {
    pokemons.forEach((pokemon, index) => {
      lines.push(`${index + 1}. *${String(pokemon.nickname || pokemon.name).toLowerCase()}*`);
    });
  }

  lines.push('', '> Use `.pc <index>` to view a Pokémon with its artwork and full details.');
  lines.push('> Use `.t2party <index>` to move it into your active party.');
  return lines.join('\n');
}

moon({
  name: 'party',
  category: 'Pokémon',
  description: 'View your active party or detailed stats for a party slot.',
  usage: '.party [index]',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    const selectedIndex = Number.parseInt(args[0], 10);

    if (args[0] && (!Number.isInteger(selectedIndex) || selectedIndex < 1)) {
      return reply('❌ Usage: `.party` or `.party <party_index>`');
    }

    // ── Featured Pokémon detail view ──────────────────────────────────────
    if (selectedIndex) {
      const entry = await getPokemonByIndex(sender, 'party', selectedIndex);
      if (!entry) return reply('❌ No Pokémon exists at that party index.');

      const pokemon = await enrichDetailMetadata(entry.pokemon);
      const caption = formatPokemonDetails(pokemon, {
        title: `PARTY SLOT ${selectedIndex}: ${String(pokemon.nickname || pokemon.name).toLowerCase()}`,
      });

      try {
        const image = await generatePartyImage({
          pokemons: [pokemon],
          trainerName: pushName || 'Trainer',
          featuredIndex: 1,
        });
        return sock.sendMessage(jid, { image, caption }, { quoted: m });
      } catch (imageError) {
        console.warn('[PARTY FEATURED IMAGE]', imageError.message);
        return reply(caption);
      }
    }

    // ── Full party image view ─────────────────────────────────────────────
    const { pokemons } = await listPokemon(sender, 'party', 6);
    if (!pokemons.length) {
      return reply('❌ Your party is empty. Use `.t2party <pc_index>` to add a Pokémon from your PC.');
    }

    // Enrich metadata for all party members
    await Promise.all(pokemons.map((pokemon) => enrichDetailMetadata(pokemon)));

    // Try to generate the party image card
    try {
      const imageBuffer = await generatePartyImage({
        pokemons,
        trainerName: pushName || 'Trainer',
      });
      const caption = partyOverviewText(pokemons, pushName || 'Trainer');
      return sock.sendMessage(jid, { image: imageBuffer, caption }, { quoted: m });
    } catch (imgErr) {
      console.warn('[PARTY IMAGE]', imgErr.message);
      // Fallback to text if image generation fails
      return reply(partyOverviewText(pokemons, pushName || 'Trainer'));
    }
  },
});

moon({
  name: 'pc',
  category: 'Pokémon',
  description: 'View your PC or detailed stats for a stored Pokémon.',
  usage: '.pc [index]',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    const infoMode = String(args[0] || '').toLowerCase() === 'info';
    const selectedIndex = Number.parseInt(infoMode ? args[1] : args[0], 10);

    if ((args[0] && !Number.isInteger(selectedIndex)) || (Number.isInteger(selectedIndex) && selectedIndex < 1)) {
      return reply('❌ Usage: `.pc`, `.pc <pc_index>`, or `.pc info <pc_index>`');
    }

    if (infoMode && selectedIndex) {
      const entry = await getPokemonByIndex(sender, 'pc', selectedIndex);
      if (!entry) return reply('❌ No Pokémon exists at that PC index.');
      const pokemon = await enrichDetailMetadata(entry.pokemon);
      const moves = Array.isArray(pokemon.moves) ? pokemon.moves : [];
      return reply(`□------------------------------□\n*Name:* ${String(pokemon.nickname || pokemon.name).toLowerCase()}\n*Gender:* ${String(pokemon.gender || 'unknown').toLowerCase()}\n*Id:* ${pokemon.pokemonId}\n\n*□- pokemon description:- □*\n> ${String(pokemon.caughtLocation || 'pc storage').toLowerCase()}\n\n*□- pokemon moves: -□*\n*Current moves:* ${moves.length ? moves.map((move) => String(move).toLowerCase()).join(', ') : 'none'}\n*Can learn moves:* use \.plearn ${selectedIndex} p 1\n*Total moves:* ${moves.length}\n\n*Owners:* ${pokemon.userId}\n□------------------------------□`);
    }

    if (selectedIndex) {
      const entry = await getPokemonByIndex(sender, 'pc', selectedIndex);
      if (!entry) return reply('❌ No Pokémon exists at that PC index.');

      const pokemon = await enrichDetailMetadata(entry.pokemon);
      let sprite;
      try {
        sprite = (await fetchPokemonData(pokemon.name)).sprite;
      } catch (error) {
        console.warn('[PC DETAIL SPRITE]', error.message);
      }

      const caption = formatPokemonDetails(pokemon, {
        title: `PC SLOT ${selectedIndex}: ${String(pokemon.nickname || pokemon.name).toLowerCase()}`,
      });
      if (sprite) {
        return sock.sendMessage(jid, { image: { url: sprite }, caption }, { quoted: m });
      }
      return reply(caption);
    }

    const { pokemons } = await listPokemon(sender, 'pc');
    return reply(pcOverview(pokemons, pushName || 'Trainer'));
  },
});

moon({
  name: 'pokem',
  aliases: ['pkm', 'pokemóns', 'pokemons', 'pkinfo', 'pokeinfo'],
  category: 'Pokémon',
  description: 'Look up a Pokémon by name and see its full info with image.',
  usage: '.pokem <name>',
  async execute(sock, jid, sender, args, m, { reply, pushName }) {
    // If no args, show trainer profile
    if (!args.length) {
      const { pokemons } = await listPokemon(sender);
      const party = pokemons.filter((pokemon) => pokemon.location === 'party').slice(0, 6);
      const shinies = pokemons.filter((pokemon) => pokemon.isShiny).length;
      const ownedNames = [...new Set(pokemons.map((p) => p.name))];
      return reply([
        `🌙 *${(pushName || 'Trainer').toUpperCase()} — POKÉMON TRAINER PROFILE*`,
        '━━━━━━━━━━━━━━━━━━━━',
        `*Total Pokémon:* ${pokemons.length}`,
        `*Active Party:* ${party.length}/6`,
        `*Shiny Pokémon:* ${shinies}`,
        '',
        '> Use `.party` to view your active team and `.pc` to view stored Pokémon.',
        '> Use `.pokem <name>` to look up any Pokémon.',
      ].join('\n'));
    }

    // Look up a specific Pokémon by name
    const pokemonName = args.join(' ');
    try {
      const data = await fetchPokemonData(pokemonName);

      // Count how many the user owns
      const { pokemons } = await listPokemon(sender);
      const owned = pokemons.filter((p) => p.name.toLowerCase() === data.name.toLowerCase());
      const partySlots = owned.filter((p) => p.location === 'party').map((p) => p.partyPosition).filter(Boolean);
      const pcSlots = owned.filter((p) => p.location === 'pc').length;

      const types = [data.type1, data.type2].filter(Boolean)
        .map((t) => t.charAt(0).toUpperCase() + t.slice(1))
        .join(', ');

      // Fetch abilities from API
      let abilities = 'Unknown';
      try {
        const { data: rawData } = await require('axios').get(
          `https://pokeapi.co/api/v2/pokemon/${data.name}`, { timeout: 8000 }
        );
        abilities = rawData.abilities
          .map((a) => a.ability.name.replace(/-/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase()))
          .join(', ');
      } catch { /* ignore */ }

      const caption = [
        `*Name:* ${data.name.charAt(0).toUpperCase() + data.name.slice(1)}`,
        `*Pokédex ID:* ${data.pokedexNumber}`,
        `*Types:* ${types}`,
        `*Abilities:* ${abilities}`,
        '',
        `*Owned:* ${owned.length}`,
        `*Party slots:* ${partySlots.length ? partySlots.join(', ') : 'None'}`,
        `*PC slots:* ${pcSlots || 'None'}`,
      ].join('\n');

      if (data.sprite) {
        return sock.sendMessage(jid, { image: { url: data.sprite }, caption }, { quoted: m });
      }
      return reply(caption);
    } catch (err) {
      console.error('[POKEMON CMD]', err.message);
      return reply(`❌ Could not find Pokémon *${pokemonName}*. Check the spelling and try again.`);
    }
  },
});

moon({
  name: 'poke',
  category: 'Pokémon',
  description: 'View a Pokémon you own by its unique ID.',
  usage: '.poke <pokemon_id>',
  async execute(sock, jid, sender, args, m, { reply }) {
    const pokemonId = args[0];
    if (!pokemonId) return reply('❌ Usage: `.poke <pokemon_id>`');

    const { owner, pokemons } = await listPokemon(sender);
    const pokemon = pokemons.find((entry) => entry.pokemonId === pokemonId);
    if (!pokemon) return reply('❌ Pokémon not found in your collection.');

    await enrichDetailMetadata(pokemon);
    let sprite;
    try {
      sprite = (await fetchPokemonData(pokemon.name)).sprite;
    } catch (error) {
      console.warn('[POKE DETAIL SPRITE]', error.message);
    }

    const caption = formatPokemonDetails(pokemon);
    if (sprite) return sock.sendMessage(jid, { image: { url: sprite }, caption }, { quoted: m });
    return reply(caption);
  },
});
