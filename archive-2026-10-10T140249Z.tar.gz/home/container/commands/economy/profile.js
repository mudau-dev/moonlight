const User = require('../../models/User');
const Guild = require('../../models/athers/Guild');
const moment = require('moment-timezone');
const { generateProfileImage, generateAnimatedProfileVideo, FRAMES, normalizeFrameId, DEFAULT_ICON } = require('../../utils/profileGenerator');
const { findOrCreateWhatsApp } = require('../../database/users');
const { getRealUserIdentity } = require('../../utils/whatsappIdentity');

function calcLevelXP(messageCount) {
  const count = Number(messageCount) || 0;
  const level = Math.floor(count / 50) + 1;
  const xp = count % 50;
  const xpTarget = 50;
  return { level, xp, xpTarget };
}

async function getUserGuild(user) {
  try {
    if (!user) return null;
    const identities = [...new Set([
      user.phoneNumber,
      user.whatsappNumber?.split('@')[0],
      user.userId,
      user.moonId,
    ].filter(Boolean))];
    return await Guild.findOne({ members: { $in: identities } });
  } catch {
    return null;
  }
}

moon({
  name: "p",
  category: "economy",
  aliases: ["profile", "pf"],
  description: "Show user profile card",
  async execute(sock, jid, sender, args, m, { reply }) {
    try {
      await sock.sendMessage(jid, { react: { text: "👤", key: m.key } });
      const contextInfo = m?.message?.extendedTextMessage?.contextInfo || {};
      const rawTarget = contextInfo?.mentionedJid?.[0] || contextInfo?.participant || sender;
      const identity = await getRealUserIdentity(sock, rawTarget);
      if (!identity) return reply('❌ That WhatsApp LID could not be resolved to a real phone number. No profile lookup was performed.');
      const target = identity.phoneJid;
      const id = identity.phoneNumber;
      
      const WEB = process.env.WEB || '';
      const userDoc = await findOrCreateWhatsApp(target);
      const user = userDoc ? (userDoc.toObject ? userDoc.toObject() : userDoc) : null;
      
      const isRegistered = user && user.moonId && !user.moonId.startsWith("moon_");
      
      const wallet = isRegistered ? Number(user.balance ?? 0) : 0;
      const bank   = isRegistered ? Number(user.bank   ?? 0) : 0;
      
      const displayRole = !isRegistered ? 'Unregistered' : (user?.isTrueOwner === true ? 'True Owner' : (user.role || 'User'));
      
      const guild = isRegistered ? await getUserGuild(user) : null;
      const guildName = guild ? guild.name : "N/A";
      const rank = isRegistered ? (await User.countDocuments({ balance: { $gt: user.balance } }) + 1) : 0;
      const { level, xp, xpTarget } = calcLevelXP(user?.messageCount || 0);
      
      // Fetch WhatsApp profile picture; fall back to stored avatar, then DEFAULT_ICON
      let profileImage = null;
      try {
        profileImage = await sock.profilePictureUrl(target, 'image');
      } catch {}

      const savedFrameId = isRegistered ? (user.profileFrame || 'classic') : 'classic';
      const frameId = normalizeFrameId(savedFrameId);
      const canUseAnimatedFrame = ['True Owner', 'Owner', 'Mod'].includes(displayRole) || user?.isTrueOwner === true;
      const requestedFrame = FRAMES[frameId] || FRAMES.classic;
      const frameInfo = requestedFrame.animated && !canUseAnimatedFrame ? FRAMES.classic : requestedFrame;

      const profileData = {
        username: isRegistered ? (user.username || id) : "N/A",
        bank: isRegistered ? bank : 0,
        wallet: isRegistered ? wallet : 0,
        balance: isRegistered ? wallet : 0,
        bio: isRegistered ? (user.bio && user.bio !== "." ? user.bio : "N/A") : "N/A",
        rank: isRegistered ? rank : 0,
        level: isRegistered ? level : 0,
        xp: isRegistered ? xp : 0,
        xpTarget: isRegistered ? xpTarget : 100,
        role: displayRole,
        // Use WhatsApp pic → stored avatar → DEFAULT_ICON (for unregistered or no avatar)
        profileImage: profileImage || (isRegistered ? user.avatarUrl : null) || DEFAULT_ICON,
        bannerUrl: isRegistered ? (user.bannerUrl || user.backgroundImage) : null,
        videoBackground: isRegistered ? user.videoBackground : null,
        profileFrame: frameId,
        cardCount: isRegistered ? (user.cards ? user.cards.length : 0) : 0,
        messageCount: isRegistered ? (user.messageCount || 0) : 0,
      };

      // A selected video background or animated frame is delivered as a 10-second
      // MP4 in WhatsApp GIF playback mode. It contains five complete loops.
      const shouldSendAnimatedGif = frameInfo.animated || Boolean(profileData.videoBackground);
      const mediaBuffer = shouldSendAnimatedGif
        ? await generateAnimatedProfileVideo(profileData)
        : await generateProfileImage(profileData);
      
      let caption = `╭━━━[ 👤 *ℙℝ𝕆𝔽𝕀𝕃𝔼* ]━━━
┃ *Name:* ${profileData.username}
┃ *Age:* ${isRegistered && user?.age ? user.age : 'N/A'}
┃ *Role:* *${displayRole}*
┃ *Level:* ${profileData.level}
┃ *Guild:* ${guildName}
┃ *bio:* ${profileData.bio}

━━[ *INFO* ]━━━
么⁩ *level:* ${profileData.level}
么⁩ *Register:* ${user?.createdAt ? moment(user.createdAt).format('DD/MM/YYYY') : "Unknown"}
╰━━━━━━━━━━━━━━━┈\n`;

      if (!isRegistered) {
        caption += `🚫 User not registered in Moonlight Haven`;
      } else {
        caption += `*Profile:* ${WEB}/user/${user.moonId}`;
      }

      if (shouldSendAnimatedGif) {
        // Baileys/WhatsApp GIF playback autoplays the MP4 inline. The encoder
        // keeps the card at 720 × 720 and repeats its two-second cycle five times.
        await sock.sendMessage(jid, {
          video: mediaBuffer,
          mimetype: 'video/mp4',
          gifPlayback: true,
          caption,
          mentions: [target],
          ptv: false,
        }, { quoted: m });
      } else {
        await sock.sendMessage(jid, { image: mediaBuffer, caption, mentions: [target] }, { quoted: m });
      }
    } catch (err) {
      console.error("PROFILE ERROR:", err);
      return reply("❌ Error loading profile.");
    }
  }
});
