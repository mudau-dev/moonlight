/**
 * handler/PokemonSpawn.js
 *
 * Automatic Pokémon spawning system.
 * Uses the same message-count trigger pattern as CardsSystem.js.
 *
 * When a Pokémon is not caught within the allowed time, the bot replies
 * to the original spawn message: "<Pokémon Name> was not claimed and fled away to the woods."
 */

const SpawnControl = require('../models/athers/SpawnControl');
const Group = require('../models/athers/Group');
const { fetchPokemonData, calculateStat, generateIVs } = require('../utils/pokemonUtils');

// ── Config ────────────────────────────────────────────────────────────────────
const SPAWN_COOLDOWN_MS = 30 * 60 * 1000;   // 30 minutes between auto-spawns
const MIN_MESSAGES = 80;                      // messages needed to trigger a spawn
const SPAWN_EXPIRE_MS = 5 * 60 * 1000;       // 5 minutes to catch before fleeing

// ── Wild Pokémon pool ─────────────────────────────────────────────────────────
const WILD_POOL = [
  'pikachu', 'charmander', 'bulbasaur', 'squirtle', 'eevee',
  'gengar', 'snorlax', 'jigglypuff', 'meowth', 'psyduck',
  'growlithe', 'ponyta', 'magikarp', 'gyarados', 'lapras',
  'vaporeon', 'jolteon', 'flareon', 'espeon', 'umbreon',
  'togepi', 'marill', 'snubbull', 'heracross', 'houndour',
  'larvitar', 'mudkip', 'torchic', 'treecko', 'ralts',
  'absol', 'bagon', 'beldum', 'turtwig', 'chimchar',
  'piplup', 'shinx', 'riolu', 'gible', 'lucario',
];

// Track active spawn expiry timers: groupJid → { timer, messageKey }
const spawnTimers = new Map();

/**
 * Called from the main message handler on every group message.
 * Triggers a Pokémon spawn when conditions are met.
 */
async function spawnPokemon(sock, jid) {
  try {
    if (!jid.endsWith('@g.us')) return;

    let group = await Group.findOne({ groupId: jid });
    if (!group) group = await Group.create({ groupId: jid });

    // `.pms poke on/off` is the canonical group switch; legacy SpawnControl remains supported.
    let spawnCtrl = await SpawnControl.findOne({ groupId: jid });
    const pokemonEnabled = group.pokemonSpawnEnabled === true || (group.pokemonSpawnEnabled == null && spawnCtrl?.enabled === true);
    if (!spawnCtrl) spawnCtrl = await SpawnControl.create({ groupId: jid, enabled: pokemonEnabled });
    if (!pokemonEnabled) return;
    if (Number(group.pokemonSpawnSkip || 0) > 0) {
      group.pokemonSpawnSkip = Math.max(0, Number(group.pokemonSpawnSkip) - 1);
      await group.save();
      return;
    }

    // Don't spawn if one is already active
    if (spawnCtrl.active) return;

    const now = Date.now();
    const lastSpawn = spawnCtrl.lastSpawn ? spawnCtrl.lastSpawn.getTime() : 0;
    if (now - lastSpawn < SPAWN_COOLDOWN_MS) return;
    if ((group.totalMessages || 0) < MIN_MESSAGES) return;

    // Pick a random Pokémon
    const pokemonName = WILD_POOL[Math.floor(Math.random() * WILD_POOL.length)];
    const level = Math.floor(Math.random() * 20) + 5; // levels 5–25

    let pokemonData;
    try {
      pokemonData = await fetchPokemonData(pokemonName);
    } catch (err) {
      console.error('[POKEMON SPAWN] Failed to fetch data:', err.message);
      return;
    }

    // Mark as active
    spawnCtrl.active = true;
    spawnCtrl.pokemon = pokemonData.name;
    spawnCtrl.level = level;
    spawnCtrl.spawnedAt = new Date();
    spawnCtrl.lastSpawn = new Date();
    await spawnCtrl.save();

    // Reset message counter
    group.totalMessages = 0;
    await group.save();

    const types = [pokemonData.type1, pokemonData.type2].filter(Boolean).join(' / ').toUpperCase();
    const caption =
      `🌿 *A WILD POKÉMON APPEARED!*\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `🐾 *${pokemonData.name.toUpperCase()}*\n` +
      `📊 *Level:* ${level}\n` +
      `🔥 *Type:* ${types}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `Catch it fast before it flees to the woods.\n` +
      `> \.catch — to try and fight it\n` +
      `> \.catch web/wb — to enter a web battle\n\n` +
      `It will *flee in 5 minutes* if not caught.`;

    let sentMsg = null;
    try {
      if (pokemonData.sprite) {
        sentMsg = await sock.sendMessage(jid, { image: { url: pokemonData.sprite }, caption });
      } else {
        sentMsg = await sock.sendMessage(jid, { text: caption });
      }
    } catch (sendErr) {
      console.error('[POKEMON SPAWN SEND ERROR]', sendErr.message);
      spawnCtrl.active = false;
      await spawnCtrl.save();
      return;
    }

    // Set expiry timer
    if (spawnTimers.has(jid)) {
      clearTimeout(spawnTimers.get(jid).timer);
    }
    const timer = setTimeout(async () => {
      try {
        const ctrl = await SpawnControl.findOne({ groupId: jid });
        if (!ctrl?.active) return; // Already caught

        ctrl.active = false;
        ctrl.pokemon = null;
        await ctrl.save();
        group.pokemonMisses = Number(group.pokemonMisses || 0) + 1;
        if (group.pokemonMisses >= 2) {
          group.pokemonMisses = 0;
          group.pokemonSpawnSkip = 2;
        }
        await group.save();
        spawnTimers.delete(jid);

        // Reply to original spawn message
        const fleeText = `${pokemonData.name.toUpperCase()} was not claimed and fled away to the woods.${Number(group.pokemonSpawnSkip || 0) > 0 ? ` The next ${group.pokemonSpawnSkip} Pokémon spawns will be skipped.` : ''}`;
        if (sentMsg?.key) {
          await sock.sendMessage(jid, { text: fleeText }, { quoted: sentMsg });
        } else {
          await sock.sendMessage(jid, { text: fleeText });
        }
      } catch (expErr) {
        console.error('[POKEMON SPAWN EXPIRE ERROR]', expErr.message);
      }
    }, SPAWN_EXPIRE_MS);

    spawnTimers.set(jid, { timer, messageKey: sentMsg?.key });

  } catch (err) {
    console.error('[POKEMON SPAWN ERROR]', err.message);
  }
}

module.exports = { spawnPokemon };
