const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const root = process.cwd();
const entry = path.join(root, 'index.js');
const sessions = path.join(root, 'sessions');
if (!fs.existsSync(entry)) {
  console.error(`[STARTUP] Missing ${entry}; refusing to pair or create a replacement session.`);
  process.exit(1);
}
if (!fs.existsSync(sessions)) fs.mkdirSync(sessions, { recursive: true });
console.log(`[STARTUP] Using ${entry}; preserving auth at ${sessions}`);
const install = spawnSync('/usr/local/bin/npm', ['install', '--omit=dev', '--no-audit', '--no-fund'], { cwd: root, stdio: 'inherit', env: process.env });
if (install.status !== 0) process.exit(install.status || 1);
const bot = spawnSync('/usr/local/bin/node', [entry], { cwd: root, stdio: 'inherit', env: process.env });
process.exit(bot.status || 0);
