// database/index.js
const mongoose = require('mongoose');

let isConnected = false;

async function connectDB() {
  if (isConnected) return true;
  try {
    // Mongoose 6+ and 8+ don't need these deprecated options
    await mongoose.connect(process.env.MONGO_URI);
    isConnected = true;
    console.log('✅ Connected to MongoDB');
    return true;
  } catch (err) {
    console.error('❌ MongoDB connection error:', err.message);
    process.exit(1);
  }
}

module.exports = { connectDB };
