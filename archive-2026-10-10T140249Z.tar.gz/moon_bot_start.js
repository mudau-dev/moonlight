// Compatibility entrypoint for panels whose preserved .env uses BOT_JS_FILE=moon_bot_start.js.
require('./index.js');
