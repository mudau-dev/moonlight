const mongoose = require('mongoose');

/**
 * GuildInvite — stores pending guild invitations sent via .ginvite.
 * Expires automatically after 48 hours.
 */
const GuildInviteSchema = new mongoose.Schema({
  guildId: { type: mongoose.Schema.Types.ObjectId, ref: 'Guild', required: true },
  guildName: { type: String, required: true },
  ownerId: { type: String, required: true },   // moonId / whatsappNumber of the guild owner
  ownerName: { type: String, default: 'Unknown' },
  targetId: { type: String, required: true },  // moonId / whatsappNumber of the invited user
  status: { type: String, enum: ['pending', 'accepted', 'declined', 'expired'], default: 'pending' },
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, default: () => new Date(Date.now() + 48 * 60 * 60 * 1000) },
});

// TTL index — MongoDB auto-deletes expired invites
GuildInviteSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('GuildInvite', GuildInviteSchema);
