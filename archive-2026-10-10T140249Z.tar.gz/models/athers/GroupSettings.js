const fs = require('fs');
const path = require('path');

const filePath = path.join(process.cwd(), 'database', 'group.json');
let groupCache = null;
let lastLoadTime = 0;
const CACHE_TTL = 30000;

function ensureFile() {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, JSON.stringify({}, null, 2));
}

function loadData() {
  const now = Date.now();
  if (groupCache && now - lastLoadTime < CACHE_TTL) return groupCache;
  ensureFile();
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    groupCache = raw.trim() ? JSON.parse(raw) : {};
    lastLoadTime = now;
    return groupCache;
  } catch (error) {
    console.error('Load error:', error);
    return groupCache || {};
  }
}

function saveData(data) {
  ensureFile();
  groupCache = data;
  lastLoadTime = Date.now();
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

function defaultGroup() {
  return {
    welcomeEnabled: false,
    welcomeMessage: '👋 Welcome @user to *@gname* you are the *@count member* .use `.menu` to start the fun',
    leaveEnabled: false,
    leaveMessage: '👋 @user left our group what a shame. @count left',
    antilink: { enabled: false, action: 'warn', warnLimit: 3, warns: {} },
    antimention: { enabled: false, notify: true, logs: [] },
    antibot: { enabled: false, action: 'delete' },
    spm: { locked: false, windowMs: 2000, linkLimit: 2 },
    akickEnabled: false,
    botEnabled: true,
    gstatus: { enabled: false, deleteMsg: false, warnEnabled: false, warnLimit: 3, warns: {} },
    antigpro: { enabled: false, action: 'warn', warnLimit: 3, warns: {} },
  };
}

function getGroup(groupId) {
  const data = loadData();
  const defaults = defaultGroup();
  let changed = false;
  if (!data[groupId]) {
    data[groupId] = defaults;
    changed = true;
  }
  const group = data[groupId];

  for (const key of ['welcomeEnabled', 'leaveEnabled', 'welcomeMessage', 'leaveMessage', 'akickEnabled', 'botEnabled']) {
    if (group[key] === undefined || group[key] === null) {
      group[key] = defaults[key];
      changed = true;
    }
  }

  for (const key of ['antilink', 'antimention', 'antibot', 'gstatus', 'antigpro', 'spm']) {
    const previous = group[key] || {};
    const next = { ...defaults[key], ...previous };
    if (Object.keys(defaults[key]).some((property) => previous[property] === undefined || previous[property] === null)) changed = true;
    group[key] = next;
  }

  if (changed) saveData(data);
  return group;
}

function updateGroup(groupId, updates) {
  const data = loadData();
  if (!data[groupId]) data[groupId] = defaultGroup();
  data[groupId] = { ...data[groupId], ...updates };
  saveData(data);
  return data[groupId];
}

function updateAntilink(groupId, updates) {
  const group = getGroup(groupId);
  return updateGroup(groupId, { antilink: { ...group.antilink, ...updates } }).antilink;
}

function updateAntimention(groupId, updates) {
  const group = getGroup(groupId);
  return updateGroup(groupId, { antimention: { ...group.antimention, ...updates } }).antimention;
}

function updateGstatus(groupId, updates) {
  const group = getGroup(groupId);
  return updateGroup(groupId, { gstatus: { ...group.gstatus, ...updates } }).gstatus;
}

function updateAntibot(groupId, updates) {
  const group = getGroup(groupId);
  return updateGroup(groupId, { antibot: { ...group.antibot, ...updates } }).antibot;
}

async function handleGroupEvents(sock, data) {
  try {
    const { id, participants, action } = data;
    const group = getGroup(id);
    const metadata = await sock.groupMetadata(id);
    const { findOrCreateWhatsApp } = require('../../database/users');

    for (const userJid of participants) {
      const isWelcome = action === 'add' && group.welcomeEnabled;
      const isLeave = action === 'remove' && group.leaveEnabled;
      if (!isWelcome && !isLeave) continue;

      let displayName = userJid.split('@')[0];
      try {
        const dbUser = await findOrCreateWhatsApp(userJid);
        if (dbUser?.username && dbUser.username !== 'Unknown') displayName = dbUser.username;
      } catch {}

      let text = isWelcome ? group.welcomeMessage : group.leaveMessage;
      const useProfile = text.includes('@p');
      text = text
        .replace(/@user/g, displayName)
        .replace(/@gname/g, metadata.subject)
        .replace(/@count/g, metadata.participants.length)
        .replace(/@p/g, '')
        .trim();

      let pp = null;
      if (useProfile) {
        try { pp = await sock.profilePictureUrl(userJid, 'image'); } catch {}
      }
      const payload = { mentions: [userJid] };
      if (pp) await sock.sendMessage(id, { image: { url: pp }, caption: text, ...payload });
      else await sock.sendMessage(id, { text, ...payload });
    }
  } catch (error) {
    console.error('Group event error:', error);
  }
}

module.exports = {
  getGroup,
  updateGroup,
  loadData,
  handleGroupEvents,
  updateAntilink,
  updateAntimention,
  updateAntibot,
  updateGstatus,
};
