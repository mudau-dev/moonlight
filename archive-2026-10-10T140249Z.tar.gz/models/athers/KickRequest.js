const mongoose = require('mongoose');

const kickResultSchema = new mongoose.Schema({
  botName: { type: String, required: true },
  status: { type: String, enum: ['processing', 'success', 'permission_denied', 'failed'], default: 'processing' },
  details: [{
    communityJid: String,
    groupJid: String,
    scope: { type: String, enum: ['community', 'group'] },
    status: { type: String, enum: ['removed', 'absent', 'permission_denied', 'failed'] },
    error: String,
    groupName: String,
  }],
  completedAt: Date,
}, { _id: false });

const kickRequestSchema = new mongoose.Schema({
  // activeKey is present only while an action is being processed. The partial
  // unique index makes duplicate target actions safe across all bot processes.
  activeKey: { type: String, default: null },
  targetJid: { type: String, required: true },
  requesterJid: { type: String, required: true },
  responseJid: { type: String, required: true },
  progressKey: { type: mongoose.Schema.Types.Mixed, default: null },
  progressBotName: { type: String, default: null },
  communities: { type: [String], required: true },
  status: { type: String, enum: ['pending', 'processing', 'completed', 'failed'], default: 'pending' },
  results: { type: [kickResultSchema], default: [] },
  evaluationAt: { type: Date, required: true },
  completedAt: Date,
  createdAt: { type: Date, default: Date.now, expires: 86400 },
});

kickRequestSchema.index(
  { activeKey: 1 },
  { unique: true, partialFilterExpression: { activeKey: { $type: 'string' } } }
);
kickRequestSchema.index({ status: 1, evaluationAt: 1 });

module.exports = mongoose.models.KickRequest || mongoose.model('KickRequest', kickRequestSchema);
