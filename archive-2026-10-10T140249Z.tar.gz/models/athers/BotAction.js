const mongoose = require('mongoose');

const botActionSchema = new mongoose.Schema({
  botName: { type: String, required: true, index: true },
  action: { type: String, enum: ['leave'], required: true },
  groupId: { type: String, required: true },
  requestedBy: { type: String, default: '' },
  status: { type: String, enum: ['pending', 'done', 'failed'], default: 'pending', index: true },
  createdAt: { type: Date, default: Date.now },
  completedAt: { type: Date, default: null },
});

module.exports = mongoose.model('BotAction', botActionSchema);
