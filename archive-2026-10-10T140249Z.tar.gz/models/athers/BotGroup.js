const mongoose = require('mongoose');

const botGroupSchema = new mongoose.Schema({
  botName: { type: String, required: true, index: true },
  groupId: { type: String, required: true },
  subject: { type: String, default: 'Unknown' },
  participantCount: { type: Number, default: 0 },
  isAdmin: { type: Boolean, default: false },
  isCommunity: { type: Boolean, default: false },
  isCommunityAnnounce: { type: Boolean, default: false },
  admins: { type: [String], default: [] },
  communityId: { type: String, default: null, index: true },
  members: { type: [String], default: [] },
  lastSeen: { type: Date, default: Date.now },
}, { timestamps: true });

botGroupSchema.index({ botName: 1, groupId: 1 }, { unique: true });
botGroupSchema.index({ lastSeen: 1 });

module.exports = mongoose.model('BotGroup', botGroupSchema);
