const mongoose = require("mongoose");

const JoinRequestSchema = new mongoose.Schema({
  userId:      { type: String, required: true },
  username:    { type: String, default: 'Unknown' },
  requestedAt: { type: Date, default: Date.now },
}, { _id: false });

const guildSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  ownerId: {
    type: String,
    required: true
  },
  members: {
    type: [String],
    default: [],
    validate: { validator: value => value.length <= 25, message: 'Guilds cannot exceed 25 members.' }
  },
  guards: {
    type: [String],
    default: []
  },
  banned: {
    type: [String],
    default: []
  },
  description: {
    type: String,
    default: "No description has been set."
  },
  descriptions: {
    type: [String],
    default: []
  },
  icon: {
    type: String,
    default: null
  },
  background: {
    type: String,
    default: null
  },
  color: {
    type: String,
    default: '#7c3aed'
  },
  xp:    { type: Number, default: 0 },
  level: { type: Number, default: 1 },
  maxMembers:        { type: Number,  min: 2, max: 25, default: 25 },
  allowMemberInvite: { type: Boolean, default: false },
  joinRequests: {
    type: [JoinRequestSchema],
    default: []
  },
}, {
  timestamps: true,
  strict: false,
  collection: 'guilds',
});

module.exports = mongoose.models?.Guild || mongoose.model("Guild", guildSchema);
