const mongoose = require('mongoose');

const GroupCategoryLockSchema = new mongoose.Schema({
  groupId: { type: String, required: true, index: true },
  category: { type: String, required: true, lowercase: true, trim: true },
  locked: { type: Boolean, default: false },
  lockedBy: { type: String, default: null },
}, { timestamps: true });

GroupCategoryLockSchema.index({ groupId: 1, category: 1 }, { unique: true });

module.exports = mongoose.models?.GroupCategoryLock || mongoose.model('GroupCategoryLock', GroupCategoryLockSchema);
