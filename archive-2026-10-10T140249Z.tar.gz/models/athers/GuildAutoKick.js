const mongoose = require('mongoose');

/**
 * GuildAutoKick — stores per-guild automatic kick settings.
 * Stored in the database so all bot instances share the same config.
 *
 * kickRoles: array of role codes to auto-kick
 *   1 = Citizens/Members (role: "User")
 *   2 = CDC
 *   3 = Moderators
 *   4 = Suspended users
 *
 * communityMode: if true, kick silently (no public message)
 * communityRoles: roles to kick in community mode
 */
const GuildAutoKickSchema = new mongoose.Schema({
  groupJid: { type: String, required: true, unique: true },
  kickRoles: { type: [Number], default: [] },        // e.g. [1, 2]
  communityMode: { type: Boolean, default: false },
  communityRoles: { type: [Number], default: [] },
  updatedAt: { type: Date, default: Date.now },
});

GuildAutoKickSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('GuildAutoKick', GuildAutoKickSchema);
