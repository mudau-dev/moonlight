const mongoose = require('mongoose');

const AnswerSchema = new mongoose.Schema({
  questionId: { type: String, required: true },
  question: { type: String, required: true },
  answer: { type: String, required: true },
}, { _id: false });

const StaffApplicationSchema = new mongoose.Schema({
  userId: { type: String, required: true, index: true },
  moonId: { type: String, required: true, index: true },
  username: { type: String, default: 'Unknown' },
  applicationType: { type: String, enum: ['mod', 'tester'], required: true, index: true },
  answers: { type: [AnswerSchema], default: [] },
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending', index: true },
  submittedAt: { type: Date, default: Date.now },
  reviewedAt: { type: Date, default: null },
  reviewedBy: { type: String, default: null },
}, { timestamps: true, collection: 'staff_applications' });

StaffApplicationSchema.index({ moonId: 1, applicationType: 1, status: 1 });

module.exports = mongoose.models.StaffApplication || mongoose.model('StaffApplication', StaffApplicationSchema);
