/**
 * models/PromoCode.js
 *
 * Database-backed promo codes.
 * All bot instances share the same codes from MongoDB.
 */

const mongoose = require('mongoose');

const PromoCodeSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, uppercase: true, trim: true },
  coins: { type: Number, required: true },
  maxMembers: { type: Number, required: true },
  claimed: { type: [String], default: [] }, // array of userId/moonId strings
  createdBy: { type: String, default: null },
  createdAt: { type: Date, default: Date.now },
  active: { type: Boolean, default: true },
});

module.exports = mongoose.model('PromoCode', PromoCodeSchema);
