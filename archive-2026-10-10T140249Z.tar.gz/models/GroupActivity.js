const mongoose = require('mongoose');

const groupActivitySchema = new mongoose.Schema({
  groupId: { type: String, required: true },
  bucketStart: { type: Date, required: true },
  userId: { type: String, required: true },
  count: { type: Number, default: 0 },
}, { timestamps: true });

groupActivitySchema.index({ groupId: 1, bucketStart: 1, userId: 1 }, { unique: true });

groupActivitySchema.statics.getSouthAfricaBucketStart = function getSouthAfricaBucketStart(value = Date.now()) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Africa/Johannesburg', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hour12: false,
  }).formatToParts(new Date(value));
  const data = Object.fromEntries(parts.filter((part) => part.type !== 'literal').map((part) => [part.type, part.value]));
  const hour = Number(data.hour) % 24;
  const localHour = hour >= 12 ? 12 : 0;
  // South Africa Standard Time is UTC+02:00 year-round.
  return new Date(Date.UTC(Number(data.year), Number(data.month) - 1, Number(data.day), localHour) - (2 * 60 * 60 * 1000));
};

// Backward-compatible name for any older in-memory callers during rolling deploys.
groupActivitySchema.statics.getSaudiBucketStart = groupActivitySchema.statics.getSouthAfricaBucketStart;

module.exports = mongoose.model('GroupActivity', groupActivitySchema);
