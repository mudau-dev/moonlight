const mongoose = require('mongoose');

const CombatantSchema = new mongoose.Schema({
  userId: { type: String, default: null },
  pokemonId: { type: String, default: null },
  name: { type: String, required: true },
  nickname: { type: String, default: null },
  level: { type: Number, default: 1 },
  sprite: { type: String, default: null },
  type1: { type: String, default: null },
  type2: { type: String, default: null },
  hp: { type: Number, default: 1 },
  maxHp: { type: Number, default: 1 },
  attack: { type: Number, default: 1 },
  defense: { type: Number, default: 1 },
  moves: { type: [String], default: [] },
  isWild: { type: Boolean, default: false },
}, { _id: false });

const WebBattleSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, index: true },
  type: { type: String, enum: ['wild', 'pvp'], required: true },
  status: { type: String, enum: ['pending', 'active', 'finished'], default: 'active' },
  groupJid: { type: String, default: null },
  guildId: { type: String, default: null },
  creatorId: { type: String, required: true },
  opponentId: { type: String, default: null },
  turnUserId: { type: String, default: null },
  players: { type: [CombatantSchema], default: [] },
  wild: { type: CombatantSchema, default: null },
  winnerId: { type: String, default: null },
  lastAction: { type: String, default: null },
  expiresAt: { type: Date, default: () => new Date(Date.now() + 30 * 60 * 1000), index: { expires: 0 } },
}, { timestamps: true, collection: 'webbattles' });

module.exports = mongoose.models.WebBattle || mongoose.model('WebBattle', WebBattleSchema);
