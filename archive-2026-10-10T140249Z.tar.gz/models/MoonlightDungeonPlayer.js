const mongoose = require('mongoose');

const LootSchema = new mongoose.Schema({
  id: { type: String, required: true },
  name: { type: String, required: true },
  rarity: { type: String, default: 'Common' },
  value: { type: Number, default: 0 },
  quantity: { type: Number, default: 1 },
  obtainedAt: { type: Date, default: Date.now },
}, { _id: false });

const MoonlightDungeonPlayerSchema = new mongoose.Schema({
  userId: { type: String, required: true, unique: true, index: true },
  username: { type: String, default: 'Unknown' },
  level: { type: Number, default: 1, min: 1 },
  levelCap: { type: Number, default: 10, min: 10 },
  xp: { type: Number, default: 0, min: 0 },
  xpToNext: { type: Number, default: 100, min: 1 },
  coins: { type: Number, default: 500, min: 0 },
  hp: { type: Number, default: 100, min: 0 },
  maxHp: { type: Number, default: 100, min: 1 },
  mana: { type: Number, default: 50, min: 0 },
  maxMana: { type: Number, default: 50, min: 1 },
  attack: { type: Number, default: 18, min: 1 },
  defense: { type: Number, default: 6, min: 0 },
  floor: { type: Number, default: 1, min: 1 },
  kills: { type: Number, default: 0, min: 0 },
  bossesDefeated: { type: Number, default: 0, min: 0 },
  deaths: { type: Number, default: 0, min: 0 },
  loot: { type: [LootSchema], default: [] },
  achievements: { type: [String], default: [] },
  hpCharms: { type: Number, default: 0, min: 0 },
  manaCharms: { type: Number, default: 0, min: 0 },
  extraLifeTotems: { type: Number, default: 0, min: 0 },
  lastWeeklyBossAt: { type: Date, default: null },
  weeklyBossWins: { type: Number, default: 0, min: 0 },
}, { timestamps: true, collection: 'moonlight_dungeon_players' });

module.exports = mongoose.models.MoonlightDungeonPlayer || mongoose.model('MoonlightDungeonPlayer', MoonlightDungeonPlayerSchema);
